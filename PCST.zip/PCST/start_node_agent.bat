@echo off
cd C:\Users\Pratham\Desktop\PCST
rem Start PCST Node Agent with gRPC
rem Usage: start_node_agent.bat <node_id> <master_port> <agent_port> [<heartbeat_interval_ms>]
rem Logs are preserved in node_agent.log
rem Script returns exit code from Maven process

rem Set default parameters
set NODE_ID=%1
set MASTER_PORT=%2
set AGENT_PORT=%3
set HEARTBEAT_INTERVAL=%4

rem Apply defaults if not provided
if "%NODE_ID%" == "" set NODE_ID=node-1
if "%MASTER_PORT%" == "" set MASTER_PORT=9090
if "%AGENT_PORT%" == "" set AGENT_PORT=9091
if "%HEARTBEAT_INTERVAL%" == "" set HEARTBEAT_INTERVAL=5000

rem Start node agent using exec-maven-plugin (this module uses exec, not spring-boot)
rem JVM -D properties must appear before the main class
mvn exec:java -pl pcst-node-agent "-Dgrpc.node.id=%NODE_ID%" "-Dgrpc.master.port=%MASTER_PORT%" "-Dgrpc.node.port=%AGENT_PORT%" "-Dgrpc.heartbeat.interval-ms=%HEARTBEAT_INTERVAL%" >node_agent.log 2>&1
set NODE_EXIT_CODE=%errorlevel%
if %NODE_EXIT_CODE% neq 0 (
    echo Node Agent startup failed with exit code %NODE_EXIT_CODE%
    echo Check node_agent.log for details.
)
exit /b %NODE_EXIT_CODE%