﻿# Omni Compute Engine (PCST)

Initial project foundation for the Omni Compute Engine / PCST distributed scheduler.

## Project Structure
- `pcst-master/`: Minimal Spring Boot Master application (Java 21)
- `pcst-node-agent/`: Minimal Plain Java Node Agent application (Java 21)
- `proto/`: Protobuf definition contracts (placeholder)
- `docs/`: Documentation (placeholder)
