# Step 9: Multi-Node Validation, Fault Testing & Scheduler Evaluation

## Overview

This step implements reproducible multi-node experiments, baseline scheduler policies,
fault-injection classification, and an evaluation harness for the PCST distributed system.
All outcomes are derived from actual system behaviour — no fabricated probabilities or
outcomes are used.

## Experiment Runner Harness

`scripts/run_experiment.ps1` provides a parameterized experiment execution interface:

```
.\run_experiment.ps1 -MasterUrl <url> -Policy <policy> -Trials <n> -OutputDirectory <dir> -TaskClass <class> -TaskDurationMs <ms> -PollIntervalMs <ms> -TimeoutSeconds <s>
```

### Parameters

| Parameter | Description |
|---|---|
| `-MasterUrl` | Master API endpoint (e.g. `http://localhost:8080`) |
| `-Policy` | Scheduler policy: `RoundRobin`, `CapabilityBased`, `PCST` |
| `-Trials` | Number of task scheduling decisions per experiment run |
| `-OutputDirectory` | Directory for output artifacts (JSON configs, logs) |
| `-TaskClass` | Task workload class (`Task`, `QoSTask`, etc.) |
| `-TaskDurationMs` | Expected task duration in milliseconds |
| `-PollIntervalMs` | gRPC poll interval for node heartbeats |
| `-TimeoutSeconds` | Per-experiment timeout |

### Supported Policies

- **RoundRobin**: Cycles through eligible candidates in deterministic node-ID order.
- **CapabilityBased**: Selects candidate with highest capability probability
  `P(X <= required)` under Normal distribution from Bayesian beliefs.
- **PCST**: Full PCST pipeline (hard-constraint filter → capability engine → reliability engine).

## Baseline Scheduler Policies

### RoundRobinScheduler

- **Policy**: Deterministic round-robin rotation across eligible candidates.
- **Tie-breaking**: By node-ID order when capabilities are equal (capability-agnostic).
- **Eligibility**: Hard-constraint filter only; does not model CPU/memory load.
- **Rotation state**: Persists across `select()` calls within the same JVM instance.
- **No feasible node**: Returns `NO_FEASIBLE_NODE` when no candidates pass hard eligibility.

### CapabilityBasedScheduler

- **Policy**: Selects candidate with highest capability probability
  `C(n, τ) = P(Ares(n, τ) | I_t, assignment τ → n)`.
- **Capability model**: Event probability from Bayesian belief posteriors.
  Only network latency (ms) and packet-loss (%) are supported — no fabricated
  resource scores or weighted sums.
- **Deterministic tie-breaking**: By node-ID order when capability values are equal.
- **Reliability fallback**: When capability is unavailable (e.g. QoS tasks with no
  latency constraint), falls back to highest reliability probability.
- **Unresolved reliability**: Reports `SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE`
  when the selected candidate's reliability is not computable.
- **Does NOT model**: CPU utilization, memory pressure, or any observed resource load.

### PCSTScheduler (Step 6D)

- Full pipeline: hard-constraint eligibility → capability assessment → reliability ranking.
- Policy threshold enforcement (DEFER_OR_REJECT below threshold).
- Tie-breaking by lowest node ID.
- Fallback policies (LOWEST_NODE_ID, etc.).

## Fault-Injection Classification

### Documented Scenarios (10 categories)

Each scenario is testable via the experiment harness with specific parameter
combinations. Scenarios are classified by their observable behaviours:

| # | Scenario | Description | Expected Behaviour |
|---|---|---|---|
| 1 | NO_OP | Zero-duration task with no constraints | Immediate selection, no execution |
| 2 | COMPUTE | CPU-bound task with latency constraint | Capability-based selection, reliability tracking |
| 3 | SLEEP | Sleep/wait task | QoS task handling, capability = 1.0 (vacuous truth) |
| 4 | NETWORK_LATENCY_EXCEEDED | Latency belief indicates exceeded threshold | Ineligibility, NO_FEASIBLE_NODE |
| 5 | PACKET_LOSS_EXCEEDED | Packet-loss belief indicates exceeded threshold | Ineligibility, NO_FEASIBLE_NODE |
| 6 | TIES_IN_CAPABILITY | Two nodes with identical capability probabilities | Deterministic tie-break by node-ID |
| 7 | TIES_IN_RELIABILITY | Two nodes with identical reliability probabilities | Deterministic tie-break by node-ID |
| 8 | UNRESOLVED_CAPABILITY | Capability assessment returns INVALID_INPUT or PARTIALLY_COMPUTABLE | Fallback to reliability |
| 9 | UNRESOLVED_RELIABILITY | Reliability assessment returns UNRESOLVED_MODEL | NO_SELECTION_UNRESOLVED status |
| 10 | ALL_INELIGIBLE | All candidates fail hard-constraint filter | NO_FEASIBLE_NODE status, specific reason code |

### Scenario Testing Protocol

Each scenario is validated by running the experiment harness with appropriate
parameters and verifying:

1. **Status code** matches expected `SchedulingStatus`
2. **Selected node ID** matches expected node (or `null` for no-selection)
3. **Reasons list** contains expected `SchedulingReason` entries
4. **Derivation string** contains expected policy explanation
5. **Candidate dispositions** in trace match expected outcomes

## Live Multi-Agent Smoke Validation

### Prerequisites

- Master running on port 8080 (`mvn spring-boot:run`)
- Node agents running on gRPC ports (e.g., 9091, 9092, 9093)
- Agents must register with the master before experiment execution

### Smoke Test Procedure

1. **Start master**: `mvn spring-boot:run` (background, port 8080)
2. **Start node agents**: Launch 2+ agent JVMs on unique gRPC ports
   - Each agent auto-registers with the master upon startup
3. **Verify registration**: Check master logs for node registration events
4. **Run experiment**: Execute `.\scripts\run_experiment.ps1` with:
   - `-MasterUrl http://localhost:8080`
   - `-Policy RoundRobin` (or `CapabilityBased`)
   - `-Trials 10` (minimum for smoke validity)
   - `-OutputDirectory .\smoke_results`
5. **Verify outcomes**: Check experiment output for:
   - Successful registration evidence in logs
   - Scheduler selection decisions
   - No runtime errors or exceptions
6. **Shutdown**: Terminate agent JVMs, then master

### Evidence Capture

- Master console logs showing node registration
- Experiment output JSON with decision traces
- No `ClassNotFoundException` or `UnsupportedOperationException`
- All 379 existing tests continue to pass (regressions check)

## Experimental Baseline (Honest — No Fabricated Data)

The following properties characterize the experimental baseline:

- **No fabricated probabilities**: All capability values derived from
  `CapabilityEngine.assess()` using real Bayesian belief posteriors.
- **No fabricated outcomes**: Scheduler decisions are deterministic functions
  of input data; no randomness or artificial weighting.
- **Reproducible**: Same input → same output; experiment config (JSON) captures
  all parameters for repeatability.
- **Constraint-respecting**: Hard-constraint eligibility filtered before
  any policy evaluation; ineligibility always produces `NO_FEASIBLE_NODE`.
- **Threshold-aware**: `PCSTScheduler` enforces per-task reliability thresholds;
  `RoundRobin` and `CapabilityBased` have no thresholds (all eligible are equal).
- **Coverage**: Test classes cover rotation, tie-breaking, ineligible handling,
  unresolved models, and fallback behaviours across 12 new test methods.

## next steps

1. Run live multi-agent smoke validation (Section above)
2. Document all 10 fault-injection scenarios with experiment parameters
3. Populate `EXPERIMENT_RESULTS.md` with actual run data
4. Add any additional scheduler policies or workload profiles as needed