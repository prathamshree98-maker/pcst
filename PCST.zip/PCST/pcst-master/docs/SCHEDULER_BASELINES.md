# Step 9: Scheduler Baseline Policies

## Overview

This document describes the baseline scheduler policies implemented for Step 9
multi-node validation. These policies serve as the scientific comparison base
for PCST scheduler evaluation. All policies are deterministic, policy-agnostic
(implementing the `Scheduler.select()` interface), and capable of being called
from separate JVM processes for multi-node experiments.

## Interface

All scheduler policies implement `com.omni.pcst.master.scheduler.Scheduler`:

```java
public interface Scheduler {
    SchedulingDecision select(Task task, long decisionTimeMillis,
                              Collection<SchedulingCandidate> candidates);
}
```

The method returns a `SchedulingDecision` containing:
- `selectedNodeId` - The chosen node, or `null`
- `selectedReliability` - Completion reliability probability, or `null`
- `status` - One of: `SELECTED`, `NO_FEASIBLE_NODE`, `NO_SELECTION_UNRESOLVED`
- `trace` - `List<CandidateDecision>` for every eligible candidate
- `reasons` - `List<SchedulingReason>` explaining the decision
- `derivation` - Human-readable explanation string

---

## RoundRobinScheduler

**File**: `pcst-master/src/main/java/.../scheduler/RoundRobinScheduler.java`

**Policy**: Deterministic round-robin rotation across eligible candidates.

### Behaviour

1. **Filter**: Candidates are filtered by hard-constraint eligibility
   (`SchedulingCandidate.eligible()`). Ineligible candidates are excluded.

2. **Empty set**: If no candidates pass eligibility →
   `SchedulingStatus.NO_FEASIBLE_NODE`, `selectedNodeId = null`.

3. **Deduplication**: Candidates are deduplicated by node ID, preserving
   first-occurrence order from the input collection.

4. **Rotation state**: On first `select()` call, the ordered list of unique
   eligible node IDs is stored and used for all subsequent calls.

5. **Selection**: The next node in the rotation is selected, advancing the
   index. Index wraps around at the end of the list.

6. **Tie-breaking**: When the rotation index points to a position, the node
   at that position in sorted node-ID order is selected. This ensures
   deterministic behaviour when capabilities are equal (the common case for
   this capability-agnostic policy).

7. **Trace**: Every eligible candidate receives a `CandidateDecision` with
   disposition `SELECTED` (if matching the chosen node) or
   `LOWER_RELIABILITY` (if not). Reliability status and capability values
   are reported as computed by the upstream engines.

8. **Reasons**: Always includes
   `SELECTED_HIGHEST_RELIABILITY` and
   `NO_POLICY_THRESHOLD_CONFIGURED`. The derivation notes that the policy
   does not rank by reliability.

### Key Properties

| Property | Value |
|---|---|
| Policy type | Deterministic rotation |
| Capability modelling | None (capability-agnostic) |
| Reliability modelling | None (all eligible are equal) |
| Hard-constraint filtering | Yes |
| Deterministic tie-breaking | By node-ID order |
| Rotation persistence | Within single JVM instance |
| No feasible node | When eligible set is empty |
| Max candidates | Unlimited (filtered by eligibility) |

### Example Decision

```
selectedNodeId: "node-b"
selectedReliability: 0.841 (or null)
status: SELECTED
derivation: "selected node node-b via round-robin rotation
  (policy does not rank by reliability; all eligible candidates are equally valid)"
trace size: 3 (if 3 eligible candidates)
reasons: [SELECTED_HIGHEST_RELIABILITY, NO_POLICY_THRESHOLD_CONFIGURED]
```

### Test Coverage

All RoundRobinScheduler behaviours are verified by `RoundRobinSchedulerTest`
(7 tests, all passing):
- Rotation across eligible nodes
- Ineligible candidates never selected
- Entirely ineligible set produces no selection
- Persistent instance preserves rotation
- Changes to eligible node set handled deterministically
- Tie-breaking by node-ID order
- No feasible node when all ineligible

---

## CapabilityBasedScheduler

**File**: `pcst-master/src/main/java/.../scheduler/CapabilityBasedScheduler.java`

**Policy**: Selects the candidate node with the highest observed capability
probability, as a baseline for scientific comparison with PCST.

### Behaviour

1. **Filter**: Candidates are filtered by hard-constraint eligibility
   (`SchedulingCandidate.eligible()`). Ineligible candidates are excluded.

2. **Empty set**: If no candidates pass eligibility →
   `SchedulingStatus.NO_FEASIBLE_NODE`, `selectedNodeId = null`,
   reason `NO_CANDIDATE_PASSED_HARD_ELIGIBILITY`.

3. **Capability assessment**: For each eligible candidate, the
   `CapabilityEngine.assess(task, snapshot, decisionTimeMillis)` method
   computes capability probability `C(n, τ) = P(Ares(n, τ) | I_t, assignment τ → n)`.
   - Only network latency (ms) and packet-loss (%) are supported
   - Capability is an event probability from the Bayesian belief posterior
   - No weighted resource scores or fabricated coefficients

4. **Find best**: The candidate with the highest capability probability is selected.
   - Deterministic tie-breaking: If multiple candidates share the same best
     capability value, the first by node-ID order is selected.
   - If capability is null for all candidates (e.g. unsupported model,
     insufficient evidence), fall back to reliability-based selection.

5. **Reliability fallback**: When capability is unavailable for all eligible
   candidates, select the candidate with the highest reliability probability.
   - `SchedulingStatus.SELECTED` with `usedReliabilityFallback = true`
   - Reason: `SELECTED_HIGHEST_RELIABILITY` (fallback path)
   - Derivation mentions "fallback to highest reliability"

6. **Selected candidate reliability**: The reliability probability of the
   selected candidate is reported as `selectedReliability`.

7. **Trace**: Every eligible candidate receives a `CandidateDecision`:
   - `SELECTED` if matching the chosen node
   - `LOWER_RELIABILITY` if eligible but not selected
   - Reliability status (`COMPUTABLE`, `UNRESOLVED_MODEL`, etc.)
   - Capability probability and status
   - Capability reasons string

8. **Reasons**: Always includes `SELECTED_HIGHEST_RELIABILITY` and
   `NO_POLICY_THRESHOLD_CONFIGURED`. If reliability is unresolved for the
   selected candidate, `SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE`
   is also included.

9. **Derivation**: Reports the selection reason:
   - Capability path: `"selected node X via capability-based policy
     (best capability probability = Y; selected node reliability = Z)"`
   - Fallback path: `"selected node X via capability-based policy
     (fallback to highest reliability; capability not available for any
     eligible candidate)"`

### Key Properties

| Property | Value |
|---|---|
| Policy type | Capability-based selection |
| Capability modelling | Bayesian posterior event probability |
| Reliability modelling | Yes (fallback when capability unavailable) |
| Hard-constraint filtering | Yes |
| Deterministic tie-breaking | By node-ID order |
| Capability model | P(X <= required) under Normal(mean, variance) |
| Unsupported requirements | Memory, storage, accelerator, compute — reported as unsupported |
| Fallback path | Reliability when capability unavailable |
| No feasible node | When eligible set is empty |
| Unresolved reporting | `UNRESOLVED_MODEL`, `INVALID_INPUT`, `INSUFFICIENT_EVIDENCE` |

### Example Decision (Capability Path)

```
selectedNodeId: "node-b"
selectedReliability: 0.977
status: SELECTED
derivation: "selected node node-b via capability-based policy
  (best capability probability = 0.977; selected node reliability = 0.92)"
trace size: 2 (if 2 eligible candidates)
reasons: [SELECTED_HIGHEST_RELIABILITY, NO_POLICY_THRESHOLD_CONFIGURED]
  + possibly SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE
```

### Example Decision (Fallback Path)

```
selectedNodeId: "node-a"
selectedReliability: 0.892
status: SELECTED
derivation: "selected node node-a via capability-based policy
  (fallback to highest reliability; capability not available for any
  eligible candidate)"
trace size: 2
reasons: [SELECTED_HIGHEST_RELIABILITY, NO_POLICY_THRESHOLD_CONFIGURED]
  + SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE
```

### Test Coverage

All CapabilityBasedScheduler behaviours are verified by
`CapabilityBasedSchedulerTest` (5 tests, all passing):
- Highest capability selected (with correct expectation for capability ordering)
- Equal capabilities use deterministic tie-break by node-ID
- Decision trace accurately explains selection (mentions "best capability probability")
- Reliability fallback when capability unavailable (QoS task handling)
- Unresolved reliability never silenced as zero or one

---

## PCSTScheduler (Step 6D Reference)

**File**: `pcst-master/src/main/java/.../scheduler/PCSTScheduler.java`

**Policy**: Full PCST pipeline implementing Steps 6A-6D.

### Behaviour Summary

1. **Step 6A**: Hard-constraint filter (`HardConstraintFilter`) — eligibility
   determination with reason codes.

2. **Step 6B**: Capability engine (`CapabilityEngine`) — computes capability
   assessment with status and probability.

3. **Step 6C**: Reliability engine (`ReliabilityEngine`) — computes completion
   reliability probability.

4. **Step 6D**: Policy engine (`PCSTScheduler`) — coordinates the pipeline:
   - Eligibility → Capability → Reliability → Policy decision
   - Per-task threshold enforcement (DEFER_OR_REJECT below threshold)
   - Tie-breaking by lowest node ID
   - Fallback policies (LOWEST_NODE_ID, etc.)

5. **Key differences from baseline policies**:
   - Policy threshold configuration possible
   - Explicit DEFER_OR_REJECT when below threshold
   - Three-status outcome space: SELECTED, DEFER_OR_REJECT, NO_SELECTION_UNRESOLVED
   - More complex decision trace with per-candidate dispositions

---

## Comparison Summary

| Feature | RoundRobin | CapabilityBased | PCST |
|---|---|---|---|
| **Implementation complexity** | Low (rotation logic only) | Medium (Bayesian capability) | High (full pipeline) |
| **Capability modelling** | None | Bayesian posterior event probability | Bayesian + requirement aggregation |
| **Reliability modelling** | None | Fallback-capable | Full computation + ranking |
| **Policy threshold** | None | None | Configurable per-task |
| **Decision space** | SELECTED / NO_FEASIBLE_NODE | SELECTED / NO_FEASIBLE_NODE | SELECTED / DEFER_OR_REJECT / NO_SELECTION_UNRESOLVED |
| **Tie-breaking** | Node-ID order | Node-ID order | Node-ID order |
| **Unresolved handling** | N/A | Report reason code | Report reason + status |
| **Test coverage** | 7 tests | 5 tests | Existing Step 6D tests |
| **Use case** | Baseline rotation comparison | Capability probability comparison | Full scientific PCST evaluation |
| **Dependencies** | Scheduler interface only | CapabilityEngine, ReliabilityEngine | Full model stack |

## Running the Baselines in Experiment Harness

All three policies can be invoked via `scripts/run_experiment.ps1`:

```
# RoundRobin
.\run_experiment.ps1 -MasterUrl http://localhost:8080 -Policy RoundRobin \
  -Trials 10 -OutputDirectory .\rr_results -TaskClass Task -TaskDurationMs 60000

# CapabilityBased
.\run_experiment.ps1 -MasterUrl http://localhost:8080 -Policy CapabilityBased \
  -Trials 10 -OutputDirectory .\cb_results -TaskClass Task -TaskDurationMs 60000

# PCST
.\run_experiment.ps1 -MasterUrl http://localhost:8080 -Policy PCST \
  -Trials 10 -OutputDirectory .\pcst_results -TaskClass Task -TaskDurationMs 60000
```

The experiment runner captures the scheduler decision traces, reasons, and
derivation strings for analysis and verification against the documented
behaviours above.