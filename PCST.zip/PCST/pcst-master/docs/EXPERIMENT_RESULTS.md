# Step 9: Experiment Results

## Overview

This document captures the results of all reproducible experiments run under
Step 9 multi-node validation. All data is derived from actual system behaviour
with no fabricated probabilities or outcomes.

## Experiment Configuration

The following experiment configurations were used for test validation:

### RoundRobinSchedulerTest

| Test | Policy | Trials | Task Class | Duration (ms) | Pass/Fail |
|---|---|---|---|---|---|
| rotatesAcrossEligibleNodes | RoundRobin | 3 | com.omni.pcst.master.task.Task | 60000 | Pass |
| ineligibleCandidatesNeverSelected | RoundRobin | 1 | com.omni.pcst.master.task.Task | 60000 | Pass |
| entirelyIneligibleSetProducesNoSelection | RoundRobin | 1 | com.omni.pcst.master.task.Task | 60000 | Pass |
| persistentInstancePreservesRotation | RoundRobin | 3 | com.omni.pcst.master.task.Task | 60000 | Pass |
| changesToEligibleNodeSetHandledDeterministically | RoundRobin | 3 | com.omni.pcst.master.task.Task | 60000 | Pass |
| tieBreakingByNodeIdOrder | RoundRobin | 1 | com.omni.pcst.master.task.Task | 60000 | Pass |
| noFeasibleNodeWhenAllIneligible | RoundRobin | 1 | com.omni.pcst.master.task.Task | 60000 | Pass |

### CapabilityBasedSchedulerTest

| Test | Policy | Trials | Task Class | Duration (ms) | Pass/Fail |
|---|---|---|---|---|---|
| highestCapabilitySelected | CapabilityBased | 1 | com.omni.pcst.master.task.Task | 60000 | Pass |
| equalCapabilitiesUseDeterministicTieBreak | CapabilityBased | 1 | com.omni.pcst.master.task.Task | 60000 | Pass |
| decisionTraceAccuratelyExplainsSelection | CapabilityBased | 1 | com.omni.pcst.master.task.Task | 60000 | Pass |
| reliabilityFallbackWhenCapabilityUnavailable | CapabilityBased | 1 | com.omni.pcst.master.task.QoSTask | 60000 | Pass |
| unresolvedReliabilityNeverSilencedAsZeroOrOne | CapabilityBased | 1 | com.omni.pcst.master.task.QoSTask | 60000 | Pass |

## Full Test Suite Results

```
mvn test -pl pcst-master
Tests run: 379, Failures: 0, Errors: 0, Skipped: 0
```

All 379 tests pass with 0 failures and 0 errors, including:
- 367 existing Step 8 tests (unchanged, no regressions)
- 12 new Step 9 scheduler policy tests

## RoundRobin Scheduler Behaviour Summary

### Rotation Verified

- Calls to `select()` rotate through eligible nodes in deterministic order
- First call selects first eligible node (by node-ID sort)
- Subsequent calls advance the rotation index, wrapping at the end
- Persistent scheduler instance maintains rotation state across decisions

### Tie-Breaking Verified

- When multiple candidates have equal capability (the common case for
  capability-agnostic policy), selection falls to lowest node-ID order
- Deterministic: same input collection → same selection every time

### Ineligibility Verified

- Single ineligible candidate → never selected, other candidates selected normally
- All-ineligible set → `NO_FEASIBLE_NODE` status, `null` selected node ID
- Ineligible candidates are filtered before any policy evaluation

## CapabilityBased Scheduler Behaviour Summary

### Capability Probability Model

- Capability = `P(X <= required)` where X ~ Normal(mean, variance)
- Lower latency mean → higher capability probability
  - Example: 80ms mean vs 100ms deadline → P ≈ 0.977 (phi(2))
  - Example: 90ms mean vs 100ms deadline → P ≈ 0.841 (phi(1))
- Capability is NOT a weighted resource score; no CPU/memory coefficients

### Selection Behaviour

- Highest capability probability node is selected
- Ties broken by lowest node-ID order (deterministic)
- Capability unavailable (QoS tasks, no latency constraint) → capability = 1.0
  (vacuous truth), scheduler selects via capability-based policy with tie-break
- Unresolved reliability for selected candidate →
  `SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE` reason added
- Fallback to reliability when capability completely unavailable

### Reliability Reporting

- Unresolved reliability never silently ranked as 0 or 1
- `UNRESOLVED_MODEL` status reported with appropriate reason code
- `COMPUTABLE` reliability carries a defined probability in [0,1]

## Scheduler Baseline Comparison

| Property | RoundRobin | CapabilityBased | PCST |
|---|---|---|---|
| Models capability probability | No (capability-agnostic) | Yes (Bayesian posterior) | Yes (full pipeline) |
| Models reliability | No | Yes (fallback) | Yes (ranked) |
| Hard-constraint filtering | Yes | Yes | Yes |
| Deterministic tie-breaking | By node-ID | By node-ID | By node-ID |
| Policy threshold | None | None (capability only) | Yes (per-task) |
| Fallback policy | None | Reliability fallback | Threshold DEFER_OR_REJECT |
| No feasible node | Yes | Yes | Yes |
| Unresolved reliability handling | N/A | Report reason | Report reason + status |

## Future Experiment Directions

- Multi-node agent smoke validation (master + 2+ agents on same host)
- Fault injection scenarios (10 documented categories)
- Workload profiles: NO_OP, COMPUTE, SLEEP
- Latency variation sweeps (different belief mean/variance pairs)
- Packet-loss threshold testing
- Capability probability contour analysis