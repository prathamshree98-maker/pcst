package com.omni.pcst.master.execution;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskClass;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import javax.sql.DataSource;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for {@link JdbcTaskRegistry} against an isolated, disposable
 * PostgreSQL database provided by TestContainers. Exercises the full
 * {@link TaskRegistry} contract: create, update (optimistic locking),
 * get, list, size, remove, tasksInState, and duplicate-task rejection.
 */
@Testcontainers
class JdbcTaskRegistryTest {

    @Container
    static final PostgreSQLContainer<?> POSTGRESQL =
            new PostgreSQLContainer<>("postgres:15-alpine");

    private DataSource dataSource;
    private JdbcTemplate jdbc;
    private JdbcTaskRegistry registry;

    @BeforeEach
    void setUp() {
        dataSource = new DriverManagerDataSource(
                POSTGRESQL.getJdbcUrl(),
                POSTGRESQL.getUsername(),
                POSTGRESQL.getPassword());
        jdbc = new JdbcTemplate(dataSource);

        String sql = readMigrationSql();
        for (String statement : splitStatements(sql)) {
            if (!statement.isBlank()) {
                jdbc.execute(statement);
            }
        }

        JdbcTaskRepository repository = new JdbcTaskRepository(jdbc, new ObjectMapper());
        registry = new JdbcTaskRegistry(repository);
    }

    @AfterEach
    void tearDown() {
        jdbc.execute("DROP TABLE IF EXISTS task_records CASCADE");
    }

    // ------------------------------------------------------------------ helpers

    private static String readMigrationSql() {
        try {
            Path migration = Path.of(
                    "src/main/resources/db/migration/V1__create_task_records.sql");
            return Files.readString(migration);
        } catch (Exception e) {
            throw new IllegalStateException("Cannot read migration SQL", e);
        }
    }

    private static List<String> splitStatements(String sql) {
        return List.of(sql.split(";\\s*"));
    }

    private static TaskRecord acceptedRecord(String taskId, String attemptId) {
        Task task = Task.builder(taskId)
                .taskClass(TaskClass.UNSPECIFIED)
                .workloadReference("NO_OP")
                .inputCharacteristics("")
                .resources(TaskResources.NONE)
                .constraints(TaskConstraints.NONE)
                .build();
        return TaskRecord.createAccepted(task, attemptId, 1_700_000_000_000L);
    }

    // ------------------------------------------------------------------ create / get

    @Test
    void createThenGetReturnsSameRecord() {
        TaskRecord created = registry.create(acceptedRecord("task-1", "attempt-1").task(), 1_700_000_000_000L);

        Optional<TaskRecord> found = registry.get("task-1");
        assertTrue(found.isPresent());
        assertEquals("task-1", found.get().taskId());
        assertEquals("attempt-1", found.get().attemptId());
        assertEquals(com.omni.pcst.master.execution.TaskState.ACCEPTED, found.get().state());
        assertEquals(created.attemptId(), found.get().attemptId());
    }

    @Test
    void getMissingReturnsEmpty() {
        assertTrue(registry.get("does-not-exist").isEmpty());
    }

    @Test
    void duplicateCreateIsRejected() {
        registry.create(acceptedRecord("task-dup", "attempt-1").task(), 1_700_000_000_000L);

        assertThrows(IllegalArgumentException.class, () ->
                registry.create(acceptedRecord("task-dup", "attempt-2").task(), 1_700_000_000_000L));
    }

    // ------------------------------------------------------------------ update

    @Test
    void updateTransitionsStateAndReturnsUpdatedRecord() {
        registry.create(acceptedRecord("task-1", "attempt-1").task(), 1_700_000_000_000L);

        Optional<TaskRecord> updated = registry.update("task-1", r ->
                r.transitionTo(com.omni.pcst.master.execution.TaskState.DISPATCHING, 2_000_000_000_000L, null));

        assertTrue(updated.isPresent());
        assertEquals(com.omni.pcst.master.execution.TaskState.DISPATCHING, updated.get().state());
        assertEquals(2_000_000_000_000L, updated.get().updatedAt());

        Optional<TaskRecord> found = registry.get("task-1");
        assertTrue(found.isPresent());
        assertEquals(com.omni.pcst.master.execution.TaskState.DISPATCHING, found.get().state());
    }

    @Test
    void updateMissingTaskReturnsEmpty() {
        Optional<TaskRecord> updated = registry.update("does-not-exist", r -> r);
        assertTrue(updated.isEmpty());
    }

    @Test
    void updateWithNoChangeReturnsCurrent() {
        registry.create(acceptedRecord("task-1", "attempt-1").task(), 1_700_000_000_000L);

        Optional<TaskRecord> updated = registry.update("task-1", r -> r);
        assertTrue(updated.isPresent());
        assertEquals(com.omni.pcst.master.execution.TaskState.ACCEPTED, updated.get().state());
    }

    // ------------------------------------------------------------------ list / size / remove

    @Test
    void allReturnsInsertedRecords() {
        registry.create(acceptedRecord("task-a", "attempt-a").task(), 1_700_000_000_000L);
        registry.create(acceptedRecord("task-b", "attempt-b").task(), 1_700_000_000_000L);

        Collection<TaskRecord> all = registry.all();
        assertEquals(2, all.size());
    }

    @Test
    void sizeReflectsRecordCount() {
        assertEquals(0, registry.size());
        registry.create(acceptedRecord("task-a", "attempt-a").task(), 1_700_000_000_000L);
        assertEquals(1, registry.size());
    }

    @Test
    void removeDeletesRecord() {
        registry.create(acceptedRecord("task-del", "attempt-del").task(), 1_700_000_000_000L);
        assertTrue(registry.get("task-del").isPresent());

        registry.remove("task-del");
        assertTrue(registry.get("task-del").isEmpty());
    }

    // ------------------------------------------------------------------ tasksInState

    @Test
    void tasksInStateFiltersByState() {
        registry.create(acceptedRecord("task-a", "attempt-a").task(), 1_700_000_000_000L);
        registry.create(acceptedRecord("task-b", "attempt-b").task(), 1_700_000_000_000L);

        List<TaskRecord> accepted = registry.tasksInState(com.omni.pcst.master.execution.TaskState.ACCEPTED);
        assertEquals(2, accepted.size());

        List<TaskRecord> succeeded = registry.tasksInState(com.omni.pcst.master.execution.TaskState.SUCCEEDED);
        assertTrue(succeeded.isEmpty());
    }

    // ------------------------------------------------------------------ optimistic concurrency

    @Test
    void concurrentUpdateConflictIsDetected() {
        registry.create(acceptedRecord("task-1", "attempt-1").task(), 1_700_000_000_000L);

        // First update succeeds.
        Optional<TaskRecord> first = registry.update("task-1", r ->
                r.transitionTo(com.omni.pcst.master.execution.TaskState.DISPATCHING, 2_000_000_000_000L, null));
        assertTrue(first.isPresent());
        assertEquals(com.omni.pcst.master.execution.TaskState.DISPATCHING, first.get().state());

        // A second update based on the stale pre-transition record should still
        // succeed because the registry re-reads the current state before applying.
        // The updader function receives the latest record, so there is no lost
        // update.
        Optional<TaskRecord> second = registry.update("task-1", r ->
                r.withDispatchAccepted(3_000_000_000_000L));
        assertTrue(second.isPresent());
        assertEquals(com.omni.pcst.master.execution.TaskState.DISPATCH_ACCEPTED, second.get().state());
    }
}
