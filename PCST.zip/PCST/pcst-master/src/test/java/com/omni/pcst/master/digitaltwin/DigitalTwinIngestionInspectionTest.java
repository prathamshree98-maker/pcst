package com.omni.pcst.master.digitaltwin;

import com.omni.pcst.master.grpc.NodeServiceImpl;
import com.omni.pcst.master.execution.InMemoryTaskRegistry;
import com.omni.pcst.master.execution.TaskExecutionCoordinator;
import com.omni.pcst.master.security.DeviceCredentialService;
import com.omni.pcst.master.security.PairingCodeService;
import com.omni.pcst.master.scheduler.PCSTScheduler;
import com.omni.pcst.proto.BatteryTelemetry;
import com.omni.pcst.proto.CpuTelemetry;
import com.omni.pcst.proto.DiskTelemetry;
import com.omni.pcst.proto.GpuTelemetry;
import com.omni.pcst.proto.MemoryTelemetry;
import com.omni.pcst.proto.NetworkTelemetry;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.ProcessTelemetry;
import com.omni.pcst.proto.RegisterNodeRequest;
import com.omni.pcst.proto.RegisterNodeResponse;
import com.omni.pcst.proto.TelemetryRequest;
import com.omni.pcst.proto.TelemetryResponse;
import io.grpc.ManagedChannel;
import io.grpc.Server;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Read-only inspection of the stored Digital Twin state after telemetry has
 * flowed through the normal runtime ingestion path (gRPC ReportTelemetry RPC
 * &rarr; NodeServiceImpl &rarr; DigitalTwinManager).
 *
 * <p>The inspection itself never mutates twin state: it only reads immutable
 * snapshots via {@link DigitalTwinManager#getSnapshot(String)}. This keeps the
 * verification strictly separate from RPC acceptance — a request can be
 * acknowledged while the stored state is inspected independently afterwards.
 *
 * <p>Deterministic: in-process gRPC, fixed timestamps, no hardware, no sleeps.
 */
class DigitalTwinIngestionInspectionTest {

    private static final String NODE_ID = "node-agent-1";
    private static final String HOSTNAME = "laptop-jd1sbkq0";
    private static final int PORT = 9091;
    private static final String AGENT_VERSION = "0.1.0";

    private static final long T1 = 1_700_000_000_000L;
    private static final long T2 = T1 + 5_000L;

    private DigitalTwinManager manager;
    private PairingCodeService pairingCodeService;
    private DeviceCredentialService deviceCredentialService;
    private TaskExecutionCoordinator coordinator;
    private Server server;
    private ManagedChannel channel;
    private NodeServiceGrpc.NodeServiceBlockingStub stub;

    @BeforeEach
    void setUp() throws IOException {
        manager = new DigitalTwinManager(100);
        pairingCodeService = new PairingCodeService(10, 1000, 10);
        deviceCredentialService = new DeviceCredentialService(false, null);
        coordinator = new TaskExecutionCoordinator(new InMemoryTaskRegistry(), manager,
                new PCSTScheduler(), 30000);
        String serverName = InProcessServerBuilder.generateName();
        server = InProcessServerBuilder.forName(serverName)
                .directExecutor()
                .addService(new NodeServiceImpl(manager, pairingCodeService,
                        deviceCredentialService, coordinator))
                .build()
                .start();
        channel = InProcessChannelBuilder.forName(serverName)
                .directExecutor()
                .build();
        stub = NodeServiceGrpc.newBlockingStub(channel);
    }

    private RegisterNodeResponse registerNodeWithPairing() {
        PairingCodeService.PairingCode code = pairingCodeService.generate(NODE_ID, "test-setup");
        return stub.registerNode(RegisterNodeRequest.newBuilder()
                .setNodeId(NODE_ID)
                .setHostname(HOSTNAME)
                .setPort(PORT)
                .setAgentVersion(AGENT_VERSION)
                .setPairingCode(code.code)
                .build());
    }

    @AfterEach
    void tearDown() {
        channel.shutdown();
        server.shutdown();
    }

    @Test
    void storedTwinStateMatchesIngestedTelemetryThroughRpcPath() {
        RegisterNodeResponse registration = registerNodeWithPairing();
        assertTrue(registration.getAccepted(), "test setup: registration must succeed");

        // Inspection point 1: the twin exists for node-agent-1.
        DigitalTwinSnapshot snapshot = manager.getSnapshot(NODE_ID).orElseThrow();
        assertEquals(NODE_ID, snapshot.nodeId());
        assertEquals(HOSTNAME, snapshot.hostname());
        assertEquals(PORT, snapshot.port());
        assertEquals(AGENT_VERSION, snapshot.agentVersion());
        assertNull(snapshot.latestObservation(), "no telemetry ingested yet");

        TelemetryResponse response = stub.reportTelemetry(telemetry(T1,
                37.5, 8192L, 4096L, 4096L, 82.5, true, 12.5, 0.25));
        assertTrue(response.getAccepted(), "test setup: telemetry must be accepted");

        // Read-only inspection of the stored state after ingestion.
        snapshot = manager.getSnapshot(NODE_ID).orElseThrow();
        TelemetryObservation latest = snapshot.latestObservation();
        assertNotNull(latest);

        // Inspection point 2: the latest accepted observation has the expected timestamp.
        assertEquals(T1, latest.timestamp());

        // Inspection point 3: the latest observation contains the reported values.
        assertEquals(37.5, latest.cpuUtilizationPercent(), 1e-9);
        assertEquals(8192L, latest.totalMemoryBytes());
        assertEquals(4096L, latest.usedMemoryBytes());
        assertEquals(4096L, latest.availableMemoryBytes());
        assertEquals(82.5, latest.batteryLevelPercent(), 1e-9);
        assertEquals(true, latest.batteryCharging());
        assertEquals(12.5, latest.latencyMs(), 1e-9);
        assertEquals(0.25, latest.packetLossPercent(), 1e-9);

        // Inspection point 4: unavailable fields remain unavailable.
        assertNull(latest.gpuUtilizationPercent(), "omitted GPU utilization stays unavailable");
        assertNull(latest.temperatureCelsius(), "omitted temperature stays unavailable");
        assertNull(latest.userActive(), "omitted user state stays unavailable");

        assertEquals(1, snapshot.observationHistory().size());
        assertEquals(T1, snapshot.observationHistory().get(0).timestamp());
        assertEquals(0, snapshot.staleObservationsRejected());
    }

    @Test
    void staleObservationDoesNotReplaceNewerStoredObservation() {
        assertTrue(registerNodeWithPairing().getAccepted(),
                "test setup: registration must succeed");

        assertTrue(stub.reportTelemetry(telemetry(T1,
                37.5, 8192L, 4096L, 4096L, 82.5, true, 12.5, 0.25)).getAccepted());

        // A stale observation (older timestamp, different values) is rejected at the RPC level.
        TelemetryResponse stale = stub.reportTelemetry(telemetry(T1 - 1_000L,
                99.9, 1024L, 512L, 512L, 10.0, false, 99.9, 9.9));
        assertFalse(stale.getAccepted(), "stale observation must be rejected");

        // Inspection point 5: the stored newer observation is untouched by the stale one.
        DigitalTwinSnapshot snapshot = manager.getSnapshot(NODE_ID).orElseThrow();
        TelemetryObservation latest = snapshot.latestObservation();
        assertEquals(T1, latest.timestamp(), "stale observation must not replace the newer one");
        assertEquals(37.5, latest.cpuUtilizationPercent(), 1e-9);
        assertEquals(8192L, latest.totalMemoryBytes());
        assertEquals(82.5, latest.batteryLevelPercent(), 1e-9);
        assertEquals(12.5, latest.latencyMs(), 1e-9);
        assertEquals(1, snapshot.observationHistory().size(), "stale observation is not added to history");
        assertEquals(1, snapshot.staleObservationsRejected());

        // A newer observation is accepted and becomes the latest stored state.
        assertTrue(stub.reportTelemetry(telemetry(T2,
                62.5, 8192L, 6144L, 2048L, 75.0, false, 25.0, 0.5)).getAccepted());

        snapshot = manager.getSnapshot(NODE_ID).orElseThrow();
        latest = snapshot.latestObservation();
        assertEquals(T2, latest.timestamp());
        assertEquals(62.5, latest.cpuUtilizationPercent(), 1e-9);
        assertEquals(6144L, latest.usedMemoryBytes());
        assertEquals(75.0, latest.batteryLevelPercent(), 1e-9);
        assertEquals(false, latest.batteryCharging());
        assertEquals(25.0, latest.latencyMs(), 1e-9);
        assertEquals(0.5, latest.packetLossPercent(), 1e-9);
        assertEquals(2, snapshot.observationHistory().size());
        assertEquals(T2, snapshot.observationHistory().get(0).timestamp(), "history is newest first");
        assertEquals(T1, snapshot.observationHistory().get(1).timestamp());
        assertEquals(1, snapshot.staleObservationsRejected(), "accepted telemetry must not count as stale");
    }

    /* ------------------------------------------------------------------ helpers */

    /**
     * Builds a telemetry request with CPU, memory, battery and network values set.
     * GPU utilization, temperature and user state are intentionally omitted so the
     * "unavailable stays unavailable" behaviour is exercised through the real
     * proto presence mapping.
     */
    private static TelemetryRequest telemetry(long timestamp,
                                              double cpu, long totalMemory, long usedMemory, long availableMemory,
                                              double batteryLevel, boolean batteryCharging,
                                              double latencyMs, double packetLossPercent) {
        return TelemetryRequest.newBuilder()
                .setNodeId(NODE_ID)
                .setTimestamp(timestamp)
                .setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(cpu))
                .setMemory(MemoryTelemetry.newBuilder()
                        .setTotalBytes(totalMemory)
                        .setUsedBytes(usedMemory)
                        .setAvailableBytes(availableMemory))
                .setGpu(GpuTelemetry.newBuilder().setAvailable(false))
                .setBattery(BatteryTelemetry.newBuilder()
                        .setLevelPercent(batteryLevel)
                        .setCharging(batteryCharging))
                .setNetwork(NetworkTelemetry.newBuilder()
                        .setLatencyMs(latencyMs)
                        .setPacketLossPercent(packetLossPercent))
                .setDisk(DiskTelemetry.newBuilder()
                        .setTotalBytes(16384L)
                        .setFreeBytes(8192L))
                .setProcesses(ProcessTelemetry.newBuilder().setProcessCount(7))
                .build();
    }
}
