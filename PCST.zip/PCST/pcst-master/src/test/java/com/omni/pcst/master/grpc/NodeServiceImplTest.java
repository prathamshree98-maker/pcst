package com.omni.pcst.master.grpc;

import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.execution.InMemoryTaskRegistry;
import com.omni.pcst.master.execution.TaskExecutionCoordinator;
import com.omni.pcst.master.security.DeviceCredentialService;
import com.omni.pcst.master.security.PairingCodeService;
import com.omni.pcst.master.scheduler.PCSTScheduler;
import com.omni.pcst.proto.CpuTelemetry;
import com.omni.pcst.proto.DiskTelemetry;
import com.omni.pcst.proto.HeartbeatRequest;
import com.omni.pcst.proto.HeartbeatResponse;
import com.omni.pcst.proto.MemoryTelemetry;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.ProcessTelemetry;
import com.omni.pcst.proto.RegisterNodeRequest;
import com.omni.pcst.proto.RegisterNodeResponse;
import com.omni.pcst.proto.TelemetryRequest;
import com.omni.pcst.proto.TelemetryResponse;
import io.grpc.ManagedChannel;
import io.grpc.Server;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for authenticated node registration:
 * pairing-code enrollment, device-credential reconnection, rejection of
 * uncredentialed registration, impersonation prevention, and revocation.
 */
class NodeServiceImplTest {

    private Server server;
    private ManagedChannel channel;
    private NodeServiceGrpc.NodeServiceBlockingStub blockingStub;
    private PairingCodeService pairingCodeService;
    private DeviceCredentialService deviceCredentialService;
    private TaskExecutionCoordinator coordinator;

    @BeforeEach
    void setUp() throws IOException {
        String serverName = InProcessServerBuilder.generateName();
        pairingCodeService = new PairingCodeService(10, 1000, 10);
        deviceCredentialService = new DeviceCredentialService(false, null);
        coordinator = new TaskExecutionCoordinator(new InMemoryTaskRegistry(), new DigitalTwinManager(100),
                new PCSTScheduler(), 30000);
        server = InProcessServerBuilder.forName(serverName)
                .directExecutor()
                .addService(new NodeServiceImpl(new DigitalTwinManager(100),
                        pairingCodeService, deviceCredentialService, coordinator))
                .build()
                .start();
        channel = InProcessChannelBuilder.forName(serverName)
                .directExecutor()
                .build();
        blockingStub = NodeServiceGrpc.newBlockingStub(channel);
    }

    @AfterEach
    void tearDown() {
        channel.shutdown();
        server.shutdown();
    }

    // ------------------------------------------------------------- pairing

    @Test
    void testRegistrationRequiresCredential() {
        RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                .setNodeId("test-node-1")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .build();

        RegisterNodeResponse response = blockingStub.registerNode(request);
        assertFalse(response.getAccepted(),
                "registration without any enrollment credential must be rejected");
        assertNotNull(response.getMessage());
    }

    @Test
    void testValidPairingCodeEnrollment() {
        PairingCodeService.PairingCode issued = pairingCodeService.generate("node-enroll-1", "test-client");

        RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                .setNodeId("node-enroll-1")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode(issued.code)
                .build();

        RegisterNodeResponse response = blockingStub.registerNode(request);
        assertTrue(response.getAccepted(), "valid pairing code enrollment must be accepted");
        assertTrue(response.hasDeviceCredential(),
                "successful enrollment must issue a device credential");
        assertFalse(response.getDeviceCredential().isBlank(),
                "issued device credential must not be blank");
    }

    @Test
    void testInvalidPairingCodeRejected() {
        RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                .setNodeId("node-enroll-1")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode("does-not-exist")
                .build();

        RegisterNodeResponse response = blockingStub.registerNode(request);
        assertFalse(response.getAccepted(), "invalid pairing code must be rejected");
    }

    @Test
    void testExpiredPairingCodeRejected() {
        PairingCodeService.PairingCode expired = pairingCodeService.generate("node-expired", "test-client", -1);

        RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                .setNodeId("node-expired")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode(expired.code)
                .build();

        RegisterNodeResponse response = blockingStub.registerNode(request);
        assertFalse(response.getAccepted(), "expired pairing code must be rejected");
    }

    @Test
    void testPairingCodeIsSingleUse() {
        PairingCodeService.PairingCode issued = pairingCodeService.generate("node-single", "test-client");

        RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                .setNodeId("node-single")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode(issued.code)
                .build();

        RegisterNodeResponse first = blockingStub.registerNode(request);
        assertTrue(first.getAccepted(), "first use of pairing code must be accepted");

        RegisterNodeResponse second = blockingStub.registerNode(request);
        assertFalse(second.getAccepted(), "reused pairing code must be rejected");
    }

    @Test
    void testConcurrentPairingCodeConsumption() throws InterruptedException {
        PairingCodeService.PairingCode issued = pairingCodeService.generate("node-concurrent", "test-client");

        int threads = 8;
        CountDownLatch latch = new CountDownLatch(threads);
        AtomicReference<Boolean> firstSuccess = new AtomicReference<>(null);
        AtomicInteger successes = new AtomicInteger(0);

        Runnable task = () -> {
            try {
                RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                        .setNodeId("node-concurrent")
                        .setHostname("test-host")
                        .setPort(9091)
                        .setAgentVersion("0.1.0")
                        .setPairingCode(issued.code)
                        .build();
                RegisterNodeResponse response = blockingStub.registerNode(request);
                if (response.getAccepted()) {
                    boolean wasNull = firstSuccess.compareAndSet(null, true);
                    if (wasNull) {
                        successes.incrementAndGet();
                    }
                }
            } finally {
                latch.countDown();
            }
        };

        Thread[] workers = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            workers[i] = new Thread(task);
            workers[i].start();
        }
        latch.await();

        assertEquals(1, successes.get(), "exactly one concurrent consumer must win the single-use code");
    }

    @Test
    void testDeviceCredentialReconnection() {
        // Enroll first.
        PairingCodeService.PairingCode issued = pairingCodeService.generate("node-reconnect", "test-client");
        RegisterNodeRequest enroll = RegisterNodeRequest.newBuilder()
                .setNodeId("node-reconnect")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode(issued.code)
                .build();
        RegisterNodeResponse enrollResp = blockingStub.registerNode(enroll);
        assertTrue(enrollResp.getAccepted());
        String deviceCredential = enrollResp.getDeviceCredential();

        // Reconnect using the device credential.
        RegisterNodeRequest reconnect = RegisterNodeRequest.newBuilder()
                .setNodeId("node-reconnect")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setDeviceCredential(deviceCredential)
                .build();
        RegisterNodeResponse response = blockingStub.registerNode(reconnect);
        assertTrue(response.getAccepted(), "valid device credential reconnection must be accepted");
    }

    @Test
    void testDeviceCredentialIdentityMismatchRejected() {
        // Enroll node-a.
        PairingCodeService.PairingCode issued = pairingCodeService.generate("node-a", "test-client");
        RegisterNodeRequest enroll = RegisterNodeRequest.newBuilder()
                .setNodeId("node-a")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode(issued.code)
                .build();
        RegisterNodeResponse enrollResp = blockingStub.registerNode(enroll);
        assertTrue(enrollResp.getAccepted());
        String deviceCredential = enrollResp.getDeviceCredential();

        // Present node-a's credential while claiming to be node-b.
        RegisterNodeRequest impersonate = RegisterNodeRequest.newBuilder()
                .setNodeId("node-b")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setDeviceCredential(deviceCredential)
                .build();
        RegisterNodeResponse response = blockingStub.registerNode(impersonate);
        assertFalse(response.getAccepted(),
                "device credential bound to another node must be rejected (impersonation)");
    }

    @Test
    void testRevokedDeviceCredentialRejected() {
        // Enroll node.
        PairingCodeService.PairingCode issued = pairingCodeService.generate("node-revoke", "test-client");
        RegisterNodeRequest enroll = RegisterNodeRequest.newBuilder()
                .setNodeId("node-revoke")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode(issued.code)
                .build();
        RegisterNodeResponse enrollResp = blockingStub.registerNode(enroll);
        assertTrue(enrollResp.getAccepted());
        String deviceCredential = enrollResp.getDeviceCredential();

        // Revoke then attempt reconnection.
        deviceCredentialService.revoke(deviceCredential);
        RegisterNodeRequest reconnect = RegisterNodeRequest.newBuilder()
                .setNodeId("node-revoke")
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setDeviceCredential(deviceCredential)
                .build();
        RegisterNodeResponse response = blockingStub.registerNode(reconnect);
        assertFalse(response.getAccepted(), "revoked device credential must be rejected");
    }

    // ------------------------------------------------------------- heartbeat / telemetry (regressions)

    @Test
    void testHeartbeatValid() {
        enrollNode("test-node-1");

        HeartbeatRequest request = HeartbeatRequest.newBuilder()
                .setNodeId("test-node-1")
                .setTimestamp(System.currentTimeMillis())
                .build();

        HeartbeatResponse response = blockingStub.heartbeat(request);
        assertTrue(response.getAcknowledged());
        assertTrue(response.getServerTime() > 0);
    }

    @Test
    void testHeartbeatUnknownNodeNotAcknowledged() {
        HeartbeatRequest request = HeartbeatRequest.newBuilder()
                .setNodeId("unregistered-node")
                .setTimestamp(System.currentTimeMillis())
                .build();

        HeartbeatResponse response = blockingStub.heartbeat(request);
        assertFalse(response.getAcknowledged(),
                "heartbeat from an unregistered node must not be acknowledged");
        assertTrue(response.getServerTime() > 0);
    }

    @Test
    void testReportTelemetryValid() {
        enrollNode("test-node-1");

        TelemetryRequest request = telemetryRequest("test-node-1");
        TelemetryResponse response = blockingStub.reportTelemetry(request);
        assertTrue(response.getAccepted());
        assertNotNull(response.getMessage());
        assertTrue(response.getServerTime() > 0);
    }

    private void enrollNode(String nodeId) {
        PairingCodeService.PairingCode code = pairingCodeService.generate(nodeId, "test-setup");
        RegisterNodeResponse response = blockingStub.registerNode(RegisterNodeRequest.newBuilder()
                .setNodeId(nodeId)
                .setHostname("test-host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setPairingCode(code.code)
                .build());
        assertTrue(response.getAccepted(), "test setup: enrollment must succeed for " + nodeId);
    }

    private static TelemetryRequest telemetryRequest(String nodeId) {
        return TelemetryRequest.newBuilder()
                .setNodeId(nodeId)
                .setTimestamp(System.currentTimeMillis())
                .setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(50.0).build())
                .setMemory(MemoryTelemetry.newBuilder()
                        .setTotalBytes(1024L * 1024L * 1024L)
                        .setUsedBytes(512L * 1024L * 1024L)
                        .setAvailableBytes(512L * 1024L * 1024L).build())
                .setDisk(DiskTelemetry.newBuilder()
                        .setTotalBytes(100L * 1024L * 1024L * 1024L)
                        .setFreeBytes(40L * 1024L * 1024L * 1024L).build())
                .setProcesses(ProcessTelemetry.newBuilder().setProcessCount(24).build())
                .build();
    }
}
