package com.omni.pcst.master.execution;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskClass;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import com.omni.pcst.proto.TaskResult;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import javax.sql.DataSource;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for {@link JdbcTaskRepository} against an isolated, disposable
 * PostgreSQL database provided by TestContainers. No production data is
 * touched; the container is discarded after the test class completes.
 */
@Testcontainers
class JdbcTaskRepositoryTest {

    @Container
    static final PostgreSQLContainer<?> POSTGRESQL =
            new PostgreSQLContainer<>("postgres:15-alpine");

    private DataSource dataSource;
    private JdbcTemplate jdbc;
    private JdbcTaskRepository repository;

    @BeforeEach
    void setUp() {
        dataSource = new DriverManagerDataSource(
                POSTGRESQL.getJdbcUrl(),
                POSTGRESQL.getUsername(),
                POSTGRESQL.getPassword());
        jdbc = new JdbcTemplate(dataSource);

        // Apply the Flyway migration SQL directly against the test container.
        String sql = readMigrationSql();
        for (String statement : splitStatements(sql)) {
            if (!statement.isBlank()) {
                jdbc.execute(statement);
            }
        }

        repository = new JdbcTaskRepository(jdbc, new ObjectMapper());
    }

    @AfterEach
    void tearDown() {
        jdbc.execute("DROP TABLE IF EXISTS task_records CASCADE");
    }

    // ------------------------------------------------------------------ helpers

    private static String readMigrationSql() {
        try {
            Path migration = Path.of(
                    "src/main/resources/db/migration/V1__create_task_records.sql");
            return Files.readString(migration);
        } catch (Exception e) {
            throw new IllegalStateException("Cannot read migration SQL", e);
        }
    }

    private static List<String> splitStatements(String sql) {
        return List.of(sql.split(";\\s*"));
    }

    private static TaskRecord record(String taskId, String attemptId) {
        Task task = Task.builder(taskId)
                .taskClass(TaskClass.UNSPECIFIED)
                .workloadReference("NO_OP")
                .inputCharacteristics("")
                .resources(TaskResources.NONE)
                .constraints(TaskConstraints.NONE)
                .build();
        return TaskRecord.createAccepted(task, attemptId, 1_700_000_000_000L);
    }

    // ------------------------------------------------------------------ insert / findById

    @Test
    void insertAndFindByIdRoundTripsAllFields() {
        TaskRecord original = record("task-1", "attempt-1");
        repository.insert(original);

        Optional<JdbcTaskRepository.VersionedRecord> found = repository.findById("task-1");
        assertTrue(found.isPresent());
        TaskRecord roundTripped = found.get().record();

        assertEquals("task-1", roundTripped.taskId());
        assertEquals("attempt-1", roundTripped.attemptId());
        assertEquals(com.omni.pcst.master.execution.TaskState.ACCEPTED, roundTripped.state());
        assertEquals(1_700_000_000_000L, roundTripped.createdAt());
        assertEquals(1_700_000_000_000L, roundTripped.updatedAt());
        assertNull(roundTripped.selectedNodeId());
        assertNull(roundTripped.dispatchTime());
        assertNull(roundTripped.errorMessage());
        assertEquals("NO_OP", roundTripped.task().workloadReference());
        assertNull(roundTripped.schedulingDecision());
        assertNull(roundTripped.result());
        assertTrue(roundTripped.history().isEmpty());
        assertEquals(1L, found.get().version());
    }

    @Test
    void findByIdMissingReturnsEmpty() {
        assertTrue(repository.findById("does-not-exist").isEmpty());
    }

    @Test
    void duplicateInsertIsRejected() {
        TaskRecord original = record("task-dup", "attempt-1");
        repository.insert(original);

        TaskRecord duplicate = record("task-dup", "attempt-2");
        assertThrows(IllegalArgumentException.class, () -> repository.insert(duplicate));
    }

    // ------------------------------------------------------------------ update with optimistic locking

    @Test
    void updateWithCorrectVersionSucceedsAndBumpsVersion() {
        TaskRecord original = record("task-1", "attempt-1");
        repository.insert(original);

        long version = repository.findById("task-1").get().version();

        TaskRecord updated = original.withDispatchSent(2_000_000_000_000L);
        int rows = repository.update(original, updated, version);
        assertEquals(1, rows);

        Optional<JdbcTaskRepository.VersionedRecord> found = repository.findById("task-1");
        assertTrue(found.isPresent());
        assertEquals(2L, found.get().version());
        assertEquals(2_000_000_000_000L, found.get().record().dispatchTime());
    }

    @Test
    void updateWithStaleVersionReturnsZeroRows() {
        TaskRecord original = record("task-1", "attempt-1");
        repository.insert(original);

        // Simulate a stale version (as if another transaction bumped it).
        int rows = repository.update(original, original.withDispatchSent(2_000_000_000_000L), 999L);
        assertEquals(0, rows);

        // The record must be unchanged.
        Optional<JdbcTaskRepository.VersionedRecord> found = repository.findById("task-1");
        assertTrue(found.isPresent());
        assertEquals(1L, found.get().version());
        assertNull(found.get().record().dispatchTime());
    }

    // ------------------------------------------------------------------ JSONB payloads

    @Test
    void resultIsRoundTrippedAsJsonb() {
        Task task = Task.builder("task-json")
                .taskClass(TaskClass.CPU_BOUND)
                .workloadReference("COMPUTE")
                .inputCharacteristics("1000")
                .resources(TaskResources.NONE)
                .constraints(TaskConstraints.NONE)
                .build();

        TaskRecord base = TaskRecord.createAccepted(task, "attempt-json", 1_700_000_000_000L);

        TaskResult result = TaskResult.newBuilder()
                .setSuccess(true)
                .setOutput("sum=500500")
                .setError("")
                .setDurationMillis(42)
                .build();

        TaskRecord withResult = base.withResult(result, 1_700_000_001_000L);
        repository.insert(withResult);

        Optional<JdbcTaskRepository.VersionedRecord> found = repository.findById("task-json");
        assertTrue(found.isPresent());
        TaskRecord roundTripped = found.get().record();

        assertNotNull(roundTripped.result());
        assertTrue(roundTripped.result().getSuccess());
        assertEquals("sum=500500", roundTripped.result().getOutput());
        assertEquals(42, roundTripped.result().getDurationMillis());
        assertEquals(com.omni.pcst.master.execution.TaskState.SUCCEEDED, roundTripped.state());
    }

    @Test
    void historyIsRoundTrippedAsJsonb() {
        TaskRecord original = record("task-hist", "attempt-hist");
        TaskRecord withHistory = original.transitionTo(
                com.omni.pcst.master.execution.TaskState.DISPATCHING, 1_700_000_001_000L, null);
        repository.insert(withHistory);

        Optional<JdbcTaskRepository.VersionedRecord> found = repository.findById("task-hist");
        assertTrue(found.isPresent());
        List<TaskRecord.StateTransition> history = found.get().record().history();
        assertEquals(1, history.size());
        assertEquals(com.omni.pcst.master.execution.TaskState.ACCEPTED, history.get(0).from());
        assertEquals(com.omni.pcst.master.execution.TaskState.DISPATCHING, history.get(0).to());
    }

    // ------------------------------------------------------------------ list / delete

    @Test
    void findAllReturnsInsertedRecords() {
        repository.insert(record("task-a", "attempt-a"));
        repository.insert(record("task-b", "attempt-b"));

        List<TaskRecord> all = repository.findAll();
        assertEquals(2, all.size());
    }

    @Test
    void deleteByIdRemovesRecord() {
        repository.insert(record("task-del", "attempt-del"));
        assertTrue(repository.findById("task-del").isPresent());

        repository.deleteById("task-del");
        assertTrue(repository.findById("task-del").isEmpty());
    }

    // ------------------------------------------------------------------ read-only connectivity probe

    @Test
    void probeVersionReturnsDatabaseServerVersion() {
        String version = repository.probeVersion();
        assertNotNull(version);
        assertFalse(version.isBlank());
        // PostgreSQL version strings start with the major version number.
        assertTrue(version.matches("\\d+\\..*"), "unexpected version string: " + version);
    }
}
