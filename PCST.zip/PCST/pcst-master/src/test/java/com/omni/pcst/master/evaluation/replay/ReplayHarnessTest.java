package com.omni.pcst.master.evaluation.replay;

import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import com.omni.pcst.master.evaluation.TelemetryEvaluationRecord;
import com.omni.pcst.master.evaluation.TelemetryEvaluationStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static com.omni.pcst.master.evaluation.replay.SyntheticReplayFixtures.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic tests for the offline replay harness.
 *
 * <p>All inputs are synthetic. Expected metric values are hand-calculated
 * closed-form results, not measured behaviour.
 */
class ReplayHarnessTest {

    @TempDir
    Path tempDir;

    private ReplayHarness harness(long[] horizons, long tolerance, long window, int minObs) {
        return new ReplayHarness(new ReplayConfig(horizons, tolerance, window, minObs));
    }

    private static ReplayHarness.MetricCell cell(ReplayHarness.EvaluationReport report,
                                                 ReplayHarness.PredictorId predictor,
                                                 String resource, long horizon) {
        return report.metrics().stream()
                .filter(m -> m.predictor() == predictor
                        && m.resourceIdentifier().equals(resource)
                        && m.horizonMillis() == horizon)
                .findFirst().orElseThrow(() -> new AssertionError(
                        "no cell for " + predictor + "/" + resource + "/" + horizon));
    }

    // 1. Stable series: persistence is exact.
    @Test
    void persistenceIsExactOnAStableSeries() throws Exception {
        Path file = writeRecords(tempDir, "flat.jsonl",
                flatCpuSeries("n1", "s1", 12, 42.0));

        ReplayHarness.EvaluationReport report =
                harness(new long[]{3_000L}, 500L, 600_000L, 2).evaluate(file);

        ReplayHarness.MetricCell persistence =
                cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                        "cpu_utilization_percent", 3_000L);
        assertTrue(persistence.scoredPairs() > 0, "the series must produce scored pairs");
        assertEquals(0.0, persistence.meanAbsoluteError(), 1e-9,
                "persistence is exact on a constant series");
        assertEquals(0.0, persistence.rootMeanSquaredError(), 1e-9);
        assertEquals(0.0, persistence.meanSignedError(), 1e-9, "no bias on a constant series");
    }

    // 2 + hand-calculated. Rising series: persistence error == H/STEP, trend == 0.
    @Test
    void risingSeriesSeparatesPersistenceFromTrend() throws Exception {
        // CPU rises exactly 1.0 per 1000 ms. For horizon H the target is
        // H/STEP units above the origin value, so persistence errs by exactly
        // H/STEP on every origin, while OLS reproduces the exact line.
        long horizon = 4_000L;
        Path file = writeRecords(tempDir, "rising.jsonl",
                linearCpuSeries("n1", "s1", 20, 0.0));

        ReplayHarness.EvaluationReport report =
                harness(new long[]{horizon}, 500L, 600_000L, 2).evaluate(file);

        ReplayHarness.MetricCell persistence =
                cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                        "cpu_utilization_percent", horizon);
        ReplayHarness.MetricCell trend =
                cell(report, ReplayHarness.PredictorId.TREND,
                        "cpu_utilization_percent", horizon);

        assertEquals(persistence.scoredPairs(), trend.scoredPairs(),
                "both predictors must be compared on comparable origins and targets");
        assertTrue(persistence.scoredPairs() > 0);

        double expectedPersistenceError = (double) horizon / STEP;
        assertEquals(expectedPersistenceError, persistence.meanAbsoluteError(), 1e-6,
                "hand-calculated persistence MAE on a unit-slope series");
        assertEquals(-expectedPersistenceError, persistence.meanSignedError(), 1e-6,
                "persistence under-predicts a rising series, so bias is negative");
        assertEquals(expectedPersistenceError, persistence.rootMeanSquaredError(), 1e-6);

        assertEquals(0.0, trend.meanAbsoluteError(), 1e-6,
                "OLS reproduces an exactly linear series");
        assertTrue(trend.meanAbsoluteError() < persistence.meanAbsoluteError(),
                "trend must beat persistence on a rising series");
    }

    // 20. Hand-calculated metric arithmetic on a known error vector.
    @Test
    void metricArithmeticIsHandCalculated() {
        // errors: +1, -1, +2, -2  =>  MAE 1.5, RMSE sqrt(2.5), bias 0
        ErrorAccumulator acc = new ErrorAccumulator("percent");
        acc.add(11.0, 10.0);   // error +1
        acc.add(9.0, 10.0);    // error -1
        acc.add(12.0, 10.0);   // error +2
        acc.add(8.0, 10.0);    // error -2

        assertEquals(4L, acc.sampleCount());
        assertEquals(1.5, acc.meanAbsoluteError(), 1e-12);
        assertEquals(Math.sqrt(2.5), acc.rootMeanSquaredError(), 1e-12);
        assertEquals(0.0, acc.meanSignedError(), 1e-12);
        assertEquals(2.0, acc.maxAbsoluteError(), 1e-12);
    }

    @Test
    void nonFiniteValuesAreNeverScored() {
        ErrorAccumulator acc = new ErrorAccumulator("percent");
        assertThrows(IllegalArgumentException.class, () -> acc.add(Double.NaN, 1.0));
        assertThrows(IllegalArgumentException.class, () -> acc.add(1.0, Double.POSITIVE_INFINITY));
        assertEquals(0L, acc.sampleCount(), "a rejected pair must not be counted");
    }

    @Test
    void zeroSamplesReportNullRatherThanZeroError() {
        ErrorAccumulator acc = new ErrorAccumulator("percent");
        assertFalse(acc.hasSamples());
        assertNull(acc.meanAbsoluteError());
        assertNull(acc.rootMeanSquaredError());
        assertNull(acc.meanSignedError(),
                "no evidence must never be rendered as perfect prediction");
    }

    // 9. Audit-only records excluded from scoring.
    @Test
    void auditOnlyRecordsAreExcludedAndCounted() throws Exception {
        List<TelemetryEvaluationRecord> records =
                new ArrayList<>(flatCpuSeries("n1", "s1", 10, 42.0));
        records.add(auditOnly("n1", "s1", 99L,
                observation(T0 + 100L, 42.0, 1000L, 500L, null, null, null, null), "DUPLICATE"));

        Path file = writeRecords(tempDir, "audit.jsonl", records);
        ReplayDataset.LoadedDataset dataset = ReplayDataset.load(file);

        assertEquals(1L, dataset.exclusionCounts()
                        .getOrDefault(ReplayDataset.ExclusionReason.NOT_ACCEPTED_BY_TWIN, 0L),
                "an audit-only record must be excluded and counted");
        assertEquals(10L, dataset.eligibleObservationCount(),
                "audit records must never enter the scoring set");
    }

    @Test
    void auditOnlyRecordCanNeverBeAScoringSample() {
        TelemetryEvaluationRecord audit = TelemetryEvaluationRecord.auditOnly(
                "n", observation(T0, 1.0, 10L, 5L, null, null, null, null),
                T0 + 1, "cfg", "s", 1L, "DUPLICATE");
        assertFalse(audit.isScorableSample());
        assertFalse(audit.acceptedByDigitalTwin());
        assertFalse(audit.validForReplay());
    }

    // 10. Records not valid for replay are excluded.
    @Test
    void notValidForReplayRecordsAreExcluded() throws Exception {
        List<TelemetryEvaluationRecord> records =
                new ArrayList<>(flatCpuSeries("n1", "s1", 10, 42.0));
        records.add(notValidForReplay("n1", "s1", 99L,
                observation(T0 + 50L, 42.0, 1000L, 500L, null, null, null, null)));

        Path file = writeRecords(tempDir, "notvalid.jsonl", records);
        ReplayDataset.LoadedDataset dataset = ReplayDataset.load(file);
        assertEquals(1L, dataset.exclusionCounts()
                        .getOrDefault(ReplayDataset.ExclusionReason.NOT_VALID_FOR_REPLAY, 0L),
                "validForReplay=false must exclude the record");
        assertEquals(10L, dataset.eligibleObservationCount());
    }

    // 8. Duplicate sequence and duplicate timestamps.
    @Test
    void duplicateSequenceAndTimestampAreExcluded() throws Exception {
        List<TelemetryEvaluationRecord> records =
                new ArrayList<>(flatCpuSeries("n1", "s1", 6, 42.0));
        // Same sequence as an existing record.
        records.add(accepted("n1", "s1", 3L,
                observation(T0 + 20L, 42.0, 1000L, 500L, null, null, null, null)));
        // Same timestamp, different (absent) sequence.
        records.add(accepted("n1", "s1", null,
                observation(T0 + 20L, 42.0, 1000L, 500L, null, null, null, null)));

        Path file = writeRecords(tempDir, "dups.jsonl", records);
        ReplayDataset.LoadedDataset dataset = ReplayDataset.load(file);

        assertEquals(1L, dataset.exclusionCounts()
                        .getOrDefault(ReplayDataset.ExclusionReason.DUPLICATE_SEQUENCE, 0L));
        assertEquals(1L, dataset.exclusionCounts()
                        .getOrDefault(ReplayDataset.ExclusionReason.DUPLICATE_TIMESTAMP, 0L));
        assertEquals(6L, dataset.eligibleObservationCount(),
                "duplicates must never be counted as independent evidence");
    }

    // 6. Node and session isolation.
    @Test
    void sessionsAndNodesAreNeverMerged() throws Exception {
        List<TelemetryEvaluationRecord> records = new ArrayList<>();
        records.addAll(flatCpuSeries("n1", "session-A", 5, 10.0));
        // Same node, new session: timestamps deliberately continue, but the
        // session boundary must keep the groups apart.
        List<TelemetryEvaluationRecord> secondSession = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            long ts = T0 + i * STEP;
            secondSession.add(accepted("n1", "session-B", (long) (i + 1),
                    observation(ts, 20.0, 1000L, 500L, null, null, null, null)));
        }
        records.addAll(secondSession);
        records.addAll(flatCpuSeries("n2", "session-A", 5, 30.0));

        Path file = writeRecords(tempDir, "sessions.jsonl", records);
        ReplayDataset.LoadedDataset dataset = ReplayDataset.load(file);

        assertEquals(3, dataset.groups().size(),
                "two nodes and two sessions must form three separate groups");
        for (String key : dataset.groupKeys()) {
            assertTrue(dataset.group(key).size() == 5,
                    "no group may absorb another session's observations: " + key);
        }
    }

    // 7. Out-of-order input is normalised deterministically.
    @Test
    void outOfOrderRecordsAreOrderedDeterministically() throws Exception {
        List<TelemetryEvaluationRecord> ordered = flatCpuSeries("n1", "s1", 6, 42.0);
        List<TelemetryEvaluationRecord> shuffled = new ArrayList<>();
        shuffled.add(ordered.get(5));
        shuffled.add(ordered.get(0));
        shuffled.add(ordered.get(3));
        shuffled.add(ordered.get(1));
        shuffled.add(ordered.get(4));
        shuffled.add(ordered.get(2));

        Path a = writeRecords(tempDir, "ordered.jsonl", ordered);
        Path b = writeRecords(tempDir, "shuffled.jsonl", shuffled);

        ReplayHarness harness = harness(new long[]{2_000L}, 500L, 600_000L, 2);
        ReplayHarness.EvaluationReport orderedReport = harness.evaluate(a);
        ReplayHarness.EvaluationReport shuffledReport = harness.evaluate(b);

        // The input path legitimately differs; everything derived from the
        // observations must be identical. The path line is normalised out
        // because JSON escaping makes the raw Windows path non-comparable.
        assertEquals(withoutInputPath(ReplayReportWriter.toJson(orderedReport)),
                withoutInputPath(ReplayReportWriter.toJson(shuffledReport)),
                "record order in the file must not change the evaluation result");
    }

    /** Removes the {@code inputPath} line, whose value differs by construction. */
    private static String withoutInputPath(String json) {
        return json.lines()
                .filter(line -> !line.contains("\"inputPath\""))
                .reduce(new StringBuilder(), (sb, line) -> sb.append(line).append('\n'), StringBuilder::append)
                .toString();
    }

    // 3. Missing resource values are never fabricated.
    @Test
    void missingResourceValuesAreNotFabricated() throws Exception {
        List<TelemetryEvaluationRecord> records = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            long ts = T0 + i * STEP;
            // CPU absent; memory present; latency and packet loss absent.
            records.add(accepted("n1", "s1", (long) (i + 1),
                    observation(ts, null, 1000L, 250L, null, null, null, null)));
        }
        Path file = writeRecords(tempDir, "missing.jsonl", records);
        ReplayHarness.EvaluationReport report =
                harness(new long[]{2_000L}, 500L, 600_000L, 2).evaluate(file);

        ReplayHarness.MetricCell cpu = cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                "cpu_utilization_percent", 2_000L);
        assertEquals(0L, cpu.scoredPairs(),
                "an absent CPU value must never be turned into a fabricated number");

        // Memory is derivable: 250/1000 = 25.0 percent, constant, so exact.
        ReplayHarness.MetricCell memory = cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                "memory_utilization_percent", 2_000L);
        assertTrue(memory.scoredPairs() > 0, "memory must be derivable from both byte counts");
        assertEquals(0.0, memory.meanAbsoluteError(), 1e-9,
                "a constant derived memory series is exactly forecast by persistence");
        assertEquals("percent", memory.unit());
    }

    // 4. Legitimate zeros are preserved and scored, not treated as missing.
    @Test
    void legitimateZeroValuesArePreservedAndScored() throws Exception {
        Path file = writeRecords(tempDir, "zeros.jsonl",
                flatCpuSeries("n1", "s1", 10, 0.0));
        ReplayHarness.EvaluationReport report =
                harness(new long[]{2_000L}, 500L, 600_000L, 2).evaluate(file);

        ReplayHarness.MetricCell cpu = cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                "cpu_utilization_percent", 2_000L);
        assertTrue(cpu.scoredPairs() > 0,
                "a legitimate zero series must be scored, not skipped as missing");
        assertEquals(0.0, cpu.meanAbsoluteError(), 1e-9);
    }

    // 11 + 12. Malformed lines and unsupported versions are reported, not fatal.
    @Test
    void malformedAndLegacyLinesAreReportedWithoutFailingTheRun() throws Exception {
        List<String> lines = new ArrayList<>();
        lines.add("{not json at all");
        lines.add("{\"v\":\"pcst-eval-v1\",\"nodeId\":\"n\"}");
        lines.add("{\"v\":\"pcst-eval-v2\",\"nodeId\":\"n\"}");
        lines.add("{\"v\":\"pcst-eval-v3\",\"nodeId\":\"n\"}");
        for (int i = 0; i < 6; i++) {
            TelemetryEvaluationRecord r = accepted("n1", "s1", (long) (i + 1),
                    observation(T0 + i * STEP, 5.0, 10L, 5L, null, null, null, null));
            lines.add(serializeForFixture(r));
        }
        Path file = writeRawLines(tempDir, "corrupt.jsonl", lines);

        ReplayDataset.LoadedDataset dataset = ReplayDataset.load(file);
        assertEquals(1L, dataset.skipReasons()
                        .getOrDefault(TelemetryEvaluationStore.SkipReason.MALFORMED_JSON, 0L));
        assertEquals(3L, dataset.skipReasons()
                        .getOrDefault(TelemetryEvaluationStore.SkipReason.UNSUPPORTED_SCHEMA_VERSION, 0L),
                "v1, v2 and v3 must all be reported as unsupported, never reinterpreted");
        assertEquals(6L, dataset.eligibleObservationCount(),
                "valid v4 records around corrupt lines must still load");
    }

    // 13. Insufficient history is reported, not silently dropped.
@Test
    void insufficientHistoryProducesNoScoredPairs() throws Exception {
        // Enough observations for the group to be evaluated, but fewer valid
        // in-window measurements than the configured minimum.
        Path file = writeRecords(tempDir, "short.jsonl",
                flatCpuSeries("n1", "s1", 5, 10.0));
        ReplayHarness.EvaluationReport report =
                harness(new long[]{1_000L}, 500L, 600_000L, 5).evaluate(file);
        ReplayHarness.MetricCell cpu = cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                "cpu_utilization_percent", 1_000L);
        assertEquals(0L, cpu.scoredPairs(), "insufficient history must not produce a score");
        assertNull(cpu.meanAbsoluteError());
        assertTrue(cpu.unscoredReasons().containsKey(ReplayHarness.UnscoredReason.INSUFFICIENT_HISTORY),
                "the failure must be reported, not silently dropped");
    }

    // 14 + 15. Missing / out-of-tolerance targets are reported.
    @Test
    void missingAndOutOfToleranceTargetsAreReported() throws Exception {
        Path file = writeRecords(tempDir, "notarget.jsonl",
                flatCpuSeries("n1", "s1", 6, 10.0));
        // A horizon far beyond the end of the data can never find a target.
        ReplayHarness.EvaluationReport report =
                harness(new long[]{10_000_000L}, 500L, 600_000L, 2).evaluate(file);
        ReplayHarness.MetricCell cpu = cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                "cpu_utilization_percent", 10_000_000L);
        assertEquals(0L, cpu.scoredPairs());
        assertEquals(0L, cpu.predictionOpportunities(),
                "no target means no scoring opportunity is claimed");
    }

    // 18. Empty dataset is handled cleanly.
    @Test
    void emptyDatasetIsHandledWithoutFailure() throws Exception {
        Path file = tempDir.resolve("empty.jsonl");
        Files.writeString(file, "");

        ReplayHarness.EvaluationReport report =
                harness(new long[]{2_000L}, 500L, 600_000L, 2).evaluate(file);
        assertEquals(0L, report.dataset().eligibleObservationCount());
        assertTrue(report.warnings().stream().anyMatch(w -> w.contains("no eligible observations")));
        assertTrue(report.metrics().isEmpty(),
                "with no eligible observation there is nothing to report a metric for");
        String json = ReplayReportWriter.toJson(report);
        assertTrue(json.contains("\"eligibleObservations\": 0"));
        assertFalse(json.contains("\"mae\": 0.000000"),
                "empty data must never be rendered as zero error");
    }

    // 19. Leakage prevention.
    @Test
    void futureDataNeverReachesThePredictor() throws Exception {
        // A series that changes character after the midpoint: the first half is
        // flat at 10, the second half is flat at 90. A leakage-free forecast at
        // an origin in the first half can only ever see the flat 10 values.
        List<TelemetryEvaluationRecord> records = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            double cpu = (i < 6) ? 10.0 : 90.0;
            records.add(accepted("n1", "s1", (long) (i + 1),
                    observation(T0 + i * STEP, cpu, 1000L, 500L, null, null, null, null)));
        }
        Path file = writeRecords(tempDir, "leak.jsonl", records);

        ReplayHarness.EvaluationReport report =
                harness(new long[]{1_000L}, 500L, 600_000L, 2).evaluate(file);

        ReplayHarness.MetricCell persistence =
                cell(report, ReplayHarness.PredictorId.PERSISTENCE, "cpu_utilization_percent", 1_000L);
        assertTrue(persistence.scoredPairs() > 0);
        // Every scored error must come from a value the predictor could not have
        // seen: no error may equal the 80-unit step between the two regimes,
        // which is what a leaked forecast would produce for early origins.
        for (ReplayHarness.GroupCoverage ignored : report.groupCoverage()) {
            assertNotNull(ignored);
        }
        assertTrue(persistence.maxAbsoluteError() <= 80.0 + 1e-9,
                "errors must be explainable by the visible data alone");
    }

    // 17. Deterministic output.
    @Test
    void outputIsDeterministicAcrossRuns() throws Exception {
        Path file = writeRecords(tempDir, "determinism.jsonl",
                linearCpuSeries("n1", "s1", 15, 0.0));
        ReplayHarness harness = harness(new long[]{1_000L, 3_000L}, 500L, 600_000L, 2);

        String firstJson = ReplayReportWriter.toJson(harness.evaluate(file));
        String firstMd = ReplayReportWriter.toMarkdown(harness.evaluate(file));
        String secondJson = ReplayReportWriter.toJson(harness.evaluate(file));
        String secondMd = ReplayReportWriter.toMarkdown(harness.evaluate(file));

        assertEquals(firstJson, secondJson, "JSON output must be byte-identical across runs");
        assertEquals(firstMd, secondMd, "Markdown output must be identical across runs");
        assertTrue(firstJson.contains(ReplayConfig.PROTOCOL));
    }

    @Test
    void reportOrderingIsStable() throws Exception {
        Path file = writeRecords(tempDir, "ordering.jsonl",
                linearCpuSeries("n1", "s1", 8, 0.0));
        ReplayHarness.EvaluationReport report =
                harness(new long[]{3_000L, 1_000L}, 500L, 600_000L, 2).evaluate(file);

        for (int i = 1; i < report.metrics().size(); i++) {
            ReplayHarness.MetricCell previous = report.metrics().get(i - 1);
            ReplayHarness.MetricCell current = report.metrics().get(i);
            int c = Integer.compare(previous.predictor().ordinal(), current.predictor().ordinal());
            if (c != 0) {
                assertTrue(c < 0, "predictors must be grouped in declaration order");
            } else {
                int r = previous.resourceIdentifier().compareTo(current.resourceIdentifier());
                assertTrue(r <= 0, "resources must be ordered by identifier");
                if (r == 0) {
                    assertTrue(previous.horizonMillis() <= current.horizonMillis(),
                            "horizons must be ordered ascending within a predictor/resource");
                }
            }
        }
    }

    // 16. Unsupported predictor/resource combinations are not pretended.
    @Test
    void everyResourceIsEvaluatedWithItsCorrectUnit() throws Exception {
        Path file = writeRecords(tempDir, "units.jsonl",
                flatCpuSeries("n1", "s1", 8, 10.0));
        ReplayHarness.EvaluationReport report =
                harness(new long[]{2_000L}, 500L, 600_000L, 2).evaluate(file);

        assertEquals("percent", cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                "cpu_utilization_percent", 2_000L).unit());
        assertEquals("milliseconds", cell(report, ReplayHarness.PredictorId.PERSISTENCE,
                "network_latency_ms", 2_000L).unit(),
                "latency must be reported in milliseconds, never percent");
    }

    @Test
    void configValidationRejectsInvalidInput() {
        assertThrows(IllegalArgumentException.class,
                () -> new ReplayConfig(new long[0], 0, 0, 1));
        assertThrows(IllegalArgumentException.class,
                () -> new ReplayConfig(new long[]{0L}, 0, 0, 1));
        assertThrows(IllegalArgumentException.class,
                () -> new ReplayConfig(new long[]{1000L}, -1, 0, 1));
        assertThrows(IllegalArgumentException.class,
                () -> new ReplayConfig(new long[]{1000L}, 0, 0, 0));
    }

    /** Serializes one record through the production codec for raw-line fixtures. */
    private static String serializeForFixture(TelemetryEvaluationRecord record) throws IOException {
        Path p = Files.createTempFile("fixture", ".jsonl");
        Path written = writeRecords(p.getParent(), p.getFileName().toString(), List.of(record));
        String line = Files.readString(written).trim();
        Files.deleteIfExists(written);
        Files.deleteIfExists(p);
        return line;
    }

    /** Ensures the fixture observation helper stays reachable for all cases. */
    @Test
    void fixtureObservationBuilderIsUsable() {
        TelemetryObservation obs = observation(T0, 1.0, 2L, 1L, 3.0, 4.0, 5.0, 6.0);
        assertEquals(1.0, obs.cpuUtilizationPercent());
        assertEquals(3.0, obs.latencyMs());
        assertEquals(6.0, obs.temperatureCelsius());
    }
}