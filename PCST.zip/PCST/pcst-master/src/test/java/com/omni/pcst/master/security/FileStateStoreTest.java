package com.omni.pcst.master.security;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link FileStateStore}: load/save round-trip, corruption
 * detection, passphrase mismatch, truncation, nonce uniqueness, and write
 * failure semantics.
 */
class FileStateStoreTest {

    @TempDir
    Path dir;

    @Test
    void testLoadNoStateFileReturnsEmpty() {
        Path stateFile = dir.resolve("no-such-file.json");
        FileStateStore store = new FileStateStore(stateFile, "passphrase-12345");
        StateSnapshot snapshot = store.load();
        assertNotNull(snapshot);
        assertTrue(snapshot.credentials().isEmpty());
    }

    @Test
    void testSaveAndLoadRoundTrip() throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");

        StateSnapshot snapshot = new StateSnapshot(Map.of(
                "token-abc", new StateSnapshot.CredentialRecord("node-1", 1000L, false),
                "token-def", new StateSnapshot.CredentialRecord("node-2", 2000L, true)
        ));
        store.save(snapshot);

        FileStateStore store2 = new FileStateStore(stateFile, "test-passphrase-12345");
        StateSnapshot loaded = store2.load();
        assertEquals(2, loaded.credentials().size());
        assertTrue(loaded.credentials().containsKey("token-abc"));
        assertTrue(loaded.credentials().containsKey("token-def"));
        assertFalse(loaded.credentials().get("token-abc").revoked());
        assertTrue(loaded.credentials().get("token-def").revoked());
    }

    @Test
    void testLoadCorruptStateThrows() throws Exception {
        Path stateFile = dir.resolve("state.json");
        // Write garbage bytes that are not valid JSON
        Files.write(stateFile, new byte[] { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05 });

        FileStateStore store = new FileStateStore(stateFile, "passphrase-12345");
        assertThrows(FileStateStore.StateStoreException.class, store::load);
    }

    @Test
    void testLoadTruncatedEncryptedStateThrows() throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store1 = new FileStateStore(stateFile, "passphrase-12345");
        store1.save(StateSnapshot.empty());

        // Truncate the file to half its size
        byte[] data = Files.readAllBytes(stateFile);
        byte[] truncated = new byte[data.length / 2];
        System.arraycopy(data, 0, truncated, 0, truncated.length);
        Files.write(stateFile, truncated);

        FileStateStore store2 = new FileStateStore(stateFile, "passphrase-12345");
        assertThrows(FileStateStore.StateStoreException.class, store2::load);
    }

    @Test
    void testLoadWrongPassphraseThrows() throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store1 = new FileStateStore(stateFile, "passphrase-A");
        store1.save(StateSnapshot.empty());

        // Try to load with a different passphrase — GCM authentication tag
        // verification must fail.
        FileStateStore store2 = new FileStateStore(stateFile, "passphrase-B");
        assertThrows(FileStateStore.StateStoreException.class, store2::load);
    }

    @Test
    void testEncryptionProducesDifferentOutput() throws Exception {
        Path stateFile1 = dir.resolve("state1.json");
        Path stateFile2 = dir.resolve("state2.json");
        FileStateStore store1 = new FileStateStore(stateFile1, "passphrase-12345");
        FileStateStore store2 = new FileStateStore(stateFile2, "passphrase-12345");

        StateSnapshot snapshot = new StateSnapshot(Map.of(
                "token-abc", new StateSnapshot.CredentialRecord("node-1", 1000L, false)
        ));
        store1.save(snapshot);
        store2.save(snapshot);

        byte[] data1 = Files.readAllBytes(stateFile1);
        byte[] data2 = Files.readAllBytes(stateFile2);

        // Both files start with the version byte and have the same length,
        // but the IV (bytes 1..13) and ciphertext should differ due to fresh
        // nonces.
        assertEquals(data1.length, data2.length);
        assertEquals(data1[0], data2[0]); // same format version
        boolean ivDiffers = false;
        for (int i = 1; i <= 12; i++) {
            if (data1[i] != data2[i]) {
                ivDiffers = true;
                break;
            }
        }
        assertTrue(ivDiffers, "IV (nonce) should differ between encryptions");
    }

    @Test
    void testSaveWriteFailureThrows() throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "passphrase-12345");

        // Save once successfully
        store.save(StateSnapshot.empty());

        // Make the state file read-only so subsequent writes fail
        stateFile.toFile().setReadOnly();

        // Attempting to save again should fail because we cannot replace a
        // read-only file.
        assertThrows(FileStateStore.StateStoreException.class,
                () -> store.save(StateSnapshot.empty()));
    }

    @Test
    @EnabledOnOs(OS.LINUX)
    void testSaveUnreadableDirectoryThrows() throws Exception {
        // Use a path under a read-only directory so new files cannot be created.
        Path stateFile = dir.resolve("readonly").resolve("state.json");

        // Create the parent directory and make it read-only
        Path parent = dir.resolve("readonly");
        Files.createDirectories(parent);
        parent.toFile().setReadOnly();

        FileStateStore store = new FileStateStore(stateFile, "passphrase-12345");
        assertThrows(FileStateStore.StateStoreException.class,
                () -> store.save(StateSnapshot.empty()));
    }
}
