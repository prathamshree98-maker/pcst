package com.omni.pcst.master.telemetry;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.evaluation.TelemetryEvaluationRecord;
import com.omni.pcst.master.evaluation.TelemetryEvaluationStore;
import com.omni.pcst.proto.CpuTelemetry;
import com.omni.pcst.proto.DiskTelemetry;
import com.omni.pcst.proto.GpuTelemetry;
import com.omni.pcst.proto.MemoryTelemetry;
import com.omni.pcst.proto.ProcessTelemetry;
import com.omni.pcst.proto.TelemetryRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Regression coverage for the Step 5E.2.2.2 corrections: duplicate suppression,
 * session authority, eviction diagnostics and concurrent ingestion.
 *
 * <p>These drive the real {@link DigitalTwinManager}, the real
 * {@link BayesianBeliefEngine} and a real store on a temporary path. No sleeps:
 * persistence is forced by explicit flush and concurrency uses latches.
 */
class TelemetryAcceptancePolicyTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final String NODE = "node-policy";
    private static final String SESSION = "session-1";

    @TempDir
    Path tempDir;

    private static TelemetryRequest req(String nodeId, long ts, String session, Long seq) {
        TelemetryRequest.Builder b = TelemetryRequest.newBuilder()
                .setNodeId(nodeId).setTimestamp(ts)
                .setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(10.0))
                .setMemory(MemoryTelemetry.newBuilder()
                        .setTotalBytes(1024L).setUsedBytes(512L).setAvailableBytes(512L))
                .setGpu(GpuTelemetry.newBuilder().setAvailable(false))
                .setDisk(DiskTelemetry.newBuilder().setTotalBytes(2048L).setFreeBytes(1024L))
                .setProcesses(ProcessTelemetry.newBuilder().setProcessCount(4));
        if (session != null) b.setAgentSessionId(session);
        if (seq != null) b.setTelemetrySequence(seq);
        return b.build();
    }

    private TelemetryEvaluationStore newStore(String name) {
        return new TelemetryEvaluationStore(tempDir.resolve(name), 1000, 10000, false);
    }

    // 1 & 2 & 3: duplicate with a newer timestamp is not applied, not scorable,
    // but is retained as a marked audit record.
    @Test
    void duplicateWithNewerTimestampDoesNotModifyTwinOrBeliefAndIsAuditOnly() throws Exception {
        TelemetryEvaluationStore store = newStore("dup.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, new BayesianBeliefEngine(), store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, T0 + 1, SESSION, 10L), T0 + 1));
        var afterFirst = manager.getSnapshot(NODE).orElseThrow();
        int historyAfterFirst = afterFirst.observationHistory().size();

        // Same sequence, strictly newer timestamp: would pass the timestamp gate.
        assertEquals(DigitalTwinManager.TelemetryIngestion.DUPLICATE_SEQUENCE,
                manager.onTelemetry(NODE, req(NODE, T0 + 50, SESSION, 10L), T0 + 50));

        var afterDuplicate = manager.getSnapshot(NODE).orElseThrow();
        assertEquals(afterFirst.latestObservation(), afterDuplicate.latestObservation(),
                "a duplicate must not change the latest observation");
        assertEquals(historyAfterFirst, afterDuplicate.observationHistory().size(),
                "a duplicate must not be appended to accepted history");
        assertEquals(afterFirst.beliefState(), afterDuplicate.beliefState(),
                "a duplicate must not trigger a Bayesian belief recomputation");

        store.flush();
        List<TelemetryEvaluationRecord> records = store.readAll();
        assertEquals(2, records.size(), "the duplicate is still retained as audit evidence");
        TelemetryEvaluationRecord audit = records.stream()
                .filter(r -> "DUPLICATE".equals(r.sequenceClassification()))
                .findFirst().orElseThrow();
        assertFalse(audit.acceptedByDigitalTwin(), "audit record is marked not accepted");
        assertFalse(audit.isScorableSample(), "a duplicate can never be a scoring sample");
        assertFalse(audit.validForReplay(), "validForReplay is cleared for an audit-only record");
        assertEquals(10L, audit.telemetrySequence());
        assertEquals(SESSION, audit.agentSessionId());
    }

    // 4: OUT_OF_ORDER with a newer timestamp remains acceptable.
    @Test
    void outOfOrderWithNewerTimestampRemainsAcceptable() throws Exception {
        TelemetryEvaluationStore store = newStore("ooo.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);

        manager.onTelemetry(NODE, req(NODE, T0 + 1, SESSION, 12L), T0 + 1);
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, T0 + 2, SESSION, 11L), T0 + 2),
                "a delayed message with a newer timestamp is legitimate and accepted");

        store.flush();
        TelemetryEvaluationRecord rec = store.readAll().stream()
                .filter(r -> "OUT_OF_ORDER".equals(r.sequenceClassification()))
                .findFirst().orElseThrow();
        assertTrue(rec.acceptedByDigitalTwin(), "out-of-order is accepted");
        assertTrue(rec.isScorableSample(), "out-of-order telemetry remains a valid sample");
    }

    // 5: forward gap accepted, interval persisted.
    @Test
    void forwardGapIsAcceptedAndIntervalPersisted() throws Exception {
        TelemetryEvaluationStore store = newStore("gap.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);

        manager.onTelemetry(NODE, req(NODE, T0 + 1, SESSION, 10L), T0 + 1);
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, T0 + 2, SESSION, 12L), T0 + 2));

        store.flush();
        TelemetryEvaluationRecord rec = store.readAll().stream()
                .filter(r -> "FORWARD_GAP".equals(r.sequenceClassification()))
                .findFirst().orElseThrow();
        assertTrue(rec.acceptedByDigitalTwin(), "a gap does not invalidate the observation");
        assertEquals(11L, rec.sequenceGapFrom());
        assertEquals(11L, rec.sequenceGapTo());
    }

    // 6: a late arrival is never recorded as confirmed loss.
    @Test
    void lateArrivalIsNotRepresentedAsConfirmedPermanentLoss() throws Exception {
        TelemetryEvaluationStore store = newStore("late.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);

        manager.onTelemetry(NODE, req(NODE, T0 + 1, SESSION, 10L), T0 + 1);
        manager.onTelemetry(NODE, req(NODE, T0 + 2, SESSION, 12L), T0 + 2);
        // The late arrival is accepted on its own merits (newer timestamp).
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, T0 + 3, SESSION, 11L), T0 + 3));

        store.flush();
        // The gap is recorded once as a FORWARD_GAP interval, and the late
        // arrival is recorded as OUT_OF_ORDER: never as "permanently lost".
        long gapRecords = store.readAll().stream()
                .filter(r -> "FORWARD_GAP".equals(r.sequenceClassification())).count();
        assertEquals(1, gapRecords, "the gap is recorded once as a discontinuity, not as loss");
        assertTrue(store.readAll().stream()
                        .anyMatch(r -> "OUT_OF_ORDER".equals(r.sequenceClassification())),
                "the late arrival is visible as its own message");
    }

    // 7: delayed telemetry from a superseded session cannot update the twin.
    @Test
    void delayedTelemetryFromSupersededSessionCannotUpdateTwin() throws Exception {
        TelemetryEvaluationStore store = newStore("obsolete.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, "session-A");
        manager.onTelemetry(NODE, req(NODE, T0 + 1, "session-A", 1L), T0 + 1);

        // Session B registers and becomes active.
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0 + 2, "session-B");
        manager.onTelemetry(NODE, req(NODE, T0 + 3, "session-B", 1L), T0 + 3);
        var afterB = manager.getSnapshot(NODE).orElseThrow();

        // A delayed message from superseded session A arrives with a newer timestamp.
        assertEquals(DigitalTwinManager.TelemetryIngestion.OBSOLETE_SESSION,
                manager.onTelemetry(NODE, req(NODE, T0 + 100, "session-A", 2L), T0 + 100),
                "telemetry from a superseded session must not be applied");

        var afterDelayed = manager.getSnapshot(NODE).orElseThrow();
        assertEquals(afterB.latestObservation(), afterDelayed.latestObservation(),
                "an obsolete session must not modify the active Digital Twin");
        assertEquals(afterB.observationHistory().size(), afterDelayed.observationHistory().size());
        assertEquals("session-B", manager.getSequenceTracker().registeredSession(NODE),
                "session tracking must not fall back to the superseded session");
    }

    // 8: same-session re-registration preserves sequence state.
    @Test
    void sameSessionReRegistrationPreservesSequenceState() throws Exception {
        TelemetryEvaluationStore store = newStore("rereg.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);
        manager.onTelemetry(NODE, req(NODE, T0 + 1, SESSION, 5L), T0 + 1);

        // The same session registers again (for example a transient reconnect).
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0 + 2, SESSION);
        assertEquals(5L, manager.getSequenceTracker().highestSequence(NODE, SESSION),
                "re-registration with the same session must not reset sequence state");

        // Sequence 5 is still recognised as a duplicate, proving state survived.
        assertEquals(DigitalTwinManager.TelemetryIngestion.DUPLICATE_SEQUENCE,
                manager.onTelemetry(NODE, req(NODE, T0 + 3, SESSION, 5L), T0 + 3),
                "duplicate detection survives same-session re-registration");
    }

    // 9: a new registered session resets only session-scoped state.
    @Test
    void newRegisteredSessionResetsOnlySessionScopedState() throws Exception {
        TelemetryEvaluationStore store = newStore("newsess.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, "session-A");
        manager.onTelemetry(NODE, req(NODE, T0 + 1, "session-A", 9L), T0 + 1);

        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0 + 2, "session-B");
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, T0 + 3, "session-B", 1L), T0 + 3),
                "a genuinely new session starts a fresh sequence scope");

        assertEquals(9L, manager.getSequenceTracker().highestSequence(NODE, "session-A"),
                "the previous session's state is retained independently");
        assertEquals(1L, manager.getSequenceTracker().highestSequence(NODE, "session-B"));
        assertEquals(1L, manager.getSequenceTracker().getSessionChangeCount(),
                "one restart is counted exactly once");
    }

    // 10: legacy metadata-free registration and telemetry still work.
    @Test
    void legacyMetadataFreeAgentStillWorks() throws Exception {
        TelemetryEvaluationStore store = newStore("legacy.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        // Registration without a session id (an older agent).
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0);

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, T0 + 1, null, null), T0 + 1),
                "legacy telemetry without metadata is still accepted");

        store.flush();
        TelemetryEvaluationRecord rec = store.readAll().get(0);
        assertNull(rec.agentSessionId(), "no session id may be fabricated");
        assertNull(rec.telemetrySequence(), "no sequence may be fabricated");
        assertEquals("NOT_REPORTED", rec.sequenceClassification());
        assertTrue(rec.isScorableSample(), "legacy telemetry remains a valid sample");
    }

    // 11: each partial-metadata combination is deterministic.
    @Test
    void partialMetadataCombinationsAreDeterministic() throws Exception {
        TelemetryEvaluationStore store = newStore("partial.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);

        long base = T0 + 1;
        // Session present, sequence absent.
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, base, SESSION, null), base));
        // Sequence present, session absent.
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, base + 1, null, 7L), base + 1));
        // Both absent.
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, req(NODE, base + 2, null, null), base + 2));

        store.flush();
        List<TelemetryEvaluationRecord> records = store.readAll();
        assertEquals(3, records.size());
        // Session-without-sequence is invalid metadata: session kept, sequence null.
        assertEquals("INVALID_METADATA", records.get(0).sequenceClassification());
        assertEquals(SESSION, records.get(0).agentSessionId());
        assertNull(records.get(0).telemetrySequence());
        // Sequence-without-session is not reportable: never assigned a session.
        assertEquals("NOT_REPORTED", records.get(1).sequenceClassification());
        assertNull(records.get(1).agentSessionId());
        assertEquals(7L, records.get(1).telemetrySequence());
        assertEquals("NOT_REPORTED", records.get(2).sequenceClassification());
    }

    // 12: timestamp-stale telemetry leaves history and belief unchanged.
    @Test
    void timestampStaleLeavesHistoryAndBeliefUnchanged() throws Exception {
        TelemetryEvaluationStore store = newStore("stale.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, new BayesianBeliefEngine(), store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);

        manager.onTelemetry(NODE, req(NODE, T0 + 100, SESSION, 1L), T0 + 100);
        var before = manager.getSnapshot(NODE).orElseThrow();

        assertEquals(DigitalTwinManager.TelemetryIngestion.STALE_OR_OUT_OF_ORDER,
                manager.onTelemetry(NODE, req(NODE, T0 + 50, SESSION, 2L), T0 + 101));

        var after = manager.getSnapshot(NODE).orElseThrow();
        assertEquals(before.observationHistory().size(), after.observationHistory().size());
        assertEquals(before.latestObservation(), after.latestObservation());
        assertEquals(before.beliefState(), after.beliefState());

        store.flush();
        assertEquals(1, store.readAll().size(), "a stale rejection writes no evaluation record");
    }

    // 13: concurrent duplicate submissions cannot both update the twin.
    @Test
    void concurrentDuplicateSubmissionsUpdateTwinOnlyOnce() throws Exception {
        TelemetryEvaluationStore store = newStore("concurdup.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, new BayesianBeliefEngine(), store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);
        manager.onTelemetry(NODE, req(NODE, T0 + 1, SESSION, 1L), T0 + 1);
        var baseline = manager.getSnapshot(NODE).orElseThrow();

        int threads = 8;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        AtomicInteger accepted = new AtomicInteger();
        AtomicInteger duplicates = new AtomicInteger();
        try {
            for (int i = 0; i < threads; i++) {
                final int idx = i;
                pool.submit(() -> {
                    try {
                        start.await();
                        // Every thread submits the SAME sequence with a newer timestamp.
                        DigitalTwinManager.TelemetryIngestion outcome = manager.onTelemetry(
                                NODE, req(NODE, T0 + 10 + idx, SESSION, 1L), T0 + 10 + idx);
                        if (outcome == DigitalTwinManager.TelemetryIngestion.ACCEPTED) {
                            accepted.incrementAndGet();
                        } else if (outcome == DigitalTwinManager.TelemetryIngestion.DUPLICATE_SEQUENCE) {
                            duplicates.incrementAndGet();
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } finally {
                        done.countDown();
                    }
                });
            }
            start.countDown();
            assertTrue(done.await(30, TimeUnit.SECONDS), "all writers finished");
        } finally {
            pool.shutdown();
            assertTrue(pool.awaitTermination(30, TimeUnit.SECONDS));
        }

        assertEquals(0, accepted.get(), "a concurrently duplicated sequence must not be accepted twice");
        assertEquals(threads, duplicates.get(), "every concurrent duplicate is reported as a duplicate");

        var after = manager.getSnapshot(NODE).orElseThrow();
        assertEquals(baseline.observationHistory().size(), after.observationHistory().size(),
                "none of the concurrent duplicates may change history");
    }

    // 14: concurrent distinct sequences do not corrupt tracker/session state.
    @Test
    void concurrentDistinctSequencesKeepTrackerConsistent() throws Exception {
        TelemetryEvaluationStore store = newStore("concursess.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(10000, null, store, "cfg");
        manager.onNodeRegistered(NODE, "h", 1, "0.1.0", T0, SESSION);

        int threads = 8;
        int perThread = 40;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        try {
            for (int t = 0; t < threads; t++) {
                pool.submit(() -> {
                    try {
                        start.await();
                        for (int i = 1; i <= perThread; i++) {
                            long seq = (System.nanoTime() % 1000) + i; // arbitrary sequences
                            long ts = T0 + 1000 + i + (seq % 7);
                            manager.onTelemetry(NODE, req(NODE, ts, SESSION, Math.abs(seq)), ts);
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } finally {
                        done.countDown();
                    }
                });
            }
            start.countDown();
            assertTrue(done.await(30, TimeUnit.SECONDS), "all writers finished");
        } finally {
            pool.shutdown();
            assertTrue(pool.awaitTermination(30, TimeUnit.SECONDS));
        }

        // The session must remain authoritative and the tracker must not have lost
        // the node's identity under concurrency.
        assertEquals(SESSION, manager.getSequenceTracker().registeredSession(NODE));
        assertFalse(manager.getSequenceTracker().isRetired(NODE, SESSION));
    }

    // 15: registeredSession() is safe under concurrent reads and writes.
    @Test
    void registeredSessionIsSafeUnderConcurrentAccess() throws Exception {
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker();
        int threads = 6;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        AtomicInteger errors = new AtomicInteger();
        try {
            for (int t = 0; t < threads; t++) {
                final int idx = t;
                final String nodeId = "shared-node";
                pool.submit(() -> {
                    try {
                        start.await();
                        for (int i = 0; i < 200; i++) {
                            // Every thread writes AND reads the same node, so the
                            // shared HashMap race this test targets would surface
                            // as an exception or a torn read.
                            tracker.noteRegistrationSession(nodeId, "sess-" + idx + "-" + i);
                            String v = tracker.registeredSession(nodeId);
                            if (v == null) {
                                errors.incrementAndGet();
                            }
                            tracker.highestSequence(nodeId, "sess-" + idx + "-" + i);
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } catch (RuntimeException e) {
                        errors.incrementAndGet();
                    } finally {
                        done.countDown();
                    }
                });
            }
            start.countDown();
            assertTrue(done.await(30, TimeUnit.SECONDS), "all threads finished");
        } finally {
            pool.shutdown();
            assertTrue(pool.awaitTermination(30, TimeUnit.SECONDS));
        }
        assertEquals(0, errors.get(),
                "concurrent session reads/writes must not race or throw");
    }
}