package com.omni.pcst.master.security;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for PairingCodeService: issuance, single-use consumption, expiry,
 * invalid codes, revocation, rate limiting, and concurrent consumption.
 */
class PairingCodeServiceTest {

    @Test
    void testGenerateReturnsCode() {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        PairingCodeService.PairingCode code = service.generate("node-1", "127.0.0.1");
        assertNotNull(code);
        assertFalse(code.code.isBlank());
        assertTrue(code.expiresAtMillis > System.currentTimeMillis());
    }

    @Test
    void testConsumeValidCode() {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        PairingCodeService.PairingCode issued = service.generate("node-1", "127.0.0.1");

        var consumed = service.consume(issued.code);
        assertTrue(consumed.isPresent());
        assertEquals("node-1", consumed.get().nodeIdHint);
        assertTrue(consumed.get().used);
    }

    @Test
    void testConsumeInvalidCode() {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        assertTrue(service.consume("does-not-exist").isEmpty());
        assertTrue(service.consume("").isEmpty());
        assertTrue(service.consume(null).isEmpty());
    }

    @Test
    void testConsumeExpiredCode() {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        PairingCodeService.PairingCode expired = service.generate("node-exp", "127.0.0.1", -1);

        assertTrue(service.consume(expired.code).isEmpty());
    }

    @Test
    void testCodeIsSingleUse() {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        PairingCodeService.PairingCode issued = service.generate("node-single", "127.0.0.1");

        assertTrue(service.consume(issued.code).isPresent());
        assertTrue(service.consume(issued.code).isEmpty());
        assertTrue(service.consume(issued.code).isEmpty());
    }

    @Test
    void testConcurrentConsumptionExactlyOneSuccess() throws InterruptedException {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        PairingCodeService.PairingCode issued = service.generate("node-concurrent", "127.0.0.1");

        int threads = 10;
        CountDownLatch latch = new CountDownLatch(threads);
        AtomicInteger successes = new AtomicInteger(0);

        Runnable task = () -> {
            try {
                if (service.consume(issued.code).isPresent()) {
                    successes.incrementAndGet();
                }
            } finally {
                latch.countDown();
            }
        };

        Thread[] workers = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            workers[i] = new Thread(task);
            workers[i].start();
        }
        latch.await();

        assertEquals(1, successes.get(), "exactly one consumer must obtain the single-use code");
    }

    @Test
    void testRevokedCodeCannotBeConsumed() {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        PairingCodeService.PairingCode issued = service.generate("node-revoke", "127.0.0.1");

        service.revoke(issued.code);
        assertTrue(service.consume(issued.code).isEmpty());
    }

    @Test
    void testRateLimiting() {
        PairingCodeService service = new PairingCodeService(10, 3, 10);
        int generated = 0;
        int rateLimited = 0;
        for (int i = 0; i < 5; i++) {
            if (service.generate("node", "127.0.0.1") != null) {
                generated++;
            } else {
                rateLimited++;
            }
        }
        assertEquals(3, generated);
        assertEquals(2, rateLimited);
    }

    @Test
    void testListActiveCodesExcludesUsedAndExpired() {
        PairingCodeService service = new PairingCodeService(10, 100, 10);
        PairingCodeService.PairingCode active = service.generate("node-active", "127.0.0.1");
        PairingCodeService.PairingCode used = service.generate("node-used", "127.0.0.1");
        service.consume(used.code);
        service.generate("node-expired", "127.0.0.1", -1);

        List<PairingCodeService.PairingCodeRecord> codes = List.copyOf(service.activeCodes());
        boolean hasActive = codes.stream().anyMatch(c -> c.code.equals(active.code));
        boolean hasUsed = codes.stream().anyMatch(c -> c.code.equals(used.code));
        assertTrue(hasActive);
        assertFalse(hasUsed);
    }
}
