package com.omni.pcst.master.telemetry;

import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static com.omni.pcst.master.telemetry.TelemetrySequenceTracker.Classification.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic classification tests for {@link TelemetrySequenceTracker}.
 *
 * <p>No sleeps: every assertion follows an explicit {@code observe} call, so a
 * test can never pass merely because an asynchronous step has not run yet.
 */
class TelemetrySequenceTrackerTest {

    private static final String NODE = "node-1";
    private static final String SESSION = "session-a";

    private final TelemetrySequenceTracker tracker = new TelemetrySequenceTracker();

    @Test
    void firstReceivedSequenceInASessionIsClassifiedAsFirst() {
        TelemetrySequenceTracker.Observation first = tracker.observe(NODE, SESSION, 7L);

        assertEquals(FIRST_SEQUENCE, first.classification());
        assertEquals(7L, first.sequence());
        assertEquals(0L, first.gapFrom());
        assertEquals(0L, first.gapTo());
        assertEquals(7L, tracker.highestSequence(NODE, SESSION));
    }

    @Test
    void consecutiveSequencesProduceNoGapDiagnostic() {
        tracker.observe(NODE, SESSION, 1L);

        for (long seq = 2; seq <= 5; seq++) {
            TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, seq);
            assertEquals(CONSECUTIVE, obs.classification(), "sequence " + seq + " must be consecutive");
            assertFalse(obs.isAnomaly(), "sequence " + seq + " must not be an anomaly");
            assertEquals(0L, obs.gapFrom());
            assertEquals(0L, obs.gapTo());
        }

        assertEquals(0L, tracker.getForwardGapCount(), "no gap may be recorded");
    }

    @Test
    void forwardGapIsReportedAsDiscontinuityNotLoss() {
        tracker.observe(NODE, SESSION, 10L);

        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, 12L);

        assertEquals(FORWARD_GAP, obs.classification());
        assertEquals(11L, obs.gapFrom(), "first missing sequence is reported");
        assertEquals(11L, obs.gapTo(), "last missing sequence is reported");
        assertEquals(1L, tracker.getForwardGapCount());
        assertEquals(12L, tracker.highestSequence(NODE, SESSION), "highest advances past the gap");
    }

    @Test
    void wideForwardGapReportsFullMissingInterval() {
        tracker.observe(NODE, SESSION, 1L);

        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, 6L);

        assertEquals(FORWARD_GAP, obs.classification());
        assertEquals(2L, obs.gapFrom());
        assertEquals(5L, obs.gapTo());
    }

    @Test
    void lateArrivalOfAGapSequenceIsDistinguishedFromAnUnfilledGap() {
        tracker.observe(NODE, SESSION, 10L);
        tracker.observe(NODE, SESSION, 12L);   // gap at 11 recorded

        long gapCountBefore = tracker.getForwardGapCount();
        assertEquals(1L, gapCountBefore);

        // 11 arrives late. It is below the highest and was not seen before, so it
        // is reported as an out-of-order arrival rather than as a new gap, and the
        // already-recorded gap is neither duplicated nor extended.
        TelemetrySequenceTracker.Observation late = tracker.observe(NODE, SESSION, 11L);

        assertEquals(OUT_OF_ORDER, late.classification(),
                "a late arrival is not the same as an unfilled gap");
        assertEquals(gapCountBefore, tracker.getForwardGapCount(),
                "a late arrival does not create or duplicate a gap record");
        assertEquals(12L, tracker.highestSequence(NODE, SESSION),
                "the highest observed sequence is unchanged by a late arrival");

        // The stream continues normally afterwards.
        assertEquals(CONSECUTIVE, tracker.observe(NODE, SESSION, 13L).classification());
    }

    @Test
    void duplicateSequenceIsClassifiedAsDuplicate() {
        tracker.observe(NODE, SESSION, 1L);
        tracker.observe(NODE, SESSION, 2L);

        TelemetrySequenceTracker.Observation dup = tracker.observe(NODE, SESSION, 2L);

        assertEquals(DUPLICATE, dup.classification());
        assertEquals(1L, tracker.getDuplicateCount());
        assertEquals(2L, tracker.highestSequence(NODE, SESSION),
                "a duplicate must not corrupt the tracked high-water mark");
    }

    @Test
    void duplicateDoesNotAdvanceTheHighWaterMark() {
        tracker.observe(NODE, SESSION, 5L);
        tracker.observe(NODE, SESSION, 5L);
        tracker.observe(NODE, SESSION, 5L);

        assertEquals(5L, tracker.highestSequence(NODE, SESSION));
        assertEquals(2L, tracker.getDuplicateCount());
    }

    @Test
    void lowerSequenceInSameSessionIsOutOfOrder() {
        tracker.observe(NODE, SESSION, 10L);

        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, 4L);

        assertEquals(OUT_OF_ORDER, obs.classification());
        assertEquals(10L, obs.highestSequence());
        assertEquals(1L, tracker.getOutOfOrderCount());
    }

    @Test
    void newSessionResetsSequencingWithoutBeingReportedAsCorruption() {
        tracker.observe(NODE, SESSION, 10L);
        tracker.observe(NODE, SESSION, 11L);

        long gapsBefore = tracker.getForwardGapCount();
        long duplicatesBefore = tracker.getDuplicateCount();
        long outOfOrderBefore = tracker.getOutOfOrderCount();

        // New process lifetime: a different session id, sequence restarts at 1.
        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, "session-b", 1L);

        assertEquals(SESSION_CHANGED, obs.classification(),
                "a new session is an identity change, not same-session corruption");
        assertEquals(gapsBefore, tracker.getForwardGapCount(), "no gap may be invented by a restart");
        assertEquals(duplicatesBefore, tracker.getDuplicateCount(), "no duplicate may be invented by a restart");
        assertEquals(outOfOrderBefore, tracker.getOutOfOrderCount(), "no out-of-order may be invented by a restart");

        // The new session then behaves like a fresh session.
        assertEquals(CONSECUTIVE, tracker.observe(NODE, "session-b", 2L).classification());
        assertEquals(2L, tracker.highestSequence(NODE, "session-b"));
        assertEquals(11L, tracker.highestSequence(NODE, SESSION),
                "the previous session's state is retained independently");
    }

    @Test
    void invalidMetadataIsDiagnosedNotAccepted() {
        TelemetrySequenceTracker.Observation blank = tracker.observe(NODE, "   ", 5L);
        assertEquals(INVALID_METADATA, blank.classification());
        assertTrue(blank.isAnomaly());

        TelemetrySequenceTracker.Observation zero = tracker.observe(NODE, SESSION, 0L);
        assertEquals(INVALID_METADATA, zero.classification(),
                "a zero sequence is invalid, not a legitimate first sequence");

        TelemetrySequenceTracker.Observation negative = tracker.observe(NODE, SESSION, -3L);
        assertEquals(INVALID_METADATA, negative.classification());

        assertEquals(3L, tracker.getInvalidMetadataCount());
        assertEquals(0L, tracker.highestSequence(NODE, SESSION),
                "invalid metadata must not create sequence state");
    }

    @Test
    void blankNodeIdIsDiagnosed() {
        TelemetrySequenceTracker.Observation obs = tracker.observe("  ", SESSION, 1L);
        assertEquals(INVALID_METADATA, obs.classification());
        assertTrue(obs.isAnomaly());
    }

    @Test
    void absentMetadataIsReportedAsNotReported() {
        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, null, 0L);
        assertEquals(NOT_REPORTED, obs.classification(),
                "an agent that reports no sequence metadata is not malformed");
        assertFalse(obs.isAnomaly());
        assertEquals(1L, tracker.getNotReportedCount());
    }

    @Test
    void differentNodesDoNotInterfere() {
        tracker.observe("node-a", SESSION, 1L);
        tracker.observe("node-a", SESSION, 2L);
        tracker.observe("node-b", SESSION, 1L);

        assertEquals(CONSECUTIVE, tracker.observe("node-a", SESSION, 3L).classification(),
                "node-a continues its own stream");
        assertEquals(FIRST_SEQUENCE, tracker.observe("node-c", SESSION, 9L).classification(),
                "an unseen node starts fresh even with a high sequence");
        assertEquals(3L, tracker.highestSequence("node-a", SESSION));
        assertEquals(1L, tracker.highestSequence("node-b", SESSION));
        assertEquals(9L, tracker.highestSequence("node-c", SESSION));
    }

    @Test
    void differentSessionsOfSameNodeDoNotInterfere() {
        tracker.observe(NODE, "s1", 1L);
        tracker.observe(NODE, "s1", 2L);
        tracker.observe(NODE, "s2", 1L);
        tracker.observe(NODE, "s2", 2L);

        assertEquals(2L, tracker.highestSequence(NODE, "s1"));
        assertEquals(2L, tracker.highestSequence(NODE, "s2"));
        assertEquals(0L, tracker.getForwardGapCount(), "neither session may produce a gap");
    }

    @Test
    void interleavedNodesAndSessionsStayIndependent() {
        tracker.observe("node-a", "s1", 1L);
        tracker.observe("node-b", "s1", 1L);
        tracker.observe("node-a", "s1", 3L);   // gap in a/s1
        tracker.observe("node-b", "s1", 2L);   // consecutive in b/s1

        assertEquals(1L, tracker.getForwardGapCount(), "only node-a's gap is counted");
        // node-a resumes consecutively after its gap; node-b is unaffected.
        assertEquals(CONSECUTIVE, tracker.observe("node-a", "s1", 4L).classification());
        assertEquals(CONSECUTIVE, tracker.observe("node-b", "s1", 3L).classification());
        assertEquals(1L, tracker.getForwardGapCount(), "node-b produced no additional gap");
        assertEquals(4L, tracker.highestSequence("node-a", "s1"));
        assertEquals(3L, tracker.highestSequence("node-b", "s1"));
    }

    @Test
    void unexpectedSequenceDoesNotSilentlyResetTracking() {
        tracker.observe(NODE, SESSION, 10L);
        tracker.observe(NODE, SESSION, 50L);   // large forward gap

        // Tracking must NOT have reset: sequence 11 is still below the high-water
        // mark and is out-of-order, not a fresh first sequence.
        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, 11L);

        assertEquals(OUT_OF_ORDER, obs.classification(),
                "an unexpected sequence must not reset session-scoped tracking");
        assertEquals(50L, tracker.highestSequence(NODE, SESSION));
    }

    @Test
    void registrationSessionChangeIsRecorded() {
        assertFalse(tracker.noteRegistrationSession(NODE, "s1"),
                "first registration is not a change");
        assertTrue(tracker.noteRegistrationSession(NODE, "s2"),
                "a different session id at registration is a restart");
        assertFalse(tracker.noteRegistrationSession(NODE, "s2"),
                "the same session id again is not a change");
        assertEquals("s2", tracker.registeredSession(NODE));
    }

    @Test
    void anomalySummaryReportsEveryCategory() {
        tracker.observe(NODE, SESSION, 1L);
        tracker.observe(NODE, SESSION, 3L);   // gap
        tracker.observe(NODE, SESSION, 3L);   // duplicate
        tracker.observe(NODE, SESSION, 2L);   // out of order
        tracker.observe(NODE, "s2", 1L);      // session changed
        tracker.observe(NODE, "", 1L);        // invalid
        tracker.observe(NODE, null, 0L);      // not reported

        var summary = tracker.anomalySummary();
        assertEquals(1L, summary.get(FORWARD_GAP));
        assertEquals(1L, summary.get(DUPLICATE));
        assertEquals(1L, summary.get(OUT_OF_ORDER));
        assertEquals(1L, summary.get(SESSION_CHANGED));
        assertEquals(1L, summary.get(INVALID_METADATA));
        assertEquals(1L, summary.get(NOT_REPORTED));
    }

    @Test
    void retainedSequenceWindowIsBounded() {
        // A tiny retention window proves duplicate detection is bounded, not unbounded.
        TelemetrySequenceTracker bounded = new TelemetrySequenceTracker(16, 2);
        bounded.observe(NODE, SESSION, 1L);
        bounded.observe(NODE, SESSION, 2L);
        bounded.observe(NODE, SESSION, 3L);

        // 1 has aged out of the 2-entry window, so it is out-of-order, not duplicate.
        assertEquals(OUT_OF_ORDER, bounded.observe(NODE, SESSION, 1L).classification());
        // 3 is still retained, so it is still detected as a duplicate.
        assertEquals(DUPLICATE, bounded.observe(NODE, SESSION, 3L).classification());
    }

    @Test
    void trackedNodeCountIsBounded() {
        TelemetrySequenceTracker bounded = new TelemetrySequenceTracker(4, 16);
        for (int i = 0; i < 50; i++) {
            bounded.observe("node-" + i, SESSION, 1L);
        }
        assertTrue(bounded.trackedNodeCount() <= 4,
                "tracked node count must stay bounded, was " + bounded.trackedNodeCount());
    }

    @Test
    void constructorRejectsInvalidBounds() {
        assertThrows(IllegalArgumentException.class, () -> new TelemetrySequenceTracker(0, 8));
        assertThrows(IllegalArgumentException.class, () -> new TelemetrySequenceTracker(8, 0));
    }

    @Test
    void concurrentObservationDoesNotCorruptTrackerState() throws Exception {
        int threads = 8;
        int perThread = 200;
        TelemetrySequenceTracker concurrent = new TelemetrySequenceTracker(64, 4096);

        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        AtomicInteger invalid = new AtomicInteger();

        try {
            for (int t = 0; t < threads; t++) {
                final int threadIndex = t;
                pool.submit(() -> {
                    try {
                        start.await();
                        for (int i = 1; i <= perThread; i++) {
                            long seq = threadIndex * perThread + i;
                            TelemetrySequenceTracker.Observation obs =
                                    concurrent.observe("node-" + threadIndex, SESSION, seq);
                            if (obs.classification() == INVALID_METADATA) {
                                invalid.incrementAndGet();
                            }
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } finally {
                        done.countDown();
                    }
                });
            }
            start.countDown();
            assertTrue(done.await(30, TimeUnit.SECONDS), "all writers finished");
        } finally {
            pool.shutdown();
            assertTrue(pool.awaitTermination(30, TimeUnit.SECONDS));
        }

        assertEquals(0, invalid.get(), "no valid metadata may be misreported as invalid");

        // Every node must end at exactly its own last sequence: no lost updates
        // and no cross-node contamination despite fully concurrent observation.
        for (int t = 0; t < threads; t++) {
            long expectedHighest = threadIndexHighest(t, perThread);
            assertEquals(expectedHighest, concurrent.highestSequence("node-" + t, SESSION),
                    "node-" + t + " high-water mark is exact");
        }
    }

    /** Each thread observes the disjoint block [t*perThread+1, (t+1)*perThread]. */
    private static long threadIndexHighest(int threadIndex, int perThread) {
        return (long) (threadIndex + 1) * perThread;
    }

    @Test
    void resetClearsTrackedState() {
        tracker.observe(NODE, SESSION, 5L);
        tracker.reset();
        assertEquals(0, tracker.trackedNodeCount());
        assertEquals(0L, tracker.highestSequence(NODE, SESSION));
        assertEquals(FIRST_SEQUENCE, tracker.observe(NODE, SESSION, 9L).classification());
    }

    @Test
    void observationsAreImmutableValueObjects() {
        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, 3L);
        assertEquals(NODE, obs.nodeId());
        assertEquals(SESSION, obs.sessionId());
        assertEquals(3L, obs.sequence());
        assertEquals(FIRST_SEQUENCE, obs.classification());
        assertFalse(obs.isAnomaly(), "a first sequence is not an anomaly");
    }
}