package com.omni.pcst.master.execution;

import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.PcstMasterApplication;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskClass;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import com.omni.pcst.master.task.TaskValidationException;
import com.omni.pcst.proto.CpuTelemetry;
import com.omni.pcst.proto.DiskTelemetry;
import com.omni.pcst.proto.MemoryTelemetry;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.ProcessTelemetry;
import com.omni.pcst.proto.TaskDispatchRequest;
import com.omni.pcst.proto.TaskDispatchResponse;
import com.omni.pcst.proto.TaskLifecycleUpdate;
import com.omni.pcst.proto.TaskLifecycleAck;
import com.omni.pcst.proto.TaskResult;
import com.omni.pcst.proto.TelemetryRequest;
import com.omni.pcst.proto.TelemetryResponse;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.*;

/**
 * End-to-end integration tests for the complete task lifecycle:
 * submission -> scheduling -> dispatch -> agent execution -> result reporting ->
 * authoritative task state reflected through the dashboard API.
 *
 * <p>The fake agent is a local gRPC server on localhost that implements the dispatch
 * side of the {@link NodeServiceGrpc} contract and reports lifecycle updates back to
 * the Master over a real plaintext channel. No sockets leave the test machine, and no
 * arbitrary code, uploaded JARs, or user-supplied scripts are executed on the agent --
 * only the built-in {@code NO_OP} workload is used.
 */
@SpringBootTest(
        classes = PcstMasterApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {
                "grpc.server.port=19090",
                "pcst.execution.dispatch-timeout-ms=800"
        }
)
class TaskExecutionIntegrationTest {

    @LocalServerPort
    private int restPort;

    @Autowired
    private TaskExecutionCoordinator coordinator;

    @Autowired
    private TaskRegistry taskRegistry;

    @Autowired
    private DigitalTwinManager digitalTwinManager;

    @Autowired
    private TestRestTemplate rest;

    private FakeAgent agent;
    private ManagedChannel channelToMaster;

    @BeforeEach
    void setUp() throws Exception {
        channelToMaster = ManagedChannelBuilder.forAddress("localhost", 19090)
                .usePlaintext().build();
    }

    @AfterEach
    void tearDown() throws Exception {
        if (agent != null) {
            agent.stop();
            agent = null;
        }
        if (channelToMaster != null) {
            channelToMaster.shutdown();
            channelToMaster.awaitTermination(5, TimeUnit.SECONDS);
            channelToMaster = null;
        }
        // Reset shared in-memory state so tests are independent regardless of order.
        digitalTwinManager.removeNode("node-1");
        taskRegistry.all().forEach(r -> taskRegistry.remove(r.taskId()));
    }

    /**
     * Starts a local fake agent and registers node-1 with the Master's Digital Twin,
     * so the scheduler has an eligible connected node to select.
     */
    private void startNode1() throws Exception {
        agent = new FakeAgent("node-1");
        agent.start();
        digitalTwinManager.onNodeRegistered("node-1", "localhost", agent.port(), "0.1.0",
                System.currentTimeMillis());
    }

    // ------------------------------------------------------------------ helpers

    private static Task minimalTask(String taskId) {
        return Task.builder(taskId)
                .taskClass(TaskClass.UNSPECIFIED)
                .workloadReference("NO_OP")
                .inputCharacteristics("")
                .resources(TaskResources.NONE)
                .constraints(TaskConstraints.NONE)
                .build();
    }

    private static void assertEventually(String description, int timeoutMillis,
                                         BooleanSupplier condition) {
        long deadline = System.currentTimeMillis() + timeoutMillis;
        AssertionError last = null;
        while (System.currentTimeMillis() < deadline) {
            try {
                if (condition.getAsBoolean()) {
                    return;
                }
            } catch (AssertionError e) {
                last = e;
            }
            try {
                Thread.sleep(10L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new AssertionError("Interrupted waiting for: " + description, e);
            }
        }
        throw new AssertionError("Timed out after " + timeoutMillis + " ms waiting for: " + description, last);
    }

    private boolean reportLifecycleAck(String taskId, String attemptId, com.omni.pcst.proto.TaskState state,
                                       TaskResult result) {
        TaskLifecycleUpdate update = TaskLifecycleUpdate.newBuilder()
                .setTaskId(taskId)
                .setAttemptId(attemptId)
                .setNodeId("node-1")
                .setState(state)
                .setTimestamp(System.currentTimeMillis())
                .setMessage("agent report")
                .setResult(result != null ? result : TaskResult.getDefaultInstance())
                .build();
        TaskLifecycleAck ack = NodeServiceGrpc.newBlockingStub(channelToMaster)
                .reportTaskLifecycle(update);
        return ack.getAccepted();
    }

    private void reportLifecycle(String taskId, String attemptId, com.omni.pcst.proto.TaskState state,
                                 TaskResult result) {
        assertTrue(reportLifecycleAck(taskId, attemptId, state, result),
                "lifecycle update must be accepted by Master");
    }

    /**
     * Reports a fresh telemetry snapshot for a registered node through the real
     * gRPC ingestion path, so the digital twin holds current evidence.
     */
    private void reportFreshTelemetry(String nodeId) {
        TelemetryRequest request = TelemetryRequest.newBuilder()
                .setNodeId(nodeId)
                .setTimestamp(System.currentTimeMillis())
                .setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(12.5).build())
                .setMemory(MemoryTelemetry.newBuilder()
                        .setTotalBytes(16L * 1024 * 1024 * 1024)
                        .setUsedBytes(4L * 1024 * 1024 * 1024)
                        .setAvailableBytes(12L * 1024 * 1024 * 1024)
                        .build())
                .setDisk(DiskTelemetry.newBuilder()
                        .setTotalBytes(512L * 1024 * 1024 * 1024)
                        .setFreeBytes(256L * 1024 * 1024 * 1024)
                        .build())
                .setProcesses(ProcessTelemetry.newBuilder().setProcessCount(42).build())
                .build();
        TelemetryResponse response = NodeServiceGrpc.newBlockingStub(channelToMaster)
                .reportTelemetry(request);
        assertTrue(response.getAccepted(), "fresh telemetry must be accepted by Master");
    }

    /** Builds the exact resource/constraint object the dashboard submit handler sends. */
    private static Map<String, Object> dashboardStylePayload(String taskId, String workload) {
        Map<String, Object> payload = new java.util.LinkedHashMap<>();
        payload.put("taskId", taskId);
        payload.put("taskClass", "NETWORK_BOUND");
        payload.put("workloadReference", workload);
        payload.put("inputCharacteristics", "");
        payload.put("expectedDurationMillis", 60000);

        Map<String, Object> resources = new java.util.LinkedHashMap<>();
        resources.put("requiredMemoryBytes", null);
        resources.put("requiredStorageBytes", null);
        resources.put("acceleratorRequired", false);
        resources.put("requiredAcceleratorMemoryBytes", null);
        resources.put("requiredComputeUnits", null);
        payload.put("resources", resources);

        Map<String, Object> constraints = new java.util.LinkedHashMap<>();
        constraints.put("deadlineEpochMillis", null);
        constraints.put("expectedDurationMillis", null);
        constraints.put("minimumBatteryPercent", null);
        constraints.put("maximumNetworkLatencyMillis", null);
        constraints.put("maximumPacketLossPercent", null);
        constraints.put("interruptionTolerance", null);
        constraints.put("requiredExecutionProfile", null);
        payload.put("constraints", constraints);
        return payload;
    }

    /**
     * Reports the realistic agent lifecycle: dispatch accepted, execution started,
     * then the terminal outcome. Mirrors what a real Node Agent sends.
     */
    private void reportExecutionLifecycle(String taskId, String attemptId, TaskResult result) {
        reportLifecycle(taskId, attemptId, com.omni.pcst.proto.TaskState.ACCEPTED, null);
        reportLifecycle(taskId, attemptId, com.omni.pcst.proto.TaskState.RUNNING, null);
        com.omni.pcst.proto.TaskState terminal = result.getSuccess()
                ? com.omni.pcst.proto.TaskState.SUCCEEDED
                : com.omni.pcst.proto.TaskState.FAILED;
        reportLifecycle(taskId, attemptId, terminal, result);
    }

    private void waitForState(String taskId, TaskState expected, int timeoutMillis) {
        assertEventually("task " + taskId + " reaches " + expected, timeoutMillis, () ->
                coordinator.getTask(taskId)
                        .map(r -> r.state() == expected)
                        .orElse(false));
    }

    // ------------------------------------------------------------------ success path

    @Test
    void validTaskSubmittedExecutedAndResultReflectedOnDashboard() throws Exception {
        String taskId = "task-success-1";
        startNode1();
        TaskRecord record = coordinator.submitTask(minimalTask(taskId));
        assertEquals(TaskState.ACCEPTED, record.state());

        // The agent receives the dispatch.
        TaskDispatchRequest dispatch = agent.nextDispatch(5000);
        assertEquals(taskId, dispatch.getTaskId());
        assertEquals("NO_OP", dispatch.getWorkloadType());

        // Agent executes NO_OP locally and reports success with the actual result.
        TaskResult success = TaskResult.newBuilder()
                .setSuccess(true)
                .setOutput("NO_OP completed")
                .setDurationMillis(5)
                .build();
        reportExecutionLifecycle(taskId, dispatch.getAttemptId(), success);

        waitForState(taskId, TaskState.SUCCEEDED, 5000);

        TaskRecord finalRecord = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.SUCCEEDED, finalRecord.state());
        assertNotNull(finalRecord.result());
        assertTrue(finalRecord.result().getSuccess());
        assertEquals("NO_OP completed", finalRecord.result().getOutput());
        assertEquals("node-1", finalRecord.selectedNodeId());

        // Dashboard/API (REST) reflects the same authoritative final state.
        ResponseEntity<Map> get = rest.getForEntity("/api/v1/tasks/{taskId}", Map.class, taskId);
        assertEquals(HttpStatus.OK, get.getStatusCode());
        assertEquals("SUCCEEDED", get.getBody().get("state"));
        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) get.getBody().get("result");
        assertNotNull(result);
        assertEquals(true, result.get("success"));
    }

    // ------------------------------------------------------------------ failure path

    @Test
    void executionFailureReportedAndRecorded() throws Exception {
        String taskId = "task-failure-1";
        startNode1();
        coordinator.submitTask(minimalTask(taskId));

        TaskDispatchRequest dispatch = agent.nextDispatch(5000);

        // Agent reports that execution failed, carrying the error detail.
        TaskResult failure = TaskResult.newBuilder()
                .setSuccess(false)
                .setError("workload threw an exception")
                .setDurationMillis(0)
                .build();
        reportExecutionLifecycle(taskId, dispatch.getAttemptId(), failure);

        waitForState(taskId, TaskState.FAILED, 5000);

        TaskRecord finalRecord = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.FAILED, finalRecord.state());
        assertNotNull(finalRecord.result());
        assertFalse(finalRecord.result().getSuccess());
        assertEquals("workload threw an exception", finalRecord.result().getError());
        assertEquals("workload threw an exception", finalRecord.errorMessage());
    }

    // ------------------------------------------------------------------ no eligible node

    @Test
    void noEligibleNodeLeadsToTerminalNoFeasibleNode() throws Exception {
        // No node is registered, so scheduling cannot select an eligible node.
        String taskId = "task-no-node-1";
        TaskRecord record = coordinator.submitTask(minimalTask(taskId));
        assertEquals(TaskState.ACCEPTED, record.state());

        waitForState(taskId, TaskState.NO_FEASIBLE_NODE, 5000);

        TaskRecord finalRecord = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.NO_FEASIBLE_NODE, finalRecord.state());
        assertNull(finalRecord.selectedNodeId());
        assertTrue(finalRecord.isTerminal());
    }

    // ------------------------------------------------------------------ node disconnect during execution

    @Test
    void nodeDisconnectDuringExecutionLeadsToOutcomeUnknown() throws Exception {
        String taskId = "task-disconnect-1";
        startNode1();
        coordinator.submitTask(minimalTask(taskId));

        // Agent accepts the dispatch but never reports a terminal outcome.
        agent.nextDispatch(5000);

        // Wait for the dispatch timeout (800 ms) to convert the in-flight dispatch
        // into OUTCOME_UNKNOWN since the agent never reported.
        waitForState(taskId, TaskState.OUTCOME_UNKNOWN, 5000);

        TaskRecord finalRecord = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.OUTCOME_UNKNOWN, finalRecord.state());
        assertTrue(finalRecord.isTerminal());
        assertNotNull(finalRecord.errorMessage());
    }

    // ------------------------------------------------------------------ duplicate result handling

    @Test
    void duplicateResultDoesNotCorruptTerminalState() throws Exception {
        String taskId = "task-duplicate-1";
        startNode1();
        coordinator.submitTask(minimalTask(taskId));

        TaskDispatchRequest dispatch = agent.nextDispatch(5000);

        TaskResult success = TaskResult.newBuilder()
                .setSuccess(true)
                .setOutput("NO_OP completed")
                .setDurationMillis(5)
                .build();
        reportExecutionLifecycle(taskId, dispatch.getAttemptId(), success);

        waitForState(taskId, TaskState.SUCCEEDED, 5000);

        // A duplicate SUCCEEDED for an already-terminal task must be rejected without
        // changing the authoritative state.
        TaskLifecycleUpdate duplicate = TaskLifecycleUpdate.newBuilder()
                .setTaskId(taskId)
                .setAttemptId(dispatch.getAttemptId())
                .setNodeId("node-1")
                .setState(com.omni.pcst.proto.TaskState.SUCCEEDED)
                .setTimestamp(System.currentTimeMillis())
                .setMessage("duplicate agent report")
                .setResult(success)
                .build();
        TaskLifecycleAck duplicateAck = NodeServiceGrpc.newBlockingStub(channelToMaster)
                .reportTaskLifecycle(duplicate);
        assertFalse(duplicateAck.getAccepted(), "duplicate terminal lifecycle update must be rejected");

        TaskRecord finalRecord = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.SUCCEEDED, finalRecord.state());
        assertEquals("NO_OP completed", finalRecord.result().getOutput());
        assertEquals(1, countTransitionsTo(finalRecord, TaskState.SUCCEEDED));
    }

    // ------------------------------------------------------------------ dashboard payload / optional requirements

    @Test
    void dashboardStyleSubmissionSchedulesOnNodeWithFreshTelemetry() throws Exception {
        String taskId = "task-dashboard-1";
        startNode1();
        reportFreshTelemetry("node-1");

        // Exact payload shape produced by the dashboard submit handler: every
        // optional resource/constraint value is absent (null).
        ResponseEntity<Map> submitted = rest.postForEntity("/api/v1/tasks",
                dashboardStylePayload(taskId, "NO_OP"), Map.class);
        assertEquals(HttpStatus.ACCEPTED, submitted.getStatusCode());

        TaskDispatchRequest dispatch = agent.nextDispatch(5000);
        assertEquals(taskId, dispatch.getTaskId());
        assertEquals("NO_OP", dispatch.getWorkloadType());

        TaskResult success = TaskResult.newBuilder()
                .setSuccess(true).setOutput("NO_OP completed").setDurationMillis(2).build();
        reportExecutionLifecycle(taskId, dispatch.getAttemptId(), success);

        waitForState(taskId, TaskState.SUCCEEDED, 5000);
        TaskRecord finalRecord = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.SUCCEEDED, finalRecord.state());
        assertEquals("node-1", finalRecord.selectedNodeId());
        assertEquals("NO_OP completed", finalRecord.result().getOutput());
    }

    @Test
    void explicitAcceleratorMemoryRequirementRemainsIndeterminate() throws Exception {
        String taskId = "task-accel-mem-1";
        startNode1();
        reportFreshTelemetry("node-1");

        Map<String, Object> payload = dashboardStylePayload(taskId, "NO_OP");
        @SuppressWarnings("unchecked")
        Map<String, Object> resources = (Map<String, Object>) payload.get("resources");
        resources.put("requiredAcceleratorMemoryBytes", 1024L);

        ResponseEntity<Map> submitted = rest.postForEntity("/api/v1/tasks", payload, Map.class);
        assertEquals(HttpStatus.ACCEPTED, submitted.getStatusCode());

        // An explicitly requested accelerator-memory requirement is genuinely
        // unverifiable on the current node model, so the node must be excluded
        // rather than silently approved.
        waitForState(taskId, TaskState.NO_FEASIBLE_NODE, 5000);

        ResponseEntity<Map> decision = rest.getForEntity("/api/v1/tasks/{taskId}/decision", Map.class, taskId);
        assertEquals(HttpStatus.OK, decision.getStatusCode());
        assertEquals("NO_FEASIBLE_NODE", decision.getBody().get("status"));
        @SuppressWarnings("unchecked")
        java.util.List<Map<String, Object>> candidates =
                (java.util.List<Map<String, Object>>) decision.getBody().get("candidates");
        assertEquals(1, candidates.size());
        Map<String, Object> candidate = candidates.get(0);
        assertEquals("node-1", candidate.get("nodeId"));
        assertEquals(false, candidate.get("eligible"));
        @SuppressWarnings("unchecked")
        java.util.List<String> reasons = (java.util.List<String>) candidate.get("rejectionReasons");
        assertNotNull(reasons);
        assertTrue(reasons.contains("ACCELERATOR_MEMORY_UNVERIFIABLE"),
                "candidate must report the actual rejection reason, was " + reasons);
    }

    // ------------------------------------------------------------------ lifecycle ordering

    @Test
    void fastNoOpTerminalResultBeforeRunningUpdateIsRetained() throws Exception {
        String taskId = "task-noop-race-1";
        startNode1();
        coordinator.submitTask(minimalTask(taskId));
        TaskDispatchRequest dispatch = agent.nextDispatch(5000);

        TaskResult success = TaskResult.newBuilder()
                .setSuccess(true).setOutput("NO_OP completed").setDurationMillis(1).build();

        // A fast workload can complete before the agent's ACCEPTED/RUNNING updates
        // are observed by the Master. The terminal result must still be accepted.
        assertTrue(reportLifecycleAck(taskId, dispatch.getAttemptId(),
                com.omni.pcst.proto.TaskState.SUCCEEDED, success));
        // Late non-terminal updates must not move the terminal task backwards.
        assertFalse(reportLifecycleAck(taskId, dispatch.getAttemptId(),
                com.omni.pcst.proto.TaskState.ACCEPTED, null));
        assertFalse(reportLifecycleAck(taskId, dispatch.getAttemptId(),
                com.omni.pcst.proto.TaskState.RUNNING, null));

        waitForState(taskId, TaskState.SUCCEEDED, 5000);
        TaskRecord record = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.SUCCEEDED, record.state());
        assertEquals("NO_OP completed", record.result().getOutput());
        assertEquals(1, countTransitionsTo(record, TaskState.SUCCEEDED));
    }

    @Test
    void computeTaskReachesSucceeded() throws Exception {
        String taskId = "task-compute-1";
        startNode1();
        coordinator.submitTask(Task.builder(taskId)
                .taskClass(TaskClass.CPU_BOUND)
                .workloadReference("COMPUTE")
                .inputCharacteristics("1000")
                .resources(TaskResources.NONE)
                .constraints(TaskConstraints.NONE)
                .build());
        TaskDispatchRequest dispatch = agent.nextDispatch(5000);
        assertEquals("COMPUTE", dispatch.getWorkloadType());

        TaskResult success = TaskResult.newBuilder()
                .setSuccess(true).setOutput("sum= 500500 (iterations=1000)").setDurationMillis(4).build();
        reportExecutionLifecycle(taskId, dispatch.getAttemptId(), success);

        waitForState(taskId, TaskState.SUCCEEDED, 5000);
        TaskRecord record = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.SUCCEEDED, record.state());
        assertTrue(record.result().getOutput().contains("iterations=1000"));
    }

    @Test
    void sleepTaskReachesSucceededAfterCompletion() throws Exception {
        String taskId = "task-sleep-1";
        startNode1();
        coordinator.submitTask(Task.builder(taskId)
                .taskClass(TaskClass.UNSPECIFIED)
                .workloadReference("SLEEP")
                .inputCharacteristics("150")
                .resources(TaskResources.NONE)
                .constraints(TaskConstraints.NONE)
                .build());
        TaskDispatchRequest dispatch = agent.nextDispatch(5000);
        assertEquals("SLEEP", dispatch.getWorkloadType());

        reportLifecycle(taskId, dispatch.getAttemptId(), com.omni.pcst.proto.TaskState.ACCEPTED, null);
        reportLifecycle(taskId, dispatch.getAttemptId(), com.omni.pcst.proto.TaskState.RUNNING, null);
        waitForState(taskId, TaskState.RUNNING, 5000);
        Thread.sleep(150);

        TaskResult success = TaskResult.newBuilder()
                .setSuccess(true).setOutput("slept 150 ms").setDurationMillis(150).build();
        reportLifecycle(taskId, dispatch.getAttemptId(), com.omni.pcst.proto.TaskState.SUCCEEDED, success);

        waitForState(taskId, TaskState.SUCCEEDED, 5000);
        TaskRecord record = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.SUCCEEDED, record.state());
        assertEquals("slept 150 ms", record.result().getOutput());
    }

    @Test
    void executionFailureReachesFailedAndLateRunningIsRejected() throws Exception {
        String taskId = "task-failed-late-1";
        startNode1();
        coordinator.submitTask(minimalTask(taskId));
        TaskDispatchRequest dispatch = agent.nextDispatch(5000);

        TaskResult failure = TaskResult.newBuilder()
                .setSuccess(false).setError("workload threw an exception").setDurationMillis(0).build();
        reportExecutionLifecycle(taskId, dispatch.getAttemptId(), failure);

        waitForState(taskId, TaskState.FAILED, 5000);
        // A late RUNNING update must not move the terminal FAILED task backwards.
        assertFalse(reportLifecycleAck(taskId, dispatch.getAttemptId(),
                com.omni.pcst.proto.TaskState.RUNNING, null));

        TaskRecord record = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.FAILED, record.state());
        assertFalse(record.result().getSuccess());
        assertEquals("workload threw an exception", record.result().getError());
        assertEquals("workload threw an exception", record.errorMessage());
    }

    @Test
    void duplicateTerminalResultDoesNotOverwriteAuthoritativeResult() throws Exception {
        String taskId = "task-duplicate-result-1";
        startNode1();
        coordinator.submitTask(minimalTask(taskId));
        TaskDispatchRequest dispatch = agent.nextDispatch(5000);

        TaskResult first = TaskResult.newBuilder()
                .setSuccess(true).setOutput("first result").setDurationMillis(1).build();
        reportExecutionLifecycle(taskId, dispatch.getAttemptId(), first);
        waitForState(taskId, TaskState.SUCCEEDED, 5000);

        TaskResult conflicting = TaskResult.newBuilder()
                .setSuccess(false).setError("conflicting duplicate").setDurationMillis(9).build();
        assertFalse(reportLifecycleAck(taskId, dispatch.getAttemptId(),
                com.omni.pcst.proto.TaskState.SUCCEEDED, conflicting));

        TaskRecord record = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.SUCCEEDED, record.state());
        assertEquals("first result", record.result().getOutput());
        assertEquals(1, countTransitionsTo(record, TaskState.SUCCEEDED));
    }

    // ------------------------------------------------------------------ failed scheduling decision retention

    @Test
    void noFeasibleNodeRetainsDecisionTrace() throws Exception {
        String taskId = "task-decision-trace-1";
        coordinator.submitTask(minimalTask(taskId));
        waitForState(taskId, TaskState.NO_FEASIBLE_NODE, 5000);

        TaskRecord record = coordinator.getTask(taskId).orElseThrow();
        assertEquals(TaskState.NO_FEASIBLE_NODE, record.state());
        assertNotNull(record.schedulingDecision());
        assertEquals("NO_FEASIBLE_NODE", record.schedulingDecision().status().name());

        ResponseEntity<Map> decision = rest.getForEntity("/api/v1/tasks/{taskId}/decision", Map.class, taskId);
        assertEquals(HttpStatus.OK, decision.getStatusCode());
        assertEquals("NO_FEASIBLE_NODE", decision.getBody().get("status"));
        @SuppressWarnings("unchecked")
        java.util.List<String> reasons = (java.util.List<String>) decision.getBody().get("reasons");
        assertNotNull(reasons);
        assertTrue(reasons.contains("NO_CANDIDATE_PASSED_HARD_ELIGIBILITY"));
    }

    // ------------------------------------------------------------------ validation / invalid request

    @Test
    void nullTaskClassIsRejected() {
        assertThrows(TaskValidationException.class, () ->
                coordinator.submitTask(Task.builder("dup").taskClass(null)
                        .workloadReference("NO_OP")
                        .resources(TaskResources.NONE)
                        .constraints(TaskConstraints.NONE).build()));
    }

    @Test
    void invalidTaskClassViaRestIsRejected() {
        ResponseEntity<String> post = rest.postForEntity("/api/v1/tasks",
                Map.of("taskId", "task-bad-class", "taskClass", "NOT_A_CLASS",
                        "workloadReference", "NO_OP"), String.class);
        assertEquals(HttpStatus.BAD_REQUEST, post.getStatusCode());
    }

    // ------------------------------------------------------------------ helper

    private int countTransitionsTo(TaskRecord record, TaskState target) {
        int count = 0;
        for (TaskRecord.StateTransition t : record.history()) {
            if (t.to() == target) {
                count++;
            }
        }
        return count;
    }

    // ------------------------------------------------------------------ fake agent

    /**
     * A controlled local fake Node Agent. It implements the dispatch RPC, records
     * incoming dispatches, and reports lifecycle outcomes back to the Master over a
     * real channel. It only ever relays the built-in NO_OP workload -- no arbitrary
     * code execution.
     */
    private static class FakeAgent {
        private final String nodeId;
        private Server server;
        private int port;
        private final AtomicReference<TaskDispatchRequest> lastDispatch = new AtomicReference<>();

        FakeAgent(String nodeId) {
            this.nodeId = nodeId;
        }

        void start() throws Exception {
            NodeServiceGrpc.NodeServiceImplBase service = new NodeServiceGrpc.NodeServiceImplBase() {
                @Override
                public void dispatchTask(TaskDispatchRequest request,
                                         StreamObserver<TaskDispatchResponse> responseObserver) {
                    lastDispatch.set(request);
                    responseObserver.onNext(TaskDispatchResponse.newBuilder()
                            .setAccepted(true)
                            .setMessage("dispatch accepted")
                            .setServerTime(System.currentTimeMillis())
                            .build());
                    responseObserver.onCompleted();
                }
            };
            server = ServerBuilder.forPort(0)
                    .addService(service)
                    .build()
                    .start();
            port = server.getPort();
        }

        void stop() {
            if (server != null) {
                server.shutdownNow();
            }
        }

        int port() {
            return port;
        }

        TaskDispatchRequest nextDispatch(int timeoutMillis) throws Exception {
            long deadline = System.currentTimeMillis() + timeoutMillis;
            while (System.currentTimeMillis() < deadline) {
                TaskDispatchRequest req = lastDispatch.getAndSet(null);
                if (req != null) {
                    return req;
                }
                Thread.sleep(10L);
            }
            throw new AssertionError("No dispatch received within " + timeoutMillis + " ms");
        }
    }
}
