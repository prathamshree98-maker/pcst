package com.omni.pcst.master.evaluation;

import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic persistence tests for the evaluation telemetry log (5E.1).
 *
 * <p>No hardware, no network, no sleeps. Concurrency tests use latches and
 * thread pools with bounded joins.
 */
class TelemetryEvaluationStoreTest {

    @TempDir
    Path tempDir;

    private static TelemetryObservation observation(long ts, Double cpu,
                                                    Long totalMem, Long usedMem) {
        return new TelemetryObservation(ts, cpu, totalMem, usedMem, null,
                null, null, null, null, null, null, null, null, null, null, null);
    }

    private static TelemetryEvaluationRecord record(long ts) {
        return TelemetryEvaluationRecord.of("node-" + ts, observation(ts, 1.0, 1024L, 512L), ts + 1, "v1");
    }

    @Test
    void roundTripPreservesValuesUnitsTimestampsNull() throws Exception {
        Path file = tempDir.resolve("eval.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 2);
        TelemetryObservation obs = observation(100L, 42.0, 1024L, 512L);
        TelemetryEvaluationRecord rec = TelemetryEvaluationRecord.of("node-a", obs, 999L, "v1");
        store.append(rec);
        store.flush();

        assertTrue(Files.exists(file));
        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size());
        assertEquals("node-a", read.get(0).nodeId());
        assertEquals(100L, read.get(0).observationTimestamp());
        assertEquals(42.0, read.get(0).observation().cpuUtilizationPercent(), 1e-9);
        assertEquals(1024L, read.get(0).observation().totalMemoryBytes());
        assertEquals(512L, read.get(0).observation().usedMemoryBytes());
        assertTrue(read.get(0).validForReplay());
        assertEquals("v1", read.get(0).collectionConfigVersion());
    }

    @Test
    void legitimateZeroPreservedNotConvertedToNull() throws Exception {
        Path file = tempDir.resolve("zero.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file);
        TelemetryObservation obs = observation(200L, 0.0, 1024L, 0L);
        store.append(TelemetryEvaluationRecord.of("n", obs, 200L, "v1"));
        store.flush();
        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size());
        assertEquals(0.0, read.get(0).observation().cpuUtilizationPercent(), 1e-9,
                "explicit zero must stay zero");
        assertEquals(0L, read.get(0).observation().usedMemoryBytes());
    }

    @Test
    void missingMeasurementDistinctFromZero() throws Exception {
        Path file = tempDir.resolve("missing.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file);
        TelemetryObservation obs = observation(300L, null, 1024L, 512L);
        store.append(TelemetryEvaluationRecord.of("n", obs, 300L, "v1"));
        store.flush();
        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size());
        assertNull(read.get(0).observation().cpuUtilizationPercent(), "null stays null");
    }

    @Test
    void outOfOrderArrivalStillReadableInEventOrder() throws Exception {
        Path file = tempDir.resolve("ooo.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file);
        store.append(TelemetryEvaluationRecord.of("n", observation(200L, 20.0, 1024L, 512L), 210L, "v1"));
        store.append(TelemetryEvaluationRecord.of("n", observation(100L, 10.0, 1024L, 512L), 110L, "v1"));
        store.flush();
        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(2, read.size());
        assertEquals(100L, read.get(0).observationTimestamp(), "readAll orders by event time");
        assertEquals(200L, read.get(1).observationTimestamp());
    }

    @Test
    void duplicateRecordsPreservedNotCollapsed() throws Exception {
        Path file = tempDir.resolve("dup.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file);
        TelemetryObservation o = observation(100L, 10.0, 1024L, 512L);
        store.append(TelemetryEvaluationRecord.of("n", o, 101L, "v1"));
        store.append(TelemetryEvaluationRecord.of("n", o, 102L, "v1"));
        store.flush();
        List<String> lines = Files.readAllLines(file);
        long nonEmpty = lines.stream().filter(l -> !l.trim().isEmpty()).count();
        assertEquals(2, nonEmpty, "duplicate observations are retained");
    }

    @Test
    void restartReopensPreviouslyWrittenRecords() throws Exception {
        Path file = tempDir.resolve("restart.jsonl");
        TelemetryEvaluationStore store1 = new TelemetryEvaluationStore(file);
        store1.append(TelemetryEvaluationRecord.of("n", observation(50L, 5.0, 1024L, 512L), 55L, "v1"));
        store1.flush();
        store1.close();

        TelemetryEvaluationStore store2 = new TelemetryEvaluationStore(file);
        assertTrue(Files.size(file) > 0, "previous records preserved across restart");
        assertEquals(1, store2.readAll().size());
    }

    @Test
    void nonFiniteMeasurementRecordedNotSilentlyDropped() throws Exception {
        Path file = tempDir.resolve("bad.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file);
        TelemetryObservation obs = observation(100L, Double.NaN, 1024L, 512L);
        store.append(TelemetryEvaluationRecord.of("n", obs, 101L, "v1"));
        store.flush();
        assertTrue(Files.size(file) > 0, "invalid measurement preserved for diagnosis");
    }

    @Test
    void configurableOutputPathCreatesParentDirectories() throws Exception {
        Path file = tempDir.resolve("subdir").resolve("eval.jsonl");
        assertFalse(Files.exists(file.getParent()));
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1);
        store.append(TelemetryEvaluationRecord.of("n", observation(100L, 1.0, 1024L, 512L), 101L, "v1"));
        assertTrue(Files.exists(file), "flush created the missing parent directory");
    }

    @Test
    void countersDistinguishAcceptedFromPersisted() throws Exception {
        Path file = tempDir.resolve("counters.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 100);
        store.append(record(1L));
        store.append(record(2L));
        assertEquals(2, store.getAcceptedRecords(), "accepted before flush");
        assertEquals(0, store.getPersistedRecords(), "accepted does not mean persisted");
        store.flush();
        assertEquals(2, store.getPersistedRecords());
        assertEquals(0, store.getQueueSize());
    }

    @Test
    void queueCapacityOverflowIsObservable() throws Exception {
        Path dir = tempDir.resolve("overflow-dir");
        Files.createDirectories(dir);
        // Output path is a directory, so every flush fails and the bounded queue fills.
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(dir, 2, 5);
        for (long i = 0; i < 20; i++) {
            store.append(record(i));
        }
        assertTrue(store.getRejectedRecords() > 0, "overflow must be counted");
        assertTrue(store.getLastWriteError() != null && store.getLastWriteError().contains("overflow"),
                "overflow must be visible: " + store.getLastWriteError());
        assertTrue(store.getQueueSize() <= store.getQueueCapacity());
    }

    @Test
    void writeFailureIsObservableAndUnwrittenRecordsRetained() throws Exception {
        Path dir = tempDir.resolve("fail-dir");
        Files.createDirectories(dir);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(dir, 10);
        store.append(record(1L));
        store.append(record(2L));
        store.flush();

        assertNotNull(store.getLastWriteError(), "flush failure must be exposed");
        assertEquals(0, store.getPersistedRecords());
        assertEquals(2, store.getQueueSize(), "unwritten records are retained, not discarded");
        assertTrue(store.getFlushFailures() >= 1);
    }

    @Test
    void thresholdFlushTriggersAtConfiguredLimit() throws Exception {
        Path file = tempDir.resolve("flush.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 2, 2);
        store.append(record(10L));
        assertEquals(0, store.getPersistedRecords(), "below threshold: nothing written");
        store.append(record(20L));
        assertEquals(2, store.getPersistedRecords(), "threshold reached: flushed synchronously");
        assertEquals(0, store.getQueueSize());
    }

    @Test
    void closeDrainsQueuedRecords() throws Exception {
        Path file = tempDir.resolve("close.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10);
        store.append(record(100L));
        assertEquals(1, store.getQueueSize(), "below threshold: still queued");
        store.close();
        assertEquals(0, store.getQueueSize(), "close drained the queue");
        assertEquals(1, store.getPersistedRecords());
        assertTrue(Files.readString(file).contains("\"nodeId\""));
    }

    @Test
    void appendAfterCloseRejected() throws Exception {
        Path file = tempDir.resolve("afterclose.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10);
        store.close();
        assertThrows(IllegalStateException.class, () -> store.append(record(100L)));
        assertTrue(store.getRejectedRecords() >= 1, "closed-store rejection is counted");
    }

    @Test
    void invalidConstructorArgumentsRejected() {
        Path file = tempDir.resolve("invalid.jsonl");
        assertThrows(IllegalArgumentException.class, () -> new TelemetryEvaluationStore(file, 0, 10));
        assertThrows(IllegalArgumentException.class, () -> new TelemetryEvaluationStore(file, 10, 0));
        assertThrows(IllegalArgumentException.class,
                () -> new TelemetryEvaluationStore(file, 20, 10),
                "flushLimit must not exceed queueCapacity");
    }

    @Test
    void secondStoreOnSameFileRejectedWhenLockingEnabled() throws Exception {
        Path file = tempDir.resolve("locked.jsonl");
        TelemetryEvaluationStore first = new TelemetryEvaluationStore(file, 50, 100, true);
        try {
            IllegalStateException ex = assertThrows(IllegalStateException.class,
                    () -> new TelemetryEvaluationStore(file, 50, 100, true));
            assertTrue(ex.getMessage().toLowerCase().contains("lock"), ex.getMessage());
        } finally {
            first.close();
        }
        // After the first writer releases, a new writer may acquire the lock.
        TelemetryEvaluationStore third = new TelemetryEvaluationStore(file, 50, 100, true);
        third.close();
    }

    @Test
    void escapedQuotesAndBackslashesHandled() throws Exception {
        Path file = tempDir.resolve("escape.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1);
        TelemetryObservation obs = observation(100L, 10.0, 1024L, 512L);
        TelemetryEvaluationRecord rec = new TelemetryEvaluationRecord("node\"test\\back", 100L, obs, 101L, "v1", true);
        store.append(rec);
        store.flush();
        String raw = Files.readString(file);
        assertTrue(raw.contains("node\\\"test\\\\back"), "quote and backslash escaped");
    }

    @Test
    void unsupportedSchemaVersionIsSkippedAndReportedNotReinterpreted() throws Exception {
        Path file = tempDir.resolve("badver.jsonl");
        // A well-formed line carrying the LEGACY schema version: it must never be
        // read back under the current schema, because v1 persisted only 8 of the
        // 16 observation components.
        Files.writeString(file,
                "{\"v\":\"" + TelemetryEvaluationStore.LEGACY_FORMAT_VERSION + "\","
                        + "\"nodeId\":\"n\",\"observationTimestamp\":1}\n"
                        + "{\"v\":\"some-future-schema\",\"nodeId\":\"m\",\"observationTimestamp\":2}\n",
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);

        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
        assertTrue(result.records().isEmpty(), "unsupported schema versions are never reinterpreted");
        assertEquals(2, result.skippedLineCount());
        assertEquals(2, result.count(TelemetryEvaluationStore.SkipReason.UNSUPPORTED_SCHEMA_VERSION));
        assertEquals(0, result.count(TelemetryEvaluationStore.SkipReason.MALFORMED_JSON));
    }

    @Test
    void malformedJSONIsSkippedAndPreservedOnDisk() throws Exception {
        Path file = tempDir.resolve("badline.jsonl");
        Files.writeString(file, "{bad\n{\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION
                        + "\",\"nodeId\":\"n\",\"observationTimestamp\":1}\n",
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);

        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
        assertTrue(result.records().isEmpty());
        assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.MALFORMED_JSON));
        assertTrue(Files.readString(file).contains("{bad"),
                "an invalid line is preserved in the file for diagnosis, never destroyed");
    }

    @Test
    void missingRequiredFieldIsReportedAsMissingNotImputed() throws Exception {
        Path file = tempDir.resolve("missingfield.jsonl");
        // Valid version, but the record omits an observation component that the
        // schema requires to be present. It must be reported, not defaulted.
        Files.writeString(file,
                "{\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\","
                        + "\"nodeId\":\"n\",\"observationTimestamp\":10,"
                        + "\"ingestionTimestamp\":11,\"collectionConfigVersion\":\"cfg\","
                        + "\"validForReplay\":true,\"observation\":{\"timestamp\":10}}\n",
                StandardOpenOption.CREATE);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);

        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
        assertTrue(result.records().isEmpty(), "an incomplete record is never partially accepted");
        assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.MISSING_REQUIRED_FIELD));
    }

    @Test
    void wrongFieldTypeIsReportedAsInvalidNotCoerced() throws Exception {
        Path file = tempDir.resolve("wrongtype.jsonl");
        Files.writeString(file,
                "{\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\","
                        + "\"nodeId\":12345,\"observationTimestamp\":10,"
                        + "\"ingestionTimestamp\":11,\"collectionConfigVersion\":\"cfg\","
                        + "\"validForReplay\":true,\"observation\":{\"timestamp\":10,"
                        + "\"cpuUtilizationPercent\":1.0,\"totalMemoryBytes\":null,"
                        + "\"usedMemoryBytes\":null,\"availableMemoryBytes\":null,"
                        + "\"gpuAvailable\":null,\"gpuUtilizationPercent\":null,"
                        + "\"batteryLevelPercent\":null,\"batteryCharging\":null,"
                        + "\"temperatureCelsius\":null,\"latencyMs\":null,"
                        + "\"packetLossPercent\":null,\"totalDiskBytes\":null,"
                        + "\"freeDiskBytes\":null,\"processCount\":null,\"userActive\":null}}\n",
                StandardOpenOption.CREATE);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);

        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
        assertTrue(result.records().isEmpty(), "a mistyped field is never coerced to text");
        assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.INVALID_FIELD_TYPE));
    }

    @Test
    void sentinelObservationTimestampIsRejected() throws Exception {
        // A record whose observation timestamp is negative is not usable telemetry.
        Path file = tempDir.resolve("sentinel.jsonl");
        Files.writeString(file,
                "{\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\","
                        + "\"nodeId\":\"n\",\"observationTimestamp\":-1,"
                        + "\"ingestionTimestamp\":11,\"collectionConfigVersion\":\"cfg\","
                        + "\"validForReplay\":true,\"acceptedByDigitalTwin\":true,"
                        + "\"observation\":{\"timestamp\":-1,"
                        + "\"cpuUtilizationPercent\":1.0,\"totalMemoryBytes\":null,"
                        + "\"usedMemoryBytes\":null,\"availableMemoryBytes\":null,"
                        + "\"gpuAvailable\":null,\"gpuUtilizationPercent\":null,"
                        + "\"batteryLevelPercent\":null,\"batteryCharging\":null,"
                        + "\"temperatureCelsius\":null,\"latencyMs\":null,"
                        + "\"packetLossPercent\":null,\"totalDiskBytes\":null,"
                        + "\"freeDiskBytes\":null,\"processCount\":null,\"userActive\":null}}\n",
                StandardOpenOption.CREATE);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);

        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
        assertTrue(result.records().isEmpty(), "negative observation timestamp is not telemetry");
        assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.SENTINEL_VALUE));
    }

    @Test
    void skipReasonsAreObservableOnTheStore() throws Exception {
        Path file = tempDir.resolve("reasons.jsonl");
        Files.writeString(file, "{bad\n{\"v\":\"nope\",\"nodeId\":\"x\"}\n",
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        store.readAllWithDiagnostics();
        assertEquals(2, store.getLastReadSkippedLines());
        assertEquals(1L, store.getLastReadSkipReasons()
                .get(TelemetryEvaluationStore.SkipReason.MALFORMED_JSON));
        assertEquals(1L, store.getLastReadSkipReasons()
                .get(TelemetryEvaluationStore.SkipReason.UNSUPPORTED_SCHEMA_VERSION));
    }

    @Test
    void readAllIsRepeatableAndOrdersDeterministically() throws Exception {
        Path file = tempDir.resolve("repeatable.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        store.append(TelemetryEvaluationRecord.of("n1", observation(200L, 2.0, 1024L, 512L), 201L, "cfg"));
        store.append(TelemetryEvaluationRecord.of("n2", observation(100L, 1.0, 1024L, 512L), 101L, "cfg"));
        // Same observation timestamp as n2 but a different node id, to exercise
        // the node-id tiebreak that makes the ordering total.
        store.append(TelemetryEvaluationRecord.of("n3", observation(100L, 3.0, 1024L, 512L), 102L, "cfg"));
        store.flush();

        List<TelemetryEvaluationRecord> first = store.readAll();
        List<TelemetryEvaluationRecord> second = store.readAll();
        assertEquals(first, second, "readAll is repeatable for an unchanged file");
        assertEquals(3, first.size());
        assertEquals(100L, first.get(0).observationTimestamp());
        assertEquals("n2", first.get(0).nodeId(), "ties break deterministically by node id");
        assertEquals("n3", first.get(1).nodeId());
        assertEquals(200L, first.get(2).observationTimestamp());
    }

    @Test
    void allSixteenObservationFieldsSurviveRoundTrip() throws Exception {
        Path file = tempDir.resolve("allfields.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        TelemetryObservation full = new TelemetryObservation(
                1_000L,
                12.5,                     // cpuUtilizationPercent
                1024L, 512L, 512L,        // total / used / available memory
                Boolean.TRUE, 7.25,       // gpuAvailable / gpuUtilizationPercent
                55.5, Boolean.FALSE,      // batteryLevelPercent / batteryCharging
                61.5,                     // temperatureCelsius
                12.75, 0.5,               // latencyMs / packetLossPercent
                4096L, 2048L,             // totalDiskBytes / freeDiskBytes
                17,                       // processCount
                Boolean.TRUE);            // userActive
        TelemetryEvaluationRecord rec =
                new TelemetryEvaluationRecord("node-full", 1_000L, full, 1_001L, "cfg-abc", true);
        store.append(rec);
        store.flush();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size());
        assertEquals(full, read.get(0).observation(),
                "all 16 observation components survive the write/read round trip");
        assertEquals(rec, read.get(0), "the whole record round trips, including provenance and flags");
        assertEquals("cfg-abc", read.get(0).collectionConfigVersion());
        assertTrue(read.get(0).validForReplay());
    }

    @Test
    void nullAndZeroRemainDistinguishableForEveryNullableField() throws Exception {
        Path file = tempDir.resolve("nullzero.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        TelemetryObservation zeros = new TelemetryObservation(
                10L,
                0.0,      // legitimate zero, not null
                0L, 0L, 0L,
                Boolean.FALSE,
                0.0,
                0.0, Boolean.FALSE,
                0.0,
                0.0, 0.0,
                0L, 0L,
                0,
                Boolean.FALSE);
        TelemetryObservation nulls = new TelemetryObservation(
                20L,
                null, null, null, null,
                null, null, null, null,
                null, null, null, null, null,
                null, null);
        store.append(new TelemetryEvaluationRecord("node-zero", 10L, zeros, 11L, "cfg", true));
        store.append(new TelemetryEvaluationRecord("node-null", 20L, nulls, 21L, "cfg", true));
        store.flush();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(2, read.size());
        assertEquals(zeros, read.get(0).observation(), "explicit zeros stay zero");
        assertEquals(nulls, read.get(1).observation(), "explicit nulls stay null");
        assertEquals(0.0, read.get(0).observation().cpuUtilizationPercent());
        assertNull(read.get(1).observation().cpuUtilizationPercent());
        assertEquals(0L, read.get(0).observation().totalMemoryBytes());
        assertNull(read.get(1).observation().totalMemoryBytes());
        assertEquals(Boolean.FALSE, read.get(0).observation().gpuAvailable());
        assertNull(read.get(1).observation().gpuAvailable());
        assertEquals(0, read.get(0).observation().processCount());
        assertNull(read.get(1).observation().processCount());
    }

    @Test
    void quotesBackslashesControlCharactersAndUnicodeRoundTrip() throws Exception {
        Path file = tempDir.resolve("escaping.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        String trickyNodeId = "node\"quote\\slash\ttab\nnewline\rreturn\u0000nul\u00e9\u4e2d\ud83d\ude00end";
        TelemetryEvaluationRecord rec = new TelemetryEvaluationRecord(
                trickyNodeId, 100L, observation(100L, 10.0, 1024L, 512L), 101L,
                "cfg with \"quote\" and \\backslash", true);
        store.append(rec);
        store.flush();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size(), "the record with special characters is still readable");
        assertEquals(trickyNodeId, read.get(0).nodeId(), "node id round trips exactly");
        assertEquals("cfg with \"quote\" and \\backslash", read.get(0).collectionConfigVersion());
    }

    @Test
    void nonFiniteMeasurementsSurviveWithoutProducingInvalidJson() throws Exception {
        Path file = tempDir.resolve("nonfinite.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        TelemetryObservation obs = new TelemetryObservation(
                100L,
                Double.NaN,
                null, null, null, null, null,
                Double.POSITIVE_INFINITY,
                null, null, Double.NEGATIVE_INFINITY, null, null, null, null, null);
        store.append(new TelemetryEvaluationRecord("node-nan", 100L, obs, 101L, "cfg", false));
        store.flush();

        // Every line must still be well-formed JSON.
        for (String line : Files.readAllLines(file)) {
            assertDoesNotThrow(() -> new com.fasterxml.jackson.databind.ObjectMapper()
                    .readTree(line), "each persisted line must be valid JSON");
        }
        TelemetryObservation readBack = store.readAll().get(0).observation();
        assertTrue(Double.isNaN(readBack.cpuUtilizationPercent()));
        assertEquals(Double.POSITIVE_INFINITY, readBack.batteryLevelPercent());
        assertEquals(Double.NEGATIVE_INFINITY, readBack.latencyMs());
    }

    @Test
    void collectionConfigVersionRoundTripsAndIsIndependentOfSchemaVersion() throws Exception {
        Path file = tempDir.resolve("provenance.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        store.append(TelemetryEvaluationRecord.of("n", observation(100L, 1.0, 1024L, 512L), 101L, "cfg-run-42"));
        store.flush();

        List<String> lines = Files.readAllLines(file);
        assertTrue(lines.get(0).contains("\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\""),
                "schema version is written and independent of provenance");
        assertTrue(lines.get(0).contains("\"collectionConfigVersion\":\"cfg-run-42\""),
                "collection provenance is written separately from the schema version");
        assertNotEquals(TelemetryEvaluationStore.FORMAT_VERSION, "cfg-run-42");

        assertEquals("cfg-run-42", store.readAll().get(0).collectionConfigVersion(),
                "provenance round trips verbatim");
    }

    @Test
    void everyRecordLineCarriesTheCurrentSchemaVersion() throws Exception {
        Path file = tempDir.resolve("version.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        store.append(TelemetryEvaluationRecord.of("n", observation(100L, 1.0, 1024L, 512L), 101L, "cfg"));
        store.flush();
        assertTrue(Files.readString(file).contains("\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\""));
        assertFalse(Files.readString(file).contains(TelemetryEvaluationStore.LEGACY_FORMAT_VERSION),
                "new records must not be written with the legacy schema marker");
    }

    @Test
    void sequenceMetadataSurvivesFullRoundTrip() throws Exception {
        Path file = tempDir.resolve("sequence.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        TelemetryEvaluationRecord rec = new TelemetryEvaluationRecord(
                "node-seq", 100L, observation(100L, 10.0, 1024L, 512L), 101L, "cfg-1", true,
                "session-abc", 42L);
        store.append(rec);
        store.flush();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size());
        assertEquals(rec, read.get(0), "the whole record including sequence metadata round trips");
        assertEquals("session-abc", read.get(0).agentSessionId());
        assertEquals(42L, read.get(0).telemetrySequence());

        String raw = Files.readString(file);
        assertTrue(raw.contains("\"agentSessionId\":\"session-abc\""), "session id is persisted");
        assertTrue(raw.contains("\"telemetrySequence\":42"), "sequence is persisted");
    }

    @Test
    void absentSequenceMetadataReadsBackAsNullNotFabricated() throws Exception {
        Path file = tempDir.resolve("nosequence.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        // No session metadata reported (an older agent).
        store.append(TelemetryEvaluationRecord.of(
                "node-legacy", observation(100L, 10.0, 1024L, 512L), 101L, "cfg-1"));
        store.flush();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size());
        assertNull(read.get(0).agentSessionId(), "absent session id must read back as null, never invented");
        assertNull(read.get(0).telemetrySequence(), "absent sequence must read back as null, never invented");
    }

    @Test
    void v2RecordsAreReportedUnsupportedNotReinterpreted() throws Exception {
        Path file = tempDir.resolve("v2.jsonl");
        // A v2 record has complete observations but no sequence metadata at all.
        String v2Line = "{\"v\":\"" + TelemetryEvaluationStore.LEGACY_FORMAT_VERSION_V2 + "\","
                + "\"nodeId\":\"n\",\"observationTimestamp\":1,\"ingestionTimestamp\":2,"
                + "\"collectionConfigVersion\":\"cfg\",\"validForReplay\":true,"
                + "\"observation\":{\"timestamp\":1,\"cpuUtilizationPercent\":1.0,"
                + "\"totalMemoryBytes\":null,\"usedMemoryBytes\":null,\"availableMemoryBytes\":null,"
                + "\"gpuAvailable\":null,\"gpuUtilizationPercent\":null,\"batteryLevelPercent\":null,"
                + "\"batteryCharging\":null,\"temperatureCelsius\":null,\"latencyMs\":null,"
                + "\"packetLossPercent\":null,\"totalDiskBytes\":null,\"freeDiskBytes\":null,"
                + "\"processCount\":null,\"userActive\":null}}\n";
        Files.writeString(file, v2Line, StandardOpenOption.CREATE);

        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();

        assertTrue(result.records().isEmpty(),
                "a v2 record must never be read as if it carried sequence metadata");
        assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.UNSUPPORTED_SCHEMA_VERSION));
    }

    @Test
    void v1AndV2RecordsAreBothRecognisedAsLegacy() {
        assertTrue(TelemetryEvaluationStore.LEGACY_FORMAT_VERSIONS
                        .contains(TelemetryEvaluationStore.LEGACY_FORMAT_VERSION),
                "v1 must be a recognised legacy version");
        assertTrue(TelemetryEvaluationStore.LEGACY_FORMAT_VERSIONS
                        .contains(TelemetryEvaluationStore.LEGACY_FORMAT_VERSION_V2),
                "v2 must be a recognised legacy version");
        assertFalse(TelemetryEvaluationStore.READABLE_FORMAT_VERSIONS
                        .contains(TelemetryEvaluationStore.FORMAT_VERSION + "-legacy"),
                "only the current version is readable");
    }

    @Test
    void nonPositivePersistedSequenceIsReportedNotCoerced() throws Exception {
        Path file = tempDir.resolve("badseq.jsonl");
        Files.writeString(file,
                "{\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\",\"nodeId\":\"n\","
                        + "\"observationTimestamp\":1,\"ingestionTimestamp\":2,"
                        + "\"collectionConfigVersion\":\"cfg\",\"validForReplay\":true,"
                        + "\"agentSessionId\":\"s\",\"telemetrySequence\":0,"
                        + "\"observation\":{\"timestamp\":1,\"cpuUtilizationPercent\":1.0,"
                        + "\"totalMemoryBytes\":null,\"usedMemoryBytes\":null,\"availableMemoryBytes\":null,"
                        + "\"gpuAvailable\":null,\"gpuUtilizationPercent\":null,\"batteryLevelPercent\":null,"
                        + "\"batteryCharging\":null,\"temperatureCelsius\":null,\"latencyMs\":null,"
                        + "\"packetLossPercent\":null,\"totalDiskBytes\":null,\"freeDiskBytes\":null,"
                        + "\"processCount\":null,\"userActive\":null}}\n",
                StandardOpenOption.CREATE);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
        assertTrue(result.records().isEmpty());
        assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.SENTINEL_VALUE));
    }

    @Test
    void recordsWithAndWithoutSequenceMetadataCoexist() throws Exception {
        Path file = tempDir.resolve("mixed.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        store.append(new TelemetryEvaluationRecord("n1", 10L, observation(10L, 1.0, 1024L, 512L), 11L,
                "cfg", true, "s1", 1L));
        store.append(TelemetryEvaluationRecord.of("n2", observation(20L, 2.0, 1024L, 512L), 21L, "cfg"));
        store.flush();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(2, read.size());
        assertEquals("s1", read.get(0).agentSessionId());
        assertEquals(1L, read.get(0).telemetrySequence());
        assertNull(read.get(1).agentSessionId());
        assertNull(read.get(1).telemetrySequence());
    }

    @Test
    void sequenceMetadataIsOptionalOnDeserialization() throws Exception {
        Path file = tempDir.resolve("optional.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        store.append(new TelemetryEvaluationRecord("n1", 10L, observation(10L, 1.0, 1024L, 512L), 11L,
                "cfg", true, null, null));
        store.flush();
        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
        assertEquals(1, result.records().size(),
                "a record without optional sequence fields is still valid and readable");
        assertEquals(0, result.skippedLineCount());
    }

    @Test
    void recordsRejectNonPositiveSequenceAtConstruction() {
        TelemetryObservation obs = observation(100L, 1.0, 1024L, 512L);
        assertThrows(IllegalArgumentException.class,
                () -> new TelemetryEvaluationRecord("n", 100L, obs, 101L, "cfg", true, "s", 0L));
        assertThrows(IllegalArgumentException.class,
                () -> new TelemetryEvaluationRecord("n", 100L, obs, 101L, "cfg", true, "s", -1L));
        assertDoesNotThrow(
                () -> new TelemetryEvaluationRecord("n", 100L, obs, 101L, "cfg", true, "s", 1L));
    }

    @Test
    void isClosedReflectsLifecycleWithoutMutatingTheStore() throws Exception {
        Path file = tempDir.resolve("isclosed.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        assertFalse(store.isClosed(), "fresh store is open");
        long acceptedBefore = store.getAcceptedRecords();
        assertFalse(store.isClosed(), "observing state does not mutate the store");
        assertEquals(acceptedBefore, store.getAcceptedRecords());
        store.close();
        assertTrue(store.isClosed(), "closed store reports closed");
    }

    @Test
    void concurrentAppendAndFlushProduceNoLossOrDuplication() throws Exception {
        Path file = tempDir.resolve("concurrent.jsonl");
        int threads = 4;
        int perThread = 200;
        int total = threads * perThread;
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 25, 4096);

        ExecutorService writers = Executors.newFixedThreadPool(threads);
        ExecutorService flusher = Executors.newSingleThreadExecutor();
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        try {
            flusher.submit(() -> {
                start.await();
                for (int i = 0; i < 50; i++) {
                    store.flush();
                }
                return null;
            });
            for (int t = 0; t < threads; t++) {
                final int base = t * perThread;
                writers.submit(() -> {
                    try {
                        start.await();
                        for (int i = 0; i < perThread; i++) {
                            long ts = base + i + 1L;
                            store.append(TelemetryEvaluationRecord.of(
                                    "node-" + ts, observation(ts, 1.0, 1024L, 512L), ts + 1, "v1"));
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } finally {
                        done.countDown();
                    }
                });
            }
            start.countDown();
            assertTrue(done.await(10, TimeUnit.SECONDS), "writers finished");
            flusher.shutdown();
            assertTrue(flusher.awaitTermination(10, TimeUnit.SECONDS));
        } finally {
            writers.shutdownNow();
            flusher.shutdownNow();
        }
        store.close();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(total, read.size(), "every accepted record persisted exactly once");
        Set<String> nodeIds = new HashSet<>();
        for (TelemetryEvaluationRecord rec : read) {
            assertTrue(nodeIds.add(rec.nodeId()), "no duplicated record: " + rec.nodeId());
        }
        assertEquals(0, store.getRejectedRecords());
        assertEquals(0, store.getQueueSize());
    }
}
