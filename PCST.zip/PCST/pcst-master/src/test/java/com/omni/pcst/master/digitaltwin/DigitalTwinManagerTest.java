package com.omni.pcst.master.digitaltwin;

import com.omni.pcst.proto.TelemetryRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic unit tests for {@link DigitalTwinManager}. No gRPC, no hardware,
 * no sleeps: all state transitions are driven directly and asserted on the
 * immutable snapshots.
 */
class DigitalTwinManagerTest {

    private static final int HISTORY_BOUND = 3;
    private static final long SERVER_TIME = 1_700_000_000_000L;

    private DigitalTwinManager manager;

    @BeforeEach
    void setUp() {
        manager = new DigitalTwinManager(HISTORY_BOUND);
    }

    @Test
    void registrationCreatesNodeState() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertEquals("node-1", snapshot.nodeId());
        assertEquals("host-1", snapshot.hostname());
        assertEquals(9091, snapshot.port());
        assertEquals("0.1.0", snapshot.agentVersion());
        assertEquals(SERVER_TIME, snapshot.registeredAtMillis());
        assertEquals(SERVER_TIME, snapshot.lastRegistrationMillis());
        assertEquals(0L, snapshot.lastHeartbeatMillis(), "no heartbeat yet");
        assertNull(snapshot.latestObservation(), "no telemetry yet");
        assertTrue(snapshot.observationHistory().isEmpty());
        assertEquals(1, manager.trackedNodeCount());
    }

    @Test
    void reRegistrationRefreshesMetadataButKeepsHistory() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);
        manager.onTelemetry("node-1", telemetryRequest(100L), SERVER_TIME + 1);
        manager.onNodeRegistered("node-1", "host-1b", 9092, "0.2.0", SERVER_TIME + 2);

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertEquals("host-1b", snapshot.hostname());
        assertEquals(9092, snapshot.port());
        assertEquals("0.2.0", snapshot.agentVersion());
        assertEquals(SERVER_TIME, snapshot.registeredAtMillis(), "first registration time is preserved");
        assertEquals(SERVER_TIME + 2, snapshot.lastRegistrationMillis());
        assertEquals(1, snapshot.observationHistory().size(), "history survives re-registration");
        assertNotNull(snapshot.latestObservation());
    }

    @Test
    void heartbeatUpdatesFreshness() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        assertTrue(manager.onHeartbeat("node-1", SERVER_TIME + 5_000L));
        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertEquals(SERVER_TIME + 5_000L, snapshot.lastHeartbeatMillis());
    }

    @Test
    void unknownNodeHeartbeatDoesNotCreateNode() {
        assertFalse(manager.onHeartbeat("ghost", SERVER_TIME));
        assertTrue(manager.getSnapshot("ghost").isEmpty());
        assertEquals(0, manager.trackedNodeCount());
    }

    @Test
    void telemetryUpdatesLatestObservationAndHistory() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry("node-1", telemetryRequest(100L), SERVER_TIME + 1));
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry("node-1", telemetryRequest(200L), SERVER_TIME + 2));

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertEquals(200L, snapshot.latestObservation().timestamp());
        assertEquals(2, snapshot.observationHistory().size());
        assertEquals(200L, snapshot.observationHistory().get(0).timestamp(), "history is newest first");
        assertEquals(100L, snapshot.observationHistory().get(1).timestamp());
        assertEquals(SERVER_TIME + 2, snapshot.lastTelemetryReceivedAtMillis());
    }

    @Test
    void outOfOrderTelemetryDoesNotOverwriteNewerObservation() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);
        manager.onTelemetry("node-1", telemetryRequest(200L), SERVER_TIME + 1);

        assertEquals(DigitalTwinManager.TelemetryIngestion.STALE_OR_OUT_OF_ORDER,
                manager.onTelemetry("node-1", telemetryRequest(100L), SERVER_TIME + 2));

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertEquals(200L, snapshot.latestObservation().timestamp(), "newer observation is untouched");
        assertEquals(1, snapshot.observationHistory().size());
        assertEquals(1, snapshot.staleObservationsRejected());
    }

    @Test
    void equalTimestampTreatedAsStale() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);
        manager.onTelemetry("node-1", telemetryRequest(200L), SERVER_TIME + 1);

        assertEquals(DigitalTwinManager.TelemetryIngestion.STALE_OR_OUT_OF_ORDER,
                manager.onTelemetry("node-1", telemetryRequest(200L), SERVER_TIME + 2));

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertEquals(1, snapshot.observationHistory().size());
        assertEquals(1, snapshot.staleObservationsRejected());
    }

    @Test
    void missingMeasurementsRemainUnavailableInsteadOfZero() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        // Request with optional measurements omitted entirely (no presence on the wire).
        TelemetryRequest sparse = TelemetryRequest.newBuilder()
                .setNodeId("node-1")
                .setTimestamp(100L)
                .setCpu(com.omni.pcst.proto.CpuTelemetry.newBuilder().setUtilizationPercent(0.0))
                .setMemory(com.omni.pcst.proto.MemoryTelemetry.newBuilder()
                        .setTotalBytes(1024).setUsedBytes(512).setAvailableBytes(512))
                .setGpu(com.omni.pcst.proto.GpuTelemetry.newBuilder().setAvailable(false))
                .setDisk(com.omni.pcst.proto.DiskTelemetry.newBuilder()
                        .setTotalBytes(2048).setFreeBytes(1024))
                .setProcesses(com.omni.pcst.proto.ProcessTelemetry.newBuilder().setProcessCount(4))
                .build();

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry("node-1", sparse, SERVER_TIME + 1));

        TelemetryObservation observation = manager.getSnapshot("node-1").orElseThrow().latestObservation();
        assertEquals(0.0, observation.cpuUtilizationPercent(),
                "an explicit zero CPU reading is a legitimate zero, not 'unavailable'");
        assertNull(observation.gpuUtilizationPercent(), "omitted GPU utilization stays unavailable");
        assertNull(observation.batteryLevelPercent(), "omitted battery level stays unavailable");
        assertNull(observation.batteryCharging(), "omitted battery charging stays unavailable");
        assertNull(observation.temperatureCelsius(), "omitted temperature stays unavailable");
        assertNull(observation.latencyMs(), "omitted latency stays unavailable");
        assertNull(observation.packetLossPercent(), "omitted packet loss stays unavailable");
        assertEquals(4, observation.processCount());
    }

    @Test
    void historyRemainsBounded() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        for (long ts = 100L; ts <= 500L; ts += 100L) {
            assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                    manager.onTelemetry("node-1", telemetryRequest(ts), SERVER_TIME + ts));
        }

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertEquals(HISTORY_BOUND, snapshot.observationHistory().size(), "history is bounded");
        assertEquals(500L, snapshot.observationHistory().get(0).timestamp(), "newest kept first");
        assertEquals(300L, snapshot.observationHistory().get(HISTORY_BOUND - 1).timestamp(),
                "oldest observations are evicted");
        assertEquals(500L, snapshot.latestObservation().timestamp());
    }

    @Test
    void unknownNodeTelemetryIsRejectedWithoutCreatingState() {
        assertEquals(DigitalTwinManager.TelemetryIngestion.UNKNOWN_NODE,
                manager.onTelemetry("ghost", telemetryRequest(100L), SERVER_TIME));

        assertTrue(manager.getSnapshot("ghost").isEmpty());
        assertEquals(0, manager.trackedNodeCount());
    }

    @Test
    void concurrentUpdatesDoNotCorruptState() throws Exception {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        int threads = 8;
        int observationsPerThread = 25;
        long baseTimestamp = 1_000L;
        int totalSent = threads * observationsPerThread;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch ready = new CountDownLatch(threads);
        CountDownLatch go = new CountDownLatch(1);
        List<Future<?>> futures = new ArrayList<>();
        try {
            for (int t = 0; t < threads; t++) {
                final int threadIndex = t;
                futures.add(pool.submit(() -> {
                    ready.countDown();
                    go.await();
                    for (int i = 0; i < observationsPerThread; i++) {
                        // Disjoint per-thread timestamp ranges; cross-thread arrival
                        // order is not deterministic, so assertions below use only
                        // interleaving-independent invariants.
                        long timestamp = baseTimestamp + (long) threadIndex * observationsPerThread + i;
                        manager.onTelemetry("node-1", telemetryRequest(timestamp), SERVER_TIME + timestamp);
                    }
                    return null;
                }));
            }
            assertTrue(ready.await(10, TimeUnit.SECONDS));
            go.countDown();
            for (Future<?> future : futures) {
                future.get(10, TimeUnit.SECONDS);
            }
        } finally {
            pool.shutdownNow();
        }

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        long stale = snapshot.staleObservationsRejected();
        long accepted = totalSent - stale;
        assertTrue(accepted > 0, "the first applied observation is always accepted");
        assertEquals(Math.min(accepted, HISTORY_BOUND), snapshot.observationHistory().size(),
                "history holds the most recent accepted observations and stays bounded");
        assertNotNull(snapshot.latestObservation());
        assertTrue(snapshot.latestObservation().timestamp() >= baseTimestamp);

        List<TelemetryObservation> history = snapshot.observationHistory();
        for (int i = 1; i < history.size(); i++) {
            assertTrue(history.get(i - 1).timestamp() > history.get(i).timestamp(),
                    "history must be strictly newest-first even under concurrent updates");
        }
        assertEquals(history.size(),
                history.stream().mapToLong(TelemetryObservation::timestamp).distinct().count(),
                "no duplicate observations in history");
    }

    @Test
    void beliefStateIsUninitializedExtensionPoint() {
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        DigitalTwinSnapshot snapshot = manager.getSnapshot("node-1").orElseThrow();
        assertNotNull(snapshot.beliefState());
        assertEquals(BeliefState.UNINITIALIZED, snapshot.beliefState(),
                "no Bayesian belief state exists yet; the extension point must be explicitly uninitialized");
    }

    /* ------------------------------------------------------------------ helpers */

    private static TelemetryRequest telemetryRequest(long timestamp) {
        return TelemetryRequest.newBuilder()
                .setNodeId("node-1")
                .setTimestamp(timestamp)
                .setCpu(com.omni.pcst.proto.CpuTelemetry.newBuilder().setUtilizationPercent(12.5))
                .setMemory(com.omni.pcst.proto.MemoryTelemetry.newBuilder()
                        .setTotalBytes(1024L).setUsedBytes(512L).setAvailableBytes(512L))
                .setGpu(com.omni.pcst.proto.GpuTelemetry.newBuilder().setAvailable(false))
                .setDisk(com.omni.pcst.proto.DiskTelemetry.newBuilder()
                        .setTotalBytes(2048L).setFreeBytes(1024L))
                .setProcesses(com.omni.pcst.proto.ProcessTelemetry.newBuilder().setProcessCount(4))
                .build();
    }
}
