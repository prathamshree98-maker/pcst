package com.omni.pcst.master.telemetry;

import com.google.protobuf.ByteString;
import com.omni.pcst.proto.RegisterNodeRequest;
import com.omni.pcst.proto.TelemetryRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Contract tests for the sequence-metadata protobuf fields.
 *
 * <p>These verify the wire contract itself: field numbers, explicit presence,
 * round-trip through the binary encoding, and backward compatibility for an
 * older agent that does not set the new fields.
 */
class TelemetrySequenceProtoContractTest {

    @Test
    void sequenceFieldsUseNewAndNonConflictingFieldNumbers() throws Exception {
        // Appending new fields must never reuse an existing number or change an
        // existing wire type. node_id=1 .. user_state=11 are pre-existing.
        assertEquals(12, TelemetryRequest.AGENT_SESSION_ID_FIELD_NUMBER);
        assertEquals(13, TelemetryRequest.TELEMETRY_SEQUENCE_FIELD_NUMBER);
        assertEquals(5, RegisterNodeRequest.AGENT_SESSION_ID_FIELD_NUMBER);

        assertEquals(1, TelemetryRequest.NODE_ID_FIELD_NUMBER);
        assertEquals(2, TelemetryRequest.TIMESTAMP_FIELD_NUMBER);
        assertEquals(11, TelemetryRequest.USER_STATE_FIELD_NUMBER);
        assertEquals(1, RegisterNodeRequest.NODE_ID_FIELD_NUMBER);
        assertEquals(4, RegisterNodeRequest.AGENT_VERSION_FIELD_NUMBER);
    }

    @Test
    void sequenceMetadataRoundTripsThroughBinaryEncoding() throws Exception {
        TelemetryRequest original = TelemetryRequest.newBuilder()
                .setNodeId("node-1")
                .setTimestamp(1234L)
                .setAgentSessionId("session-xyz")
                .setTelemetrySequence(77L)
                .build();

        TelemetryRequest decoded = TelemetryRequest.parseFrom(original.toByteArray());

        assertEquals("node-1", decoded.getNodeId());
        assertTrue(decoded.hasAgentSessionId());
        assertEquals("session-xyz", decoded.getAgentSessionId());
        assertTrue(decoded.hasTelemetrySequence());
        assertEquals(77L, decoded.getTelemetrySequence());
    }

    @Test
    void omittedSequenceFieldsHaveExplicitAbsence() throws Exception {
        TelemetryRequest original = TelemetryRequest.newBuilder()
                .setNodeId("node-1")
                .setTimestamp(1234L)
                .build();

        TelemetryRequest decoded = TelemetryRequest.parseFrom(original.toByteArray());

        assertFalse(decoded.hasAgentSessionId(), "an unsent session id must read back as absent");
        assertFalse(decoded.hasTelemetrySequence(), "an unsent sequence must read back as absent");
        assertEquals("", decoded.getAgentSessionId());
        assertEquals(0L, decoded.getTelemetrySequence());
    }

    @Test
    void olderAgentMessageRemainsDecodableByNewMaster() throws Exception {
        // A message encoded before the new fields existed must still decode.
        ByteString legacyEncoded = TelemetryRequest.newBuilder()
                .setNodeId("legacy-node")
                .setTimestamp(999L)
                .build()
                .toByteString();

        TelemetryRequest decoded = TelemetryRequest.parseFrom(legacyEncoded);

        assertEquals("legacy-node", decoded.getNodeId());
        assertEquals(999L, decoded.getTimestamp());
        assertFalse(decoded.hasAgentSessionId());
        assertFalse(decoded.hasTelemetrySequence());
    }

    @Test
    void zeroSequenceIsDistinguishableFromAbsent() throws Exception {
        TelemetryRequest withZero = TelemetryRequest.newBuilder()
                .setNodeId("n")
                .setTelemetrySequence(0L)
                .build();

        TelemetryRequest without = TelemetryRequest.newBuilder()
                .setNodeId("n")
                .build();

        assertTrue(withZero.hasTelemetrySequence(),
                "an explicit zero is present, which the Master treats as invalid metadata");
        assertFalse(without.hasTelemetrySequence(), "an omitted sequence is absent");
    }

    @Test
    void registrationCarriesOptionalSessionId() throws Exception {
        RegisterNodeRequest withSession = RegisterNodeRequest.newBuilder()
                .setNodeId("node-1")
                .setHostname("host")
                .setPort(9091)
                .setAgentVersion("0.1.0")
                .setAgentSessionId("session-abc")
                .build();
        RegisterNodeRequest decoded = RegisterNodeRequest.parseFrom(withSession.toByteArray());
        assertTrue(decoded.hasAgentSessionId());
        assertEquals("session-abc", decoded.getAgentSessionId());

        RegisterNodeRequest withoutSession = RegisterNodeRequest.newBuilder()
                .setNodeId("node-1")
                .build();
        assertFalse(RegisterNodeRequest.parseFrom(withoutSession.toByteArray()).hasAgentSessionId(),
                "an older agent that omits the session id stays decodable");
    }

    @Test
    void unicodeSessionIdSurvivesEncoding() throws Exception {
        TelemetryRequest original = TelemetryRequest.newBuilder()
                .setNodeId("n")
                .setAgentSessionId("sessiÃ³n-ä¸­æ–‡-\uD83D\uDE00")
                .setTelemetrySequence(5L)
                .build();
        TelemetryRequest decoded = TelemetryRequest.parseFrom(original.toByteArray());
        assertEquals("sessiÃ³n-ä¸­æ–‡-\uD83D\uDE00", decoded.getAgentSessionId());
    }
}