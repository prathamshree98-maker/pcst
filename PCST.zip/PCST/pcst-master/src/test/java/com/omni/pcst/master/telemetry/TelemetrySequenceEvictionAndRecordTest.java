package com.omni.pcst.master.telemetry;

import com.omni.pcst.master.evaluation.TelemetryEvaluationRecord;
import com.omni.pcst.master.evaluation.TelemetryEvaluationStore;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.omni.pcst.master.telemetry.TelemetrySequenceTracker.Classification.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Regression coverage for tracker eviction behaviour and the v4 evaluation-record
 * contract (classification, gap interval, acceptance evidence, legacy handling).
 */
class TelemetrySequenceEvictionAndRecordTest {

    private static final String NODE = "node-evict";
    private static final String SESSION = "session-evict";

    @TempDir
    Path tempDir;

    private static TelemetryObservation obs(long ts) {
        return new TelemetryObservation(ts, 10.0, 1024L, 512L, null, null, null, null,
                null, null, null, null, null, null, null, null);
    }

    // 16: eviction produces an explicit diagnostic, not a silent FIRST_SEQUENCE.
    @Test
    void nodeEvictionDoesNotSilentlyClaimAGenuineFirstSequence() {
        // A tiny node bound forces eviction of the tracked node's state.
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker(1, 256);
        tracker.observe(NODE, SESSION, 40L);
        assertEquals(40L, tracker.highestSequence(NODE, SESSION));

        // Force another node into the map, evicting NODE's classification state.
        tracker.observe("other-node", SESSION, 1L);

        // A later, LOWER sequence for the evicted node must not be reported as a
        // genuine first sequence. Either the compact high-water mark survives
        // (classifying it out-of-order), or the loss is reported explicitly.
        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, 5L);
        assertNotEquals(FIRST_SEQUENCE, obs.classification(),
                "an evicted node's old sequence must never look brand new");
        assertTrue(
                obs.classification() == OUT_OF_ORDER
                        || obs.classification() == DUPLICATE
                        || obs.classification() == TRACKING_STATE_EVICTED,
                "expected an explicit diagnostic, got " + obs.classification());
    }

    @Test
    void highWaterMarkSurvivesNodeEviction() {
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker(1, 256);
        tracker.observe(NODE, SESSION, 100L);
        tracker.observe("other-node", SESSION, 1L);   // evicts NODE's NodeState

        assertEquals(100L, tracker.highestSequence(NODE, SESSION),
                "the compact high-water mark survives eviction");
        assertEquals(1L, tracker.getEvictedStateCount() > 0 ? 1L : 0L,
                "an eviction is counted when it occurs");
    }

    @Test
    void aHigherSequenceAfterEvictionIsStillClassifiedNormally() {
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker(1, 256);
        tracker.observe(NODE, SESSION, 100L);
        tracker.observe("other-node", SESSION, 1L);

        TelemetrySequenceTracker.Observation obs = tracker.observe(NODE, SESSION, 101L);
        assertEquals(CONSECUTIVE, obs.classification(),
                "a genuinely following sequence is still recognised after eviction");
    }

    // 17: session eviction cannot override registered-session authority.
    @Test
    void sessionEvictionCannotOverrideRegisteredAuthority() {
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker(8, 256);
        tracker.noteRegistrationSession(NODE, "session-established");
        tracker.observe(NODE, "session-established", 5L);

        // Churn many distinct sessions. This legitimately promotes each unseen
        // session to active, so what must never happen is a RETIRED session
        // becoming active again through per-node session eviction.
        for (int i = 0; i < 50; i++) {
            tracker.observe(NODE, "churn-" + i, 1L);
        }

        assertFalse(tracker.isRetired(NODE, "session-established") && tracker.isRetired(NODE, "churn-49"),
                "the active session must never also be marked retired");

        // Whatever churn-49 retired, re-sending it must be refused outright
        // rather than promoted back to active. Retirement is deliberately
        // bounded, so this is asserted inside the documented window: churning
        // more sessions than the per-node session bound forces SessionState
        // eviction while the retirement record is still retained.
        TelemetrySequenceTracker tracker2 = new TelemetrySequenceTracker(8, 256);
        tracker2.noteRegistrationSession(NODE, "session-A");
        tracker2.observe(NODE, "churn-0", 1L);          // promotes churn-0, retires session-A
        for (int i = 1; i < 8; i++) {
            tracker2.observe(NODE, "churn-" + i, 1L);    // forces per-node SessionState eviction
        }
        assertTrue(tracker2.isRetired(NODE, "churn-0"),
                "superseded sessions stay retired through session eviction");
        assertEquals(TelemetrySequenceTracker.Classification.OBSOLETE_SESSION,
                tracker2.observe(NODE, "churn-0", 2L).classification(),
                "a retired session cannot be promoted back to active by session eviction");
    }

    @Test
    void retirementWindowIsBoundedAndDocumented() {
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker(8, 256,
                TelemetrySequenceTracker.DEFAULT_MAX_RETIRED_SESSIONS_PER_NODE);
        tracker.noteRegistrationSession(NODE, "session-A");
        tracker.observe(NODE, "session-A", 1L);

        // Churn far more sessions than the retirement window can hold.
        for (int i = 0; i < 100; i++) {
            tracker.observe(NODE, "churn-" + i, 1L);
        }

        // A very old session may be forgotten by the bounded window; that is a
        // documented memory bound, not a claim of permanent memory.
        assertFalse(tracker.isRetired(NODE, "session-A"),
                "retirement records are bounded and may age out");
    }

    @Test
    void registeredSessionSurvivesNodeMapEviction() {
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker(1, 256);
        tracker.noteRegistrationSession(NODE, SESSION);
        tracker.observe("other-node", SESSION, 1L);   // evicts NODE from the node map

        assertEquals(SESSION, tracker.registeredSession(NODE),
                "session authority lives outside the evictable node map");
    }

    @Test
    void retiredSessionRemainsRetiredAfterEviction() {
        TelemetrySequenceTracker tracker = new TelemetrySequenceTracker(1, 256);
        tracker.noteRegistrationSession(NODE, "session-old");
        tracker.noteRegistrationSession(NODE, "session-new");
        assertTrue(tracker.isRetired(NODE, "session-old"));
        tracker.observe("other-node", SESSION, 1L);   // evict NODE

        assertTrue(tracker.isRetired(NODE, "session-old"),
                "retirement survives node-map eviction");
        assertEquals(TelemetrySequenceTracker.Classification.OBSOLETE_SESSION,
                tracker.observe(NODE, "session-old", 1L).classification(),
                "a retired session is still rejected after eviction");
    }

    // 18: v4 records round-trip every field.
    @Test
    void v4RecordRoundTripsAllEvidence() throws Exception {
        Path file = tempDir.resolve("v4.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        TelemetryEvaluationRecord rec = TelemetryEvaluationRecord.of(
                "node-v4", obs(1000L), 1001L, "cfg-v4", "sess-v4", 42L,
                "FORWARD_GAP", 11L, 13L);
        store.append(rec);
        store.flush();

        List<TelemetryEvaluationRecord> read = store.readAll();
        assertEquals(1, read.size());
        TelemetryEvaluationRecord back = read.get(0);
        assertEquals("node-v4", back.nodeId());
        assertEquals(1000L, back.observationTimestamp());
        assertEquals(1001L, back.ingestionTimestamp());
        assertEquals("cfg-v4", back.collectionConfigVersion());
        assertEquals("sess-v4", back.agentSessionId());
        assertEquals(42L, back.telemetrySequence());
        assertEquals("FORWARD_GAP", back.sequenceClassification());
        assertEquals(11L, back.sequenceGapFrom());
        assertEquals(13L, back.sequenceGapTo());
        assertTrue(back.acceptedByDigitalTwin());
        assertTrue(back.isScorableSample());
        assertEquals(obs(1000L), back.observation(), "all observation fields round-trip");
    }

    @Test
    void v4RecordPreservesNullsAndZeroes() throws Exception {
        Path file = tempDir.resolve("v4nulls.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        TelemetryObservation zeros = new TelemetryObservation(
                10L, 0.0, 0L, 0L, 0L, Boolean.FALSE, 0.0, 0.0, Boolean.FALSE,
                0.0, 0.0, 0.0, 0L, 0L, 0, Boolean.FALSE);
        TelemetryEvaluationRecord rec = TelemetryEvaluationRecord.of(
                "n", zeros, 11L, "cfg", null, null, null, null, null);
        store.append(rec);
        store.flush();

        TelemetryEvaluationRecord back = store.readAll().get(0);
        assertNull(back.agentSessionId());
        assertNull(back.telemetrySequence());
        assertNull(back.sequenceClassification());
        assertNull(back.sequenceGapFrom());
        assertNull(back.sequenceGapTo());
        assertEquals(zeros, back.observation(), "zero stays zero and null stays null");
    }

    // 20: audit-only records cannot enter the accepted-observation path.
    @Test
    void auditOnlyRecordIsNeverScorable() throws Exception {
        Path file = tempDir.resolve("audit.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        TelemetryEvaluationRecord audit = TelemetryEvaluationRecord.auditOnly(
                "n", obs(100L), 101L, "cfg", "sess", 7L, "DUPLICATE");
        store.append(audit);
        store.flush();

        TelemetryEvaluationRecord back = store.readAll().get(0);
        assertFalse(back.acceptedByDigitalTwin());
        assertFalse(back.validForReplay());
        assertFalse(back.isScorableSample(), "an audit record can never be a scoring sample");
        assertEquals("DUPLICATE", back.sequenceClassification());

        // Even if a caller tries to construct one as accepted+replayable, the
        // record's compact constructor refuses to keep validForReplay true.
        TelemetryEvaluationRecord forced = new TelemetryEvaluationRecord(
                "n", 100L, obs(100L), 101L, "cfg", true, "sess", 7L,
                "DUPLICATE", null, null, false);
        assertFalse(forced.isScorableSample(),
                "acceptedByDigitalTwin=false must always clear validForReplay");
    }

    // 19: v1/v2/v3 records are handled explicitly with no fabricated metadata.
    @Test
    void legacyVersionsAreRecognisedAndNeverReinterpreted() throws Exception {
        assertEquals(Set.of("pcst-eval-v1", "pcst-eval-v2", "pcst-eval-v3"),
                TelemetryEvaluationStore.LEGACY_FORMAT_VERSIONS,
                "v1, v2 and v3 must all be recognised as legacy");
        assertEquals(Set.of(TelemetryEvaluationStore.FORMAT_VERSION),
                TelemetryEvaluationStore.READABLE_FORMAT_VERSIONS,
                "only v4 is readable");

        for (String legacy : TelemetryEvaluationStore.LEGACY_FORMAT_VERSIONS) {
            Path file = tempDir.resolve("legacy-" + legacy + ".jsonl");
            Files.writeString(file, "{\"v\":\"" + legacy + "\",\"nodeId\":\"n\","
                    + "\"observationTimestamp\":1,\"ingestionTimestamp\":2,"
                    + "\"collectionConfigVersion\":\"c\",\"validForReplay\":true,"
                    + "\"observation\":{\"timestamp\":1}}\n", StandardOpenOption.CREATE);
            TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
            TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();
            assertTrue(result.records().isEmpty(),
                    legacy + " must never be reinterpreted as v4");
            assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.UNSUPPORTED_SCHEMA_VERSION),
                    legacy + " must be reported as an unsupported version");
        }
    }

    @Test
    void v3RecordIsNotGivenFabricatedAcceptanceEvidence() throws Exception {
        Path file = tempDir.resolve("v3.jsonl");
        // A valid v3 record: complete observations, sequence metadata, but no
        // classification and no acceptedByDigitalTwin flag.
        Files.writeString(file,
                "{\"v\":\"" + TelemetryEvaluationStore.LEGACY_FORMAT_VERSION_V3 + "\","
                        + "\"nodeId\":\"n\",\"observationTimestamp\":1,\"ingestionTimestamp\":2,"
                        + "\"collectionConfigVersion\":\"c\",\"validForReplay\":true,"
                        + "\"agentSessionId\":\"s\",\"telemetrySequence\":5,"
                        + "\"observation\":{\"timestamp\":1,\"cpuUtilizationPercent\":1.0,"
                        + "\"totalMemoryBytes\":null,\"usedMemoryBytes\":null,"
                        + "\"availableMemoryBytes\":null,\"gpuAvailable\":null,"
                        + "\"gpuUtilizationPercent\":null,\"batteryLevelPercent\":null,"
                        + "\"batteryCharging\":null,\"temperatureCelsius\":null,"
                        + "\"latencyMs\":null,\"packetLossPercent\":null,"
                        + "\"totalDiskBytes\":null,\"freeDiskBytes\":null,"
                        + "\"processCount\":null,\"userActive\":null}}\n",
                StandardOpenOption.CREATE);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();

        assertTrue(result.records().isEmpty(),
                "a v3 record cannot supply acceptance evidence, so it is not read as v4");
        assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.UNSUPPORTED_SCHEMA_VERSION));
    }

    @Test
    void classificationNameIsPersistedVerbatim() throws Exception {
        Path file = tempDir.resolve("classnames.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        for (String name : List.of("DUPLICATE", "OUT_OF_ORDER", "NOT_REPORTED", "SESSION_CHANGED")) {
            store.append(TelemetryEvaluationRecord.auditOnly(
                    "n-" + name, obs(100L), 101L, "cfg", "s", 1L, name));
        }
        store.flush();

        Map<String, Long> counts = store.readAll().stream().collect(
                java.util.stream.Collectors.groupingBy(
                        TelemetryEvaluationRecord::sequenceClassification,
                        java.util.stream.Collectors.counting()));
        assertEquals(1L, counts.get("DUPLICATE"));
        assertEquals(1L, counts.get("OUT_OF_ORDER"));
        assertEquals(1L, counts.get("NOT_REPORTED"));
        assertEquals(1L, counts.get("SESSION_CHANGED"));
    }

    // 21: store saturation/failure remains best-effort and visible.
    @Test
    void storeQueueSaturationRemainsObservableAndBestEffort() throws Exception {
        Path dir = tempDir.resolve("saturated");
        Files.createDirectories(dir);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(dir, 2, 5, false);
        for (int i = 0; i < 20; i++) {
            store.append(TelemetryEvaluationRecord.of("n" + i, obs(1000L + i), 1001L + i, "cfg"));
        }
        assertTrue(store.getRejectedRecords() > 0, "saturation is counted");
        assertTrue(store.getLastWriteError() != null && store.getLastWriteError().contains("overflow"),
                "saturation is visible: " + store.getLastWriteError());
        store.close();
        assertTrue(store.isClosed());
    }
}