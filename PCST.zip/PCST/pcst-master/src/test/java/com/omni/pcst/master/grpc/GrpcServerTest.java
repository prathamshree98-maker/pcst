package com.omni.pcst.master.grpc;

import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.execution.InMemoryTaskRegistry;
import com.omni.pcst.master.execution.TaskExecutionCoordinator;
import com.omni.pcst.master.security.DeviceCredentialService;
import com.omni.pcst.master.security.PairingCodeService;
import com.omni.pcst.master.scheduler.PCSTScheduler;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for {@link GrpcServer} TLS configuration validation.
 */
class GrpcServerTest {

    private DigitalTwinManager manager = new DigitalTwinManager(100);
    private PairingCodeService pairingService = new PairingCodeService(10, 1000, 10);
    private DeviceCredentialService credentialService = new DeviceCredentialService(false, null);
    private final TaskExecutionCoordinator coordinator =
            new TaskExecutionCoordinator(new InMemoryTaskRegistry(), manager, new PCSTScheduler(), 30000);

    private NodeServiceImpl newNodeService() {
        return new NodeServiceImpl(manager, pairingService, credentialService, coordinator);
    }

    @Test
    void plaintextModeDoesNotRequireCertificates() {
        GrpcServer server = new GrpcServer(9090, newNodeService(),
                "disabled", "", "");
        assertNotNull(server);
    }

    @Test
    void productionModeFailsClosedWithoutCertificateChain() {
        assertThrows(IllegalStateException.class, () ->
                new GrpcServer(9090, newNodeService(),
                        "production", "", ""));
    }

    @Test
    void productionModeFailsClosedWithoutPrivateKey() {
        assertThrows(IllegalStateException.class, () ->
                new GrpcServer(9090, newNodeService(),
                        "production", "/path/to/cert.pem", ""));
    }

    @Test
    void developmentModeRequiresCertificates() {
        assertThrows(IllegalStateException.class, () ->
                new GrpcServer(9090, newNodeService(),
                        "development", "", ""));
    }

    @Test
    void unknownTlsModeRejected() {
        assertThrows(IllegalStateException.class, () ->
                new GrpcServer(9090, newNodeService(),
                        "insecure", "/path/to/cert.pem", "/path/to/key.pem"));
    }

    @Test
    void productionModeAcceptsValidConfiguration(@TempDir Path dir) throws Exception {
        Path cert = dir.resolve("cert.pem");
        Path key = dir.resolve("key.pem");
        cert.toFile().createNewFile();
        key.toFile().createNewFile();
        assertDoesNotThrow(() ->
                new GrpcServer(9090, newNodeService(),
                        "production", cert.toString(), key.toString()));
    }
}
