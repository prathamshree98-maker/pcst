package com.omni.pcst.master.benchmark;

/**
 * Latent true state of one compute node, hidden from schedulers except the oracle.
 *
 * <p>The true state represents what is actually happening on the node. Schedulers
 * only observe noisy, delayed, incomplete telemetry derived from this state. The
 * oracle arm may inspect true state directly; deployable schedulers must not.
 *
 * <p>State evolves deterministically per tick using a seeded drift function so the
 * simulation is reproducible.
 */
public final class NodeModel {

    private final String nodeId;
    private double trueLatencyMs;
    private double truePacketLossPercent;
    private double trueCpuUtilizationPercent;
    private final double latencyDriftPerTick;
    private final double packetLossDriftPerTick;
    private final double cpuDriftPerTick;

    private NodeModel(String nodeId, double trueLatencyMs, double truePacketLossPercent,
                      double trueCpuUtilizationPercent, double latencyDriftPerTick,
                      double packetLossDriftPerTick, double cpuDriftPerTick) {
        this.nodeId = nodeId;
        this.trueLatencyMs = trueLatencyMs;
        this.truePacketLossPercent = truePacketLossPercent;
        this.trueCpuUtilizationPercent = trueCpuUtilizationPercent;
        this.latencyDriftPerTick = latencyDriftPerTick;
        this.packetLossDriftPerTick = packetLossDriftPerTick;
        this.cpuDriftPerTick = cpuDriftPerTick;
    }

    /** @return the node identifier */
    public String nodeId() {
        return nodeId;
    }

    /** @return true network latency in milliseconds */
    public double trueLatencyMs() {
        return trueLatencyMs;
    }

    /** @return true packet loss in percent */
    public double truePacketLossPercent() {
        return truePacketLossPercent;
    }

    /** @return true CPU utilization in percent */
    public double trueCpuUtilizationPercent() {
        return trueCpuUtilizationPercent;
    }

    /**
     * Advances the node state by one tick using deterministic drift.
     * Values are clamped to valid ranges: latency >= 0, packet loss in [0,100],
     * CPU utilization in [0,100].
     */
    public void tick() {
        trueLatencyMs = Math.max(0.0, trueLatencyMs + latencyDriftPerTick);
        truePacketLossPercent = clamp0100(truePacketLossPercent + packetLossDriftPerTick);
        trueCpuUtilizationPercent = clamp0100(trueCpuUtilizationPercent + cpuDriftPerTick);
    }

    private static double clamp0100(double value) {
        return Math.max(0.0, Math.min(100.0, value));
    }

    /** Builder for {@link NodeModel}. */
    public static class Builder {
        private String nodeId;
        private double trueLatencyMs = 50.0;
        private double truePacketLossPercent = 1.0;
        private double trueCpuUtilizationPercent = 50.0;
        private double latencyDriftPerTick = 0.0;
        private double packetLossDriftPerTick = 0.0;
        private double cpuDriftPerTick = 0.0;

        public Builder nodeId(String nodeId) {
            this.nodeId = nodeId;
            return this;
        }

        public Builder trueLatencyMs(double trueLatencyMs) {
            this.trueLatencyMs = trueLatencyMs;
            return this;
        }

        public Builder truePacketLossPercent(double truePacketLossPercent) {
            this.truePacketLossPercent = truePacketLossPercent;
            return this;
        }

        public Builder trueCpuUtilizationPercent(double trueCpuUtilizationPercent) {
            this.trueCpuUtilizationPercent = trueCpuUtilizationPercent;
            return this;
        }

        public Builder latencyDriftPerTick(double latencyDriftPerTick) {
            this.latencyDriftPerTick = latencyDriftPerTick;
            return this;
        }

        public Builder packetLossDriftPerTick(double packetLossDriftPerTick) {
            this.packetLossDriftPerTick = packetLossDriftPerTick;
            return this;
        }

        public Builder cpuDriftPerTick(double cpuDriftPerTick) {
            this.cpuDriftPerTick = cpuDriftPerTick;
            return this;
        }

        public NodeModel build() {
            return new NodeModel(nodeId, trueLatencyMs, truePacketLossPercent,
                    trueCpuUtilizationPercent, latencyDriftPerTick,
                    packetLossDriftPerTick, cpuDriftPerTick);
        }
    }
}
