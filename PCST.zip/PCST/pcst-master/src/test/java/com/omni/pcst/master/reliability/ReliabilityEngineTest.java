package com.omni.pcst.master.reliability;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.capability.BeliefPosteriorDistributionSource;
import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityCombiner;
import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.capability.CapabilityStatus;
import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.task.HardConstraintConfig;
import com.omni.pcst.master.task.InterruptionTolerance;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.RejectionReason;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Hand-calculated tests for {@link ReliabilityEngine}.
 *
 * <p>The only value the current model can produce is the resource-only contract
 * case, where {@code Esucc = Eresource} and {@code R = C = &Phi;((r - &mu;)/&sigma;)}.
 * Every expected probability is computed by hand from the standard normal table,
 * so the tests pin the arithmetic rather than trusting the implementation. Every
 * other case must yield an explicit status with a {@code null} reliability. No
 * randomness, no gRPC, no wall-clock dependence.
 */
class ReliabilityEngineTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final long HORIZON = 60_000L;
    private static final long MAX_AGE = HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS;
    private static final double TOL = 1e-6;

    private static final String LATENCY = BayesianBeliefEngine.NETWORK_LATENCY_MS;
    private static final String PACKET_LOSS = BayesianBeliefEngine.NETWORK_PACKET_LOSS_PERCENT;

    private static final double PHI_2 = 0.9772498680518208;
    private static final double PHI_POINT_FOUR = 0.6554217416103242;

    private final CapabilityEngine capabilityEngine = new CapabilityEngine();
    private final ReliabilityEngine engine = new ReliabilityEngine();

    /* ------------------------------------------------------------ fixtures */

    private static ResourceBelief belief(String key, double mean, double variance) {
        return new ResourceBelief(key, mean, variance, 5L, T0);
    }

    private static Map<String, ResourceBelief> beliefs(ResourceBelief... entries) {
        Map<String, ResourceBelief> map = new LinkedHashMap<>();
        for (ResourceBelief entry : entries) {
            map.put(entry.resourceName(), entry);
        }
        return map;
    }

    private static DigitalTwinSnapshot snapshot(String nodeId, long receivedAt,
                                                Map<String, ResourceBelief> beliefs) {
        BeliefState state = beliefs.isEmpty()
                ? BeliefState.UNINITIALIZED
                : BeliefState.of(beliefs, 1L, receivedAt, receivedAt);
        return new DigitalTwinSnapshot(nodeId, "host-" + nodeId, 9091, "0.1.0",
                T0, T0, T0, null, List.of(), receivedAt, 0L, state);
    }

    private static Task latencyTask(double maxLatency) {
        return Task.builder("task-lat")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, null, null, null))
                .build();
    }

    private static Task networkTask(double maxLatency, double maxPacketLoss) {
        return Task.builder("task-net")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, maxPacketLoss, null, null))
                .build();
    }

    private ReliabilityInput input(Task task, DigitalTwinSnapshot node) {
        return new ReliabilityInput(task, node, null, capabilityEngine.assess(task, node, T0));
    }

    private ReliabilityInput input(Task task, DigitalTwinSnapshot node, NodeEligibilityResult eligibility) {
        return new ReliabilityInput(task, node, eligibility, capabilityEngine.assess(task, node, T0));
    }

    /* ------------------------------------------- resource-only contract: R = C */

    @Test
    void resourceOnlyContractYieldsCapabilityProbability() {
        // r = 100 ms, X ~ Normal(80, 10^2): R = P(X <= 100) = Phi(2) = 0.9772499.
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(PHI_2, assessment.reliability(), TOL);
        assertTrue(assessment.derivedFromCapability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.RESOURCE_EVENT_IS_ENTIRE_CONTRACT));

        CapabilityAssessment capability = capabilityEngine.assess(task, node, T0);
        assertEquals(capability.capability(), assessment.reliability(),
                "R must equal C exactly for a resource-only contract (no extra factor)");
    }

    @Test
    void packetLossOnlyContractYieldsCapabilityProbability() {
        // r = 3 %, X ~ Normal(1, 1^2): R = Phi(2) = 0.9772499.
        Task task = Task.builder("task-loss")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, null, 3.0, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-loss", T0, beliefs(belief(PACKET_LOSS, 1.0, 1.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(PHI_2, assessment.reliability(), TOL);
        assertTrue(assessment.derivedFromCapability());
    }

    @Test
    void eventsCoverAllSpecificationSuccessEventsInOrder() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-all", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(
                List.of(ReliabilityEvent.RESOURCE, ReliabilityEvent.DEADLINE, ReliabilityEvent.ENERGY,
                        ReliabilityEvent.QOS, ReliabilityEvent.STABILITY),
                assessment.events().stream().map(SuccessEventAssessment::event).toList());
        assertEquals(1, assessment.requiredEvents().size());
        assertEquals(ReliabilityEvent.RESOURCE, assessment.requiredEvents().get(0).event());
        assertEquals(ReliabilityReason.EVENT_NOT_IN_CONTRACT,
                assessment.eventFor(ReliabilityEvent.DEADLINE).reason());
        assertFalse(assessment.eventFor(ReliabilityEvent.STABILITY).required());
    }

    @Test
    void reliabilityAppliesNoUncertaintyPenaltyBeyondTheCapabilityProbability() {
        // Same mean, different variance: the value tracks Phi((r-mu)/sigma) exactly.
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot tight = snapshot("tight", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        DigitalTwinSnapshot wide = snapshot("wide", T0, beliefs(belief(LATENCY, 80.0, 2500.0)));

        ReliabilityAssessment tightR = engine.assess(input(task, tight));
        ReliabilityAssessment wideR = engine.assess(input(task, wide));

        assertEquals(PHI_2, tightR.reliability(), TOL);            // Phi((100-80)/10)
        assertEquals(PHI_POINT_FOUR, wideR.reliability(), TOL);    // Phi((100-80)/50)
        assertEquals(capabilityEngine.assess(task, wide, T0).capability(), wideR.reliability());
    }

    /* ----------------------------- does NOT blindly copy capability: other events */

    @Test
    void networkPlusDeadlineDoesNotReturnCapability() {
        Task task = Task.builder("task-deadline")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(T0 + 600_000L, null, null, 100.0, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-deadline", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertFalse(assessment.derivedFromCapability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.NO_COMPLETION_TIME_MODEL));

        SuccessEventAssessment deadline = assessment.eventFor(ReliabilityEvent.DEADLINE);
        assertTrue(deadline.required());
        assertNull(deadline.probability());
        assertEquals(ReliabilityReason.NO_COMPLETION_TIME_MODEL, deadline.reason());

        // The capability estimate (COMPUTABLE, Phi(2)) must not have been relabelled
        // or multiplied into a reliability number.
        CapabilityAssessment capability = capabilityEngine.assess(task, node, T0);
        assertEquals(CapabilityStatus.COMPUTABLE, capability.status());
        assertEquals(PHI_2, capability.capability(), TOL);
        assertNull(assessment.reliability());
    }

    @Test
    void networkPlusBatteryDoesNotReturnCapability() {
        Task task = Task.builder("task-battery")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, 30.0, 100.0, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-battery", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.NO_ENERGY_PROCESS_MODEL));
        assertEquals(ReliabilityEvent.ENERGY, assessment.requiredEvents().get(1).event());
    }

    @Test
    void networkPlusQosTargetDoesNotReturnCapability() {
        Task task = Task.builder("task-qos")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, 100.0, null, null, "gpu-profile"))
                .build();
        DigitalTwinSnapshot node = snapshot("node-qos", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.NO_QOS_MODEL));
    }

    @Test
    void networkPlusInterruptionToleranceDoesNotReturnCapability() {
        Task task = Task.builder("task-stability")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, 100.0, null,
                        InterruptionTolerance.NON_PREEMPTIBLE, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-stability", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.NO_STABILITY_MODEL));
    }

    @Test
    void unresolvedResourceJointDoesNotProduceReliability() {
        // Two network conditions with the default (unresolved) combiner: no joint C.
        Task task = networkTask(100.0, 3.0);
        DigitalTwinSnapshot node = snapshot("node-joint", T0, beliefs(
                belief(LATENCY, 80.0, 100.0), belief(PACKET_LOSS, 1.0, 1.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.RESOURCE_JOINT_MODEL_UNRESOLVED));
    }

    @Test
    void resourceJointCapabilityUnderIndependenceOptInIsInherited() {
        CapabilityEngine independence = new CapabilityEngine(
                new BeliefPosteriorDistributionSource(), CapabilityCombiner.independenceProduct(), MAX_AGE);
        Task task = networkTask(100.0, 3.0);
        DigitalTwinSnapshot node = snapshot("node-optin", T0, beliefs(
                belief(LATENCY, 80.0, 100.0), belief(PACKET_LOSS, 1.0, 1.0)));
        CapabilityAssessment capability = independence.assess(task, node, T0);

        ReliabilityAssessment assessment =
                engine.assess(new ReliabilityInput(task, node, null, capability));

        assertEquals(ReliabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(PHI_2 * PHI_2, assessment.reliability(), TOL);
        assertTrue(assessment.derivedFromCapability());
    }

    /* ------------------------------------------------------ hard constraints */

    @Test
    void provenHardConstraintRejectionIsNotOverturned() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        NodeEligibilityResult rejected = new NodeEligibilityResult(task.taskId(), "node-lat",
                false, false, List.of(), List.of(RejectionReason.NETWORK_LATENCY_EXCEEDED), T0);

        ReliabilityAssessment assessment = engine.assess(input(task, node, rejected));

        assertEquals(ReliabilityStatus.REJECTED_HARD_CONSTRAINT, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.HARD_CONSTRAINT_VIOLATION));
        assertFalse(assessment.reasons().contains(ReliabilityReason.HARD_CONSTRAINT_INDETERMINATE));
    }

    @Test
    void indeterminateRejectionIsDistinguishedFromProvenViolation() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        NodeEligibilityResult rejected = new NodeEligibilityResult(task.taskId(), "node-lat",
                false, true, List.of(), List.of(RejectionReason.STALE_EVIDENCE), T0);

        ReliabilityAssessment assessment = engine.assess(input(task, node, rejected));

        assertEquals(ReliabilityStatus.REJECTED_HARD_CONSTRAINT, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.HARD_CONSTRAINT_INDETERMINATE));
        assertFalse(assessment.reasons().contains(ReliabilityReason.HARD_CONSTRAINT_VIOLATION));
    }

    @Test
    void eligibleButIndeterminateIsUnresolved() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        NodeEligibilityResult admitted = new NodeEligibilityResult(task.taskId(), "node-lat",
                true, true, List.of(), List.of(RejectionReason.NETWORK_LATENCY_UNKNOWN), T0);

        ReliabilityAssessment assessment = engine.assess(input(task, node, admitted));

        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.HARD_CONSTRAINT_INDETERMINATE));
    }

    /* ---------------------------------------------- capability status propagation */

    @Test
    void partialCapabilityDoesNotProduceReliability() {
        Task task = Task.builder("task-partial")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .resources(TaskResources.requiringMemory(1024L))
                .constraints(new TaskConstraints(null, null, null, 100.0, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-partial", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertFalse(assessment.derivedFromCapability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.RESOURCE_UNSUPPORTED_MODEL));
    }

    @Test
    void unsupportedCapabilityDoesNotProduceReliability() {
        Task task = Task.builder("task-mem")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .resources(TaskResources.requiringMemory(1024L))
                .build();
        DigitalTwinSnapshot node = snapshot("node-mem", T0, Map.of());

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.UNSUPPORTED_MODEL, assessment.status());
        assertNull(assessment.reliability());
        assertNotEquals(0.0, assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.RESOURCE_UNSUPPORTED_MODEL));
    }

    @Test
    void capabilityInsufficientEvidencePropagates() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-empty", T0, Map.of());

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.INSUFFICIENT_EVIDENCE, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.CAPABILITY_INSUFFICIENT_EVIDENCE));
    }

    @Test
    void capabilityInvalidInputPropagates() {
        Task task = Task.builder("task-nohorizon")
                .workloadReference("ref")
                .constraints(new TaskConstraints(null, null, null, 100.0, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-noh", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.INVALID_INPUT, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.CAPABILITY_INVALID_INPUT));
    }

    /* ------------------------------------------------------------- bad inputs */

    @Test
    void missingCapabilityAssessmentIsInvalidInput() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment =
                engine.assess(new ReliabilityInput(task, node, null, null));

        assertEquals(ReliabilityStatus.INVALID_INPUT, assessment.status());
        assertNull(assessment.reliability());
        assertEquals("MISSING", assessment.capabilityStatus());
        assertTrue(assessment.reasons().contains(ReliabilityReason.MISSING_CAPABILITY_ASSESSMENT));
    }

    @Test
    void mismatchedNodeIdentitiesAreInvalidInput() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot assessed = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        DigitalTwinSnapshot mismatched = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        CapabilityAssessment capability = capabilityEngine.assess(task, assessed, T0);

        ReliabilityAssessment assessment =
                engine.assess(new ReliabilityInput(task, mismatched, null, capability));

        assertEquals(ReliabilityStatus.INVALID_INPUT, assessment.status());
        assertNull(assessment.reliability());
        assertTrue(assessment.reasons().contains(ReliabilityReason.INVALID_INPUT));
    }

    @Test
    void nullBoundariesAreRejected() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        assertThrows(NullPointerException.class, () -> engine.assess(null));
        assertThrows(NullPointerException.class, () -> new ReliabilityInput(null, node, null, null));
        assertThrows(NullPointerException.class, () -> new ReliabilityInput(task, null, null, null));
    }

    /* ------------------------------------------------------- vacuous contract */

    @Test
    void taskWithNoSuccessEventsIsVacuouslyReliable() {
        Task task = Task.minimal("task-none", "ref");
        DigitalTwinSnapshot node = snapshot("node-none", T0, Map.of());

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertEquals(ReliabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(1.0, assessment.reliability(), TOL);
        assertTrue(assessment.reasons().contains(ReliabilityReason.VACUOUS_SUCCESS_CONTRACT));
        assertEquals(1, assessment.requiredEvents().size());
    }

    /* ----------------------------------------------- determinism and immutability */

    @Test
    void identicalInputsProduceIdenticalAssessments() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        ReliabilityInput input = input(task, node);

        ReliabilityAssessment first = engine.assess(input);
        ReliabilityAssessment second = engine.assess(input);

        assertEquals(first, second);
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    void assessmentListsAreImmutable() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-imm", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        ReliabilityAssessment assessment = engine.assess(input(task, node));

        assertThrows(UnsupportedOperationException.class, () -> assessment.events().clear());
        assertThrows(UnsupportedOperationException.class, () -> assessment.reasons().clear());
    }

    /* --------------------------------------------------------------- batching */

    @Test
    void assessAllIsOrderedByNodeIdAndDeduplicates() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        ReliabilityInput inputB = input(task, b);
        ReliabilityInput inputA = input(task, a);

        List<ReliabilityAssessment> results = engine.assessAll(List.of(inputB, inputA, inputB));

        assertEquals(2, results.size());
        assertEquals(List.of("node-a", "node-b"),
                results.stream().map(ReliabilityAssessment::nodeId).toList());
        assertEquals(PHI_2, results.get(0).reliability(), TOL);
        assertNotNull(results.get(1).reliability());
    }
}
