package com.omni.pcst.master.evaluation.replay;

import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import com.omni.pcst.master.evaluation.TelemetryEvaluationRecord;
import com.omni.pcst.master.evaluation.TelemetryEvaluationStore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds deterministic synthetic telemetry evaluation files for tests.
 *
 * <p>Every artefact produced here is <b>synthetic test data</b>. No generated
 * value is a measurement of real system behaviour, and no test asserts a real
 * accuracy claim.
 */
final class SyntheticReplayFixtures {

    static final long T0 = 1_700_000_000_000L;
    static final long STEP = 1_000L;

    private SyntheticReplayFixtures() {
    }

    /** Observation with only the fields a case needs; everything else is null. */
    static TelemetryObservation observation(long ts, Double cpu, Long totalMem, Long usedMem,
                                            Double latency, Double packetLoss,
                                            Double battery, Double temperature) {
        return new TelemetryObservation(ts, cpu, totalMem, usedMem, null, null, null, battery,
                null, temperature, latency, packetLoss, null, null, null, null);
    }

    static TelemetryEvaluationRecord accepted(String nodeId, String sessionId, Long sequence,
                                              TelemetryObservation observation) {
        return TelemetryEvaluationRecord.of(nodeId, observation, observation.timestamp() + 1L,
                "synthetic-cfg", sessionId, sequence, "CONSECUTIVE", null, null);
    }

    static TelemetryEvaluationRecord auditOnly(String nodeId, String sessionId, Long sequence,
                                               TelemetryObservation observation, String classification) {
        return TelemetryEvaluationRecord.auditOnly(nodeId, observation,
                observation.timestamp() + 1L, "synthetic-cfg", sessionId, sequence, classification);
    }

    static TelemetryEvaluationRecord notValidForReplay(String nodeId, String sessionId, Long sequence,
                                                        TelemetryObservation observation) {
        return new TelemetryEvaluationRecord(nodeId, observation.timestamp(), observation,
                observation.timestamp() + 1L, "synthetic-cfg", false, sessionId, sequence,
                "INVALID_METADATA", null, null, true);
    }

    /** Serializes records to a JSON Lines file using the production codec. */
    static Path writeRecords(Path dir, String name, List<TelemetryEvaluationRecord> records)
            throws IOException {
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(
                dir.resolve(name), 1000, 10000, false);
        for (TelemetryEvaluationRecord record : records) {
            store.append(record);
        }
        store.flush();
        store.close();
        return store.getOutputPath();
    }

    /** Writes a JSON Lines file composed of raw text lines (for corruption cases). */
    static Path writeRawLines(Path dir, String name, List<String> lines) throws IOException {
        Path file = dir.resolve(name);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(line).append(System.lineSeparator());
        }
        Files.writeString(file, sb.toString(), StandardCharsets.UTF_8);
        return file;
    }

    /**
     * A perfectly linear CPU series: value increases by exactly {@code 1.0} per
     * {@link #STEP} millis.
     *
     * <p>With horizon H, persistence predicts {@code y(t)} while the actual is
     * {@code y(t)+H/STEP}, so the persistence error is exactly
     * {@code H/STEP} for every origin. OLS fits this series exactly, so the
     * trend error is 0. These closed-form values are asserted by the tests.
     */
    static List<TelemetryEvaluationRecord> linearCpuSeries(String nodeId, String sessionId,
                                                           int count, double startValue) {
        List<TelemetryEvaluationRecord> records = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            long ts = T0 + i * STEP;
            double cpu = startValue + i;   // +1.0 per step
            records.add(accepted(nodeId, sessionId, (long) (i + 1),
                    observation(ts, cpu, 1000L, 500L, null, null, null, null)));
        }
        return records;
    }

    /** A flat CPU series: persistence is exact, so its error is 0. */
    static List<TelemetryEvaluationRecord> flatCpuSeries(String nodeId, String sessionId,
                                                          int count, double value) {
        List<TelemetryEvaluationRecord> records = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            long ts = T0 + i * STEP;
            records.add(accepted(nodeId, sessionId, (long) (i + 1),
                    observation(ts, value, 1000L, 500L, null, null, null, null)));
        }
        return records;
    }
}