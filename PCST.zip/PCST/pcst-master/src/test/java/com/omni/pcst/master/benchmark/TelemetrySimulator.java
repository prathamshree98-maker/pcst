package com.omni.pcst.master.benchmark;

import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.util.Random;

/**
 * Generates observable {@link TelemetryObservation} from a node's true latent state.
 *
 * <p>Telemetry is a noisy, partial observation of the true state. The simulator
 * applies configurable Gaussian noise, staleness (old timestamps), and missing
 * fields (null values) to model real-world observation imperfections.
 *
 * <p>True state is never exposed through this class; only the produced observation
 * is returned.
 */
public final class TelemetrySimulator {

    private final Random random;
    private final double noiseStdDev;
    private final double stalenessProbability;
    private final double missingFieldProbability;
    private final long baseTimestampMillis;

    private TelemetrySimulator(Random random, double noiseStdDev,
                               double stalenessProbability, double missingFieldProbability,
                               long baseTimestampMillis) {
        this.random = random;
        this.noiseStdDev = noiseStdDev;
        this.stalenessProbability = stalenessProbability;
        this.missingFieldProbability = missingFieldProbability;
        this.baseTimestampMillis = baseTimestampMillis;
    }

    /**
     * Produces an observation for one node at one tick.
     *
     * @param nodeModel the node whose true state is observed; must not be null
     * @param tickIndex the current simulation tick; used for timestamp progression
     * @return a telemetry observation derived from true state with noise,
     *         possible staleness, and possible missing fields
     */
    public TelemetryObservation observe(NodeModel nodeModel, int tickIndex) {
        long timestamp = baseTimestampMillis + (long) tickIndex * 5000L;

        // Staleness: observation timestamp may be older than the current tick.
        long observationTimestamp = timestamp;
        if (random.nextDouble() < stalenessProbability) {
            observationTimestamp = timestamp - (long) (random.nextDouble() * 60000L);
        }

        // CPU utilization: noisy observation of true CPU.
        Double cpu = clamp0100(nodeModel.trueCpuUtilizationPercent()
                + random.nextGaussian() * noiseStdDev);
        if (random.nextDouble() < missingFieldProbability) {
            cpu = null;
        }

        // Latency: noisy observation of true latency (ms).
        Double latency = Math.max(0.0, nodeModel.trueLatencyMs()
                + random.nextGaussian() * noiseStdDev * 10.0);
        if (random.nextDouble() < missingFieldProbability) {
            latency = null;
        }

        // Packet loss: noisy observation of true packet loss (%).
        Double packetLoss = clamp0100(nodeModel.truePacketLossPercent()
                + random.nextGaussian() * noiseStdDev * 2.0);
        if (random.nextDouble() < missingFieldProbability) {
            packetLoss = null;
        }

        return new TelemetryObservation(
                observationTimestamp,
                cpu, null, null, null,
                null, null, null, null, null,
                latency, packetLoss, null, null, null, null);
    }

    private static double clamp0100(double value) {
        return Math.max(0.0, Math.min(100.0, value));
    }

    /** Builder for {@link TelemetrySimulator}. */
    public static class Builder {
        private long seed = 42L;
        private double noiseStdDev = 5.0;
        private double stalenessProbability = 0.0;
        private double missingFieldProbability = 0.0;
        private long baseTimestampMillis = 1_700_000_000_000L;

        public Builder seed(long seed) {
            this.seed = seed;
            return this;
        }

        public Builder noiseStdDev(double noiseStdDev) {
            this.noiseStdDev = noiseStdDev;
            return this;
        }

        public Builder stalenessProbability(double stalenessProbability) {
            this.stalenessProbability = stalenessProbability;
            return this;
        }

        public Builder missingFieldProbability(double missingFieldProbability) {
            this.missingFieldProbability = missingFieldProbability;
            return this;
        }

        public Builder baseTimestampMillis(long baseTimestampMillis) {
            this.baseTimestampMillis = baseTimestampMillis;
            return this;
        }

        public TelemetrySimulator build() {
            return new TelemetrySimulator(new Random(seed), noiseStdDev,
                    stalenessProbability, missingFieldProbability, baseTimestampMillis);
        }
    }
}
