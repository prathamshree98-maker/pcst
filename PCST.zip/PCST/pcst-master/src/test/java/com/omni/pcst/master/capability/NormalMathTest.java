package com.omni.pcst.master.capability;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Hand-calculated tests for {@link NormalMath}.
 *
 * <p>The Abramowitz–Stegun 7.1.26 approximation has a maximum absolute error of
 * 1.5&times;10<sup>&minus;7</sup>, so every assertion uses a tolerance of
 * 1&times;10<sup>&minus;6</sup> against values taken from standard normal tables.
 */
class NormalMathTest {

    private static final double TOL = 1e-6;

    @Test
    void erfMatchesStandardTable() {
        assertEquals(0.0, NormalMath.erf(0.0), TOL);
        assertEquals(0.5204998778130465, NormalMath.erf(0.5), TOL);
        assertEquals(0.8427007929497149, NormalMath.erf(1.0), TOL);
        assertEquals(0.9661051464753107, NormalMath.erf(1.5), TOL);
    }

    @Test
    void erfIsOdd() {
        assertEquals(-NormalMath.erf(1.0), NormalMath.erf(-1.0), TOL);
        assertEquals(-NormalMath.erf(2.0), NormalMath.erf(-2.0), TOL);
    }

    @Test
    void standardNormalCdfMatchesStandardTable() {
        assertEquals(0.5, NormalMath.standardNormalCdf(0.0), TOL);
        assertEquals(0.8413447460685429, NormalMath.standardNormalCdf(1.0), TOL);
        assertEquals(0.9772498680518208, NormalMath.standardNormalCdf(2.0), TOL);
        assertEquals(0.6914624612740131, NormalMath.standardNormalCdf(0.5), TOL);
        assertEquals(0.6554217416103242, NormalMath.standardNormalCdf(0.4), TOL);
        assertEquals(0.1586552539314570, NormalMath.standardNormalCdf(-1.0), TOL);
        assertEquals(0.0227501319481792, NormalMath.standardNormalCdf(-2.0), TOL);
    }

    @Test
    void upperAndLowerTailsSumToOne() {
        double lower = NormalMath.probabilityAtMost(5.0, 0.25, 4.0);
        double upper = NormalMath.probabilityAtLeast(5.0, 0.25, 4.0);
        assertEquals(1.0, lower + upper, TOL);
    }

    @Test
    void reproducesSpecificationSection82Example() {
        // Spec 8.2: M ~ Normal(5, 0.5^2), P(M >= 4) = 1 - Phi((4-5)/0.5) = 1 - Phi(-2).
        double atLeast = NormalMath.probabilityAtLeast(5.0, 0.25, 4.0);
        assertEquals(0.9772498680518208, atLeast, TOL);
        // Stated in the specification as approximately 0.977.
        assertEquals(0.977, atLeast, 5e-4);
    }

    @Test
    void probabilityAtMostAtMeanIsOneHalfForAnyVariance() {
        assertEquals(0.5, NormalMath.probabilityAtMost(100.0, 100.0, 100.0), TOL);
        assertEquals(0.5, NormalMath.probabilityAtMost(100.0, 2500.0, 100.0), TOL);
        assertEquals(0.5, NormalMath.probabilityAtMost(100.0, 1.0, 100.0), TOL);
    }

    @Test
    void variationOfVarianceDependsOnEventGeometry() {
        // Mean below the threshold: more spread adds mass above it, lowering P(X <= threshold).
        double tight = NormalMath.probabilityAtMost(80.0, 100.0, 100.0);   // Phi(2.0)
        double wide = NormalMath.probabilityAtMost(80.0, 2500.0, 100.0);   // Phi(0.4)
        assertEquals(0.9772498680518208, tight, TOL);
        assertEquals(0.6554217416103242, wide, TOL);
        assertTrue(wide < tight);
    }

    @Test
    void nonPositiveOrNonFiniteVarianceIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> NormalMath.probabilityAtMost(0.0, 0.0, 1.0));
        assertThrows(IllegalArgumentException.class,
                () -> NormalMath.probabilityAtMost(0.0, -1.0, 1.0));
        assertThrows(IllegalArgumentException.class,
                () -> NormalMath.probabilityAtMost(0.0, Double.NaN, 1.0));
        assertThrows(IllegalArgumentException.class,
                () -> NormalMath.probabilityAtMost(0.0, Double.POSITIVE_INFINITY, 1.0));
    }
}
