package com.omni.pcst.master.execution;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Read-only connectivity probe against the Neon production branch.
 *
 * <p>Runs only {@code SELECT 1} against the datasource URL provided via the
 * {@code DATABASE_URL} environment variable. No writes, no migrations, no
 * schema changes. Disabled when {@code DATABASE_URL} is not set.
 *
 * <p>Neon connection strings use the libpq {@code postgresql://} scheme with
 * {@code channel_binding=require}, which the PostgreSQL JDBC driver does not
 * accept natively. The test adapts the URL before connecting.
 */
@EnabledIfEnvironmentVariable(named = "DATABASE_URL", matches = ".+")
class NeonReadOnlyConnectivityTest {

    @Test
    void selectOneSucceedsAgainstLinkedBranch() throws Exception {
        String raw = System.getenv("DATABASE_URL");
        // Never log the URL or any embedded credentials.
        String jdbcUrl = toJdbcUrl(raw);
        Properties props = toProps(raw);

        try (Connection conn = DriverManager.getConnection(jdbcUrl, props);
             Statement stmt = conn.createStatement()) {
            var rs = stmt.executeQuery("SELECT 1");
            assertTrue(rs.next());
            assertEquals(1, rs.getInt(1));
        }
    }

    /**
     * Converts a Neon libpq connection string to a JDBC URL. Credentials are
     * stripped from the URL and returned separately via {@link #toProps}.
     * The returned URL contains no credentials.
     */
    private static String toJdbcUrl(String raw) {
        String url = raw;
        if (!url.startsWith("jdbc:")) {
            url = "jdbc:" + url;
        }
        // Strip userinfo (credentials) from the URL authority.
        int schemeEnd = url.indexOf("://");
        if (schemeEnd >= 0) {
            int at = url.indexOf('@', schemeEnd);
            if (at > 0) {
                int pathStart = url.indexOf('/', at);
                String hostPort = (pathStart > 0)
                        ? url.substring(at + 1, pathStart)
                        : url.substring(at + 1);
                String rest = (pathStart > 0)
                        ? url.substring(pathStart)
                        : "";
                url = url.substring(0, schemeEnd + 3) + hostPort + rest;
            }
        }
        // The PostgreSQL JDBC driver supports channel binding via channelBinding;
        // translate the libpq channel_binding parameter instead of dropping it,
        // so channel-binding security is preserved rather than silently disabled.
        url = url.replace("channel_binding=require", "channelBinding=require");
        url = url.replace("?&", "?").replace("&&", "&");
        if (url.endsWith("?") || url.endsWith("&")) {
            url = url.substring(0, url.length() - 1);
        }
        return url;
    }

    /**
     * Extracts user and password from the libpq userinfo segment.
     */
    private static Properties toProps(String raw) {
        Properties props = new Properties();
        int schemeEnd = raw.indexOf("://");
        if (schemeEnd >= 0) {
            int at = raw.indexOf('@', schemeEnd);
            if (at > 0) {
                String userInfo = raw.substring(schemeEnd + 3, at);
                int colon = userInfo.indexOf(':');
                if (colon > 0) {
                    props.setProperty("user", userInfo.substring(0, colon));
                    props.setProperty("password", userInfo.substring(colon + 1));
                }
            }
        }
        props.setProperty("sslmode", "require");
        return props;
    }
}
