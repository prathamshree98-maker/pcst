package com.omni.pcst.master.task;

import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic unit tests for {@link HardConstraintFilter}.
 *
 * <p>No gRPC, no network: candidates are immutable {@link DigitalTwinSnapshot}
 * records assembled directly, exactly as {@code DigitalTwinManager#getSnapshot}
 * would hand them to the filter.
 */
class HardConstraintFilterTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final long ONE_MIB = 1024L * 1024L;
    private static final long ONE_GIB = 1024L * ONE_MIB;

    private HardConstraintFilter filter;

    @BeforeEach
    void setUp() {
        filter = new HardConstraintFilter();
    }

    /* ---------------------------------------------------------- task fixtures */

    private static Task taskWithRequirements() {
        return Task.builder("task-1")
                .taskClass(TaskClass.CPU_BOUND)
                .workloadReference("docker://benchmark:1")
                .expectedDurationMillis(60_000L)
                .resources(new TaskResources(
                        2 * ONE_GIB,
                        10 * ONE_GIB,
                        false,
                        null,
                        null))
                .constraints(new TaskConstraints(
                        T0 + 3_600_000L,
                        60_000L,
                        10.0,
                        50.0,
                        1.0,
                        null,
                        null))
                .build();
    }

    private static Task noRequirementsTask() {
        return Task.minimal("task-min", "docker://trivial:1");
    }

    private static Task taskWithResources(TaskResources resources) {
        return Task.builder("task-res").workloadReference("ref").resources(resources).build();
    }

    private static Task taskWithConstraints(TaskConstraints constraints) {
        return Task.builder("task-con").workloadReference("ref").constraints(constraints).build();
    }

    /* ------------------------------------------------------- snapshot fixtures */

    private static TelemetryObservation observation(long timestamp,
                                                     Long availableMemoryBytes,
                                                     Long freeDiskBytes,
                                                     Boolean gpuAvailable,
                                                     Double batteryPercent,
                                                     Double latencyMs,
                                                     Double packetLossPercent) {
        return new TelemetryObservation(
                timestamp,
                12.5,
                8 * ONE_GIB,
                8 * ONE_GIB - (availableMemoryBytes == null ? 0 : availableMemoryBytes),
                availableMemoryBytes,
                gpuAvailable,
                null,
                batteryPercent,
                null,
                null,
                latencyMs,
                packetLossPercent,
                100 * ONE_GIB,
                freeDiskBytes,
                4,
                null);
    }

    private static DigitalTwinSnapshot snapshot(String nodeId,
                                                 TelemetryObservation latest,
                                                 long lastTelemetryReceivedAtMillis,
                                                 long lastHeartbeatMillis) {
        List<TelemetryObservation> history = latest == null
                ? List.of()
                : List.of(latest);
        return new DigitalTwinSnapshot(
                nodeId,
                "host-" + nodeId,
                9091,
                "0.1.0",
                T0,
                T0,
                lastHeartbeatMillis,
                latest,
                history,
                lastTelemetryReceivedAtMillis,
                0L,
                BeliefState.UNINITIALIZED);
    }

    /** Fully healthy node whose measurements satisfy every requirement. */
    private static DigitalTwinSnapshot healthyNode(String nodeId, long now) {
        return snapshot(nodeId,
                observation(now, 6 * ONE_GIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01),
                now, now);
    }

    /* ------------------------------------------------------------------- tests */

    @Test
    void allRequirementsSatisfied() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot node = healthyNode("node-ok", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-ok", node, T0);

        assertTrue(result.eligible());
        assertFalse(result.indeterminate());
        assertTrue(result.reasons().isEmpty());
        assertEquals("task-1", result.taskId());
        assertEquals("node-ok", result.nodeId());
        assertEquals(T0, result.decisionTimeMillis());
        for (ConstraintEvaluation ce : result.constraints()) {
            assertEquals(ConstraintOutcome.SATISFIED, ce.outcome(),
                    () -> "constraint " + ce.constraint() + " should be satisfied");
            assertNull(ce.reason());
        }
    }

    @Test
    void singleDefiniteViolation() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot node = snapshot("node-low-mem",
                observation(T0, ONE_MIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-low-mem", node, T0);

        assertFalse(result.eligible());
        assertFalse(result.indeterminate(), "memory shortfall is a proven violation, not unproven");
        assertEquals(1, result.reasons().size());
        assertEquals(RejectionReason.MEMORY_INSUFFICIENT, result.reasons().get(0));

        ConstraintEvaluation memory = result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY);
        assertNotNull(memory);
        assertEquals(ConstraintOutcome.VIOLATED, memory.outcome());
        assertEquals("bytes", memory.unit());
        assertEquals("available>=" + (2 * ONE_GIB), memory.required());
        assertNotNull(memory.observed());

        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.STORAGE_AVAILABILITY).outcome());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.BATTERY_LEVEL).outcome());
    }

    @Test
    void multipleSimultaneousViolationsAllReported() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot node = snapshot("node-bad",
                observation(T0, ONE_MIB, ONE_MIB, Boolean.FALSE, 5.0, 500.0, 9.0),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-bad", node, T0);

        assertFalse(result.eligible());
        assertEquals(5, result.reasons().size(), "memory, storage, battery, latency, packet loss");
        assertTrue(result.reasons().contains(RejectionReason.MEMORY_INSUFFICIENT));
        assertTrue(result.reasons().contains(RejectionReason.STORAGE_INSUFFICIENT));
        assertTrue(result.reasons().contains(RejectionReason.BATTERY_BELOW_MINIMUM));
        assertTrue(result.reasons().contains(RejectionReason.NETWORK_LATENCY_EXCEEDED));
        assertTrue(result.reasons().contains(RejectionReason.PACKET_LOSS_EXCEEDED));
        assertEquals(5, result.blockingConstraints().size());
    }

    @Test
    void exactBoundaryComparisonsAreSatisfactions() {
        Task task = Task.builder("task-edge")
                .workloadReference("ref")
                .resources(new TaskResources(2 * ONE_GIB, 10 * ONE_GIB, false, null, null))
                .constraints(new TaskConstraints(null, null, 20.0, 25.0, 0.5, null, null))
                .build();

        DigitalTwinSnapshot node = snapshot("node-edge",
                observation(T0, 2 * ONE_GIB, 10 * ONE_GIB, null, 20.0, 25.0, 0.5),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-edge", node, T0);

        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY).outcome());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.STORAGE_AVAILABILITY).outcome());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.BATTERY_LEVEL).outcome());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.NETWORK_LATENCY).outcome());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.PACKET_LOSS).outcome());
    }

    @Test
    void oneEligibleAndOneIneligibleNode() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot good = healthyNode("node-a", T0);
        DigitalTwinSnapshot bad = snapshot("node-b",
                observation(T0, ONE_MIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01),
                T0, T0);

        List<NodeEligibilityResult> results = filter.filter(task, List.of(good, bad), T0);

        assertEquals(2, results.size());
        NodeEligibilityResult a = results.stream().filter(r -> r.nodeId().equals("node-a")).findFirst().orElseThrow();
        NodeEligibilityResult b = results.stream().filter(r -> r.nodeId().equals("node-b")).findFirst().orElseThrow();
        assertTrue(a.eligible());
        assertFalse(b.eligible());
        assertEquals(List.of(a), NodeEligibilityResult.eligibleCandidates(results));
    }

    @Test
    void multipleHeterogeneousNodesDeterministicOrder() {
        Task task = taskWithRequirements();
        List<DigitalTwinSnapshot> nodes = List.of(
                healthyNode("node-z", T0),
                snapshot("node-m", observation(T0, ONE_MIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01), T0, T0),
                healthyNode("node-a", T0));

        List<NodeEligibilityResult> results = filter.filter(task, nodes, T0);

        assertEquals(List.of("node-a", "node-m", "node-z"),
                results.stream().map(NodeEligibilityResult::nodeId).toList());
        assertTrue(results.get(0).eligible());
        assertFalse(results.get(1).eligible());
        assertTrue(results.get(2).eligible());

        List<NodeEligibilityResult> shuffled = filter.filter(task,
                List.of(nodes.get(2), nodes.get(0), nodes.get(1)), T0);
        for (NodeEligibilityResult r : shuffled) {
            NodeEligibilityResult reference = results.stream()
                    .filter(x -> x.nodeId().equals(r.nodeId())).findFirst().orElseThrow();
            assertEquals(reference.eligible(), r.eligible());
            assertEquals(reference.reasons(), r.reasons());
        }
    }

    @Test
    void missingResourceDataIsIndeterminateNotZero() {
        Task task = taskWithResources(TaskResources.requiringMemory(ONE_GIB));

        DigitalTwinSnapshot node = snapshot("node-sparse",
                observation(T0, null, 50 * ONE_GIB, null, null, null, null),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-sparse", node, T0);

        ConstraintEvaluation memory = result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY);
        assertEquals(ConstraintOutcome.INDETERMINATE, memory.outcome());
        assertEquals(RejectionReason.NO_OBSERVATION, memory.reason());
        assertNotNull(memory.observed());
        assertFalse(result.eligible(), "conservative default rejects on unproven constraint");
        assertTrue(result.indeterminate());
    }

    @Test
    void staleTelemetryIsIndeterminate() {
        Task task = taskWithResources(TaskResources.requiringMemory(ONE_GIB));

        long staleReceived = T0 - HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS - 1L;
        DigitalTwinSnapshot node = snapshot("node-stale",
                observation(staleReceived, 6 * ONE_GIB, 50 * ONE_GIB, null, null, null, null),
                staleReceived, staleReceived);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-stale", node, T0);

        ConstraintEvaluation memory = result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY);
        assertEquals(ConstraintOutcome.INDETERMINATE, memory.outcome());
        assertEquals(RejectionReason.STALE_EVIDENCE, memory.reason());
        assertFalse(result.eligible());
        assertTrue(result.indeterminate());
    }

    @Test
    void telemetryJustInsideAgeLimitStillFresh() {
        Task task = taskWithResources(TaskResources.requiringMemory(ONE_GIB));

        long received = T0 - HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS;
        DigitalTwinSnapshot node = snapshot("node-fresh",
                observation(received, 6 * ONE_GIB, 50 * ONE_GIB, null, null, null, null),
                received, received);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-fresh", node, T0);
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY).outcome());
        assertTrue(result.eligible());
    }

    @Test
    void uninitializedDigitalTwinHasNoObservation() {
        Task task = taskWithResources(TaskResources.requiringMemory(ONE_GIB));

        DigitalTwinSnapshot node = snapshot("node-uninit", null, 0L, 0L);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-uninit", node, T0);

        assertEquals(ConstraintOutcome.INDETERMINATE,
                result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY).outcome());
        assertEquals(RejectionReason.NO_OBSERVATION,
                result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY).reason());
        assertFalse(result.eligible());
        assertTrue(result.indeterminate());
    }

    @Test
    void unknownNodeReportsNodeUnknown() {
        Task task = taskWithRequirements();

        List<NodeEligibilityResult> results = filter.filterByNodeIds(
                task, List.of("ghost-1", "ghost-2"), id -> null, T0);

        assertEquals(2, results.size());
        for (NodeEligibilityResult r : results) {
            assertFalse(r.eligible());
            assertFalse(r.indeterminate(), "an unregistered id is a proven absence");
            assertEquals(RejectionReason.NODE_UNKNOWN, r.reasons().get(0));
            assertFalse(RejectionReason.NODE_UNKNOWN.isIndeterminate());
        }
        assertTrue(NodeEligibilityResult.eligibleCandidates(results).isEmpty());
    }

    @Test
    void explicitZeroValuesEvaluatedNotTreatedAsAbsent() {
        Task task = taskWithConstraints(new TaskConstraints(null, null, 0.0, 0.0, 0.0, null, null));

        DigitalTwinSnapshot node = snapshot("node-zero",
                observation(T0, 6 * ONE_GIB, 50 * ONE_GIB, null, 0.0, 0.0, 0.0),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-zero", node, T0);

        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.BATTERY_LEVEL).outcome());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.NETWORK_LATENCY).outcome());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.PACKET_LOSS).outcome());
    }

    @Test
    void gpuRequiredOnCpuOnlyNodeIsProvenViolation() {
        Task task = taskWithResources(new TaskResources(null, null, true, null, null));

        DigitalTwinSnapshot cpuOnly = snapshot("node-cpu",
                observation(T0, 6 * ONE_GIB, 50 * ONE_GIB, Boolean.FALSE, null, null, null),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-cpu", cpuOnly, T0);

        assertEquals(ConstraintOutcome.VIOLATED,
                result.outcomeOf(HardConstraint.ACCELERATOR_PRESENCE).outcome());
        assertEquals(RejectionReason.ACCELERATOR_ABSENT,
                result.outcomeOf(HardConstraint.ACCELERATOR_PRESENCE).reason());
        assertFalse(result.eligible());
        assertFalse(result.indeterminate());
    }

    @Test
    void gpuRequiredOnGpuNodeStillIndeterminateForDeviceMemory() {
        Task task = taskWithResources(TaskResources.requiringAccelerator(2 * ONE_GIB));

        DigitalTwinSnapshot gpuNode = snapshot("node-gpu",
                observation(T0, 6 * ONE_GIB, 50 * ONE_GIB, Boolean.TRUE, null, null, null),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-gpu", gpuNode, T0);

        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.ACCELERATOR_PRESENCE).outcome());
        ConstraintEvaluation vram = result.outcomeOf(HardConstraint.ACCELERATOR_MEMORY);
        assertEquals(ConstraintOutcome.INDETERMINATE, vram.outcome());
        assertEquals(RejectionReason.ACCELERATOR_MEMORY_UNVERIFIABLE, vram.reason());
        assertTrue(result.indeterminate());
        assertFalse(result.eligible(), "conservative default: unproven device memory excludes the node");
    }

    @Test
    void computeCapacityNeverInferredFromUtilization() {
        Task task = taskWithResources(new TaskResources(null, null, false, null, 16.0));

        DigitalTwinSnapshot idleNode = snapshot("node-idle",
                observation(T0, 6 * ONE_GIB, 50 * ONE_GIB, null, null, null, null),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-idle", idleNode, T0);

        ConstraintEvaluation compute = result.outcomeOf(HardConstraint.COMPUTE_CAPACITY);
        assertEquals(ConstraintOutcome.INDETERMINATE, compute.outcome());
        assertEquals(RejectionReason.COMPUTE_CAPACITY_UNVERIFIABLE, compute.reason());
        assertFalse(result.eligible());
    }

    @Test
    void deadlineInfeasibleWhenDurationCannotFit() {
        Task task = taskWithConstraints(new TaskConstraints(T0 + 1_000L, 2_000L, null, null, null, null, null));

        DigitalTwinSnapshot node = healthyNode("node-dl", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-dl", node, T0);

        assertEquals(ConstraintOutcome.VIOLATED,
                result.outcomeOf(HardConstraint.DEADLINE_FEASIBILITY).outcome());
        assertEquals(RejectionReason.DEADLINE_INFEASIBLE,
                result.outcomeOf(HardConstraint.DEADLINE_FEASIBILITY).reason());
        assertFalse(result.eligible());
    }

    @Test
    void deadlineFeasibleWhenDurationFits() {
        Task task = taskWithConstraints(new TaskConstraints(T0 + 10_000L, 2_000L, null, null, null, null, null));

        DigitalTwinSnapshot node = healthyNode("node-dl", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-dl", node, T0);

        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.DEADLINE_FEASIBILITY).outcome());
    }

    @Test
    void deadlineWithoutDurationIsIndeterminate() {
        Task task = taskWithConstraints(new TaskConstraints(T0 + 10_000L, null, null, null, null, null, null));

        DigitalTwinSnapshot node = healthyNode("node-dl", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-dl", node, T0);

        assertEquals(ConstraintOutcome.INDETERMINATE,
                result.outcomeOf(HardConstraint.DEADLINE_FEASIBILITY).outcome());
        assertEquals(RejectionReason.DEADLINE_UNVERIFIABLE,
                result.outcomeOf(HardConstraint.DEADLINE_FEASIBILITY).reason());
        assertTrue(result.indeterminate());
    }

    @Test
    void taskDurationUsedWhenConstraintsOmitDuration() {
        Task task = Task.builder("task-dur")
                .workloadReference("ref")
                .expectedDurationMillis(5_000L)
                .constraints(new TaskConstraints(T0 + 10_000L, null, null, null, null, null, null))
                .build();

        DigitalTwinSnapshot node = healthyNode("node-dur", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-dur", node, T0);
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.DEADLINE_FEASIBILITY).outcome());
    }

    @Test
    void admitUnprovenPolicyAdmitsIndeterminateNodes() {
        HardConstraintFilter permissive = new HardConstraintFilter(
                HardConstraintConfig.of(15_000L, IndeterminatePolicy.ADMIT_UNPROVEN));

        Task task = taskWithResources(new TaskResources(ONE_GIB, null, false, 2 * ONE_GIB, 16.0));

        DigitalTwinSnapshot node = snapshot("node-policy",
                observation(T0, 6 * ONE_GIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01),
                T0, T0);

        List<NodeEligibilityResult> results = permissive.filter(task, List.of(node), T0);
        assertEquals(1, results.size());
        assertTrue(results.get(0).eligible(),
                "ADMIT_UNPROVEN admits a node whose proven constraints all pass");
        assertTrue(results.get(0).indeterminate());
    }

    @Test
    void admitUnprovenPolicyStillRejectsProvenViolations() {
        HardConstraintFilter permissive = new HardConstraintFilter(
                HardConstraintConfig.of(15_000L, IndeterminatePolicy.ADMIT_UNPROVEN));

        Task task = taskWithResources(TaskResources.requiringMemory(ONE_GIB));

        DigitalTwinSnapshot node = snapshot("node-policy",
                observation(T0, ONE_MIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01),
                T0, T0);

        NodeEligibilityResult result = permissive.filter(task, List.of(node), T0).get(0);

        assertFalse(result.eligible());
        assertFalse(result.indeterminate(), "memory shortfall is proven");
        assertTrue(result.reasons().contains(RejectionReason.MEMORY_INSUFFICIENT));
    }

    @Test
    void indeterminatePolicyDefaultIsReject() {
        assertEquals(IndeterminatePolicy.REJECT, new HardConstraintFilter().config().indeterminatePolicy());
    }

    @Test
    void negativeMaxEvidenceAgeRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> HardConstraintConfig.of(-1L, IndeterminatePolicy.REJECT));
    }

    @Test
    void nullSnapshotYieldsEvaluationErrorNotCrash() {
        Task task = taskWithRequirements();

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-null", null, T0);

        assertNotNull(result);
        assertFalse(result.eligible());
        assertTrue(result.indeterminate());
        assertEquals(RejectionReason.EVALUATION_ERROR, result.reasons().get(0));
    }

    @Test
    void nullObservationCandidateDoesNotAffectOtherCandidates() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot good = healthyNode("node-good", T0);
        DigitalTwinSnapshot uninitialized = snapshot("node-uninit", null, T0, T0);

        List<NodeEligibilityResult> results = filter.filter(task, List.of(good, uninitialized), T0);

        assertEquals(2, results.size());
        assertTrue(results.stream().filter(r -> r.nodeId().equals("node-good")).findFirst().orElseThrow().eligible());
        NodeEligibilityResult broken = results.stream()
                .filter(r -> r.nodeId().equals("node-uninit")).findFirst().orElseThrow();
        assertFalse(broken.eligible());
        assertTrue(broken.reasons().contains(RejectionReason.NO_OBSERVATION));
    }

    @Test
    void emptyCandidateListYieldsEmptyResult() {
        List<NodeEligibilityResult> results = filter.filter(taskWithRequirements(), List.of(), T0);
        assertTrue(results.isEmpty());
        assertTrue(NodeEligibilityResult.eligibleCandidates(results).isEmpty());
    }

    @Test
    void duplicateNodeIdsCollapseDeterministically() {
        Task task = noRequirementsTask();
        DigitalTwinSnapshot first = healthyNode("node-dup", T0);
        DigitalTwinSnapshot second = snapshot("node-dup",
                observation(T0, ONE_MIB, ONE_MIB, Boolean.FALSE, 1.0, 999.0, 9.0),
                T0, T0);

        List<NodeEligibilityResult> results = filter.filter(task, List.of(first, second, first), T0);

        assertEquals(1, results.size(), "duplicates collapse to one evaluation");
        assertEquals("node-dup", results.get(0).nodeId());
        assertTrue(results.get(0).eligible(), "first occurrence in iteration order wins");
    }

    @Test
    void multipleReasonsRemainVisibleAndOrdered() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot node = snapshot("node-multi",
                observation(T0, ONE_MIB, ONE_MIB, Boolean.FALSE, 5.0, 500.0, 9.0),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-multi", node, T0);

        assertEquals(result.blockingConstraints().size(), result.reasons().size());
        for (int i = 0; i < result.blockingConstraints().size(); i++) {
            assertEquals(result.blockingConstraints().get(i).reason(), result.reasons().get(i));
        }
        assertEquals(HardConstraint.values().length, result.constraints().size());
    }

    @Test
    void resultsAreDeterministicAcrossRepeatedEvaluation() {
        Task task = taskWithRequirements();
        List<DigitalTwinSnapshot> nodes = List.of(
                healthyNode("node-1", T0),
                snapshot("node-2", observation(T0, ONE_MIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01), T0, T0),
                snapshot("node-3", observation(T0, 6 * ONE_GIB, ONE_MIB, Boolean.TRUE, 80.0, 10.0, 0.01), T0, T0));

        List<NodeEligibilityResult> first = filter.filter(task, nodes, T0);
        List<NodeEligibilityResult> second = filter.filter(task, nodes, T0);

        assertEquals(first.size(), second.size());
        for (int i = 0; i < first.size(); i++) {
            NodeEligibilityResult a = first.get(i);
            NodeEligibilityResult b = second.get(i);
            assertEquals(a.nodeId(), b.nodeId());
            assertEquals(a.eligible(), b.eligible());
            assertEquals(a.indeterminate(), b.indeterminate());
            assertEquals(a.reasons(), b.reasons());
            assertEquals(a.constraints(), b.constraints());
        }
    }

    @Test
    void eligibleCandidatesDerivesFeasibleSet() {
        Task task = taskWithRequirements();
        List<DigitalTwinSnapshot> nodes = List.of(
                healthyNode("node-1", T0),
                snapshot("node-2", observation(T0, ONE_MIB, 50 * ONE_GIB, Boolean.TRUE, 80.0, 10.0, 0.01), T0, T0),
                healthyNode("node-3", T0));

        List<NodeEligibilityResult> results = filter.filter(task, nodes, T0);
        List<NodeEligibilityResult> feasible = NodeEligibilityResult.eligibleCandidates(results);

        assertEquals(2, feasible.size());
        assertEquals(List.of("node-1", "node-3"),
                feasible.stream().map(NodeEligibilityResult::nodeId).toList());
    }

    @Test
    void noRequirementsTaskIsEligibleOnHealthyNode() {
        DigitalTwinSnapshot node = healthyNode("node-x", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(noRequirementsTask(), "node-x", node, T0);

        assertTrue(result.eligible());
        assertTrue(result.reasons().isEmpty());
        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.MEMORY_AVAILABILITY).outcome());
    }

    @Test
    void batteryUnknownWhenMeasurementAbsent() {
        Task task = taskWithConstraints(new TaskConstraints(null, null, 10.0, null, null, null, null));

        DigitalTwinSnapshot node = snapshot("node-batt",
                observation(T0, 6 * ONE_GIB, 50 * ONE_GIB, null, null, null, null),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-batt", node, T0);

        ConstraintEvaluation battery = result.outcomeOf(HardConstraint.BATTERY_LEVEL);
        assertEquals(ConstraintOutcome.INDETERMINATE, battery.outcome());
        assertEquals(RejectionReason.BATTERY_UNKNOWN, battery.reason());
        assertTrue(battery.reason().isIndeterminate());
        assertFalse(result.eligible());
    }

    @Test
    void networkMeasurementsAbsentAreIndeterminate() {
        Task task = taskWithConstraints(new TaskConstraints(null, null, null, 50.0, 1.0, null, null));

        DigitalTwinSnapshot node = snapshot("node-net",
                observation(T0, 6 * ONE_GIB, 50 * ONE_GIB, null, null, null, null),
                T0, T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-net", node, T0);

        assertEquals(ConstraintOutcome.INDETERMINATE,
                result.outcomeOf(HardConstraint.NETWORK_LATENCY).outcome());
        assertEquals(RejectionReason.NETWORK_LATENCY_UNKNOWN,
                result.outcomeOf(HardConstraint.NETWORK_LATENCY).reason());
        assertEquals(ConstraintOutcome.INDETERMINATE,
                result.outcomeOf(HardConstraint.PACKET_LOSS).outcome());
        assertEquals(RejectionReason.PACKET_LOSS_UNKNOWN,
                result.outcomeOf(HardConstraint.PACKET_LOSS).reason());
    }

    @Test
    void executionProfileUnverifiableOnCurrentModel() {
        Task task = taskWithConstraints(new TaskConstraints(null, null, null, null, null, null, "gpu-any"));

        DigitalTwinSnapshot node = healthyNode("node-profile", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-profile", node, T0);

        ConstraintEvaluation profile = result.outcomeOf(HardConstraint.EXECUTION_PROFILE);
        assertEquals(ConstraintOutcome.INDETERMINATE, profile.outcome());
        assertEquals(RejectionReason.EXECUTION_PROFILE_UNVERIFIABLE, profile.reason());
        assertFalse(result.eligible());
    }

    @Test
    void blankExecutionProfileNotEvaluated() {
        Task task = taskWithConstraints(new TaskConstraints(null, null, null, null, null, null, "  "));

        DigitalTwinSnapshot node = healthyNode("node-profile", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-profile", node, T0);

        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.EXECUTION_PROFILE).outcome());
    }

    @Test
    void noDeadlineMakesDeadlineConstraintSatisfied() {
        Task task = noRequirementsTask();
        DigitalTwinSnapshot node = healthyNode("node-nodl", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-nodl", node, T0);

        assertEquals(ConstraintOutcome.SATISFIED,
                result.outcomeOf(HardConstraint.DEADLINE_FEASIBILITY).outcome());
    }

    @Test
    void resultListsAreImmutable() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot node = healthyNode("node-imm", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-imm", node, T0);

        assertThrows(UnsupportedOperationException.class, () -> result.constraints().clear());
        assertThrows(UnsupportedOperationException.class, () -> result.reasons().clear());
    }

    @Test
    void nullObservationSnapshotDoesNotThrow() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot nullSnap = snapshot("node-nullsnap", null, 0L, 0L);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-nullsnap", nullSnap, T0);

        assertNotNull(result);
        assertFalse(result.eligible());
    }

    @Test
    void filterByNodeIdsResolvesThroughProvidedResolver() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot node = healthyNode("node-resolved", T0);
        Map<String, DigitalTwinSnapshot> registry = new HashMap<>();
        registry.put("node-resolved", node);

        List<NodeEligibilityResult> results = filter.filterByNodeIds(
                task, List.of("node-resolved", "node-missing"),
                registry::get, T0);

        assertEquals(2, results.size());
        assertTrue(results.stream().filter(r -> r.nodeId().equals("node-resolved")).findFirst().orElseThrow().eligible());
        assertEquals(RejectionReason.NODE_UNKNOWN,
                results.stream().filter(r -> r.nodeId().equals("node-missing")).findFirst().orElseThrow().reasons().get(0));
    }

    @Test
    void evaluationCoversAllHardConstraints() {
        Task task = taskWithRequirements();
        DigitalTwinSnapshot node = healthyNode("node-all", T0);

        NodeEligibilityResult result = filter.evaluateCandidate(task, "node-all", node, T0);

        for (HardConstraint constraint : HardConstraint.values()) {
            assertNotNull(result.outcomeOf(constraint),
                    () -> "constraint " + constraint + " must be evaluated");
        }
    }
}