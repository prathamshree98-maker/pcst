package com.omni.pcst.master.execution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Executable evidence that Spring Boot's {@code DataSourceAutoConfiguration} and
 * {@code FlywayAutoConfiguration} are activated <b>only</b> when
 * {@code pcst.persistence.jdbc.enabled=true}.
 *
 * <p>{@link PcstMasterApplication} excludes {@code DataSourceAutoConfiguration};
 * {@link TaskPersistenceConfiguration} conditionally re-imports it (and
 * {@code FlywayAutoConfiguration}) via {@link
 * org.springframework.boot.autoconfigure.ImportAutoConfiguration} when
 * {@code pcst.persistence.jdbc.enabled=true}. No real database is connected.
 */
class TaskPersistenceConfigurationTest {

    private static final String ENABLED_TRUE = "pcst.persistence.jdbc.enabled=true";
    private static final String ENABLED_FALSE = "pcst.persistence.jdbc.enabled=false";

    @Test
    void jdbcDisabledDoesNotActivateDatasourceOrFlyway() {
        new ApplicationContextRunner()
                .withUserConfiguration(TaskPersistenceConfiguration.class)
                .withPropertyValues(ENABLED_FALSE)
                .run(context -> {
                    // Disabled: no datasource bean is created automatically and no Flyway bean.
                    assertThat(context.getBeanNamesForType(javax.sql.DataSource.class)).isEmpty();
                    assertThat(context).doesNotHaveBean(org.flywaydb.core.Flyway.class.getName());
                });
    }

    @Test
    void jdbcEnabledWithUnavailableDatabaseFailsClosed() {
        // Enabled with an unreachable datasource: FlywayAutoConfiguration activates and its
        // FlywayMigrationInitializer attempts to obtain a connection on startup, so the
        // application context fails to start (fail closed) instead of silently falling back
        // to in-memory storage.
        new ApplicationContextRunner()
                .withUserConfiguration(TaskPersistenceConfiguration.class)
                .withPropertyValues(
                        ENABLED_TRUE,
                        "spring.datasource.url=jdbc:postgresql://localhost:5432/neondb"
                )
                .run(context -> {
                    assertThatThrownBy(() -> context.getBean(org.flywaydb.core.Flyway.class))
                            .isInstanceOf(IllegalStateException.class);
                });
    }
}
