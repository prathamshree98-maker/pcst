package com.omni.pcst.master.belief;

import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic mathematical tests for {@link BayesianBeliefEngine}.
 *
 * <p>All expected values are hand-computed from the Normal–Normal conjugate
 * update: with prior N(&mu;<sub>0</sub>, &sigma;<sub>0</sub><sup>2</sup>) and n
 * measurements of noise variance r,
 * <pre>
 *   posterior variance = 1 / (1/&sigma;<sub>0</sub><sup>2</sup> + n/r)
 *   posterior mean     = posteriorVariance * (&mu;<sub>0</sub>/&sigma;<sub>0</sub><sup>2</sup> + &Sigma;x<sub>i</sub>/r)
 * </pre>
 * No randomness, no hardware, no time dependence.
 */
class BayesianBeliefEngineTest {

    private static final String CPU = BayesianBeliefEngine.CPU_UTILIZATION_PERCENT;
    private static final String MEMORY = BayesianBeliefEngine.MEMORY_UTILIZATION_PERCENT;

    private static final double PRIOR_MEAN = 50.0;
    private static final double PRIOR_VARIANCE = 100.0;
    private static final double SENSOR_VARIANCE = 25.0;

    private static final BayesianBeliefEngine ENGINE = new BayesianBeliefEngine(
            List.of(new BayesianBeliefEngine.ResourceModel(
                    CPU, PRIOR_MEAN, PRIOR_VARIANCE, SENSOR_VARIANCE)));

    @Test
    void emptyOrNullHistoryReturnsUninitialized() {
        assertEquals(BeliefState.UNINITIALIZED, ENGINE.update(null));
        assertEquals(BeliefState.UNINITIALIZED, ENGINE.update(List.of()));
    }

    @Test
    void singleObservationPosteriorMatchesHandComputation() {
        // prior N(50, 100), one measurement x=60 with noise variance 25:
        //   precision = 1/100 + 1/25 = 0.05  -> variance = 20
        //   mean = 20 * (50/100 + 60/25) = 20 * 2.9 = 58
        BeliefState state = ENGINE.update(List.of(observation(100L, 60.0)));

        assertNotEquals(BeliefState.UNINITIALIZED, state);
        ResourceBelief cpu = state.beliefFor(CPU).orElseThrow();
        assertEquals(58.0, cpu.posteriorMean(), 1e-12);
        assertEquals(20.0, cpu.posteriorVariance(), 1e-12);
        assertEquals(1, cpu.observationCount());
        assertEquals(100L, cpu.lastObservationTimestamp());
        assertEquals(1, state.observationCount());
        assertEquals(100L, state.latestObservationTimestamp());
        assertTrue(state.computedAtMillis() > 0);
    }

    @Test
    void twoObservationsPosteriorMatchesHandComputation() {
        // prior N(50, 100), measurements 60 and 80 with noise variance 25:
        //   precision = 0.01 + 2/25 = 0.09 -> variance = 100/9
        //   mean = (100/9) * (0.5 + 140/25) = 610/9
        BeliefState state = ENGINE.update(List.of(observation(200L, 80.0), observation(100L, 60.0)));

        ResourceBelief cpu = state.beliefFor(CPU).orElseThrow();
        assertEquals(610.0 / 9.0, cpu.posteriorMean(), 1e-12);
        assertEquals(100.0 / 9.0, cpu.posteriorVariance(), 1e-12);
        assertEquals(2, cpu.observationCount());
        assertEquals(200L, cpu.lastObservationTimestamp(), "newest observation first in history");
    }

    @Test
    void fullHistoryRecomputeMatchesSingleObservationFold() {
        BeliefState batch = ENGINE.update(List.of(observation(100L, 60.0), observation(200L, 80.0)));

        // The engine is stateless: recomputing from the full two-observation
        // history after a first pass over just the first observation must give
        // the identical posterior — the result depends only on history contents.
        ENGINE.update(List.of(observation(100L, 60.0)));
        BeliefState second = ENGINE.update(List.of(observation(100L, 60.0), observation(200L, 80.0)));

        assertEquals(batch.beliefFor(CPU).orElseThrow().posteriorMean(),
                second.beliefFor(CPU).orElseThrow().posteriorMean(), 1e-12);
        assertEquals(batch.beliefFor(CPU).orElseThrow().posteriorVariance(),
                second.beliefFor(CPU).orElseThrow().posteriorVariance(), 1e-12);
    }

    @Test
    void missingMeasurementsAreSkippedWithoutChangingBelief() {
        BeliefState withMissing = ENGINE.update(List.of(observation(100L, null)));

        assertTrue(withMissing.beliefFor(CPU).isEmpty(),
                "a null measurement carries no information: no belief is produced");
        assertEquals(1, withMissing.observationCount(),
                "the observation itself is still consumed");
        assertEquals(ENGINE.update(List.of(observation(100L, 60.0))).beliefFor(CPU).orElseThrow().posteriorMean(),
                ENGINE.update(List.of(observation(100L, 60.0), observation(200L, null)))
                        .beliefFor(CPU).orElseThrow().posteriorMean(), 1e-12,
                "a null measurement must not change the posterior");
    }

    @Test
    void uncertaintyDecreasesWithMoreObservations() {
        BeliefState one = ENGINE.update(List.of(observation(100L, 60.0)));
        BeliefState two = ENGINE.update(List.of(observation(100L, 60.0), observation(200L, 80.0)));

        double varOne = one.beliefFor(CPU).orElseThrow().posteriorVariance();
        double varTwo = two.beliefFor(CPU).orElseThrow().posteriorVariance();
        assertTrue(varTwo < varOne, "more data must strictly reduce posterior variance");
        assertTrue(varOne < PRIOR_VARIANCE, "even one measurement beats the prior variance");
    }

    @Test
    void posteriorMeanConvergesToSampleMeanAsDataAccumulates() {
        // 100 identical measurements x=70: precision = 0.01 + 100/25 = 4.01,
        // mean = (50*0.01 + 70*100/25) / 4.01 = 280.5/4.01 ≈ 69.95.
        List<TelemetryObservation> history = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            history.add(observation(100L + i, 70.0));
        }

        ResourceBelief cpu = ENGINE.update(history).beliefFor(CPU).orElseThrow();
        assertEquals(69.95, cpu.posteriorMean(), 0.05, "with abundant data the posterior hugs the sample mean");
        assertEquals(1.0 / 4.01, cpu.posteriorVariance(), 1e-9);
        assertEquals(100, cpu.observationCount());
    }

    @Test
    void memoryUtilizationIsDerivedFromUsedAndTotalBytes() {
        BayesianBeliefEngine engine = new BayesianBeliefEngine(
                List.of(new BayesianBeliefEngine.ResourceModel(MEMORY, 50.0, 100.0, 25.0)));

        // used=6144 of total=8192 -> 75%; posterior mean = 20*(0.5 + 75/25) = 70
        BeliefState state = engine.update(List.of(observation(100L, null, 8192L, 6144L)));
        ResourceBelief mem = state.beliefFor(MEMORY).orElseThrow();
        assertEquals(70.0, mem.posteriorMean(), 1e-12);

        // Missing total or used bytes carries no information.
        assertTrue(engine.update(List.of(observation(100L, null, null, 6144L)))
                .beliefFor(MEMORY).isEmpty());
        assertTrue(engine.update(List.of(observation(100L, null, 8192L, null)))
                .beliefFor(MEMORY).isEmpty());
        // Zero total is not derivable (would divide by zero).
        assertTrue(engine.update(List.of(observation(100L, null, 0L, 0L)))
                .beliefFor(MEMORY).isEmpty());
    }

    @Test
    void nonFiniteMeasurementsAreSkipped() {
        BeliefState state = ENGINE.update(List.of(
                observation(100L, Double.NaN),
                observation(200L, Double.POSITIVE_INFINITY),
                observation(300L, 60.0)));

        ResourceBelief cpu = state.beliefFor(CPU).orElseThrow();
        assertEquals(1, cpu.observationCount(), "only the finite measurement counts");
        assertEquals(58.0, cpu.posteriorMean(), 1e-12, "posterior equals the single-finite-measurement case");
    }

    @Test
    void invalidModelConfigurationIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new BayesianBeliefEngine(List.of()));
        assertThrows(NullPointerException.class, () -> new BayesianBeliefEngine(null));
        assertThrows(IllegalArgumentException.class, () -> new BayesianBeliefEngine.ResourceModel(
                CPU, 50.0, 0.0, 25.0), "zero prior variance");
        assertThrows(IllegalArgumentException.class, () -> new BayesianBeliefEngine.ResourceModel(
                CPU, 50.0, -1.0, 25.0), "negative prior variance");
        assertThrows(IllegalArgumentException.class, () -> new BayesianBeliefEngine.ResourceModel(
                CPU, 50.0, 100.0, 0.0), "zero sensor variance");
        assertThrows(IllegalArgumentException.class, () -> new BayesianBeliefEngine.ResourceModel(
                " ", 50.0, 100.0, 25.0), "blank resource name");
        assertThrows(IllegalArgumentException.class, () -> new BayesianBeliefEngine(List.of(
                new BayesianBeliefEngine.ResourceModel(CPU, 50.0, 100.0, 25.0),
                new BayesianBeliefEngine.ResourceModel(CPU, 0.0, 100.0, 25.0))), "duplicate resource name");
    }

    @Test
    void defaultModelsCoverTheIngestedResourceTypes() {
        BeliefState state = new BayesianBeliefEngine().update(List.of(
                observation(100L, 12.5, 1024L, 512L, 82.5, 12.5, 0.25)));

        assertNotEquals(BeliefState.UNINITIALIZED, state);
        assertEquals(5, state.beliefs().size(), "one belief per default resource model");
        assertTrue(state.beliefFor(BayesianBeliefEngine.CPU_UTILIZATION_PERCENT).isPresent());
        assertTrue(state.beliefFor(BayesianBeliefEngine.MEMORY_UTILIZATION_PERCENT).isPresent());
        assertTrue(state.beliefFor(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT).isPresent());
        assertTrue(state.beliefFor(BayesianBeliefEngine.NETWORK_LATENCY_MS).isPresent());
        assertTrue(state.beliefFor(BayesianBeliefEngine.NETWORK_PACKET_LOSS_PERCENT).isPresent());

        // Memory: used=512 of total=1024 -> 50%; prior mean is also 50, so the
        // posterior mean stays exactly 50 regardless of the noise assumption.
        assertEquals(50.0, state.beliefFor(BayesianBeliefEngine.MEMORY_UTILIZATION_PERCENT)
                .orElseThrow().posteriorMean(), 1e-12);
    }

    @Test
    void nullBatteryLevelIsSkippedAndNeverBecomesHundredPercent() {
        BayesianBeliefEngine engine = new BayesianBeliefEngine();

        TelemetryObservation noBattery100 = observation(100L, 12.5, 1024L, 512L, null, 12.5, 0.25);
        BeliefState state = engine.update(List.of(noBattery100));
        assertNotEquals(BeliefState.UNINITIALIZED, state);
        assertTrue(state.beliefFor(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT).isEmpty(),
                "an unavailable battery level must produce no battery belief, not 100%");
        assertTrue(state.beliefFor(BayesianBeliefEngine.CPU_UTILIZATION_PERCENT).isPresent());

        TelemetryObservation battery40at200 = observation(200L, 12.5, 1024L, 512L, 40.0, 12.5, 0.25);
        TelemetryObservation noBattery300 = observation(300L, 12.5, 1024L, 512L, null, 12.5, 0.25);
        BeliefState withNulls = engine.update(List.of(noBattery300, battery40at200, noBattery100));
        BeliefState withoutNulls = engine.update(List.of(battery40at200));
        ResourceBelief withNullsBattery =
                withNulls.beliefFor(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT).orElseThrow();
        ResourceBelief withoutNullsBattery =
                withoutNulls.beliefFor(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT).orElseThrow();
        assertEquals(1, withNullsBattery.observationCount(), "null battery readings carry no information");
        assertEquals(withoutNullsBattery.posteriorMean(), withNullsBattery.posteriorMean(), 1e-12);
        assertTrue(withNullsBattery.posteriorMean() < 50.0,
                "null observations must not pull the battery belief toward a fabricated 100");
    }

    /* ------------------------------------------------------------------ helpers */

    private static TelemetryObservation observation(long timestamp, Double cpu) {
        return observation(timestamp, cpu, null, null);
    }

    private static TelemetryObservation observation(long timestamp, Double cpu,
                                                    Long totalMemory, Long usedMemory) {
        return new TelemetryObservation(timestamp, cpu, totalMemory, usedMemory,
                null, null, null, null, null, null, null, null, null, null, null, null);
    }

    private static TelemetryObservation observation(long timestamp, Double cpu,
                                                    Long totalMemory, Long usedMemory,
                                                    Double battery, Double latency, Double packetLoss) {
        return new TelemetryObservation(timestamp, cpu, totalMemory, usedMemory,
                null, null, null, battery, null, null, latency, packetLoss, null, null, null, null);
    }
}
