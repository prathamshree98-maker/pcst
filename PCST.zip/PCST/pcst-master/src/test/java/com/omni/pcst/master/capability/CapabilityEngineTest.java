package com.omni.pcst.master.capability;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.task.HardConstraintConfig;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Hand-calculated tests for {@link CapabilityEngine}.
 *
 * <p>Each expected probability is computed by hand from
 * {@code C = P(X <= r) = &Phi;((r - &mu;) / &sigma;)} using the standard normal
 * table, so the tests pin the arithmetic rather than trusting the implementation.
 * No randomness, no gRPC, no wall-clock dependence.
 */
class CapabilityEngineTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final long HORIZON = 60_000L;
    private static final long MAX_AGE = HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS;
    private static final double TOL = 1e-6;

    private static final String LATENCY = BayesianBeliefEngine.NETWORK_LATENCY_MS;
    private static final String PACKET_LOSS = BayesianBeliefEngine.NETWORK_PACKET_LOSS_PERCENT;

    private final CapabilityEngine engine = new CapabilityEngine();

    /* ------------------------------------------------------------- values */

    private static final double PHI_2 = 0.9772498680518208;
    private static final double PHI_1 = 0.8413447460685429;
    private static final double PHI_POINT_FOUR = 0.6554217416103242;
    private static final double PHI_4 = 0.9999683287581669;

    /* ------------------------------------------------------------ fixtures */

    private static ResourceBelief belief(String key, double mean, double variance) {
        return new ResourceBelief(key, mean, variance, 5L, T0);
    }

    private static Map<String, ResourceBelief> beliefs(ResourceBelief... entries) {
        Map<String, ResourceBelief> map = new LinkedHashMap<>();
        for (ResourceBelief entry : entries) {
            map.put(entry.resourceName(), entry);
        }
        return map;
    }

    private static DigitalTwinSnapshot snapshot(String nodeId, long receivedAt,
                                                Map<String, ResourceBelief> beliefs) {
        BeliefState state = beliefs.isEmpty()
                ? BeliefState.UNINITIALIZED
                : BeliefState.of(beliefs, 1L, receivedAt, receivedAt);
        return new DigitalTwinSnapshot(nodeId, "host-" + nodeId, 9091, "0.1.0",
                T0, T0, T0, null, List.of(), receivedAt, 0L, state);
    }

    /** A snapshot with fresh latency and packet-loss beliefs, at the decision instant. */
    private static DigitalTwinSnapshot networkNode(String nodeId,
                                                   double latencyMean, double latencyVariance,
                                                   double packetLossMean, double packetLossVariance) {
        return snapshot(nodeId, T0, beliefs(
                belief(LATENCY, latencyMean, latencyVariance),
                belief(PACKET_LOSS, packetLossMean, packetLossVariance)));
    }

    private static Task latencyTask(double maxLatency) {
        return Task.builder("task-lat")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, null, null, null))
                .build();
    }

    private static Task networkTask(double maxLatency, double maxPacketLoss) {
        return Task.builder("task-net")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, maxPacketLoss, null, null))
                .build();
    }

    /* --------------------------------------------- single supported marginal */

    @Test
    void latencyOnlyComputesHandCalculatedUpperTailProbability() {
        // r = 100 ms, X ~ Normal(80, 10^2): P(X <= 100) = Phi(2) = 0.9772499.
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-lat", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.COMPUTABLE, assessment.status());
        assertTrue(assessment.isComputable());
        assertEquals(PHI_2, assessment.capability(), TOL);

        RequirementCapability latency = assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY);
        assertNotNull(latency);
        assertEquals(CapabilityReason.COMPUTED, latency.reason());
        assertEquals(100.0, latency.requiredValue(), TOL);
        assertEquals("milliseconds", latency.requiredUnit());
        assertEquals(PHI_2, latency.probability(), TOL);
        assertEquals(1, assessment.requirements().size());
    }

    @Test
    void packetLossOnlyComputesHandCalculatedUpperTailProbability() {
        // r = 3 %, X ~ Normal(1, 1^2): P(X <= 3) = Phi(2) = 0.9772499.
        Task task = Task.builder("task-loss")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, null, 3.0, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-loss", T0, beliefs(belief(PACKET_LOSS, 1.0, 1.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(PHI_2, assessment.capability(), TOL);
        assertEquals("percent",
                assessment.requirementFor(CapabilityDimension.PACKET_LOSS).requiredUnit());
    }

    @Test
    void predictiveDistributionCarriesProvenanceAndAssumption() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-prov", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        RequirementCapability latency =
                engine.assess(task, node, T0).requirementFor(CapabilityDimension.NETWORK_LATENCY);

        PredictiveDistribution distribution = latency.predictiveDistribution();
        assertNotNull(distribution);
        assertEquals(80.0, distribution.mean(), TOL);
        assertEquals(100.0, distribution.variance(), TOL);
        assertEquals(10.0, distribution.standardDeviation(), TOL);
        assertEquals(BeliefPosteriorDistributionSource.SOURCE, distribution.source());
        assertFalse(distribution.assumption().isBlank());
    }

    /* ------------------------------------------- event probability, not score */

    @Test
    void capabilityIsEventProbabilityNotALinearScore() {
        // A linear "score" such as mean/threshold would rank these by 1.0, 0.8, 0.8.
        // The event probability instead gives Phi((r - mean)/sigma), which is not
        // monotone in that score: two nodes with the same score differ sharply.
        Task task = latencyTask(100.0);

        CapabilityAssessment atThreshold =
                engine.assess(task, snapshot("s1", T0, beliefs(belief(LATENCY, 100.0, 100.0))), T0);
        CapabilityAssessment tightBelow =
                engine.assess(task, snapshot("s2", T0, beliefs(belief(LATENCY, 80.0, 25.0))), T0);
        CapabilityAssessment wideBelow =
                engine.assess(task, snapshot("s3", T0, beliefs(belief(LATENCY, 80.0, 2500.0))), T0);

        assertEquals(0.5, atThreshold.capability(), TOL);                    // Phi(0)
        assertEquals(PHI_4, tightBelow.capability(), TOL);                   // Phi((100-80)/5)
        assertEquals(PHI_POINT_FOUR, wideBelow.capability(), TOL);           // Phi((100-80)/50)
        assertFalse(tightBelow.capability() == wideBelow.capability(),
                "equal linear score (both mean/threshold = 0.8) but different event probability");
    }

    @Test
    void lowerUncertaintyIsNotUniversallyHigherCapability() {
        // Same mean, different variance, mean equal to the threshold: both 0.5.
        Task task = latencyTask(100.0);
        CapabilityAssessment tight =
                engine.assess(task, snapshot("tight", T0, beliefs(belief(LATENCY, 100.0, 100.0))), T0);
        CapabilityAssessment wide =
                engine.assess(task, snapshot("wide", T0, beliefs(belief(LATENCY, 100.0, 2500.0))), T0);
        assertEquals(0.5, tight.capability(), TOL);
        assertEquals(0.5, wide.capability(), TOL);

        // Mean below the threshold: more spread lowers capability here.
        CapabilityAssessment tight2 =
                engine.assess(task, snapshot("tight2", T0, beliefs(belief(LATENCY, 80.0, 100.0))), T0);
        CapabilityAssessment wide2 =
                engine.assess(task, snapshot("wide2", T0, beliefs(belief(LATENCY, 80.0, 2500.0))), T0);
        assertEquals(PHI_2, tight2.capability(), TOL);
        assertEquals(PHI_POINT_FOUR, wide2.capability(), TOL);
        assertTrue(wide2.capability() < tight2.capability());
    }

    /* ------------------------------------------------- unsupported conditions */

    @Test
    void memoryOnlyRequirementIsUnsupportedModel() {
        Task task = Task.builder("task-mem")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .resources(TaskResources.requiringMemory(1024L))
                .build();
        DigitalTwinSnapshot node = snapshot("node-mem", T0, Map.of());

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.UNSUPPORTED_MODEL, assessment.status());
        assertNull(assessment.capability());
        assertFalse(assessment.isComputable());
        RequirementCapability memory =
                assessment.requirementFor(CapabilityDimension.MEMORY_AVAILABILITY);
        assertEquals(CapabilityReason.UNIT_MISMATCH, memory.reason());
        assertEquals("bytes", memory.requiredUnit());
        assertTrue(assessment.reasons().contains(CapabilityReason.UNIT_MISMATCH));
    }

    @Test
    void computeOnlyRequirementIsUnsupportedModel() {
        Task task = Task.builder("task-compute")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .resources(new TaskResources(null, null, false, null, 16.0))
                .build();
        DigitalTwinSnapshot node = snapshot("node-compute", T0, Map.of());

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.UNSUPPORTED_MODEL, assessment.status());
        assertEquals(CapabilityReason.NO_PREDICTIVE_MODEL,
                assessment.requirementFor(CapabilityDimension.COMPUTE_CAPACITY).reason());
    }

    @Test
    void mixedUnsupportedAndSupportedIsPartiallyComputable() {
        Task task = Task.builder("task-mixed")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .resources(TaskResources.requiringMemory(1024L))
                .constraints(new TaskConstraints(null, null, null, 100.0, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-mixed", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.PARTIALLY_COMPUTABLE, assessment.status());
        assertNull(assessment.capability());
        assertTrue(assessment.hasUnsupportedResourceCondition());
        assertEquals(PHI_2,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).probability(), TOL);
    }

    /* ---------------------------------------------------------- joint events */

    @Test
    void twoComputableConditionsWithDefaultCombinerAreUnresolved() {
        Task task = networkTask(100.0, 3.0);
        DigitalTwinSnapshot node = networkNode("node-net", 80.0, 100.0, 1.0, 1.0);

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.PARTIALLY_COMPUTABLE, assessment.status());
        assertNull(assessment.capability());
        assertTrue(assessment.reasons().contains(CapabilityReason.JOINT_MODEL_UNRESOLVED));
        assertEquals(PHI_2,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).probability(), TOL);
        assertEquals(PHI_2,
                assessment.requirementFor(CapabilityDimension.PACKET_LOSS).probability(), TOL);
        assertEquals(CapabilityCombiner.unresolved().identifier(), assessment.combinerName());
    }

    @Test
    void twoComputableConditionsWithIndependenceOptInMultiply() {
        CapabilityEngine independence = new CapabilityEngine(
                new BeliefPosteriorDistributionSource(), CapabilityCombiner.independenceProduct(), MAX_AGE);
        Task task = networkTask(100.0, 3.0);
        DigitalTwinSnapshot node = networkNode("node-net", 80.0, 100.0, 1.0, 1.0);

        CapabilityAssessment assessment = independence.assess(task, node, T0);

        assertEquals(CapabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(PHI_2 * PHI_2, assessment.capability(), TOL);
        assertFalse(assessment.reasons().contains(CapabilityReason.JOINT_MODEL_UNRESOLVED));
        assertFalse(assessment.combinerAssumption().isBlank());
    }

    /* -------------------------------------------------------------- evidence */

    @Test
    void missingBeliefIsInsufficientEvidence() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-empty", T0, Map.of());

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.INSUFFICIENT_EVIDENCE, assessment.status());
        assertNull(assessment.capability());
        assertEquals(CapabilityReason.MISSING_BELIEF,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).reason());
    }

    @Test
    void staleBeliefIsInsufficientEvidence() {
        Task task = latencyTask(100.0);
        long staleReceived = T0 - MAX_AGE - 1L;
        DigitalTwinSnapshot node = snapshot("node-stale", staleReceived, beliefs(belief(LATENCY, 80.0, 100.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.INSUFFICIENT_EVIDENCE, assessment.status());
        assertEquals(CapabilityReason.STALE_EVIDENCE,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).reason());
    }

    @Test
    void evidenceExactlyAtAgeLimitIsStillFresh() {
        Task task = latencyTask(100.0);
        long received = T0 - MAX_AGE;
        DigitalTwinSnapshot node = snapshot("node-edge-age", received, beliefs(belief(LATENCY, 80.0, 100.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(PHI_2, assessment.capability(), TOL);
    }

    @Test
    void evidenceAfterOriginIsRejected() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-future", T0 + 1L, beliefs(belief(LATENCY, 80.0, 100.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.INSUFFICIENT_EVIDENCE, assessment.status());
        assertEquals(CapabilityReason.EVIDENCE_AFTER_ORIGIN,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).reason());
    }

    /* ----------------------------------------------------------- bad inputs */

    @Test
    void missingHorizonIsInvalidInput() {
        Task task = Task.builder("task-nohorizon")
                .workloadReference("ref")
                .constraints(new TaskConstraints(null, null, null, 100.0, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-noh", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.INVALID_INPUT, assessment.status());
        assertNull(assessment.capability());
        assertEquals(CapabilityReason.MISSING_HORIZON,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).reason());
        assertNull(assessment.horizonMillis());
    }

    @Test
    void nonPositiveVarianceIsInvalidInput() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-var0", T0, beliefs(belief(LATENCY, 80.0, 0.0)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.INVALID_INPUT, assessment.status());
        assertEquals(CapabilityReason.NON_POSITIVE_VARIANCE,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).reason());
    }

    @Test
    void nonFiniteVarianceIsInvalidInput() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot node = snapshot("node-varNaN", T0, beliefs(belief(LATENCY, 80.0, Double.NaN)));

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.INVALID_INPUT, assessment.status());
        assertEquals(CapabilityReason.NON_FINITE_PARAMETER,
                assessment.requirementFor(CapabilityDimension.NETWORK_LATENCY).reason());
    }

    /* --------------------------------------------- vacuous and deferred events */

    @Test
    void noRequirementsIsVacuouslyComputable() {
        Task task = Task.minimal("task-none", "ref");
        DigitalTwinSnapshot node = snapshot("node-none", T0, Map.of());

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(1.0, assessment.capability(), TOL);
        assertTrue(assessment.reasons().contains(CapabilityReason.VACUOUS_NO_REQUIREMENTS));
        assertTrue(assessment.requirements().isEmpty());
    }

    @Test
    void batteryOnlyRequirementIsDeferredAndCapabilityIsVacuous() {
        Task task = Task.builder("task-batt")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, 30.0, null, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-batt", T0, Map.of());

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(1.0, assessment.capability(), TOL);
        assertEquals(CapabilityReason.DEFERRED_ENERGY_RELIABILITY,
                assessment.requirementFor(CapabilityDimension.BATTERY_ENERGY).reason());
        assertFalse(assessment.requirementFor(CapabilityDimension.BATTERY_ENERGY).isResourceCondition());
    }

    @Test
    void deadlineOnlyRequirementIsDeferred() {
        Task task = Task.builder("task-deadline")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(T0 + 600_000L, null, null, null, null, null, null))
                .build();
        DigitalTwinSnapshot node = snapshot("node-deadline", T0, Map.of());

        CapabilityAssessment assessment = engine.assess(task, node, T0);

        assertEquals(CapabilityStatus.COMPUTABLE, assessment.status());
        assertEquals(CapabilityReason.DEFERRED_DEADLINE_RELIABILITY,
                assessment.requirementFor(CapabilityDimension.DEADLINE).reason());
    }

    /* ------------------------------------------------------------ batching */

    @Test
    void assessAllIsOrderedByNodeIdAndDeduplicates() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));

        List<CapabilityAssessment> results = engine.assessAll(task, List.of(b, a, b), T0);

        assertEquals(2, results.size());
        assertEquals(List.of("node-a", "node-b"),
                results.stream().map(CapabilityAssessment::nodeId).toList());
        assertEquals(PHI_1, results.get(0).capability(), TOL);   // Phi((100-90)/10) = Phi(1)
        assertEquals(PHI_2, results.get(1).capability(), TOL);
    }

    @Test
    void assessEligibleSkipsIneligibleAndFlagsUnresolvedSnapshot() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot eligible = snapshot("node-ok", T0, beliefs(belief(LATENCY, 80.0, 100.0)));

        NodeEligibilityResult ok = new NodeEligibilityResult(
                task.taskId(), "node-ok", true, false, List.of(), List.of(), T0);
        NodeEligibilityResult rejected = new NodeEligibilityResult(
                task.taskId(), "node-no", false, false, List.of(), List.of(), T0);
        NodeEligibilityResult missing = new NodeEligibilityResult(
                task.taskId(), "node-missing", true, false, List.of(), List.of(), T0);

        Map<String, DigitalTwinSnapshot> registry = new LinkedHashMap<>();
        registry.put("node-ok", eligible);

        List<CapabilityAssessment> results =
                engine.assessEligible(task, List.of(ok, rejected, missing), registry::get, T0);

        assertEquals(2, results.size(), "ineligible candidate is skipped");
        assertEquals(List.of("node-missing", "node-ok"),
                results.stream().map(CapabilityAssessment::nodeId).toList());
        assertEquals(CapabilityStatus.COMPUTABLE, results.get(1).status());
        assertEquals(CapabilityStatus.INVALID_INPUT, results.get(0).status());
        assertTrue(results.get(0).reasons().contains(CapabilityReason.INVALID_INPUT));
    }

    /* ----------------------------------------------------------- boundaries */

    @Test
    void nullTaskOrSnapshotIsRejected() {
        assertThrows(NullPointerException.class,
                () -> engine.assess(null, snapshot("node", T0, Map.of()), T0));
        assertThrows(NullPointerException.class,
                () -> engine.assess(latencyTask(100.0), null, T0));
    }

    @Test
    void negativeMaxEvidenceAgeIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new CapabilityEngine(new BeliefPosteriorDistributionSource(),
                        CapabilityCombiner.unresolved(), -1L));
    }

    @Test
    void requirementListsAreImmutable() {
        Task task = latencyTask(100.0);
        CapabilityAssessment assessment =
                engine.assess(task, snapshot("node-imm", T0, beliefs(belief(LATENCY, 80.0, 100.0))), T0);

        assertThrows(UnsupportedOperationException.class, () -> assessment.requirements().clear());
        assertThrows(UnsupportedOperationException.class, () -> assessment.reasons().clear());
    }
}
