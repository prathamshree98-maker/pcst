package com.omni.pcst.master.benchmark;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityEngine;
import com.omni.pcst.master.reliability.ReliabilityInput;
import com.omni.pcst.master.scheduler.BenchmarkRoundRobinScheduler;
import com.omni.pcst.master.scheduler.CapabilityBasedScheduler;
import com.omni.pcst.master.scheduler.PCSTScheduler;
import com.omni.pcst.master.scheduler.SchedulingCandidate;
import com.omni.pcst.master.scheduler.SchedulingDecision;
import com.omni.pcst.master.scheduler.SchedulingPolicyConfig;
import com.omni.pcst.master.scheduler.SchedulingStatus;
import com.omni.pcst.master.task.HardConstraintFilter;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Runs a deterministic benchmark comparing PCST against independent baselines.
 *
 * <p><b>Comparison mode: policy-only.</b> All schedulers (PCST, Round Robin,
 * Capability-Based, CPU Least Loaded, Oracle) receive the identical pre-composed
 * {@link SchedulingCandidate} set through {@link Scheduler#select(Task, long,
 * Collection)}. Each candidate carries the same hard-constraint eligibility,
 * capability assessment, and reliability assessment. This ensures a fair
 * policy-level comparison: no scheduler receives more information than any other.
 *
 * <p><b>End-to-end mode: labelled separately.</b> {@link PCSTScheduler#schedule}
 * (which internally composes filter + capability + reliability + select) is
 * exercised in {@link com.omni.pcst.master.scheduler.PCSTBenchmarkCorrectnessTest}
 * as a standalone smoke test, not mixed into the comparative runner.
 *
 * <p>For each task in the sequence, the runner:
 * <ol>
 *   <li>Generates telemetry for each node from true state</li>
 *   <li>Updates Bayesian beliefs from observation history</li>
 *   <li>Builds {@link DigitalTwinSnapshot} objects</li>
 *   <li>Runs {@link HardConstraintFilter} for eligibility</li>
 *   <li>Runs {@link CapabilityEngine} and {@link ReliabilityEngine}</li>
 *   <li>Composes identical {@link SchedulingCandidate} sets for all schedulers</li>
 *   <li>Invokes each scheduler's {@code select()} and records the decision</li>
 *   <li>Derives the simulated outcome from true state on the selected node</li>
 *   <li>Advances node state by one tick</li>
 * </ol>
 *
 * <p>True state is never exposed to PCST, Round Robin, Capability-Based, or CPU
 * Least Loaded. Only the Oracle arm inspects hidden true state, as a separate
 * reference arm.
 */
public final class BenchmarkRunner {

    private final int nodeCount;
    private final int taskCount;
    private final long seed;
    private final List<NodeModel> nodes;
    private final TelemetrySimulator telemetrySimulator;
    private final TaskGenerator taskGenerator;
    private final long baseTimestampMillis;
    private final int tickIntervalMillis = 5000;

    // Per-node observation history (newest first)
    private final Map<String, List<TelemetryObservation>> observationHistoryByNode = new LinkedHashMap<>();

    private BenchmarkRunner(int nodeCount, int taskCount, long seed,
                            List<NodeModel> nodes, TelemetrySimulator telemetrySimulator,
                            TaskGenerator taskGenerator, long baseTimestampMillis) {
        this.nodeCount = nodeCount;
        this.taskCount = taskCount;
        this.seed = seed;
        this.nodes = nodes;
        this.telemetrySimulator = telemetrySimulator;
        this.taskGenerator = taskGenerator;
        this.baseTimestampMillis = baseTimestampMillis;
        for (NodeModel node : nodes) {
            observationHistoryByNode.put(node.nodeId(), new ArrayList<>());
        }
    }

    /**
     * Runs the full benchmark and returns structured results.
     *
     * @return list of {@link SchedulingResult}, one per (scheduler, task) pair
     */
    public List<SchedulingResult> run() {
        List<SchedulingResult> results = new ArrayList<>();

        // Scheduler instances (policy-only, all via select())
        PCSTScheduler pcstScheduler = new PCSTScheduler(SchedulingPolicyConfig.none());
        BenchmarkRoundRobinScheduler roundRobinScheduler = new BenchmarkRoundRobinScheduler();
        CapabilityBasedScheduler capabilityBasedScheduler = new CapabilityBasedScheduler();

        // Bayesian belief engine shared across nodes
        BayesianBeliefEngine beliefEngine = new BayesianBeliefEngine();
        CapabilityEngine capabilityEngine = new CapabilityEngine();
        ReliabilityEngine reliabilityEngine = new ReliabilityEngine();
        HardConstraintFilter hardConstraintFilter = new HardConstraintFilter();

        List<Task> tasks = taskGenerator.latencyTasks(taskCount);

        for (int taskIndex = 0; taskIndex < taskCount; taskIndex++) {
            long decisionTimeMillis = baseTimestampMillis + (long) taskIndex * tickIntervalMillis;
            Task task = tasks.get(taskIndex);

            // Step 1: Generate telemetry and update beliefs for each node
            Map<String, DigitalTwinSnapshot> snapshotsByNode = new LinkedHashMap<>();
            Map<String, Double> cpuLoadByNode = new LinkedHashMap<>();
            Map<String, Double> trueLatencyByNode = new LinkedHashMap<>();
            Map<String, Double> truePacketLossByNode = new LinkedHashMap<>();

            for (NodeModel node : nodes) {
                TelemetryObservation obs = telemetrySimulator.observe(node, taskIndex);
                observationHistoryByNode.get(node.nodeId()).add(0, obs); // newest first

                // Observed CPU load (for CPU Least Loaded baseline)
                if (obs.cpuUtilizationPercent() != null) {
                    cpuLoadByNode.put(node.nodeId(), obs.cpuUtilizationPercent());
                }

                // True state for oracle arm only
                trueLatencyByNode.put(node.nodeId(), node.trueLatencyMs());
                truePacketLossByNode.put(node.nodeId(), node.truePacketLossPercent());

                // Build belief state from full history
                BeliefState beliefState = beliefEngine.update(
                        new ArrayList<>(observationHistoryByNode.get(node.nodeId())));

                DigitalTwinSnapshot snapshot = new DigitalTwinSnapshot(
                        node.nodeId(), "host-" + node.nodeId(), 9091, "0.1.0",
                        baseTimestampMillis, baseTimestampMillis, baseTimestampMillis,
                        obs, List.copyOf(observationHistoryByNode.get(node.nodeId())),
                        baseTimestampMillis + (long) taskIndex * tickIntervalMillis, 0L, beliefState);

                snapshotsByNode.put(node.nodeId(), snapshot);
            }

            // Step 2: Hard constraint filter (same for all schedulers)
            List<NodeEligibilityResult> eligibilityResults =
                    hardConstraintFilter.filter(task,
                            new ArrayList<>(snapshotsByNode.values()), decisionTimeMillis);

            // Step 3: Compose candidates (identical for all schedulers)
            Map<String, SchedulingCandidate> candidatesByNode = new LinkedHashMap<>();
            for (NodeEligibilityResult er : eligibilityResults) {
                DigitalTwinSnapshot snapshot = snapshotsByNode.get(er.nodeId());
                if (snapshot == null) continue;

                CapabilityAssessment capability = capabilityEngine.assess(task, snapshot, decisionTimeMillis);
                ReliabilityAssessment reliability = reliabilityEngine.assess(
                        new ReliabilityInput(task, snapshot, er, capability));
                SchedulingCandidate candidate = new SchedulingCandidate(er, capability, reliability);
                candidatesByNode.put(er.nodeId(), candidate);
            }

            List<SchedulingCandidate> allCandidates = new ArrayList<>(candidatesByNode.values());

            // Snapshot of the eligible node IDs and per-candidate data for
            // candidate-set equivalence assertions. Computed from allCandidates
            // (what schedulers actually see), not from eligibilityResults directly,
            // because some eligible results may lack snapshots and were excluded
            // from the candidate set.
            List<String> eligibleNodeIds = allCandidates.stream()
                    .filter(SchedulingCandidate::eligible)
                    .map(SchedulingCandidate::nodeId)
                    .toList();

            // Step 4: Run each scheduler via select() — identical candidate set.
            // All schedulers are long-lived instances so that stateful policies
            // (Round Robin rotation) maintain state across tasks within a run.
            SchedulingDecision pcstDecision = pcstScheduler.select(task, decisionTimeMillis, allCandidates);
            SchedulingDecision rrDecision = roundRobinScheduler.select(task, decisionTimeMillis, allCandidates);
            SchedulingDecision cbDecision = capabilityBasedScheduler.select(task, decisionTimeMillis, allCandidates);

            CpuLeastLoadedScheduler cllScheduler = new CpuLeastLoadedScheduler(cpuLoadByNode);
            SchedulingDecision cllDecision = cllScheduler.select(task, decisionTimeMillis, allCandidates);

            OracleScheduler oracleScheduler = new OracleScheduler(trueLatencyByNode, truePacketLossByNode);
            SchedulingDecision oracleDecision = oracleScheduler.select(task, decisionTimeMillis, allCandidates);

            // Step 5: Record results for each scheduler
            results.add(recordResult("PCST", seed, taskIndex, task, pcstDecision,
                    eligibleNodeIds, snapshotsByNode, trueLatencyByNode, truePacketLossByNode, cpuLoadByNode));
            results.add(recordResult("RoundRobin", seed, taskIndex, task, rrDecision,
                    eligibleNodeIds, snapshotsByNode, trueLatencyByNode, truePacketLossByNode, cpuLoadByNode));
            results.add(recordResult("CapabilityBased", seed, taskIndex, task, cbDecision,
                    eligibleNodeIds, snapshotsByNode, trueLatencyByNode, truePacketLossByNode, cpuLoadByNode));
            results.add(recordResult("CpuLeastLoaded", seed, taskIndex, task, cllDecision,
                    eligibleNodeIds, snapshotsByNode, trueLatencyByNode, truePacketLossByNode, cpuLoadByNode));
            results.add(recordResult("Oracle", seed, taskIndex, task, oracleDecision,
                    eligibleNodeIds, snapshotsByNode, trueLatencyByNode, truePacketLossByNode, cpuLoadByNode));

            // Step 6: Advance node state
            for (NodeModel node : nodes) {
                node.tick();
            }
        }

        return results;
    }

    private SchedulingResult recordResult(String schedulerName, long seed, int taskIndex,
                                          Task task, SchedulingDecision decision,
                                          List<String> eligibleNodeIds,
                                          Map<String, DigitalTwinSnapshot> snapshotsByNode,
                                          Map<String, Double> trueLatencyByNode,
                                          Map<String, Double> truePacketLossByNode,
                                          Map<String, Double> cpuLoadByNode) {
        String selectedNodeId = decision.selectedNodeId();

        // Outcome accounting:
        //   taskSucceeded   = true only when a node was selected AND true state
        //                   satisfies all expressed constraints.
        //   taskFailed      = true only when a node was selected AND constraints
        //                   were violated.
        //   unfinished      = true when no node was selected (DEFER_OR_REJECT,
        //                   NO_FEASIBLE_NODE, NO_SELECTION_UNRESOLVED).
        boolean taskSucceeded = false;
        boolean taskFailed = false;
        Double trueLatency = null;
        Double truePacketLoss = null;
        Double trueCpu = null;

        if (selectedNodeId != null) {
            trueLatency = trueLatencyByNode.get(selectedNodeId);
            truePacketLoss = truePacketLossByNode.get(selectedNodeId);
            DigitalTwinSnapshot snapshot = snapshotsByNode.get(selectedNodeId);
            if (snapshot != null && snapshot.latestObservation() != null) {
                trueCpu = snapshot.latestObservation().cpuUtilizationPercent();
            }

            TaskConstraints constraints = task.constraints();
            if (constraints != null && trueLatency != null && truePacketLoss != null) {
                boolean latencyOk = constraints.maximumNetworkLatencyMillis() == null
                        || trueLatency <= constraints.maximumNetworkLatencyMillis();
                boolean lossOk = constraints.maximumPacketLossPercent() == null
                        || truePacketLoss <= constraints.maximumPacketLossPercent();
                if (latencyOk && lossOk) {
                    taskSucceeded = true;
                } else {
                    taskFailed = true;
                }
            } else {
                // Missing true-state data means outcome cannot be evaluated
                taskFailed = true;
            }
        }

        return new SchedulingResult(
                schedulerName, seed, taskIndex, task.taskId(),
                selectedNodeId,
                decision.status().name(),
                decision.selectedReliability(),
                decision.policyFallback(),
                eligibleNodeIds.contains(selectedNodeId),
                taskSucceeded,
                taskFailed,
                trueLatency, truePacketLoss, trueCpu,
                decision.decisionTimeMillis());
    }

    /** Builder for {@link BenchmarkRunner}. */
    public static class Builder {
        private int nodeCount = 3;
        private int taskCount = 10;
        private long seed = 42L;
        private double baseLatencyMs = 50.0;
        private double basePacketLossPercent = 1.0;
        private double baseCpuUtilizationPercent = 50.0;
        private double noiseStdDev = 5.0;
        private double stalenessProbability = 0.0;
        private double missingFieldProbability = 0.0;
        private long baseTimestampMillis = 1_700_000_000_000L;

        public Builder nodeCount(int nodeCount) {
            this.nodeCount = nodeCount;
            return this;
        }

        public Builder taskCount(int taskCount) {
            this.taskCount = taskCount;
            return this;
        }

        public Builder seed(long seed) {
            this.seed = seed;
            return this;
        }

        public Builder baseLatencyMs(double baseLatencyMs) {
            this.baseLatencyMs = baseLatencyMs;
            return this;
        }

        public Builder basePacketLossPercent(double basePacketLossPercent) {
            this.basePacketLossPercent = basePacketLossPercent;
            return this;
        }

        public Builder baseCpuUtilizationPercent(double baseCpuUtilizationPercent) {
            this.baseCpuUtilizationPercent = baseCpuUtilizationPercent;
            return this;
        }

        public Builder noiseStdDev(double noiseStdDev) {
            this.noiseStdDev = noiseStdDev;
            return this;
        }

        public Builder stalenessProbability(double stalenessProbability) {
            this.stalenessProbability = stalenessProbability;
            return this;
        }

        public Builder missingFieldProbability(double missingFieldProbability) {
            this.missingFieldProbability = missingFieldProbability;
            return this;
        }

        public Builder baseTimestampMillis(long baseTimestampMillis) {
            this.baseTimestampMillis = baseTimestampMillis;
            return this;
        }

        public BenchmarkRunner build() {
            List<NodeModel> nodeModels = new ArrayList<>(nodeCount);
            for (int i = 0; i < nodeCount; i++) {
                double nodeLatency = baseLatencyMs + i * 10.0; // 50, 60, 70 ms
                double nodeLoss = basePacketLossPercent + i * 0.5; // 1.0, 1.5, 2.0 %
                double nodeCpu = baseCpuUtilizationPercent + i * 5.0; // 50, 55, 60 %
                nodeModels.add(new NodeModel.Builder()
                        .nodeId("node-" + (i + 1))
                        .trueLatencyMs(nodeLatency)
                        .truePacketLossPercent(nodeLoss)
                        .trueCpuUtilizationPercent(nodeCpu)
                        .build());
            }

            TelemetrySimulator simulator = new TelemetrySimulator.Builder()
                    .seed(seed)
                    .noiseStdDev(noiseStdDev)
                    .stalenessProbability(stalenessProbability)
                    .missingFieldProbability(missingFieldProbability)
                    .baseTimestampMillis(baseTimestampMillis)
                    .build();

            TaskGenerator generator = new TaskGenerator.Builder()
                    .seed(seed)
                    .baseTimestampMillis(baseTimestampMillis)
                    .build();

            return new BenchmarkRunner(nodeCount, taskCount, seed, nodeModels,
                    simulator, generator, baseTimestampMillis);
        }
    }
}
