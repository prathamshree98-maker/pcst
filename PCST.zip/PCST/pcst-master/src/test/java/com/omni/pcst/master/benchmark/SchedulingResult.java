package com.omni.pcst.master.benchmark;

/**
 * Immutable record of one scheduling decision and its simulated outcome.
 *
 * <p>This is a benchmark output type. It records what each scheduler decided,
 * what the true state was at decision time, and whether the task would have
 * succeeded or failed on the selected node.
 *
 * <p>Outcome accounting:
 * <ul>
 *   <li>{@code taskSucceeded} — true only when a node was selected AND true state
 *       satisfies all expressed constraints.</li>
 *   <li>{@code taskFailed} — true only when a node was selected AND constraints
 *       were violated (or true-state data was missing).</li>
 *   <li>Unfinished — when no node was selected ({@code DEFER_OR_REJECT},
 *       {@code NO_FEASIBLE_NODE}, {@code NO_SELECTION_UNRESOLVED}). Neither
 *       {@code taskSucceeded} nor {@code taskFailed} is true.</li>
 * </ul>
 *
 * <p>A task with no selected node must not be counted as an executed failure.
 */
public record SchedulingResult(
        String schedulerName,
        long seed,
        int taskIndex,
        String taskId,
        String selectedNodeId,
        String status,
        Double predictedReliability,
        boolean policyFallback,
        boolean feasibleNodeFound,
        boolean taskSucceeded,
        boolean taskFailed,
        Double trueLatencyOnSelectedNode,
        Double truePacketLossOnSelectedNode,
        Double trueCpuOnSelectedNode,
        long decisionTimeMillis) {
}
