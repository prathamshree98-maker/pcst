package com.omni.pcst.master.benchmark;

import com.omni.pcst.master.scheduler.CandidateDecision;
import com.omni.pcst.master.scheduler.CandidateDisposition;
import com.omni.pcst.master.scheduler.SchedulingCandidate;
import com.omni.pcst.master.scheduler.SchedulingDecision;
import com.omni.pcst.master.scheduler.SchedulingReason;
import com.omni.pcst.master.scheduler.SchedulingStatus;
import com.omni.pcst.master.scheduler.Scheduler;
import com.omni.pcst.master.task.Task;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Benchmark-local CPU Least Loaded scheduler.
 *
 * <p>Selects the eligible candidate with the lowest observed CPU utilization.
 * CPU load is supplied externally via a {@code Map<String, Double>} keyed by
 * node id, representing observed CPU utilization percent from telemetry.
 * Missing telemetry is treated as the worst possible load
 * ({@code Double.MAX_VALUE}), never fabricated as zero. Ties are broken
 * deterministically by lowest node ID.
 *
 * <p>This is a baseline policy for comparison only. It does not use capability
 * probabilities, reliability estimates, or Bayesian beliefs. It is independent
 * of PCST reliability scoring.
 *
 * <p>Unlike {@code com.omni.pcst.master.scheduler.LeastLoadedScheduler} (which is
 * deprecated and delegates to CapabilityBasedScheduler), this implementation
 * genuinely models load via observed CPU utilization.
 */
public final class CpuLeastLoadedScheduler implements Scheduler {

    private final Map<String, Double> cpuLoadByNode;

    /**
     * @param cpuLoadByNode observed CPU utilization percent per node id;
     *                      nodes not present are treated as worst load
     */
    public CpuLeastLoadedScheduler(Map<String, Double> cpuLoadByNode) {
        this.cpuLoadByNode = cpuLoadByNode == null ? Map.of() : Map.copyOf(cpuLoadByNode);
    }

    @Override
    public SchedulingDecision select(Task task, long decisionTimeMillis,
                                     Collection<SchedulingCandidate> candidates) {
        List<SchedulingCandidate> eligible =
                new ArrayList<>(candidates.stream()
                        .filter(c -> c != null && c.eligible())
                        .toList());

        if (eligible.isEmpty()) {
            return new SchedulingDecision(
                    task.taskId(), decisionTimeMillis,
                    SchedulingStatus.NO_FEASIBLE_NODE, null, null, null, false,
                    List.of(),
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no candidate passed hard eligibility; feasible set F_t(tau) is empty");
        }

        // Deduplicate by node id, preserving first occurrence order
        Map<String, SchedulingCandidate> byNodeId = new LinkedHashMap<>();
        for (SchedulingCandidate c : eligible) {
            byNodeId.putIfAbsent(c.nodeId(), c);
        }
        List<SchedulingCandidate> uniqueEligible =
                new ArrayList<>(byNodeId.values());

        // Select lowest CPU utilization; missing telemetry = worst load
        SchedulingCandidate winner = uniqueEligible.stream()
                .min(Comparator
                        .comparingDouble((SchedulingCandidate c) -> cpuLoadByNode.getOrDefault(c.nodeId(), Double.MAX_VALUE))
                        .thenComparing(SchedulingCandidate::nodeId))
                .orElseThrow();

        String selectedNodeId = winner.nodeId();

        // Pseudo-reliability derived from CPU load: lower load = higher reliability.
        // Clamped to [0, 1]; missing telemetry (worst load) yields 0.0.
        double selectedCpuLoad = cpuLoadByNode.getOrDefault(selectedNodeId, Double.MAX_VALUE);
        double selectedReliability = selectedCpuLoad == Double.MAX_VALUE
                ? 0.0
                : Math.max(0.0, Math.min(1.0, 1.0 - selectedCpuLoad / 100.0));

        // Build trace
        List<CandidateDecision> trace = new ArrayList<>(uniqueEligible.size());
        for (SchedulingCandidate c : uniqueEligible) {
            boolean isSelected = c.nodeId().equals(selectedNodeId);
            trace.add(new CandidateDecision(
                    c.nodeId(), c.eligible(),
                    isSelected ? CandidateDisposition.SELECTED : CandidateDisposition.LOWER_RELIABILITY,
                    c.eligibility().reasons(),
                    c.reliability().status(),
                    c.reliability().reliability(),
                    c.reliability().capabilityStatus(),
                    c.capability() == null ? null : c.capability().capability(),
                    isSelected ? "selected by CPU least-loaded policy"
                            : "eligible but not selected (higher CPU load)"));
        }

        List<SchedulingReason> reasons = new ArrayList<>();
        reasons.add(SchedulingReason.SELECTED_HIGHEST_RELIABILITY);
        reasons.add(SchedulingReason.NO_POLICY_THRESHOLD_CONFIGURED);

        String derivation = "selected node " + selectedNodeId
                + " via CPU least-loaded policy (lowest observed CPU utilization)";

        return new SchedulingDecision(
                task.taskId(), decisionTimeMillis,
                SchedulingStatus.SELECTED,
                selectedNodeId, selectedReliability, null, false,
                trace, reasons, derivation);
    }

    /** @return the CPU load map used by this scheduler */
    public Map<String, Double> cpuLoadByNode() {
        return cpuLoadByNode;
    }
}
