package com.omni.pcst.master.evaluation;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Configuration-wiring coverage for the evaluation store.
 *
 * <p>The store's output path is redirected into a JVM-scoped temporary directory
 * so this test can never append to a repository-relative collection path (such
 * as {@code pcst-master/data/eval-telemetry.jsonl}), which is reserved for real
 * collection runs.
 */
@SpringBootTest
class TelemetryEvaluationStoreConfigTest {

    private static final Path OUTPUT_DIR = createRunScopedOutputDir();
    private static final Path OUTPUT_FILE = OUTPUT_DIR.resolve("eval-config-test.jsonl");

    @Autowired
    private TelemetryEvaluationStoreConfig storeConfig;

    @Autowired
    private TelemetryEvaluationStoreConfig.TelemetryEvaluationDiagnostics diagnostics;

    @DynamicPropertySource
    static void evaluationProperties(DynamicPropertyRegistry registry) {
        registry.add("pcst.evaluation.enabled", () -> "true");
        registry.add("pcst.evaluation.flush-limit", () -> "10");
        registry.add("pcst.evaluation.flush-interval-ms", () -> "5000");
        registry.add("pcst.evaluation.queue-capacity", () -> "100");
        registry.add("pcst.evaluation.file-locking", () -> "false");
        registry.add("pcst.evaluation.path", () -> OUTPUT_FILE.toString());
        registry.add("pcst.evaluation.collection-config-version", () -> "cfg-test-v9");
        // Ephemeral port so this context can coexist with any other @SpringBootTest
        // context in the same JVM instead of colliding on the fixed 9090 default.
        registry.add("grpc.server.port", () -> "0");
    }

    private static Path createRunScopedOutputDir() {
        try {
            return Files.createTempDirectory("pcst-eval-config-test-");
        } catch (IOException e) {
            throw new UncheckedIOException("cannot create run-scoped evaluation output directory", e);
        }
    }

    @Test
    void testOutputStaysInTemporaryDirectory() {
        Path actual = storeConfig.getStore().getOutputPath().toAbsolutePath().normalize();
        Path expectedRoot = OUTPUT_DIR.toAbsolutePath().normalize();
        assertTrue(actual.startsWith(expectedRoot),
                "test store must write under the temporary directory, but was " + actual);
    }

    @Test
    void storeBeanIsCreatedAndConfigurable() {
        assertNotNull(storeConfig.getStore(), "Store bean should be created");
        assertEquals(0, storeConfig.getStore().getQueueSize());
        assertEquals(10, storeConfig.getStore().getFlushLimit());
        assertEquals(100, storeConfig.getStore().getQueueCapacity());
    }

    @Test
    void diagnosticsBeanIsCreated() {
        assertNotNull(diagnostics);
        assertTrue(diagnostics.getAcceptedCount() >= 0);
        assertTrue(diagnostics.getPersistedCount() >= 0);
    }

    @Test
    void collectionConfigVersionIsBoundIndependentlyOfSchemaVersion() {
        assertEquals("cfg-test-v9", storeConfig.getProperties().getCollectionConfigVersion());
        assertEquals("cfg-test-v9", storeConfig.getProperties().effectiveCollectionConfigVersion());
        assertNotEquals(TelemetryEvaluationStore.FORMAT_VERSION,
                storeConfig.getProperties().effectiveCollectionConfigVersion(),
                "collection provenance must never be the schema version");
    }

    @Test
    void blankCollectionConfigVersionIsMarkedUnknownNotInvented() {
        TelemetryEvaluationProperties blank = new TelemetryEvaluationProperties();
        blank.setCollectionConfigVersion("   ");
        blank.validate();
        assertEquals(TelemetryEvaluationStore.UNKNOWN_COLLECTION_CONFIG_VERSION,
                blank.effectiveCollectionConfigVersion());
        assertNotEquals(TelemetryEvaluationStore.FORMAT_VERSION,
                blank.effectiveCollectionConfigVersion(),
                "unknown provenance must not fall back to the schema version");
    }

    @Test
    void invalidConfigurationIsRejectedClearly() {
        TelemetryEvaluationProperties flushTooSmall = new TelemetryEvaluationProperties();
        flushTooSmall.setFlushLimit(0);
        IllegalArgumentException e1 = assertThrows(IllegalArgumentException.class,
                flushTooSmall::validate);
        assertTrue(e1.getMessage().contains("flush-limit"), e1.getMessage());

        TelemetryEvaluationProperties inverted = new TelemetryEvaluationProperties();
        inverted.setFlushLimit(50);
        inverted.setQueueCapacity(10);
        IllegalArgumentException e2 = assertThrows(IllegalArgumentException.class, inverted::validate);
        assertTrue(e2.getMessage().contains("must not exceed"), e2.getMessage());

        TelemetryEvaluationProperties noPath = new TelemetryEvaluationProperties();
        noPath.setPath("  ");
        assertThrows(IllegalArgumentException.class, noPath::validate);

        TelemetryEvaluationProperties nullVersion = new TelemetryEvaluationProperties();
        nullVersion.setCollectionConfigVersion(null);
        IllegalArgumentException e3 = assertThrows(IllegalArgumentException.class, nullVersion::validate);
        assertTrue(e3.getMessage().contains("collection-config-version"), e3.getMessage());
    }

    @org.junit.jupiter.api.AfterAll
    static void removeRunScopedOutputDir() {
        try (Stream<Path> walk = Files.walk(OUTPUT_DIR)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // best-effort cleanup; never fail the suite on temp cleanup
                }
            });
        } catch (IOException ignored) {
            // best-effort cleanup
        }
    }
}