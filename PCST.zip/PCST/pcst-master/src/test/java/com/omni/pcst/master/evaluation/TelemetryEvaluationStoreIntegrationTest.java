package com.omni.pcst.master.evaluation;

import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration coverage for evaluation-telemetry persistence inside the real
 * Spring context.
 *
 * <p><b>Isolation contract.</b> The application context (and therefore the single
 * {@link TelemetryEvaluationStore} bean and its output file) is shared by every
 * method in this class. Tests here therefore:
 * <ul>
 *   <li>never close, disable or otherwise mutate the shared store;</li>
 *   <li>own a unique node id, so file-based assertions filter to their own data
 *       instead of relying on cumulative shared counters;</li>
 *   <li>assert on deltas or on parsed file content, never on absolute totals.</li>
 * </ul>
 * The output file is redirected to a JVM-unique temporary directory so repeated
 * runs cannot inherit each other's appended records.
 */
@SpringBootTest
class TelemetryEvaluationStoreIntegrationTest {

    private static final Path OUTPUT_DIR = createRunScopedOutputDir();
    private static final Path OUTPUT_FILE = OUTPUT_DIR.resolve("eval-telemetry-integration.jsonl");

    private static final long SERVER_TIME = 1_700_000_000_000L;

    /** Collection provenance this run configures; independent of the schema version. */
    private static final String COLLECTION_CONFIG_VERSION = "integration-run-cfg-1";

    @TempDir
    Path tempDir;

    @Autowired
    private TelemetryEvaluationStoreConfig storeConfig;

    @Autowired
    private DigitalTwinManager digitalTwinManager;

    @Autowired
    private TelemetryEvaluationStoreConfig.TelemetryEvaluationDiagnostics diagnostics;

    /**
     * Redirects the shared store to a directory that is unique to this JVM run.
     * The log is append-only, so reusing one path across runs would let a second
     * run observe the previous run's records.
     */
    @DynamicPropertySource
    static void evaluationProperties(DynamicPropertyRegistry registry) {
        registry.add("pcst.evaluation.enabled", () -> "true");
        registry.add("pcst.evaluation.flush-limit", () -> "3");
        registry.add("pcst.evaluation.flush-interval-ms", () -> "1000");
        registry.add("pcst.evaluation.queue-capacity", () -> "100");
        registry.add("pcst.evaluation.file-locking", () -> "false");
        registry.add("pcst.evaluation.path", () -> OUTPUT_FILE.toString());
        registry.add("pcst.evaluation.collection-config-version", () -> COLLECTION_CONFIG_VERSION);
        // Ephemeral port: a second Spring context in the same JVM (other
        // @SpringBootTest classes) must not collide with the fixed 9090 default.
        registry.add("grpc.server.port", () -> "0");
    }

    private static Path createRunScopedOutputDir() {
        try {
            return Files.createTempDirectory("pcst-eval-integration-");
        } catch (IOException e) {
            throw new UncheckedIOException("cannot create run-scoped evaluation output directory", e);
        }
    }

    @AfterAll
    static void removeRunScopedOutputDir() {
        try (Stream<Path> walk = Files.walk(OUTPUT_DIR)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // best-effort cleanup; never fail the suite on temp cleanup
                }
            });
        } catch (IOException ignored) {
            // best-effort cleanup
        }
    }

    @BeforeEach
    void setUp() {
        // The shared store must be usable for every test. If a previous test
        // closed it, fail loudly here instead of with a confusing assertion
        // deeper in an unrelated test.
        assertFalse(isStoreClosed(), "shared store must remain open for every test in this class");
    }

    // ---------------------------------------------------------------- wiring

    @Test
    void springContextCreatesSingleStoreAndWiresToManager() {
        assertNotNull(storeConfig.getStore(), "Store bean should be created");
        assertNotNull(digitalTwinManager, "DigitalTwinManager bean should be created");
        assertEquals(3, storeConfig.getStore().getFlushLimit(), "flush-limit is bound");
        assertEquals(100, storeConfig.getStore().getQueueCapacity(), "queue-capacity is bound");
        assertEquals(OUTPUT_FILE.toAbsolutePath().normalize(),
                storeConfig.getStore().getOutputPath(),
                "store writes to the run-scoped path");
        assertNotNull(diagnostics, "diagnostics facade is wired");
        assertEquals(storeConfig.getStore().getAcceptedRecords(), diagnostics.getAcceptedCount());
    }

    @Test
    void configuredCollectionVersionIsPersistedWithoutChangingSchemaVersion() throws Exception {
        assertEquals(COLLECTION_CONFIG_VERSION, digitalTwinManager.getCollectionConfigVersion(),
                "the manager is wired with the configured collection provenance");
        assertNotEquals(TelemetryEvaluationStore.FORMAT_VERSION, COLLECTION_CONFIG_VERSION);

        String nodeId = "node-provenance";
        digitalTwinManager.onNodeRegistered(nodeId, "host-provenance", 9105, "0.1.0", SERVER_TIME);
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                digitalTwinManager.onTelemetry(nodeId, telemetryRequest(SERVER_TIME + 20_000), SERVER_TIME + 20_000));

        awaitCondition(() -> {
            try {
                return !recordsForNode(nodeId).isEmpty();
            } catch (java.io.IOException e) {
                return false;
            }
        }, 3000, "record persisted");

        TelemetryEvaluationRecord rec = recordsForNode(nodeId).get(0);
        assertEquals(COLLECTION_CONFIG_VERSION, rec.collectionConfigVersion(),
                "the configured provenance is stored verbatim on the record");
        assertNotEquals(TelemetryEvaluationStore.FORMAT_VERSION, rec.collectionConfigVersion(),
                "changing provenance must not make it look like the schema version");

        String rawLine = Files.readAllLines(storeConfig.getStore().getOutputPath()).stream()
                .filter(l -> l.contains(nodeId))
                .findFirst().orElseThrow();
        assertTrue(rawLine.contains("\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\""),
                "schema version is written independently of provenance");
        assertTrue(rawLine.contains("\"collectionConfigVersion\":\"" + COLLECTION_CONFIG_VERSION + "\""),
                "collection provenance is written separately from the schema version");
    }

    // ------------------------------------------------- end-to-end persistence

    @Test
    void acceptedTelemetryReachesPersistedOutput() throws Exception {
        String nodeId = "node-accepted";
        digitalTwinManager.onNodeRegistered(nodeId, "host-accepted", 9101, "0.1.0", SERVER_TIME);

        long persistedBefore = diagnostics.getPersistedCount();

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                digitalTwinManager.onTelemetry(nodeId, telemetryRequest(SERVER_TIME + 1), SERVER_TIME + 1),
                "telemetry from a registered node is accepted");

        // flush-limit is 3, so this single record reaches disk via the periodic
        // flush within one interval.
        awaitCondition(() -> diagnostics.getPersistedCount() > persistedBefore, 3000,
                "accepted telemetry is eventually persisted");

        List<TelemetryEvaluationRecord> mine = recordsForNode(nodeId);
        assertEquals(1, mine.size(), "exactly this test's record is stored");
        TelemetryEvaluationRecord rec = mine.get(0);
        assertEquals(SERVER_TIME + 1, rec.observationTimestamp());
        assertEquals(12.5, rec.observation().cpuUtilizationPercent(), 1e-9);
        assertEquals(1024L, rec.observation().totalMemoryBytes());
        assertEquals(512L, rec.observation().usedMemoryBytes());
        assertTrue(rec.validForReplay(), "well-formed observation is replayable");
        assertEquals(COLLECTION_CONFIG_VERSION, rec.collectionConfigVersion(),
                "record carries the configured collection provenance");
        assertNotEquals(TelemetryEvaluationStore.FORMAT_VERSION, rec.collectionConfigVersion(),
                "collection provenance must never be the record schema version");
    }

    @Test
    void periodicFlushingWorksWithoutReachingThreshold() throws Exception {
        String nodeId = "node-periodic";
        digitalTwinManager.onNodeRegistered(nodeId, "host-periodic", 9102, "0.1.0", SERVER_TIME);

        int flushLimit = storeConfig.getStore().getFlushLimit();
        int recordsToSend = flushLimit - 1;
        assertTrue(recordsToSend >= 1, "flush-limit leaves room for a below-threshold case");
        assertTrue(recordsToSend < flushLimit, "this test must stay below the threshold");

        long persistedBefore = diagnostics.getPersistedCount();

        for (int i = 1; i <= recordsToSend; i++) {
            assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                    digitalTwinManager.onTelemetry(nodeId, telemetryRequest(SERVER_TIME + i), SERVER_TIME + i));
        }

        // Threshold flush cannot be the cause: fewer than flushLimit records were
        // sent, and append() only flushes synchronously at queue.size() >= flushLimit.
        awaitCondition(() -> diagnostics.getPersistedCount() >= persistedBefore + recordsToSend, 3000,
                "periodic flush persists below-threshold records");

        List<TelemetryEvaluationRecord> mine = recordsForNode(nodeId);
        assertEquals(recordsToSend, mine.size(), "only this test's records are counted");
        Set<Long> timestamps = new HashSet<>();
        for (TelemetryEvaluationRecord rec : mine) {
            assertEquals(nodeId, rec.nodeId());
            assertTrue(timestamps.add(rec.observationTimestamp()), "no duplicate timestamp: " + rec.observationTimestamp());
        }
        assertEquals(recordsToSend, timestamps.size(), "every below-threshold record persisted exactly once");
    }

    @Test
    void thresholdFlushingStillWorks() throws Exception {
        String nodeId = "node-threshold";
        digitalTwinManager.onNodeRegistered(nodeId, "host-threshold", 9103, "0.1.0", SERVER_TIME);

        int flushLimit = storeConfig.getStore().getFlushLimit();
        long persistedBefore = diagnostics.getPersistedCount();
        long base = SERVER_TIME + 10_000;

        for (int i = 1; i <= flushLimit; i++) {
            assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                    digitalTwinManager.onTelemetry(nodeId, telemetryRequest(base + i), base + i));
        }

        // append() flushes synchronously once the queue reaches flushLimit, so no
        // wait is needed here; the periodic flush interval is 1000ms.
        assertTrue(diagnostics.getPersistedCount() >= persistedBefore + flushLimit,
                "threshold flush is synchronous on the append that reaches the limit");
        assertEquals(flushLimit, recordsForNode(nodeId).size());
    }

    // ----------------------------------------------------------- concurrency

    @Test
    void concurrentAppendAndFlushDoNotCorrupt() throws Exception {
        String nodeId = "node-concurrent";
        digitalTwinManager.onNodeRegistered(nodeId, "host-concurrent", 9104, "0.1.0", SERVER_TIME);

        int threads = 8;
        int recordsPerThread = 10;
        int total = threads * recordsPerThread;

        long acceptedBefore = diagnostics.getAcceptedCount();
        long persistedBefore = diagnostics.getPersistedCount();
        long rejectedBefore = diagnostics.getRejectedCount();
        long flushFailuresBefore = diagnostics.getFlushFailures();

        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch ready = new CountDownLatch(threads);
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);

        List<DigitalTwinManager.TelemetryIngestion> outcomes =
                java.util.Collections.synchronizedList(new ArrayList<>(total));
        List<Long> sentTimestamps = java.util.Collections.synchronizedList(new ArrayList<>(total));

        // Timestamp assignment and ingestion are performed under one lock so the
        // observation timestamps are strictly increasing *and* applied in that
        // order. Without this, concurrent arrival order makes the Digital Twin's
        // stale/out-of-order guard reject observations - a legitimate outcome that
        // would mask what this test is actually about (store concurrency).
        Object orderingLock = new Object();
        AtomicInteger sequence = new AtomicInteger();

        try {
            for (int t = 0; t < threads; t++) {
                pool.submit(() -> {
                    ready.countDown();
                    try {
                        start.await();
                        for (int i = 0; i < recordsPerThread; i++) {
                            synchronized (orderingLock) {
                                long timestamp = SERVER_TIME + 100_000 + sequence.incrementAndGet();
                                sentTimestamps.add(timestamp);
                                outcomes.add(digitalTwinManager.onTelemetry(
                                        nodeId, telemetryRequest(timestamp), timestamp + 1000));
                            }
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } finally {
                        done.countDown();
                    }
                });
            }
            assertTrue(ready.await(10, TimeUnit.SECONDS), "workers started");
            start.countDown();
            assertTrue(done.await(10, TimeUnit.SECONDS), "all writers finished");
        } finally {
            pool.shutdown();
            assertTrue(pool.awaitTermination(10, TimeUnit.SECONDS));
        }

        // Any rejection by the Digital Twin is asserted separately so it can never
        // be mistaken for a successful store append.
        long rejectedIngestion = outcomes.stream()
                .filter(o -> o != DigitalTwinManager.TelemetryIngestion.ACCEPTED)
                .count();
        assertEquals(0, rejectedIngestion,
                "all " + total + " observations must be accepted by the Digital Twin; rejections="
                        + rejectedIngestion);
        assertEquals(total, outcomes.size());
        assertEquals(total, new HashSet<>(sentTimestamps).size(), "sent timestamps are unique");

        awaitCondition(() -> diagnostics.getPersistedCount() >= persistedBefore + total, 5000,
                "all concurrently appended records are flushed to disk");

        assertEquals(total, diagnostics.getAcceptedCount() - acceptedBefore,
                "every observation reached the store");
        assertEquals(total, diagnostics.getPersistedCount() - persistedBefore,
                "every accepted record reached disk");
        assertEquals(0, diagnostics.getRejectedCount() - rejectedBefore,
                "queue capacity was never exceeded");
        assertEquals(0, diagnostics.getFlushFailures() - flushFailuresBefore,
                "no flush failed during concurrent appends");
        assertEquals(0, storeConfig.getStore().getQueueSize(), "nothing left queued");

        List<TelemetryEvaluationRecord> mine = recordsForNode(nodeId);
        assertEquals(total, mine.size(), "exactly this test's records are persisted, none lost");

        Set<Long> persistedTimestamps = new HashSet<>();
        for (TelemetryEvaluationRecord rec : mine) {
            assertTrue(persistedTimestamps.add(rec.observationTimestamp()),
                    "record persisted more than once: " + rec.observationTimestamp());
            assertEquals(nodeId, rec.nodeId());
            assertEquals(12.5, rec.observation().cpuUtilizationPercent(), 1e-9,
                    "each JSONL line parsed back to its original values");
            assertEquals(1024L, rec.observation().totalMemoryBytes());
            assertTrue(rec.validForReplay());
        }
        assertEquals(new HashSet<>(sentTimestamps), persistedTimestamps,
                "persisted set equals sent set: nothing lost, nothing invented");
    }

    // ------------------------------------------------------ lifecycle, local

    @Test
    void orderlyCloseDrainsQueueOfLocalStore() throws Exception {
        // Deliberately NOT the shared Spring bean: closing it would poison every
        // other test in this class.
        Path file = tempDir.resolve("close-drain.jsonl");
        TelemetryEvaluationStore local = new TelemetryEvaluationStore(file, 10, 100, false);
        try {
            local.append(record("node-close", 100L));
            assertEquals(1, local.getQueueSize(), "below threshold: still queued, not yet persisted");
            assertEquals(0, local.getPersistedRecords(), "accepted does not mean persisted");

            local.close();

            assertEquals(0, local.getQueueSize(), "close drained the queue");
            assertEquals(1, local.getPersistedRecords(), "close persisted the queued record");
            List<TelemetryEvaluationRecord> read = local.readAll();
            assertEquals(1, read.size());
            assertEquals("node-close", read.get(0).nodeId());
            assertEquals(100L, read.get(0).observationTimestamp());
        } finally {
            local.close();
        }

        // The shared store is untouched and still usable.
        assertFalse(isStoreClosed(), "local close must not close the shared store");
    }

    @Test
    void appendAfterCloseIsRejectedAndCounted() throws Exception {
        Path file = tempDir.resolve("after-close.jsonl");
        TelemetryEvaluationStore local = new TelemetryEvaluationStore(file, 10, 100, false);
        local.close();

        assertThrows(IllegalStateException.class, () -> local.append(record("node-after-close", 200L)),
                "appending to a closed store must fail loudly");
        assertTrue(local.getRejectedRecords() >= 1, "closed-store rejection is counted, not silent");
        assertFalse(isStoreClosed(), "shared store remains open");
    }

    // --------------------------------------------------- failure observability

    @Test
    void queueOverflowIsObservable() throws Exception {
        Path dir = tempDir.resolve("overflow-dir");
        Files.createDirectories(dir);
        // Output path is a directory, so every flush fails and the bounded queue fills.
        TelemetryEvaluationStore local = new TelemetryEvaluationStore(dir, 2, 5, false);
        try {
            for (int i = 0; i < 20; i++) {
                local.append(record("node-overflow", 1000L + i));
            }
            assertTrue(local.getRejectedRecords() > 0, "overflow is counted and reported");
            assertNotNull(local.getLastWriteError());
            assertTrue(local.getLastWriteError().contains("overflow"),
                    "overflow is visible in the last error: " + local.getLastWriteError());
            assertTrue(local.getQueueSize() <= local.getQueueCapacity(),
                    "bounded queue is never exceeded");
        } finally {
            local.close();
        }
        assertFalse(isStoreClosed(), "shared store remains open");
    }

    @Test
    void flushFailureIsObservableAndRecordsNotDiscarded() throws Exception {
        Path dir = tempDir.resolve("flush-fail-dir");
        Files.createDirectories(dir);
        TelemetryEvaluationStore local = new TelemetryEvaluationStore(dir, 10, 100, false);
        try {
            local.append(record("node-fail", 1L));
            local.append(record("node-fail", 2L));
            local.flush();

            assertNotNull(local.getLastWriteError(), "flush failure is surfaced");
            assertEquals(0, local.getPersistedRecords(), "nothing was written");
            assertEquals(2, local.getQueueSize(), "unwritten records are retained, never discarded");
            assertTrue(local.getFlushFailures() >= 1, "flush failure is counted");
        } finally {
            local.close();
        }
        assertFalse(isStoreClosed(), "shared store remains open");
    }

    @Test
    void invalidConfigurationFailsClearly() {
        TelemetryEvaluationProperties props = new TelemetryEvaluationProperties();
        props.setFlushLimit(0);
        IllegalArgumentException tooSmall = assertThrows(IllegalArgumentException.class, props::validate);
        assertTrue(tooSmall.getMessage().contains("flush-limit"), tooSmall.getMessage());

        TelemetryEvaluationProperties inverted = new TelemetryEvaluationProperties();
        inverted.setFlushLimit(50);
        inverted.setQueueCapacity(10);
        IllegalArgumentException invertedMessage = assertThrows(IllegalArgumentException.class, inverted::validate);
        assertTrue(invertedMessage.getMessage().contains("must not exceed"), invertedMessage.getMessage());

        TelemetryEvaluationProperties blank = new TelemetryEvaluationProperties();
        blank.setPath("  ");
        assertThrows(IllegalArgumentException.class, blank::validate);

        // The store constructor enforces the same invariants defensively.
        assertThrows(IllegalArgumentException.class,
                () -> new TelemetryEvaluationStore(tempDir.resolve("invalid.jsonl"), 0, 10, false));
        assertThrows(IllegalArgumentException.class,
                () -> new TelemetryEvaluationStore(tempDir.resolve("invalid.jsonl"), 10, 0, false));
        assertThrows(IllegalArgumentException.class,
                () -> new TelemetryEvaluationStore(tempDir.resolve("invalid.jsonl"), 20, 10, false));
    }

    @Test
    void secondStoreTargetingSameFileRejected() throws Exception {
        // Uses its own file so the shared store's output is never contended.
        Path file = tempDir.resolve("exclusive.jsonl");
        TelemetryEvaluationStore first = new TelemetryEvaluationStore(file, 50, 100, true);
        try {
            IllegalStateException ex = assertThrows(IllegalStateException.class,
                    () -> new TelemetryEvaluationStore(file, 50, 100, true),
                    "a second writer must be refused");
            assertTrue(ex.getMessage().toLowerCase().contains("lock"), ex.getMessage());
        } finally {
            first.close();
        }

        // Once the first writer released the lock, a new writer may take it.
        TelemetryEvaluationStore third = new TelemetryEvaluationStore(file, 50, 100, true);
        third.close();

        assertFalse(isStoreClosed(), "shared store remains open");
    }

    @Test
    void directConstructorsStillWorkAndRoundTrip() throws Exception {
        Path file = tempDir.resolve("direct.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 1, 100, false);
        try {
            store.append(record("node-direct", 300L));
            store.flush();

            List<TelemetryEvaluationRecord> read = store.readAll();
            assertEquals(1, read.size());
            assertEquals("node-direct", read.get(0).nodeId());
            assertEquals(300L, read.get(0).observationTimestamp());
            assertEquals(10.0, read.get(0).observation().cpuUtilizationPercent(), 1e-9);
            assertEquals(1024L, read.get(0).observation().totalMemoryBytes());
        } finally {
            store.close();
        }
        assertFalse(isStoreClosed(), "shared store remains open");
    }

    // ------------------------------------------------------- data integrity

    @Test
    void malformedLineIsSkippedAndObservableNotSilentlyAccepted() throws Exception {
        Path file = tempDir.resolve("malformed.jsonl");
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file, 10, 100, false);
        try {
            store.append(record("node-good", 500L));
            store.flush();
            store.close();

            // Corrupt lines of the kinds a partially-written log can contain:
            // a truncated current-schema line, a legacy-schema line, and a line
            // whose observation block omits required components.
            Files.writeString(file,
                    "{\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\",\"nodeId\":\"truncated\"\n"
                            + "{\"v\":\"" + TelemetryEvaluationStore.LEGACY_FORMAT_VERSION + "\","
                            + "\"nodeId\":\"legacy\",\"observationTimestamp\":7}\n"
                            + "{\"v\":\"" + TelemetryEvaluationStore.FORMAT_VERSION + "\","
                            + "\"nodeId\":\"incomplete\",\"observationTimestamp\":8,"
                            + "\"observation\":{\"timestamp\":8}}\n",
                    java.nio.file.StandardOpenOption.APPEND);

            TelemetryEvaluationStore.ReadResult result = store.readAllWithDiagnostics();

            assertEquals(1, result.records().size(), "only the well-formed record is returned");
            assertEquals("node-good", result.records().get(0).nodeId());
            assertEquals(3, result.skippedLineCount(), "all three corrupt lines are reported as skipped");
            assertEquals(3, store.getLastReadSkippedLines(), "skip count is observable on the store");
            assertEquals(3, result.skipped().size());
            assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.MALFORMED_JSON));
            assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.UNSUPPORTED_SCHEMA_VERSION),
                    "a legacy-schema line is never re-interpreted under the current schema");
            assertEquals(1, result.count(TelemetryEvaluationStore.SkipReason.MISSING_REQUIRED_FIELD));

            for (TelemetryEvaluationRecord rec : result.records()) {
                assertNotEquals("_", rec.nodeId(), "no synthetic placeholder record is ever produced");
                assertTrue(rec.observationTimestamp() >= 0, "no sentinel timestamp is ever produced");
            }

            // Repeatable: a second read of an unchanged file yields the same result.
            TelemetryEvaluationStore.ReadResult again = store.readAllWithDiagnostics();
            assertEquals(result.records(), again.records(), "readAll semantics are repeatable");
            assertEquals(result.skippedLineCount(), again.skippedLineCount());

            // The corrupt data is preserved on disk for diagnosis, not destroyed.
            String raw = Files.readString(file);
            assertTrue(raw.contains("node-good"), "valid record preserved");
            assertTrue(raw.contains("truncated"), "corrupt line preserved for diagnosis");
        } finally {
            store.close();
        }
    }

    // ---------------------------------------------------------------- helpers

    private boolean isStoreClosed() {
        TelemetryEvaluationStore store = storeConfig.getStore();
        return store == null || store.isClosed();
    }

    private List<TelemetryEvaluationRecord> recordsForNode(String nodeId) throws IOException {
        return storeConfig.getStore().readAll().stream()
                .filter(r -> nodeId.equals(r.nodeId()))
                .collect(java.util.stream.Collectors.toList());
    }

    private static TelemetryEvaluationRecord record(String nodeId, long ts) {
        return TelemetryEvaluationRecord.of(nodeId,
                new TelemetryObservation(ts, 10.0, 1024L, 512L, null, null, null, null, null,
                        null, null, null, null, null, null, null),
                ts + 1, "pcst-eval-v1");
    }

    private static void awaitCondition(BooleanSupplier condition, long timeoutMillis, String message) {
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMillis);
        while (System.nanoTime() < deadline) {
            if (condition.getAsBoolean()) {
                return;
            }
            try {
                Thread.sleep(25);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                fail("interrupted while waiting for: " + message);
            }
        }
        assertTrue(condition.getAsBoolean(), message);
    }

    private static com.omni.pcst.proto.TelemetryRequest telemetryRequest(long timestamp) {
        return com.omni.pcst.proto.TelemetryRequest.newBuilder()
                .setNodeId("test-node")
                .setTimestamp(timestamp)
                .setCpu(com.omni.pcst.proto.CpuTelemetry.newBuilder().setUtilizationPercent(12.5))
                .setMemory(com.omni.pcst.proto.MemoryTelemetry.newBuilder()
                        .setTotalBytes(1024L).setUsedBytes(512L).setAvailableBytes(512L))
                .setGpu(com.omni.pcst.proto.GpuTelemetry.newBuilder().setAvailable(false))
                .setDisk(com.omni.pcst.proto.DiskTelemetry.newBuilder().setTotalBytes(2048L).setFreeBytes(1024L))
                .setProcesses(com.omni.pcst.proto.ProcessTelemetry.newBuilder().setProcessCount(4))
                .build();
    }
}