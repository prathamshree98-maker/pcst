package com.omni.pcst.master.telemetry;

import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.evaluation.TelemetryEvaluationRecord;
import com.omni.pcst.master.evaluation.TelemetryEvaluationStore;
import com.omni.pcst.proto.CpuTelemetry;
import com.omni.pcst.proto.DiskTelemetry;
import com.omni.pcst.proto.GpuTelemetry;
import com.omni.pcst.proto.MemoryTelemetry;
import com.omni.pcst.proto.ProcessTelemetry;
import com.omni.pcst.proto.TelemetryRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * End-to-end coverage of sequence metadata from the ingestion entry point
 * through the Digital Twin into the persisted evaluation record.
 *
 * <p>These tests use the real {@link DigitalTwinManager} and a real
 * {@link TelemetryEvaluationStore} on a temporary path. No sleeps: every
 * assertion follows explicit calls, and persistence is forced by an explicit
 * flush rather than by waiting for a timer.
 */
class TelemetrySequenceIngestionTest {

    private static final long SERVER_TIME = 1_700_000_000_000L;
    private static final String SESSION = "session-abc";
    private static final String NODE = "node-seq";

    @TempDir
    Path tempDir;

    private static TelemetryRequest request(String nodeId, long timestamp,
                                            String session, Long sequence) {
        TelemetryRequest.Builder builder = TelemetryRequest.newBuilder()
                .setNodeId(nodeId)
                .setTimestamp(timestamp)
                .setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(10.0))
                .setMemory(MemoryTelemetry.newBuilder()
                        .setTotalBytes(1024L).setUsedBytes(512L).setAvailableBytes(512L))
                .setGpu(GpuTelemetry.newBuilder().setAvailable(false))
                .setDisk(DiskTelemetry.newBuilder().setTotalBytes(2048L).setFreeBytes(1024L))
                .setProcesses(ProcessTelemetry.newBuilder().setProcessCount(4));
        if (session != null) {
            builder.setAgentSessionId(session);
        }
        if (sequence != null) {
            builder.setTelemetrySequence(sequence);
        }
        return builder.build();
    }

    private TelemetryEvaluationStore newStore(String file) {
        return new TelemetryEvaluationStore(tempDir.resolve(file), 1000, 10000, false);
    }

    @Test
    void sequenceMetadataFlowsFromRequestIntoPersistedRecord() throws Exception {
        TelemetryEvaluationStore store = newStore("flow.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, request(NODE, SERVER_TIME + 1, SESSION, 1L), SERVER_TIME + 1));
        store.flush();

        List<TelemetryEvaluationRecord> records = store.readAll();
        assertEquals(1, records.size());
        assertEquals(SESSION, records.get(0).agentSessionId(),
                "the session id from the request is persisted verbatim");
        assertEquals(1L, records.get(0).telemetrySequence(),
                "the sequence from the request is persisted");
        assertEquals("cfg-1", records.get(0).collectionConfigVersion());
        assertEquals(1L, manager.getSequenceTracker().highestSequence(NODE, SESSION));
    }

    @Test
    void requestWithoutSequenceMetadataPersistsNulls() throws Exception {
        TelemetryEvaluationStore store = newStore("nometa.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, request(NODE, SERVER_TIME + 1, null, null), SERVER_TIME + 1));
        store.flush();

        TelemetryEvaluationRecord record = store.readAll().get(0);
        assertNull(record.agentSessionId(), "no session metadata must persist as null, never invented");
        assertNull(record.telemetrySequence(), "no sequence must persist as null, never invented");
    }

    @Test
    void consecutiveTelemetryProducesNoGapDiagnostic() throws Exception {
        TelemetryEvaluationStore store = newStore("consecutive.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        for (long seq = 1; seq <= 5; seq++) {
            assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                    manager.onTelemetry(NODE, request(NODE, SERVER_TIME + seq, SESSION, seq), SERVER_TIME + seq));
        }

        assertEquals(0L, manager.getSequenceTracker().getForwardGapCount());
        assertEquals(5L, manager.getSequenceTracker().highestSequence(NODE, SESSION));
    }

    @Test
    void forwardGapAcrossAFailedSendIsDetectedButDoesNotRejectTelemetry() throws Exception {
        TelemetryEvaluationStore store = newStore("gap.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        // Sequence 2 was produced by the agent but its send failed; the next
        // successful message is 3.
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, request(NODE, SERVER_TIME + 1, SESSION, 1L), SERVER_TIME + 1));
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, request(NODE, SERVER_TIME + 3, SESSION, 3L), SERVER_TIME + 3));

        assertEquals(1L, manager.getSequenceTracker().getForwardGapCount(),
                "the discontinuity in the received stream is detected");
        assertEquals(3L, manager.getSequenceTracker().highestSequence(NODE, SESSION));

        store.flush();
        assertEquals(2, store.readAll().size(),
                "a sequence gap never causes telemetry to be dropped by the Master");
    }

    @Test
    void timestampStaleRejectionIsIndependentOfSequenceTracking() throws Exception {
        TelemetryEvaluationStore store = newStore("stale.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        long base = SERVER_TIME + 100;
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, request(NODE, base, SESSION, 1L), base));
        // A back-dated snapshot: sequence continues (2) but the timestamp is stale.
        assertEquals(DigitalTwinManager.TelemetryIngestion.STALE_OR_OUT_OF_ORDER,
                manager.onTelemetry(NODE, request(NODE, base - 50, SESSION, 2L), base + 1),
                "timestamp staleness still rejects the observation");

        // The sequence tracker still observed it, so the received-stream record
        // is complete even though the observation was rejected.
        assertEquals(2L, manager.getSequenceTracker().highestSequence(NODE, SESSION));
        assertEquals(0L, manager.getSequenceTracker().getForwardGapCount(),
                "a stale rejection is not a sequence gap");

        store.flush();
        assertEquals(1, store.readAll().size(), "only the accepted observation is persisted");
    }

    @Test
    void sequenceAnomalyDoesNotSilentlyResetTracking() throws Exception {
        TelemetryEvaluationStore store = newStore("noreset.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        long base = SERVER_TIME + 200;
        manager.onTelemetry(NODE, request(NODE, base + 1, SESSION, 1L), base + 1);
        manager.onTelemetry(NODE, request(NODE, base + 2, SESSION, 50L), base + 2);  // big gap
        // A late arrival below the high-water mark must not reset tracking.
        manager.onTelemetry(NODE, request(NODE, base + 3, SESSION, 2L), base + 3);

        assertEquals(50L, manager.getSequenceTracker().highestSequence(NODE, SESSION),
                "tracking was not reset by the unexpected sequence");
        assertEquals(1L, manager.getSequenceTracker().getOutOfOrderCount());
    }

    @Test
    void newSessionAfterRestartIsNotReportedAsCorruption() throws Exception {
        TelemetryEvaluationStore store = newStore("restart.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME, "session-1");

        long base = SERVER_TIME + 300;
        manager.onTelemetry(NODE, request(NODE, base + 1, "session-1", 1L), base + 1);
        manager.onTelemetry(NODE, request(NODE, base + 2, "session-1", 2L), base + 2);

        // The agent process restarts: same node id, new session id, sequence restarts.
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", base + 3, "session-2");
        assertEquals("session-2", manager.getSequenceTracker().registeredSession(NODE));
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, request(NODE, base + 3, "session-2", 1L), base + 3));

        assertEquals(0L, manager.getSequenceTracker().getForwardGapCount(),
                "a restart must not be reported as a sequence gap");
        assertEquals(0L, manager.getSequenceTracker().getDuplicateCount(),
                "a restart must not be reported as a duplicate");
        assertEquals(1L, manager.getSequenceTracker().getSessionChangeCount());
        assertEquals(1L, manager.getSequenceTracker().highestSequence(NODE, "session-2"));
        assertEquals(2L, manager.getSequenceTracker().highestSequence(NODE, "session-1"));
    }

    @Test
    void invalidSequenceMetadataDoesNotBlockIngestion() throws Exception {
        TelemetryEvaluationStore store = newStore("invalid.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        // A blank session id with a positive sequence: invalid metadata, but the
        // observation must still be ingested.
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry(NODE, request(NODE, SERVER_TIME + 1, "   ", 5L), SERVER_TIME + 1),
                "invalid sequence metadata must never reject telemetry");

        assertEquals(1L, manager.getSequenceTracker().getInvalidMetadataCount());
        store.flush();
        assertEquals(1, store.readAll().size(), "the observation is persisted regardless");
    }

    @Test
    void concurrentIngestionCannotCorruptTrackerState() throws Exception {
        TelemetryEvaluationStore store = newStore("concurrent.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(10000, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        int threads = 8;
        int perThread = 50;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        AtomicInteger accepted = new AtomicInteger();
        AtomicInteger rejected = new AtomicInteger();
        final Object ingestOrder = new Object();
        java.util.concurrent.atomic.AtomicLong sequence = new java.util.concurrent.atomic.AtomicLong();

        try {
            for (int t = 0; t < threads; t++) {
                final int threadIndex = t;
                pool.submit(() -> {
                    try {
                        start.await();
                        for (int i = 1; i <= perThread; i++) {
                            // The Digital Twin applies observations under a per-node
                            // lock and rejects non-increasing timestamps, so a
                            // multi-writer test on one node cannot also expect every
                            // write accepted unless the (sequence, timestamp) pair
                            // is drawn together inside one lock. That keeps this test
                            // focused on SEQUENCE-tracker concurrency; the timestamp
                            // gate is covered separately.
                            synchronized (ingestOrder) {
                                long seq = sequence.getAndIncrement() + 1;
                                long ts = SERVER_TIME + 10_000 + (seq - 1);
                                DigitalTwinManager.TelemetryIngestion outcome =
                                        manager.onTelemetry(NODE, request(NODE, ts, SESSION, seq), ts);
                                if (outcome == DigitalTwinManager.TelemetryIngestion.ACCEPTED) {
                                    accepted.incrementAndGet();
                                } else {
                                    rejected.incrementAndGet();
                                }
                            }
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } finally {
                        done.countDown();
                    }
                });
            }
            start.countDown();
            assertTrue(done.await(30, TimeUnit.SECONDS), "all writers finished");
        } finally {
            pool.shutdown();
            assertTrue(pool.awaitTermination(30, TimeUnit.SECONDS));
        }

        assertEquals(0, rejected.get(), "distinct timestamps per thread must all be accepted");
        assertEquals(threads * perThread, accepted.get());

        long expectedHighest = (long) threads * perThread;
        assertEquals(expectedHighest, manager.getSequenceTracker().highestSequence(NODE, SESSION),
                "the high-water mark is exact under full concurrency");

        store.flush();
        assertEquals(threads * perThread, store.readAll().size(),
                "every accepted observation is persisted exactly once");
    }

    @Test
    void trackerNeverAltersTwinState() throws Exception {
        TelemetryEvaluationStore store = newStore("isolated.jsonl");
        DigitalTwinManager manager = new DigitalTwinManager(100, null, store, "cfg-1");
        manager.onNodeRegistered(NODE, "host", 9091, "0.1.0", SERVER_TIME);

        manager.onTelemetry(NODE, request(NODE, SERVER_TIME + 1, SESSION, 1L), SERVER_TIME + 1);
        var before = manager.getSnapshot(NODE).orElseThrow();

        // Inject an anomaly directly into the tracker; twin state must not change.
        manager.getSequenceTracker().observe(NODE, SESSION, 999L);

        var after = manager.getSnapshot(NODE).orElseThrow();
        assertEquals(before.latestObservation(), after.latestObservation(),
                "sequence tracking must not alter the latest observation");
        assertEquals(before.staleObservationsRejected(), after.staleObservationsRejected(),
                "sequence tracking must not affect the staleness counter");
        assertEquals(before.observationHistory().size(), after.observationHistory().size(),
                "sequence tracking must not alter observation history");
    }
}