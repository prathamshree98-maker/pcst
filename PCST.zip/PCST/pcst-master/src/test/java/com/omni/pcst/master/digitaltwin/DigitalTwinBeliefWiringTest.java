package com.omni.pcst.master.digitaltwin;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.proto.BatteryTelemetry;
import com.omni.pcst.proto.CpuTelemetry;
import com.omni.pcst.proto.DiskTelemetry;
import com.omni.pcst.proto.GpuTelemetry;
import com.omni.pcst.proto.MemoryTelemetry;
import com.omni.pcst.proto.NetworkTelemetry;
import com.omni.pcst.proto.ProcessTelemetry;
import com.omni.pcst.proto.TelemetryRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Verifies that the Bayesian update engine is actually wired into the Digital
 * Twin: accepted telemetry must populate {@link BeliefState} in the stored
 * twin state, and the beliefs must reflect the ingested observations.
 */
class DigitalTwinBeliefWiringTest {

    private static final long SERVER_TIME = 1_700_000_000_000L;

    @Test
    void acceptedTelemetryPopulatesBeliefState() {
        DigitalTwinManager manager = new DigitalTwinManager(100, new BayesianBeliefEngine());
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        DigitalTwinSnapshot before = manager.getSnapshot("node-1").orElseThrow();
        assertEquals(BeliefState.UNINITIALIZED, before.beliefState(),
                "no observation processed yet: belief state must be uninitialized");

        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry("node-1", telemetry(100L, 12.5, 1024L, 512L,
                        82.5, true, 12.5, 0.25), SERVER_TIME + 1));

        DigitalTwinSnapshot after = manager.getSnapshot("node-1").orElseThrow();
        assertNotEquals(BeliefState.UNINITIALIZED, after.beliefState());
        assertEquals(100L, after.beliefState().latestObservationTimestamp());

        ResourceBelief cpu = after.beliefState()
                .beliefFor(BayesianBeliefEngine.CPU_UTILIZATION_PERCENT).orElseThrow();
        assertEquals(1, cpu.observationCount());
        assertTrue(cpu.posteriorMean() > 12.5 && cpu.posteriorMean() < 50.0,
                "posterior mean is shrunk from the prior toward the observation: " + cpu.posteriorMean());
        assertTrue(cpu.posteriorVariance() < 2500.0, "uncertainty is reduced below the prior variance");

        ResourceBelief memory = after.beliefState()
                .beliefFor(BayesianBeliefEngine.MEMORY_UTILIZATION_PERCENT).orElseThrow();
        assertEquals(50.0, memory.posteriorMean(), 1e-9,
                "used=512 of total=1024 is 50%, equal to the prior mean: posterior stays 50");

        ResourceBelief battery = after.beliefState()
                .beliefFor(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT).orElseThrow();
        assertEquals(82.178, battery.posteriorMean(), 0.001);

        ResourceBelief latency = after.beliefState()
                .beliefFor(BayesianBeliefEngine.NETWORK_LATENCY_MS).orElseThrow();
        assertEquals(1, latency.observationCount());
    }

    @Test
    void successiveObservationsUpdateTheBelief() {
        DigitalTwinManager manager = new DigitalTwinManager(100, new BayesianBeliefEngine());
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        manager.onTelemetry("node-1", telemetry(100L, 10.0, 1024L, 512L, 80.0, true, 10.0, 0.1),
                SERVER_TIME + 1);
        manager.onTelemetry("node-1", telemetry(200L, 30.0, 1024L, 512L, 60.0, true, 30.0, 0.2),
                SERVER_TIME + 2);

        ResourceBelief cpu = manager.getSnapshot("node-1").orElseThrow().beliefState()
                .beliefFor(BayesianBeliefEngine.CPU_UTILIZATION_PERCENT).orElseThrow();
        assertEquals(2, cpu.observationCount());
        assertTrue(cpu.posteriorMean() > 10.0 && cpu.posteriorMean() < 30.0,
                "posterior mean lies between the two observations: " + cpu.posteriorMean());

        ResourceBelief battery = manager.getSnapshot("node-1").orElseThrow().beliefState()
                .beliefFor(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT).orElseThrow();
        assertTrue(battery.posteriorMean() < 80.0 && battery.posteriorMean() > 60.0,
                "battery belief moved toward the newer observation: " + battery.posteriorMean());
    }

    @Test
    void missingMeasurementsLeaveResourceBeliefAbsent() {
        DigitalTwinManager manager = new DigitalTwinManager(100, new BayesianBeliefEngine());
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);

        // Telemetry without battery and network: those measurements never arrive.
        TelemetryRequest sparse = TelemetryRequest.newBuilder()
                .setNodeId("node-1")
                .setTimestamp(100L)
                .setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(20.0))
                .setMemory(MemoryTelemetry.newBuilder()
                        .setTotalBytes(1024L).setUsedBytes(512L).setAvailableBytes(512L))
                .setGpu(GpuTelemetry.newBuilder().setAvailable(false))
                .setDisk(DiskTelemetry.newBuilder().setTotalBytes(2048L).setFreeBytes(1024L))
                .setProcesses(ProcessTelemetry.newBuilder().setProcessCount(4))
                .build();
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry("node-1", sparse, SERVER_TIME + 1));

        BeliefState beliefState = manager.getSnapshot("node-1").orElseThrow().beliefState();
        assertNotEquals(BeliefState.UNINITIALIZED, beliefState);
        assertTrue(beliefState.beliefFor(BayesianBeliefEngine.CPU_UTILIZATION_PERCENT).isPresent());
        assertTrue(beliefState.beliefFor(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT).isEmpty(),
                "no battery measurement was ever ingested: no battery belief may exist");
        assertTrue(beliefState.beliefFor(BayesianBeliefEngine.NETWORK_LATENCY_MS).isEmpty(),
                "no latency measurement was ever ingested: no latency belief may exist");
    }

    @Test
    void nullEngineLeavesBeliefStateUninitialized() {
        DigitalTwinManager manager = new DigitalTwinManager(100, null);
        manager.onNodeRegistered("node-1", "host-1", 9091, "0.1.0", SERVER_TIME);
        assertEquals(DigitalTwinManager.TelemetryIngestion.ACCEPTED,
                manager.onTelemetry("node-1", telemetry(100L, 12.5, 1024L, 512L,
                        82.5, true, 12.5, 0.25), SERVER_TIME + 1));

        assertEquals(BeliefState.UNINITIALIZED, manager.getSnapshot("node-1").orElseThrow().beliefState(),
                "without a configured engine the belief state must stay explicitly uninitialized");
    }

    /* ------------------------------------------------------------------ helpers */

    private static TelemetryRequest telemetry(long timestamp, double cpu,
                                              long totalMemory, long usedMemory,
                                              double batteryLevel, boolean charging,
                                              double latencyMs, double packetLossPercent) {
        return TelemetryRequest.newBuilder()
                .setNodeId("node-1")
                .setTimestamp(timestamp)
                .setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(cpu))
                .setMemory(MemoryTelemetry.newBuilder()
                        .setTotalBytes(totalMemory).setUsedBytes(usedMemory).setAvailableBytes(512L))
                .setGpu(GpuTelemetry.newBuilder().setAvailable(false))
                .setBattery(BatteryTelemetry.newBuilder()
                        .setLevelPercent(batteryLevel).setCharging(charging))
                .setNetwork(NetworkTelemetry.newBuilder()
                        .setLatencyMs(latencyMs).setPacketLossPercent(packetLossPercent))
                .setDisk(DiskTelemetry.newBuilder().setTotalBytes(2048L).setFreeBytes(1024L))
                .setProcesses(ProcessTelemetry.newBuilder().setProcessCount(4))
                .build();
    }
}
