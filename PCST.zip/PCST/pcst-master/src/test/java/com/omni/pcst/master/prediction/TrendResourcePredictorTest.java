package com.omni.pcst.master.prediction;

import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic challenger tests for Step 5D trend predictor.
 * No calibration / superiority claims.
 */
class TrendResourcePredictorTest {

    private static final TrendResourcePredictor PREDICTOR = new TrendResourcePredictor();

    private static TelemetryObservation obs(long ts, Double cpu) {
        return new TelemetryObservation(ts, cpu, 1024L, 512L, null,
                null, null, null, null, null, null, null, null, null, null, null);
    }

    private static DigitalTwinSnapshot snapshot(List<TelemetryObservation> history) {
        TelemetryObservation latest = history.isEmpty() ? null : history.get(0);
        return new DigitalTwinSnapshot("n1", "h1", 9091, "v1", 1L, 1L, 1L,
                latest, List.copyOf(history), 1L, 0L, BeliefState.UNINITIALIZED);
    }

    // --- positive slope ---
    @Test
    void positiveSlopeProjectsUpward() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 40.0), obs(100L, 20.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                100L, 0L, 200L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        assertTrue(f.hasPointEstimate());
        // slope = 20 / 100ms = 0.2 per ms; at 300 (horizon 100 from 200) = 40 + 0.2*100 = 60
        assertEquals(60.0, f.pointEstimate(), 1e-6);
    }

    // --- negative slope ---
    @Test
    void negativeSlopeProjectsDownward() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 20.0), obs(100L, 40.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                100L, 0L, 200L);
        assertEquals(0.0, PREDICTOR.forecast(req).pointEstimate(), 1e-6,
                "decreasing trend projects to 0 at +100ms from 20");
    }

    // --- flat signal ---
    @Test
    void flatSignalEqualsPersistence() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 50.0), obs(100L, 50.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                50L, 0L, 200L);
        assertEquals(50.0, PREDICTOR.forecast(req).pointEstimate(), 1e-6);
    }

    // --- irregular timestamps ---
    @Test
    void irregularTimestampsUseActualSpacing() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(400L, 30.0), obs(100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                100L, 0L, 400L);
        // slope = 20 / 300ms; at 500 (horizon 100 from 400) = 30 + (20/300)*100 ≈ 36.667
        assertEquals(36.6666667, PREDICTOR.forecast(req).pointEstimate(), 1e-4);
    }

    // --- zero horizon ---
    @Test
    void zeroHorizonEqualsFittedAtRequestTime() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 30.0), obs(100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        // At request time 200, fitted value = 30 (newest is endpoint of line)
        assertEquals(30.0, PREDICTOR.forecast(req).pointEstimate(), 1e-6);
    }

    // --- single-point fallback ---
    @Test
    void singlePointFallbackToPersistence() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(300L, 55.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                100L, 0L, 300L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        assertEquals(55.0, f.pointEstimate(), 1e-9);
    }

    // --- missing values ---
    @Test
    void missingValueSkippedRegressionUsesRest() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 30.0),
                                  obs(150L, null),
                                  obs(100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                100L, 0L, 200L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        // Should use 100 and 200 points; slope = 20/100 = 0.2; proj at 300 = 50
        assertEquals(50.0, f.pointEstimate(), 1e-6);
    }

    // --- non-finite values ---
    @Test
    void nonFiniteValueSkippedRegressionUsesRest() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, Double.NaN), obs(100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        // One valid (10) + one NaN skipped -> fallback to persistence (10 at ts=100)
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        assertEquals(10.0, f.pointEstimate(), 1e-9);
    }

    @Test
    void infinityValueSkippedRegressionUsesRest() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, Double.POSITIVE_INFINITY),
                                  obs(100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        assertEquals(10.0, PREDICTOR.forecast(req).pointEstimate(), 1e-9);
    }

    // --- duplicate timestamps ---
    @Test
    void duplicateTimestampsFallBackToPersistence() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 40.0), obs(200L, 20.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                50L, 0L, 200L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        assertEquals(40.0, f.pointEstimate(), 1e-9,
                "duplicate ts -> denominator ~ 0 -> persistence fallback (newest)");
    }

    // --- future-data exclusion ---
    @Test
    void futureObservationExcludedFromRegression() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(500L, 999.0), obs(200L, 20.0), obs(100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        // ts=500 > 200 excluded; regression on 100,200 -> slope 0.1; proj at 200 = 20
        assertEquals(20.0, PREDICTOR.forecast(req).pointEstimate(), 1e-6);
    }

    // --- stale / empty history ---
    @Test
    void staleAllOlderThanWindow() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(50L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 10L, 200L); // window = [190,200]; 50 is stale
        assertEquals(ResourceForecast.Status.STALE_OBSERVATIONS,
                PREDICTOR.forecast(req).status());
    }

    @Test
    void emptyHistoryReturnsMissingObservations() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of()),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.MISSING_OBSERVATIONS,
                PREDICTOR.forecast(req).status());
    }

    // --- unsupported ---
    @Test
    void unsupportedResourceReturnsUnsupported() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, 10.0))),
                "fake_resource",
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.UNSUPPORTED_RESOURCE,
                PREDICTOR.forecast(req).status());
    }

    // --- large timestamps ---
    @Test
    void largeEpochTimestampsNumericallyStable() {
        long big = 1_700_000_000_000L;
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(big + 100L, 30.0), obs(big, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                50L, 0L, big + 100L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        // slope = 20 / 100; proj = 30 + 0.2*50 = 40
        assertEquals(40.0, f.pointEstimate(), 1e-6);
    }

    // --- no fabricated zero for missing ---
    @Test
    void missingDataNeverFabricatesZero() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of()),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertFalse(PREDICTOR.forecast(req).hasPointEstimate());
    }

    // --- no calibration / reliability claim ---
    @Test
    void resultDoesNotClaimCalibration() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 30.0), obs(100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                100L, 0L, 200L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertTrue(f.status() == ResourceForecast.Status.OK);
        assertFalse(f.hasUncertainty(), "trend challenger does not claim predictive uncertainty");
    }

    // --- overflow / safe arithmetic ---
    @Test
    void veryLargeRequestedAtPlusHorizonSafeInDouble() {
        long big = 9_000_000_000_000_000_000L; // near Long.MAX_VALUE/2 but safe in double
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(big, 30.0), obs(big - 100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                50L, 0L, big);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        // At very large epoch values double retains integer precision but
        // sub-millisecond slope effects may round; assert safety, not exact slope.
        assertTrue(f.hasPointEstimate(), "large epoch produces safe forecast");
    }

    @Test
    void overflowTargetTimeRejectedSafely() {
        // Long.MAX_VALUE + anything overflows long; double conversion handles safely
        // But we can also test extreme where double becomes non-finite (not realistic at long range)
        // Instead: verify the safe arithmetic path exists by using a very large pair
        long nearMax = Long.MAX_VALUE - 100L;
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(nearMax, 30.0), obs(nearMax - 100L, 10.0))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, nearMax);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status(), "large valid pair should not be rejected");
    }
}
