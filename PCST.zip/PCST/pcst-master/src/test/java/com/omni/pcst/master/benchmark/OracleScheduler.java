package com.omni.pcst.master.benchmark;

import com.omni.pcst.master.scheduler.CandidateDecision;
import com.omni.pcst.master.scheduler.CandidateDisposition;
import com.omni.pcst.master.scheduler.SchedulingCandidate;
import com.omni.pcst.master.scheduler.SchedulingDecision;
import com.omni.pcst.master.scheduler.SchedulingReason;
import com.omni.pcst.master.scheduler.SchedulingStatus;
import com.omni.pcst.master.scheduler.Scheduler;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Ideal telemetry oracle scheduler (oracle arm only).
 *
 * <p>Selects the eligible node with the best true state according to the task's
 * constraints. The oracle first identifies truly feasible nodes using the
 * simulator's declared outcome function (true state must satisfy all expressed
 * constraints), then applies a deterministic selection rule among feasible
 * nodes: lowest true latency for latency-constrained tasks, lowest true packet
 * loss for packet-loss-constrained tasks, tie-broken by lowest node ID.
 *
 * <p>This scheduler inspects hidden true state and is therefore NOT a deployable
 * policy — it is reported as a separate reference arm only, never mixed with
 * scheduler inputs.
 *
 * <p>This provides an upper bound on what any scheduler could achieve with
 * perfect observability of true node state.
 */
public final class OracleScheduler implements Scheduler {

    private final Map<String, Double> trueLatencyByNode;
    private final Map<String, Double> truePacketLossByNode;

    /**
     * @param trueLatencyByNode     true latency ms per node id
     * @param truePacketLossByNode  true packet loss percent per node id
     */
    public OracleScheduler(Map<String, Double> trueLatencyByNode,
                           Map<String, Double> truePacketLossByNode) {
        this.trueLatencyByNode = trueLatencyByNode == null ? Map.of() : Map.copyOf(trueLatencyByNode);
        this.truePacketLossByNode = truePacketLossByNode == null ? Map.of() : Map.copyOf(truePacketLossByNode);
    }

    @Override
    public SchedulingDecision select(Task task, long decisionTimeMillis,
                                     Collection<SchedulingCandidate> candidates) {
        // Step 1: Filter to eligible candidates only
        List<SchedulingCandidate> eligible = new ArrayList<>(
                candidates.stream()
                        .filter(c -> c != null && c.eligible())
                        .toList());

        if (eligible.isEmpty()) {
            return new SchedulingDecision(
                    task.taskId(), decisionTimeMillis,
                    SchedulingStatus.NO_FEASIBLE_NODE, null, null, null, false,
                    List.of(),
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no candidate passed hard eligibility; feasible set F_t(tau) is empty");
        }

        // Step 2: Identify truly feasible nodes using the outcome function.
        // A node is truly feasible if its true state satisfies all expressed
        // constraints (latency <= max, packet loss <= max).
        TaskConstraints constraints = task.constraints();
        final Double maxLatency = constraints == null ? null : constraints.maximumNetworkLatencyMillis();
        final Double maxLoss = constraints == null ? null : constraints.maximumPacketLossPercent();

        List<SchedulingCandidate> feasible = new ArrayList<>();
        for (SchedulingCandidate c : eligible) {
            Double lat = trueLatencyByNode.get(c.nodeId());
            Double loss = truePacketLossByNode.get(c.nodeId());
            if (lat == null || loss == null) {
                // Missing true-state data: cannot verify feasibility; exclude.
                continue;
            }
            boolean latencyOk = maxLatency == null || lat <= maxLatency;
            boolean lossOk = maxLoss == null || loss <= maxLoss;
            if (latencyOk && lossOk) {
                feasible.add(c);
            }
        }

        if (feasible.isEmpty()) {
            // No truly feasible node exists among eligible candidates.
            return new SchedulingDecision(
                    task.taskId(), decisionTimeMillis,
                    SchedulingStatus.NO_FEASIBLE_NODE, null, null, null, false,
                    List.of(),
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no truly feasible node: true state violates all expressed constraints");
        }

        // Step 3: Select the best feasible node deterministically.
        // Primary sort: lowest normalized constraint violation score.
        // Tie-break: lowest node ID.
        SchedulingCandidate winner = feasible.stream()
                .min(Comparator
                        .comparingDouble((SchedulingCandidate c) -> {
                            double score = 0.0;
                            if (maxLatency != null) {
                                Double lat = trueLatencyByNode.get(c.nodeId());
                                score += lat / maxLatency;
                            }
                            if (maxLoss != null) {
                                Double loss = truePacketLossByNode.get(c.nodeId());
                                score += loss / maxLoss;
                            }
                            return score;
                        })
                        .thenComparing(SchedulingCandidate::nodeId))
                .orElseThrow();

        String selectedNodeId = winner.nodeId();

        List<CandidateDecision> trace = new ArrayList<>(feasible.size());
        for (SchedulingCandidate c : feasible) {
            boolean isSelected = c.nodeId().equals(selectedNodeId);
            trace.add(new CandidateDecision(
                    c.nodeId(), c.eligible(),
                    isSelected ? CandidateDisposition.SELECTED : CandidateDisposition.LOWER_RELIABILITY,
                    c.eligibility().reasons(),
                    c.reliability().status(),
                    c.reliability().reliability(),
                    c.reliability().capabilityStatus(),
                    c.capability() == null ? null : c.capability().capability(),
                    isSelected ? "selected by oracle (true state)"
                            : "eligible but not selected by oracle"
            ));
        }

        // Also trace infeasible eligible candidates as excluded
        for (SchedulingCandidate c : eligible) {
            if (!feasible.contains(c)) {
                trace.add(new CandidateDecision(
                        c.nodeId(), c.eligible(),
                        CandidateDisposition.EXCLUDED_HARD_CONSTRAINT,
                        c.eligibility().reasons(),
                        c.reliability().status(),
                        c.reliability().reliability(),
                        c.reliability().capabilityStatus(),
                        c.capability() == null ? null : c.capability().capability(),
                        "excluded by oracle: true state violates expressed constraints"
                ));
            }
        }

        List<SchedulingReason> reasons = new ArrayList<>();
        reasons.add(SchedulingReason.SELECTED_HIGHEST_RELIABILITY);
        reasons.add(SchedulingReason.NO_POLICY_THRESHOLD_CONFIGURED);

        String derivation = "selected node " + selectedNodeId
                + " via oracle (true state, reference arm only)";

        return new SchedulingDecision(
                task.taskId(), decisionTimeMillis,
                SchedulingStatus.SELECTED,
                selectedNodeId, 1.0, null, false,
                trace, reasons, derivation);
    }

    /** @return true latency map used by this oracle */
    public Map<String, Double> trueLatencyByNode() {
        return trueLatencyByNode;
    }

    /** @return true packet loss map used by this oracle */
    public Map<String, Double> truePacketLossByNode() {
        return truePacketLossByNode;
    }
}
