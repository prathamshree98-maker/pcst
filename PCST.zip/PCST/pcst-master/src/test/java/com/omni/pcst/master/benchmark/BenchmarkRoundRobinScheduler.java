package com.omni.pcst.master.benchmark;

import com.omni.pcst.master.scheduler.CandidateDecision;
import com.omni.pcst.master.scheduler.CandidateDisposition;
import com.omni.pcst.master.scheduler.SchedulingCandidate;
import com.omni.pcst.master.scheduler.SchedulingDecision;
import com.omni.pcst.master.scheduler.SchedulingReason;
import com.omni.pcst.master.scheduler.SchedulingStatus;
import com.omni.pcst.master.scheduler.Scheduler;
import com.omni.pcst.master.task.Task;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Benchmark-local Round Robin adapter that rotates across tasks while respecting
 * each task's current eligible candidates.
 *
 * <p>Unlike {@link com.omni.pcst.master.scheduler.RoundRobinScheduler} (which is
 * stateful and was not designed to handle changing eligible sets across calls),
 * this adapter:
 * <ul>
 *   <li>Maintains a rotation index across task decisions</li>
 *   <li>Only considers currently-eligible candidates for each task</li>
 *   <li>Skips nodes that were previously eligible but are no longer eligible</li>
 *   <li>Adds newly-eligible nodes to the rotation</li>
 *   <li>Resets rotation to the first eligible candidate when the eligible set
 *       becomes empty and then non-empty again</li>
 * </ul>
 *
 * <p>This is a baseline policy for comparison only. It does not use capability
 * probabilities, reliability estimates, or Bayesian beliefs. It is independent
 * of PCST reliability scoring.
 */
public final class BenchmarkRoundRobinScheduler implements Scheduler {

    // Rotation state: ordered list of eligible node IDs from the most recent
    // call where the eligible set was non-empty, plus the next index to select.
    private List<String> rotationOrder = new ArrayList<>();
    private int nextIndex = 0;

    @Override
    public SchedulingDecision select(Task task, long decisionTimeMillis,
                                     Collection<SchedulingCandidate> candidates) {
        // Filter to eligible candidates only, sorted by node ID for determinism
        List<SchedulingCandidate> eligible = new ArrayList<>(
                candidates.stream()
                        .filter(c -> c != null && c.eligible())
                        .toList());
        eligible.sort((a, b) -> a.nodeId().compareTo(b.nodeId()));

        if (eligible.isEmpty()) {
            // No eligible candidates: reset rotation, return NO_FEASIBLE_NODE
            rotationOrder = new ArrayList<>();
            nextIndex = 0;
            return new SchedulingDecision(
                    task.taskId(), decisionTimeMillis,
                    SchedulingStatus.NO_FEASIBLE_NODE, null, null, null, false,
                    List.of(),
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no candidate passed hard eligibility; feasible set F_t(tau) is empty");
        }

        // Current eligible node IDs in sorted order
        List<String> currentEligibleIds = new ArrayList<>();
        for (SchedulingCandidate c : eligible) {
            currentEligibleIds.add(c.nodeId());
        }

        // Update rotation order: preserve existing entries that are still eligible,
        // append new eligible entries at the end.
        List<String> newRotationOrder = new ArrayList<>();
        for (String id : rotationOrder) {
            if (currentEligibleIds.contains(id)) {
                newRotationOrder.add(id);
            }
        }
        for (String id : currentEligibleIds) {
            if (!newRotationOrder.contains(id)) {
                newRotationOrder.add(id);
            }
        }
        rotationOrder = newRotationOrder;

        // Clamp nextIndex to valid range
        if (nextIndex >= rotationOrder.size()) {
            nextIndex = 0;
        }

        // Select the node at the current rotation index
        String selectedNodeId = rotationOrder.get(nextIndex);
        nextIndex = (nextIndex + 1) % rotationOrder.size();

        // Map selected node id back to its candidate
        SchedulingCandidate winner = null;
        for (SchedulingCandidate c : eligible) {
            if (c.nodeId().equals(selectedNodeId)) {
                winner = c;
                break;
            }
        }

        // Build candidate trace
        List<CandidateDecision> trace = new ArrayList<>(eligible.size());
        for (SchedulingCandidate c : eligible) {
            boolean isSelected = c.nodeId().equals(selectedNodeId);
            trace.add(new CandidateDecision(
                    c.nodeId(), c.eligible(),
                    isSelected ? CandidateDisposition.SELECTED : CandidateDisposition.LOWER_RELIABILITY,
                    c.eligibility().reasons(),
                    c.reliability().status(),
                    c.reliability().reliability(),
                    c.reliability().capabilityStatus(),
                    c.capability() == null ? null : c.capability().capability(),
                    isSelected ? "selected by round-robin rotation"
                            : "eligible but not selected by round-robin rotation"
            ));
        }

        List<SchedulingReason> reasons = new ArrayList<>();
        reasons.add(SchedulingReason.SELECTED_HIGHEST_RELIABILITY);
        reasons.add(SchedulingReason.NO_POLICY_THRESHOLD_CONFIGURED);

        String derivation = "selected node " + selectedNodeId
                + " via round-robin rotation across tasks (policy does not rank by reliability)";

        return new SchedulingDecision(
                task.taskId(), decisionTimeMillis,
                SchedulingStatus.SELECTED,
                selectedNodeId, null, null, false,
                trace, reasons, derivation);
    }
}
