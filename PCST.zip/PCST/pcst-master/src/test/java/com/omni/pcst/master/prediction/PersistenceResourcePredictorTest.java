package com.omni.pcst.master.prediction;

import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic tests for the persistence prediction baseline (Step 5C).
 *
 * <p>Every test uses hand-built immutable snapshots; no gRPC, no hardware,
 * no probability sampling. Uncertainty assertions verify only that a value
 * is present/absent; they never claim calibration or predictive validity.
 */
class PersistenceResourcePredictorTest {

    private static final PersistenceResourcePredictor PREDICTOR =
            new PersistenceResourcePredictor();

    // -- helpers --------------------------------------------------------------

    private static TelemetryObservation obs(long ts, Double cpu,
                                            Long totalMem, Long usedMem,
                                            Double battery, Double latency,
                                            Double packetLoss) {
        return new TelemetryObservation(
                ts, cpu, totalMem, usedMem, null,
                null, null, battery, null, null,
                latency, packetLoss, null, null, null, null);
    }

    private static DigitalTwinSnapshot snapshot(List<TelemetryObservation> history) {
        TelemetryObservation latest = history.isEmpty() ? null : history.get(0);
        return new DigitalTwinSnapshot(
                "n1", "h1", 9091, "v1",
                1L, 1L, 1L,
                latest,
                List.copyOf(history),
                1L, 0L,
                BeliefState.UNINITIALIZED);
    }

    // -- 1. CPU forecast ------------------------------------------------------

    @Test
    void cpuForecastFromValidLatestObservation() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(300L, 42.0, 1024L, 512L, 60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 300L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status(), "valid observation -> OK");
        assertTrue(f.hasPointEstimate(), "must carry the observed value");
        assertEquals(42.0, f.pointEstimate(), 1e-9);
        assertEquals(300L, f.observationTimestamp());
        assertEquals(1, f.observationCount());
        assertFalse(f.hasUncertainty(), "single observation -> no dispersion claim");
    }

    // -- 2. Battery, latency, packet loss ------------------------------------

    @Test
    void batteryForecastFromValidObservation() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 10.0, 1024L, 512L, 77.5, 5.0, 0.1))),
                ForecastableResource.BATTERY_LEVEL_PERCENT.identifier(),
                0L, 0L, 200L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        assertEquals(77.5, f.pointEstimate(), 1e-9);
    }

    @Test
    void latencyForecastFromValidObservation() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 10.0, 1024L, 512L, 60.0, 25.0, 0.2))),
                ForecastableResource.NETWORK_LATENCY_MS.identifier(),
                0L, 0L, 200L);
        assertEquals(25.0, PREDICTOR.forecast(req).pointEstimate(), 1e-9);
    }

    @Test
    void packetLossForecastFromValidObservation() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 10.0, 1024L, 512L, 60.0, 10.0, 2.5))),
                ForecastableResource.NETWORK_PACKET_LOSS_PERCENT.identifier(),
                0L, 0L, 200L);
        assertEquals(2.5, PREDICTOR.forecast(req).pointEstimate(), 1e-9);
    }

    // -- 3. Memory derivation & invalid inputs -------------------------------

    @Test
    void memoryUtilizationDerivedCorrectly() {
        // 6144 / 8192 = 0.75 -> 75%
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, null, 8192L, 6144L, null, null, null))),
                ForecastableResource.MEMORY_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertEquals(75.0, PREDICTOR.forecast(req).pointEstimate(), 1e-9);
    }

    @Test
    void memoryUtilizationMissingTotalBytesCarriesNoInformation() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, null, null, 6144L, null, null, null))),
                ForecastableResource.MEMORY_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.MISSING_MEASUREMENT,
                PREDICTOR.forecast(req).status());
    }

    @Test
    void memoryUtilizationZeroTotalIsNotDerivable() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, null, 0L, 0L, null, null, null))),
                ForecastableResource.MEMORY_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.MISSING_MEASUREMENT,
                PREDICTOR.forecast(req).status());
    }

    @Test
    void memoryUtilizationNegativeTotalIsNotDerivable() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, null, -100L, 50L, null, null, null))),
                ForecastableResource.MEMORY_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.MISSING_MEASUREMENT,
                PREDICTOR.forecast(req).status());
    }

    // -- 4. Missing resource values / empty history ---------------------------

    @Test
    void missingResourceValueInObservationYieldsMissingMeasurement() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, null, 1024L, 512L, null, null, null))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.MISSING_MEASUREMENT,
                PREDICTOR.forecast(req).status());
    }

    @Test
    void emptyHistoryYieldsMissingObservations() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of()),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.MISSING_OBSERVATIONS,
                PREDICTOR.forecast(req).status());
    }

    // -- 5. Unsupported identifier / invalid windows ------------------------

    @Test
    void unsupportedResourceIdentifierReturnsUnsupported() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, 10.0, 1024L, 512L, 60.0, 5.0, 0.1))),
                "unsupported_resource",
                0L, 0L, 100L);
        assertEquals(ResourceForecast.Status.UNSUPPORTED_RESOURCE,
                PREDICTOR.forecast(req).status());
    }

    @Test
    void invalidNegativeHorizonThrows() {
        assertThrows(IllegalArgumentException.class, () ->
                new ForecastRequest(
                        snapshot(List.of()),
                        ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                        -1L, 0L, 100L));
    }

    @Test
    void invalidNegativeWindowThrows() {
        assertThrows(IllegalArgumentException.class, () ->
                new ForecastRequest(
                        snapshot(List.of()),
                        ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                        0L, -10L, 100L));
    }

    // -- 6. Observation-window filtering & stale observations --------------

    @Test
    void observationWindowFiltersOlderObservations() {
        // History: ts=300 (cpu=30), ts=200 (cpu=20), ts=100 (cpu=10)
        // Request at 250 with window 150 -> only ts=200 qualifies (ts=100 is < 100? wait)
        // Actually windowStart = 250 - 150 = 100. So ts=200 and ts=100 are in.
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(300L, 30.0, 1024L, 512L, 60.0, 10.0, 0.5),
                                  obs(200L, 20.0, 1024L, 512L, 60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 150L, 250L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertEquals(ResourceForecast.Status.OK, f.status());
        assertEquals(20.0, f.pointEstimate(), 1e-9, "newest in-window is ts=200");
    }

    @Test
    void staleObservationsAllOlderThanWindow() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, 10.0, 1024L, 512L, 60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 10L, 200L); // window [190,200]; obs at 100 is stale
        assertEquals(ResourceForecast.Status.STALE_OBSERVATIONS,
                PREDICTOR.forecast(req).status());
    }

    // -- 7. Newest-first selection -------------------------------------------

    @Test
    void newestFirstHistorySelectsNewestValidObservation() {
        // History newest-first: ts=200 first, ts=100 second
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 55.0, 1024L, 512L, 60.0, 10.0, 0.5),
                                  obs(100L, 15.0, 1024L, 512L, 60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        assertEquals(55.0, PREDICTOR.forecast(req).pointEstimate(), 1e-9);
    }

    @Test
    void newestFirstSkipsNullThenTakesNextValid() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, null, 1024L, 512L, 60.0, 10.0, 0.5),
                                  obs(100L, 25.0, 1024L, 512L, 60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        // Newest (ts=200) is null -> skip -> ts=100 valid = 25
        assertEquals(25.0, PREDICTOR.forecast(req).pointEstimate(), 1e-9);
    }

    // -- 8. Non-finite values ------------------------------------------------

    @Test
    void nonFiniteCpuValueTreatedAsMissingNotAsZero() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, Double.NaN, 1024L, 512L, 60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        assertEquals(ResourceForecast.Status.NON_FINITE_MEASUREMENT,
                PREDICTOR.forecast(req).status());
    }

    @Test
    void positiveInfinityTreatedAsNonFinite() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, Double.POSITIVE_INFINITY, 1024L, 512L,
                        60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        assertEquals(ResourceForecast.Status.NON_FINITE_MEASUREMENT,
                PREDICTOR.forecast(req).status());
    }

    // -- 9. Explicit uncertainty / status without fabricated zeros -----------

    @Test
    void singleObservationProducesNoUncertaintyClaim() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(100L, 50.0, 1024L, 512L, 60.0, 5.0, 0.1))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertTrue(f.hasPointEstimate());
        assertFalse(f.hasUncertainty(), "one observation must not claim dispersion");
    }

    @Test
    void twoObservationsProduceUncertaintyValue() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of(obs(200L, 60.0, 1024L, 512L, 60.0, 10.0, 0.5),
                                  obs(100L, 40.0, 1024L, 512L, 60.0, 10.0, 0.5))),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 200L);
        ResourceForecast f = PREDICTOR.forecast(req);
        assertTrue(f.hasPointEstimate());
        assertTrue(f.hasUncertainty(), "two observations allow spread diagnostic");
        assertEquals(10.0, f.uncertainty(), 1e-9, "half-range of [40,60] = 10");
    }

    @Test
    void resultDoesNotFabricateZeroForMissingData() {
        ForecastRequest req = new ForecastRequest(
                snapshot(List.of()),
                ForecastableResource.CPU_UTILIZATION_PERCENT.identifier(),
                0L, 0L, 100L);
        assertFalse(PREDICTOR.forecast(req).hasPointEstimate(),
                "missing observations must not become a fabricated zero");
    }
}
