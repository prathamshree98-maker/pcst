package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.capability.CapabilityStatus;
import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityEngine;
import com.omni.pcst.master.reliability.ReliabilityInput;
import com.omni.pcst.master.reliability.ReliabilityStatus;
import com.omni.pcst.master.task.HardConstraintConfig;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Benchmark Stage 1 correctness tests for the PCST production implementation.
 *
 * <p>These tests exercise the real {@link PCSTScheduler}, {@link CapabilityEngine},
 * {@link ReliabilityEngine}, and {@link HardConstraintFilter} through their public
 * APIs. No production code is modified and no production algorithm is reimplemented
 * in test helpers. Expected probabilities are computed independently using the
 * documented normal-CDF formula {@code C = Phi((r - mu) / sigma)}.
 *
 * <p>Tests A, D, E, and F from the benchmark plan already exist in
 * {@link PCSTSchedulerTest} (ranking, threshold, tie-breaking, hard-constraint
 * override). This file adds the missing correctness cases (stale evidence,
 * missing evidence) and a Stage 2 end-to-end smoke test through
 * {@link PCSTScheduler#schedule}.
 */
class PCSTBenchmarkCorrectnessTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final long HORIZON = 60_000L;
    private static final double PHI_2 = 0.9772498680518208;
    private static final String LATENCY = BayesianBeliefEngine.NETWORK_LATENCY_MS;

    private final CapabilityEngine capabilityEngine = new CapabilityEngine();
    private final ReliabilityEngine reliabilityEngine = new ReliabilityEngine();
    private final PCSTScheduler scheduler = new PCSTScheduler(SchedulingPolicyConfig.none());

    private static ResourceBelief belief(String key, double mean, double variance) {
        return new ResourceBelief(key, mean, variance, 5L, T0);
    }

    private static Map<String, ResourceBelief> beliefs(ResourceBelief... entries) {
        Map<String, ResourceBelief> map = new LinkedHashMap<>();
        for (ResourceBelief entry : entries) {
            map.put(entry.resourceName(), entry);
        }
        return map;
    }

    /**
     * Builds a deterministic snapshot. {@code latestObservation} may be {@code null};
     * that is fine for tests that call {@link PCSTScheduler#select} directly, but
     * tests that call {@link PCSTScheduler#schedule} must supply a real observation
     * so the internal {@link HardConstraintFilter} can evaluate freshness.
     */
    private static DigitalTwinSnapshot snapshot(String nodeId, long receivedAt,
                                                Map<String, ResourceBelief> beliefs,
                                                TelemetryObservation latestObservation) {
        BeliefState state = beliefs.isEmpty()
                ? BeliefState.UNINITIALIZED
                : BeliefState.of(beliefs, 1L, receivedAt, receivedAt);
        return new DigitalTwinSnapshot(nodeId, "host-" + nodeId, 9091, "0.1.0",
                T0, T0, T0, latestObservation, List.of(), receivedAt, 0L, state);
    }

    private static DigitalTwinSnapshot snapshot(String nodeId, long receivedAt,
                                                Map<String, ResourceBelief> beliefs) {
        return snapshot(nodeId, receivedAt, beliefs, null);
    }

    private static TelemetryObservation observation(long timestamp, Double latencyMs) {
        return new TelemetryObservation(
                timestamp, null, null, null, null,
                null, null, null, null, null,
                latencyMs, null, null, null, null, null);
    }

    private static Task latencyTask(double maxLatency) {
        return Task.builder("task-lat")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, null, null, null))
                .build();
    }

    private SchedulingCandidate candidate(Task task, DigitalTwinSnapshot node,
                                          NodeEligibilityResult eligibility) {
        CapabilityAssessment cap = capabilityEngine.assess(task, node, T0);
        ReliabilityAssessment rel = reliabilityEngine.assess(
                new ReliabilityInput(task, node, eligibility, cap));
        return new SchedulingCandidate(eligibility, cap, rel);
    }

    private NodeEligibilityResult eligible(Task task, String nodeId) {
        return new NodeEligibilityResult(task.taskId(), nodeId, true, false, List.of(),
                List.of(), T0);
    }

    // --------------------------------------------------------------- Test B: stale evidence

    /**
     * Stale evidence (older than maxEvidenceAgeMillis) must make the capability
     * assessment stale, which makes reliability unresolved, which leads PCST to
     * NO_SELECTION_UNRESOLVED when no fallback is configured.
     */
    @Test
    void staleEvidenceMakesReliabilityUnresolvedAndNoSelection() {
        Task task = latencyTask(100.0);
        // 16 seconds ago: older than DEFAULT_MAX_EVIDENCE_AGE_MILLIS (15s)
        long staleReceivedAt = T0 - (HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS + 1000L);
        DigitalTwinSnapshot node = snapshot("node-a", staleReceivedAt,
                beliefs(belief(LATENCY, 80.0, 100.0)));

        SchedulingCandidate cand = candidate(task, node, eligible(task, "node-a"));

        assertEquals(CapabilityStatus.INSUFFICIENT_EVIDENCE, cand.capability().status());
        assertNull(cand.capability().capability(), "stale evidence must not yield a number");
        assertEquals(ReliabilityStatus.INSUFFICIENT_EVIDENCE, cand.reliability().status());
        assertNull(cand.reliability().reliability());

        SchedulingDecision decision = scheduler.select(task, T0, List.of(cand));
        assertEquals(SchedulingStatus.NO_SELECTION_UNRESOLVED, decision.status());
        assertNull(decision.selectedNodeId());
        assertNull(decision.selectedReliability());
        assertFalse(decision.policyFallback());
        assertTrue(decision.reasons().contains(
                SchedulingReason.NO_ELIGIBLE_CANDIDATE_HAS_A_RELIABILITY_ESTIMATE));
    }

    // ----------------------------------------------------------- Test C: missing evidence

    /**
     * Missing evidence (no belief at all for the required resource) must not be
     * silently replaced with a fabricated value. The capability must be
     * INSUFFICIENT_EVIDENCE, reliability unresolved, and PCST must not select.
     */
    @Test
    void missingEvidenceProducesNoFabricatedValueAndNoSelection() {
        Task task = latencyTask(100.0);
        // UNINITIALIZED belief state: no resource beliefs whatsoever.
        DigitalTwinSnapshot node = snapshot("node-a", T0, Map.of());

        SchedulingCandidate cand = candidate(task, node, eligible(task, "node-a"));

        assertEquals(CapabilityStatus.INSUFFICIENT_EVIDENCE, cand.capability().status());
        assertNull(cand.capability().capability());
        assertEquals(ReliabilityStatus.INSUFFICIENT_EVIDENCE, cand.reliability().status());
        assertNull(cand.reliability().reliability());

        SchedulingDecision decision = scheduler.select(task, T0, List.of(cand));
        assertEquals(SchedulingStatus.NO_SELECTION_UNRESOLVED, decision.status());
        assertNull(decision.selectedNodeId());
        assertNull(decision.selectedReliability());
    }

    // ------------------------------------------------------ Stage 2: smoke test via schedule()

    /**
     * End-to-end smoke test through {@link PCSTScheduler#schedule}, which composes
     * HardConstraintFilter -> CapabilityEngine -> ReliabilityEngine -> select.
     *
     * <p>Each snapshot supplies a real {@link TelemetryObservation} with
     * {@code latencyMs} below the task maximum (100 ms), so the internal hard
     * constraint filter marks both nodes eligible.
     *
     * <p>Node-a: latency N(90, 100) -> C = Phi((100-90)/10) = Phi(1) ~= 0.8413
     * Node-b: latency N(80, 100) -> C = Phi((100-80)/10) = Phi(2) ~= 0.9772
     *
     * <p>Node-b has strictly higher reliability and should be selected.
     */
    @Test
    void scheduleSelectsHigherReliabilityNodeEndToEnd() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot nodeA = snapshot("node-a", T0,
                beliefs(belief(LATENCY, 90.0, 100.0)),
                observation(T0, 90.0));
        DigitalTwinSnapshot nodeB = snapshot("node-b", T0,
                beliefs(belief(LATENCY, 80.0, 100.0)),
                observation(T0, 80.0));

        SchedulingDecision decision = scheduler.schedule(task, T0, List.of(nodeA, nodeB));

        assertNotNull(decision);
        assertEquals(SchedulingStatus.SELECTED, decision.status());
        assertEquals("node-b", decision.selectedNodeId());
        assertEquals(PHI_2, decision.selectedReliability(), 1e-6);
        assertNull(decision.policyThreshold());
        assertFalse(decision.policyFallback());
        assertTrue(decision.reasons().contains(SchedulingReason.SELECTED_HIGHEST_RELIABILITY));
        assertEquals(2, decision.candidates().size());
        assertNotNull(decision.selectedCandidate());
        assertEquals("node-b", decision.selectedCandidate().nodeId());
    }
}
