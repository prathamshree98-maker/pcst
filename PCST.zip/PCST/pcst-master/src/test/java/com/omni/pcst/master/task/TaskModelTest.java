package com.omni.pcst.master.task;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the immutable task model and its validation contract.
 */
class TaskModelTest {

    private static final long ONE_MIB = 1024L * 1024L;
    private static final long ONE_GIB = 1024L * 1024L * 1024L;

    @Test
    void validMinimalTask() {
        Task task = Task.minimal("task-1", "docker://image");

        assertEquals("task-1", task.taskId());
        assertEquals(TaskClass.UNSPECIFIED, task.taskClass());
        assertEquals("docker://image", task.workloadReference());
        assertEquals("", task.inputCharacteristics());
        assertNull(task.expectedDurationMillis());
        assertEquals(TaskResources.NONE, task.resources());
        assertEquals(TaskConstraints.NONE, task.constraints());
        assertTrue(task.resources().isEmpty());
        assertFalse(task.hasExpectedDuration());
        assertTrue(task.hasWorkloadReference());
    }

    @Test
    void validTaskWithAllSupportedRequirements() {
        Task task = Task.builder("task-2")
                .taskClass(TaskClass.ACCELERATOR_BOUND)
                .workloadReference("registry/training:latest")
                .inputCharacteristics("float32 tensor batch=64")
                .expectedDurationMillis(60_000L)
                .resources(new TaskResources(
                        2 * ONE_GIB,
                        10 * ONE_GIB,
                        true,
                        4 * ONE_GIB,
                        12.5))
                .constraints(new TaskConstraints(
                        1_700_000_000_000L,
                        60_000L,
                        20.0,
                        25.0,
                        0.5,
                        InterruptionTolerance.NON_PREEMPTIBLE,
                        "gpu-any"))
                .build();

        assertEquals("task-2", task.taskId());
        assertEquals(TaskClass.ACCELERATOR_BOUND, task.taskClass());
        assertEquals(2 * ONE_GIB, task.resources().requiredMemoryBytes());
        assertEquals(10 * ONE_GIB, task.resources().requiredStorageBytes());
        assertTrue(task.resources().acceleratorRequired());
        assertEquals(4 * ONE_GIB, task.resources().requiredAcceleratorMemoryBytes());
        assertEquals(12.5, task.resources().requiredComputeUnits());
        assertEquals(1_700_000_000_000L, task.constraints().deadlineEpochMillis());
        assertEquals(20.0, task.constraints().minimumBatteryPercent());
        assertEquals(25.0, task.constraints().maximumNetworkLatencyMillis());
        assertEquals(0.5, task.constraints().maximumPacketLossPercent());
        assertEquals(InterruptionTolerance.NON_PREEMPTIBLE, task.constraints().interruptionTolerance());
        assertEquals("gpu-any", task.constraints().requiredExecutionProfile());
        assertTrue(task.hasExpectedDuration());
        assertTrue(task.constraints().hasDeadline());
        assertTrue(task.constraints().hasDuration());
        assertFalse(task.resources().isEmpty());
    }

    @Test
    void nullTaskIdRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> Task.minimal(null, "ref"));
        assertTrue(ex.fields().contains("taskId"));
    }

    @Test
    void blankTaskIdRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> Task.minimal("   ", "ref"));
        assertTrue(ex.fields().contains("taskId"));
        assertTrue(ex.getMessage().contains("taskId"));
    }

    @Test
    void negativeMemoryRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> Task.builder("t").workloadReference("ref")
                        .resources(new TaskResources(-1L, null, false, null, null)).build());
        assertTrue(ex.fields().contains("requiredMemoryBytes"));
    }

    @Test
    void negativeStorageRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskResources(null, -5L, false, null, null));
        assertTrue(ex.fields().contains("requiredStorageBytes"));
    }

    @Test
    void negativeAcceleratorMemoryRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskResources(null, null, true, -100L, null));
        assertTrue(ex.fields().contains("requiredAcceleratorMemoryBytes"));
    }

    @Test
    void negativeComputeUnitsRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskResources(null, null, false, null, -0.1));
        assertTrue(ex.fields().contains("requiredComputeUnits"));
    }

    @Test
    void nonFiniteComputeUnitsRejected() {
        assertThrows(TaskValidationException.class,
                () -> new TaskResources(null, null, false, null, Double.NaN));
        assertThrows(TaskValidationException.class,
                () -> new TaskResources(null, null, false, null, Double.POSITIVE_INFINITY));
    }

    @Test
    void negativeExpectedDurationRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> Task.builder("t").workloadReference("ref")
                        .constraints(new TaskConstraints(null, -1L, null, null, null, null, null)).build());
        assertTrue(ex.fields().contains("expectedDurationMillis"));
    }

    @Test
    void negativeDeadlineRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskConstraints(-1L, null, null, null, null, null, null));
        assertTrue(ex.fields().contains("deadlineEpochMillis"));
    }

    @Test
    void batteryPercentAbove100Rejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskConstraints(null, null, 100.1, null, null, null, null));
        assertTrue(ex.fields().contains("minimumBatteryPercent"));
    }

    @Test
    void negativeBatteryPercentRejected() {
        assertThrows(TaskValidationException.class,
                () -> new TaskConstraints(null, null, -1.0, null, null, null, null));
    }

    @Test
    void negativeLatencyRejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskConstraints(null, null, null, -0.5, null, null, null));
        assertTrue(ex.fields().contains("maximumNetworkLatencyMillis"));
    }

    @Test
    void packetLossAbove100Rejected() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskConstraints(null, null, null, null, 150.0, null, null));
        assertTrue(ex.fields().contains("maximumPacketLossPercent"));
    }

    @Test
    void nullResourcesRejected() {
        assertThrows(TaskValidationException.class,
                () -> new Task("t", TaskClass.UNSPECIFIED, "ref", null, null, null, TaskConstraints.NONE));
    }

    @Test
    void nullConstraintsRejected() {
        assertThrows(TaskValidationException.class,
                () -> new Task("t", TaskClass.UNSPECIFIED, "ref", null, null, TaskResources.NONE, null));
    }

    @Test
    void multipleTaskLevelViolationsReportedTogether() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new Task(null, null, "ref", null, null,
                        TaskResources.NONE, TaskConstraints.NONE));
        List<String> fields = ex.fields();
        assertTrue(fields.contains("taskId"));
        assertTrue(fields.contains("taskClass"));
        assertEquals(2, fields.size());
    }

    @Test
    void nestedConstraintViolationsIdentifyTheirField() {
        TaskValidationException ex = assertThrows(TaskValidationException.class,
                () -> new TaskConstraints(null, null, 200.0, null, null, null, null));
        assertTrue(ex.fields().contains("minimumBatteryPercent"));
    }

    @Test
    void absentRequirementVersusExplicitZeroPreserved() {
        TaskResources absent = TaskResources.NONE;
        TaskResources explicitZero = new TaskResources(0L, 0L, false, 0L, 0.0);

        assertNull(absent.requiredMemoryBytes());
        assertEquals(0L, explicitZero.requiredMemoryBytes());
        assertTrue(absent.isEmpty());
        assertFalse(explicitZero.isEmpty());
    }

    @Test
    void zeroLatencyIsARealRequirementNotAbsent() {
        Task task = Task.builder("t").workloadReference("ref")
                .constraints(new TaskConstraints(null, null, null, 0.0, null, null, null))
                .build();

        assertEquals(0.0, task.constraints().maximumNetworkLatencyMillis());
    }

    @Test
    void deadlineInfeasibleFromDurationIsDetectedByConstraintsValidation() {
        TaskConstraints constraints = new TaskConstraints(
                1000L, 2000L, null, null, null, null, null);

        List<ValidationViolation> violations = constraints.validateAgainstDecisionTime(500L);
        assertFalse(violations.isEmpty());
        assertEquals("constraints.deadlineEpochMillis", violations.get(0).field());
    }

    @Test
    void deadlineFeasibleFromDurationPasses() {
        TaskConstraints constraints = new TaskConstraints(
                10_000L, 2_000L, null, null, null, null, null);

        assertTrue(constraints.validateAgainstDecisionTime(5_000L).isEmpty());
    }

    @Test
    void deadlineWithoutDurationYieldsNoViolation() {
        TaskConstraints constraints = new TaskConstraints(
                1000L, null, null, null, null, null, null);

        assertTrue(constraints.validateAgainstDecisionTime(500L).isEmpty());
    }

    @Test
    void explicitZeroDeadlineMinusZeroDurationIsFeasibleAtDecisionTime() {
        TaskConstraints constraints = new TaskConstraints(
                1000L, 0L, null, null, null, null, null);

        assertTrue(constraints.validateAgainstDecisionTime(1000L).isEmpty());
        assertFalse(constraints.validateAgainstDecisionTime(1001L).isEmpty());
    }

    @Test
    void taskExhibitsValueSemanticsAndNoMutatorSurface() {
        Task a = Task.builder("t").workloadReference("ref").resources(TaskResources.requiringMemory(ONE_MIB)).build();
        Task b = Task.builder("t").workloadReference("ref").resources(TaskResources.requiringMemory(ONE_MIB)).build();
        Task c = Task.builder("t").workloadReference("ref").resources(TaskResources.requiringMemory(2 * ONE_MIB)).build();

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertEquals(ONE_MIB, a.resources().requiredMemoryBytes());
    }

    @Test
    void convenienceFactoriesProduceExpectedShapes() {
        TaskResources memory = TaskResources.requiringMemory(ONE_GIB);
        assertEquals(ONE_GIB, memory.requiredMemoryBytes());
        assertNull(memory.requiredStorageBytes());
        assertFalse(memory.acceleratorRequired());

        TaskResources accel = TaskResources.requiringAccelerator(2 * ONE_GIB);
        assertTrue(accel.acceleratorRequired());
        assertEquals(2 * ONE_GIB, accel.requiredAcceleratorMemoryBytes());
    }

    @Test
    void nullToleranceIsDistinguishableFromExplicitChoice() {
        Task noChoice = Task.minimal("t", "ref");
        assertNull(noChoice.constraints().interruptionTolerance());

        Task choice = Task.builder("t").workloadReference("ref")
                .constraints(new TaskConstraints(null, null, null, null, null,
                        InterruptionTolerance.PREEMPTIBLE, null))
                .build();
        assertEquals(InterruptionTolerance.PREEMPTIBLE, choice.constraints().interruptionTolerance());
    }

    @Test
    void blankExecutionProfileIsTreatedAsAbsent() {
        Task task = Task.builder("t").workloadReference("ref")
                .constraints(new TaskConstraints(null, null, null, null, null, null, "  "))
                .build();
        assertEquals("  ", task.constraints().requiredExecutionProfile(),
                "a blank profile is preserved verbatim; the filter decides its meaning");
    }
}