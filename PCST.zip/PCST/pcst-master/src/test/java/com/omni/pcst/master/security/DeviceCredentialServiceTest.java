package com.omni.pcst.master.security;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for DeviceCredentialService: issuance, validation, identity
 * binding, revocation, and persistent storage across restart.
 */
class DeviceCredentialServiceTest {

    @Test
    void testIssueReturnsToken() {
        DeviceCredentialService service = new DeviceCredentialService(false, null);
        String token = service.issue("node-1");
        assertNotNull(token);
        assertFalse(token.isBlank());
    }

    @Test
    void testValidateCorrectNode() {
        DeviceCredentialService service = new DeviceCredentialService(false, null);
        String token = service.issue("node-1");
        assertTrue(service.validate(token, "node-1"));
    }

    @Test
    void testValidateWrongNodeRejected() {
        DeviceCredentialService service = new DeviceCredentialService(false, null);
        String token = service.issue("node-1");
        assertFalse(service.validate(token, "node-2"),
                "credential bound to node-1 must not validate for node-2 (impersonation)");
    }

    @Test
    void testValidateUnknownTokenRejected() {
        DeviceCredentialService service = new DeviceCredentialService(false, null);
        assertFalse(service.validate("unknown-token", "node-1"));
        assertFalse(service.validate("", "node-1"));
        assertFalse(service.validate(null, "node-1"));
    }

    @Test
    void testRevokedCredentialRejected() {
        DeviceCredentialService service = new DeviceCredentialService(false, null);
        String token = service.issue("node-1");
        assertTrue(service.validate(token, "node-1"));

        service.revoke(token);
        assertFalse(service.validate(token, "node-1"),
                "revoked credential must be rejected");
    }

    @Test
    void testRevokeByNodeId() {
        DeviceCredentialService service = new DeviceCredentialService(false, null);
        service.issue("node-1");
        assertTrue(service.validate(service.tokenForNodeId("node-1").orElseThrow(), "node-1"));

        service.revokeByNodeId("node-1");
        assertFalse(service.validate(service.tokenForNodeId("node-1").orElse(null), "node-1"));
    }

    @Test
    void testTokenForNodeIdAbsentWhenNone() {
        DeviceCredentialService service = new DeviceCredentialService(false, null);
        assertFalse(service.tokenForNodeId("nonexistent").isPresent());
    }

    // ------------------------------------------------------------------ persistence

    @Test
    void testCredentialPersistedAcrossRestart(@TempDir Path dir) throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");

        // First "Master instance": issue a credential and persist
        DeviceCredentialService service1 = new DeviceCredentialService(true, store);
        String token = service1.issue("node-1");
        assertTrue(service1.validate(token, "node-1"));

        // Second "Master instance" after restart: loads from same store
        DeviceCredentialService service2 = new DeviceCredentialService(true, store);
        assertTrue(service2.validate(token, "node-1"),
                "credential issued before restart must still validate after restart");
        assertEquals(token, service2.tokenForNodeId("node-1").orElseThrow(),
                "token binding must survive restart");
    }

    @Test
    void testRevokedCredentialStaysRevokedAfterRestart(@TempDir Path dir) throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");

        DeviceCredentialService service1 = new DeviceCredentialService(true, store);
        String token = service1.issue("node-1");
        service1.revoke(token);
        assertFalse(service1.validate(token, "node-1"));

        // After restart, revoked credential must still be rejected
        DeviceCredentialService service2 = new DeviceCredentialService(true, store);
        assertFalse(service2.validate(token, "node-1"),
                "revoked credential must remain revoked after restart");
    }

    @Test
    void testInvalidCredentialRejectedAfterRestart(@TempDir Path dir) throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");

        DeviceCredentialService service1 = new DeviceCredentialService(true, store);
        service1.issue("node-1");

        DeviceCredentialService service2 = new DeviceCredentialService(true, store);
        assertFalse(service2.validate("totally-fake-token", "node-1"),
                "unknown credential must be rejected after restart");
    }

    @Test
    void testImpersonationRejectedAfterRestart(@TempDir Path dir) throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");

        DeviceCredentialService service1 = new DeviceCredentialService(true, store);
        String token = service1.issue("node-a");

        DeviceCredentialService service2 = new DeviceCredentialService(true, store);
        assertFalse(service2.validate(token, "node-b"),
                "credential bound to node-a must not validate for node-b after restart");
    }

    @Test
    void testNewCredentialAfterRestart(@TempDir Path dir) throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");

        DeviceCredentialService service1 = new DeviceCredentialService(true, store);
        service1.issue("node-1");

        DeviceCredentialService service2 = new DeviceCredentialService(true, store);
        String newToken = service2.issue("node-2");
        assertTrue(service2.validate(newToken, "node-2"),
                "new credential issued after restart must validate");
        assertFalse(service2.validate(newToken, "node-1"),
                "new credential must not validate for a different node");
    }

    // ------------------------------------------------------------------ write-failure (fail-closed)

    @Test
    void testIssueWriteFailureFailsClosed(@TempDir Path dir) throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");
        DeviceCredentialService service = new DeviceCredentialService(true, store);

        // Save once successfully so the file exists, then make it read-only
        // so subsequent writes fail.
        store.save(StateSnapshot.empty());
        stateFile.toFile().setReadOnly();

        // Issue should fail closed: throw and not add the credential to memory.
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> service.issue("node-1"));
        assertTrue(ex.getMessage().contains("persist"),
                "Expected persist failure message, got: " + ex.getMessage());
        assertFalse(service.validate(service.tokenForNodeId("node-1").orElse(null), "node-1"),
                "Credential must not be in memory when persistence failed");
    }

    @Test
    void testRevokeWriteFailureFailsClosed(@TempDir Path dir) throws Exception {
        Path stateFile = dir.resolve("state.json");
        FileStateStore store = new FileStateStore(stateFile, "test-passphrase-12345");
        DeviceCredentialService service = new DeviceCredentialService(true, store);

        String token = service.issue("node-1");
        assertTrue(service.validate(token, "node-1"));

        // Make the state file read-only so the revocation persist fails.
        store.save(StateSnapshot.empty()); // re-save to ensure file exists
        stateFile.toFile().setReadOnly();

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> service.revoke(token));
        assertTrue(ex.getMessage().contains("revocation"),
                "Expected revocation failure message, got: " + ex.getMessage());
        assertTrue(service.validate(token, "node-1"),
                "Credential must still be valid when revocation persistence failed");
    }
}
