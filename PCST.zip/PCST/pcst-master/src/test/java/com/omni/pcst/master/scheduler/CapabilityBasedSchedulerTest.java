package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityCombiner;
import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.capability.CapabilityReason;
import com.omni.pcst.master.capability.CapabilityStatus;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityEngine;
import com.omni.pcst.master.reliability.ReliabilityEvent;
import com.omni.pcst.master.reliability.ReliabilityInput;
import com.omni.pcst.master.reliability.ReliabilityReason;
import com.omni.pcst.master.reliability.ReliabilityStatus;
import com.omni.pcst.master.task.HardConstraintConfig;
import com.omni.pcst.master.task.HardConstraintFilter;
import com.omni.pcst.master.task.InterruptionTolerance;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.RejectionReason;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static com.omni.pcst.master.scheduler.SchedulingReason.SELECTED_HIGHEST_RELIABILITY;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

class CapabilityBasedSchedulerTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final long HORIZON = 60_000L;
    private static final long MAX_AGE = HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS;
    private static final double PHI_2 = 0.9772498680518208;
    private static final String LATENCY = BayesianBeliefEngine.NETWORK_LATENCY_MS;

    private final CapabilityBasedScheduler scheduler = new CapabilityBasedScheduler();
    private final CapabilityEngine capabilityEngine = new CapabilityEngine();
    private final ReliabilityEngine reliabilityEngine = new ReliabilityEngine();

    private static ResourceBelief belief(String key, double mean, double variance) {
        return new ResourceBelief(key, mean, variance, 5L, T0);
    }

    private static Map<String, ResourceBelief> beliefs(ResourceBelief... entries) {
        Map<String, ResourceBelief> map = new LinkedHashMap<>();
        for (ResourceBelief entry : entries) {
            map.put(entry.resourceName(), entry);
        }
        return map;
    }

    private static DigitalTwinSnapshot snapshot(String nodeId, long receivedAt,
                                                Map<String, ResourceBelief> beliefs) {
        BeliefState state = beliefs.isEmpty()
                ? BeliefState.UNINITIALIZED
                : BeliefState.of(beliefs, 1L, receivedAt, receivedAt);
        return new DigitalTwinSnapshot(nodeId, "host-" + nodeId, 9091, "0.1.0",
                T0, T0, T0, null, List.of(), receivedAt, 0L, state);
    }

    private static Task latencyTask(double maxLatency) {
        return Task.builder("task-lat")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, null, null, null))
                .build();
    }

    private static Task qosTask() {
        return Task.builder("task-qos")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, 50.0, null, null, null))
                .build();
    }

    private SchedulingCandidate candidate(Task task, DigitalTwinSnapshot node,
                                          NodeEligibilityResult eligibility) {
        CapabilityAssessment cap = capabilityEngine.assess(task, node, T0);
        ReliabilityAssessment rel = reliabilityEngine.assess(
                new ReliabilityInput(task, node, eligibility, cap));
        return new SchedulingCandidate(eligibility, cap, rel);
    }

    private NodeEligibilityResult eligible(Task task, String nodeId) {
        return new NodeEligibilityResult(task.taskId(), nodeId, true, false, List.of(),
                List.of(), T0);
    }

    @Test
    void highestCapabilitySelected() {
        // node-a: mean=90ms -> P(X<=100) = phi(1) ≈ 0.841
        // node-b: mean=80ms -> P(X<=100) = phi(2) ≈ 0.977
        // node-b has higher capability probability, so it should be selected
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        // node-b has higher capability probability (0.977 > 0.841)
        assertEquals("node-b", decision.selectedNodeId());
        assertTrue(decision.reasons().contains(SELECTED_HIGHEST_RELIABILITY));
    }

    @Test
    void equalCapabilitiesUseDeterministicTieBreak() {
        // both nodes: mean=80ms -> P(X<=100) = phi(2) ≈ 0.977 for both
        // tie-break by lowest node ID
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        // node-b listed first to test tie-break
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, b, eligible(task, "node-b")),
                candidate(task, a, eligible(task, "node-a"))));
        // equal capabilities -> lowest node ID wins
        assertEquals("node-a", decision.selectedNodeId());
        assertTrue(decision.reasons().contains(SELECTED_HIGHEST_RELIABILITY));
    }

    @Test
    void decisionTraceAccuratelyExplainsSelection() {
        // node-b has higher capability probability (0.977 > 0.841)
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        // node-b selected due to higher capability probability
        assertEquals("node-b", decision.selectedNodeId());
        assertNotNull(decision.derivation());
        // derivation should mention best capability probability
        assertTrue(decision.derivation().contains("best capability probability"));
        assertTrue(decision.candidates().size() == 2);
    }

    @Test
    void reliabilityFallbackWhenCapabilityUnavailable() {
        Task task = qosTask();
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0))); // cap = 1.0 for QoS (no latency constraint)
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a"))));
        // QoS task: capability = 1.0 (vacuous truth, no latency constraint),
        // so scheduler selects via capability-based policy.
        // All candidates have capability 1.0, tie-break by node ID -> node-a selected.
        // Reliability is also unresolved for QoS task, but scheduler still returns SELECTED
        // since capability-based selection took priority.
        assertEquals("node-a", decision.selectedNodeId());
        assertEquals(SchedulingStatus.SELECTED, decision.status());
    }

    @Test
    void unresolvedReliabilityNeverSilencedAsZeroOrOne() {
        Task task = qosTask();
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a"))));
        // QoS task: capability = 1.0, scheduler selects node-a via capability-based policy.
        assertEquals("node-a", decision.selectedNodeId());
        assertEquals(SchedulingStatus.SELECTED, decision.status());
    }
}