package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.capability.BeliefPosteriorDistributionSource;
import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityCombiner;
import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.capability.CapabilityReason;
import com.omni.pcst.master.capability.CapabilityStatus;
import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityEngine;
import com.omni.pcst.master.reliability.ReliabilityEvent;
import com.omni.pcst.master.reliability.ReliabilityInput;
import com.omni.pcst.master.reliability.ReliabilityReason;
import com.omni.pcst.master.reliability.ReliabilityStatus;
import com.omni.pcst.master.task.HardConstraintConfig;
import com.omni.pcst.master.task.HardConstraintFilter;
import com.omni.pcst.master.task.InterruptionTolerance;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.RejectionReason;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link RoundRobinScheduler} (Step 9 baseline).
 *
 * <p>Scenarios verify: rotation across eligible nodes, ineligible candidates
 * never selected, empty/ineligible sets produce no selection, persistent
 * scheduler instance preserves rotation across decisions, changes to the
 * eligible-node set are handled deterministically, tie-breaking by node-id
 * order, and no-feasible-node when all candidates are ineligible.
 */
class RoundRobinSchedulerTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final long HORIZON = 60_000L;
    private static final long MAX_AGE = HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS;
    private static final double PHI_2 = 0.9772498680518208;
    private static final String LATENCY = BayesianBeliefEngine.NETWORK_LATENCY_MS;
    private static final String PACKET_LOSS = BayesianBeliefEngine.NETWORK_PACKET_LOSS_PERCENT;

    private final CapabilityEngine capabilityEngine = new CapabilityEngine();
    private final ReliabilityEngine reliabilityEngine = new ReliabilityEngine();
    private final RoundRobinScheduler scheduler = new RoundRobinScheduler();

    private static ResourceBelief belief(String key, double mean, double variance) {
        return new ResourceBelief(key, mean, variance, 5L, T0);
    }

    private static Map<String, ResourceBelief> beliefs(ResourceBelief... entries) {
        Map<String, ResourceBelief> map = new LinkedHashMap<>();
        for (ResourceBelief entry : entries) {
            map.put(entry.resourceName(), entry);
        }
        return map;
    }

    private static DigitalTwinSnapshot snapshot(String nodeId, long receivedAt,
                                                Map<String, ResourceBelief> beliefs) {
        BeliefState state = beliefs.isEmpty()
                ? BeliefState.UNINITIALIZED
                : BeliefState.of(beliefs, 1L, receivedAt, receivedAt);
        return new DigitalTwinSnapshot(nodeId, "host-" + nodeId, 9091, "0.1.0",
                T0, T0, T0, null, List.of(), receivedAt, 0L, state);
    }

    private static Task latencyTask(double maxLatency) {
        return Task.builder("task-lat")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, null, null, null))
                .build();
    }

    private SchedulingCandidate candidate(Task task, DigitalTwinSnapshot node,
                                        NodeEligibilityResult eligibility) {
        CapabilityAssessment cap = capabilityEngine.assess(task, node, T0);
        ReliabilityAssessment rel = reliabilityEngine.assess(
                new ReliabilityInput(task, node, eligibility, cap));
        return new SchedulingCandidate(eligibility, cap, rel);
    }

    private NodeEligibilityResult eligible(Task task, String nodeId) {
        return new NodeEligibilityResult(task.taskId(), nodeId, true, false, List.of(),
                List.of(), T0);
    }

    @Test
    void rotatesAcrossEligibleNodes() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision first = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals("node-a", first.selectedNodeId());

        SchedulingDecision second = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals("node-b", second.selectedNodeId());

        SchedulingDecision third = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals("node-a", third.selectedNodeId());
    }

    @Test
    void ineligibleCandidatesNeverSelected() {
        Task task = latencyTask(100.0);
        NodeEligibilityResult rejected = new NodeEligibilityResult(task.taskId(), "node-a",
                false, false, List.of(), List.of(RejectionReason.NETWORK_LATENCY_EXCEEDED), T0);
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0))), rejected)));
        assertEquals(SchedulingStatus.NO_FEASIBLE_NODE, decision.status());
        assertNull(decision.selectedNodeId());
    }

    @Test
    void entirelyIneligibleSetProducesNoSelection() {
        Task task = latencyTask(100.0);
        NodeEligibilityResult rejectedA = new NodeEligibilityResult(task.taskId(), "node-a",
                false, false, List.of(), List.of(), T0);
        NodeEligibilityResult rejectedB = new NodeEligibilityResult(task.taskId(), "node-b",
                false, false, List.of(), List.of(), T0);
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0))), rejectedA),
                candidate(task, snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0))), rejectedB)));
        assertEquals(SchedulingStatus.NO_FEASIBLE_NODE, decision.status());
        assertNull(decision.selectedNodeId());
    }

    @Test
    void persistentInstancePreservesRotation() {
        RoundRobinScheduler scheduler = new RoundRobinScheduler();
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision d1 = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals("node-a", d1.selectedNodeId());

        SchedulingDecision d2 = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals("node-b", d2.selectedNodeId());

        SchedulingDecision d3 = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals("node-a", d3.selectedNodeId());
    }

    @Test
    void changesToEligibleNodeSetHandledDeterministically() {
        RoundRobinScheduler scheduler = new RoundRobinScheduler();
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        DigitalTwinSnapshot c = snapshot("node-c", T0, beliefs(belief(LATENCY, 70.0, 100.0)));
        SchedulingDecision d1 = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals("node-a", d1.selectedNodeId());

        SchedulingDecision d2 = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b")),
                candidate(task, c, eligible(task, "node-c"))));
        assertEquals("node-b", d2.selectedNodeId());

        SchedulingDecision d3 = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, c, eligible(task, "node-c"))));
        assertEquals("node-a", d3.selectedNodeId());
    }

    @Test
    void tieBreakingByNodeIdOrder() {
        RoundRobinScheduler scheduler = new RoundRobinScheduler();
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision d1 = scheduler.select(task, T0, List.of(
                candidate(task, b, eligible(task, "node-b")),
                candidate(task, a, eligible(task, "node-a"))));
        assertEquals("node-a", d1.selectedNodeId());

        SchedulingDecision d2 = scheduler.select(task, T0, List.of(
                candidate(task, b, eligible(task, "node-b")),
                candidate(task, a, eligible(task, "node-a"))));
        assertEquals("node-b", d2.selectedNodeId());
    }

    @Test
    void noFeasibleNodeWhenAllIneligible() {
        Task task = latencyTask(100.0);
        NodeEligibilityResult rejected = new NodeEligibilityResult(task.taskId(), "node-a",
                false, false, List.of(), List.of(RejectionReason.NETWORK_LATENCY_EXCEEDED), T0);
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0))), rejected)));
        assertEquals(SchedulingStatus.NO_FEASIBLE_NODE, decision.status());
        assertNull(decision.selectedNodeId());
    }
}
