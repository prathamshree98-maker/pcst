package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.capability.BeliefPosteriorDistributionSource;
import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityCombiner;
import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.capability.CapabilityReason;
import com.omni.pcst.master.capability.CapabilityStatus;
import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityEngine;
import com.omni.pcst.master.reliability.ReliabilityEvent;
import com.omni.pcst.master.reliability.ReliabilityInput;
import com.omni.pcst.master.reliability.ReliabilityReason;
import com.omni.pcst.master.reliability.ReliabilityStatus;
import com.omni.pcst.master.task.HardConstraintConfig;
import com.omni.pcst.master.task.HardConstraintFilter;
import com.omni.pcst.master.task.InterruptionTolerance;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.RejectionReason;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link PCSTScheduler} (Step 6D).
 *
 * <p>Scenarios verify: highest reliability selection, threshold enforcement,
 * tie-breaking by lowest node id, no feasible node, defer-or-reject when below
 * threshold, no selection when all unresolved, unresolved reliability not ranked
 * as zero/one, ineligibility never overridden, fallback policy behaviour, and
 * decision trace per candidate.
 */
class PCSTSchedulerTest {

    private static final long T0 = 1_700_000_000_000L;
    private static final long HORIZON = 60_000L;
    private static final long MAX_AGE = HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS;
    private static final double PHI_2 = 0.9772498680518208;
    private static final String LATENCY = BayesianBeliefEngine.NETWORK_LATENCY_MS;
    private static final String PACKET_LOSS = BayesianBeliefEngine.NETWORK_PACKET_LOSS_PERCENT;

    private final CapabilityEngine capabilityEngine = new CapabilityEngine();
    private final ReliabilityEngine reliabilityEngine = new ReliabilityEngine();
    private final PCSTScheduler scheduler = new PCSTScheduler(SchedulingPolicyConfig.none());

    private static ResourceBelief belief(String key, double mean, double variance) {
        return new ResourceBelief(key, mean, variance, 5L, T0);
    }

    private static Map<String, ResourceBelief> beliefs(ResourceBelief... entries) {
        Map<String, ResourceBelief> map = new LinkedHashMap<>();
        for (ResourceBelief entry : entries) {
            map.put(entry.resourceName(), entry);
        }
        return map;
    }

    private static DigitalTwinSnapshot snapshot(String nodeId, long receivedAt,
                                                Map<String, ResourceBelief> beliefs) {
        BeliefState state = beliefs.isEmpty()
                ? BeliefState.UNINITIALIZED
                : BeliefState.of(beliefs, 1L, receivedAt, receivedAt);
        return new DigitalTwinSnapshot(nodeId, "host-" + nodeId, 9091, "0.1.0",
                T0, T0, T0, null, List.of(), receivedAt, 0L, state);
    }

    private static Task latencyTask(double maxLatency) {
        return Task.builder("task-lat")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, maxLatency, null, null, null))
                .build();
    }

    private SchedulingCandidate candidate(Task task, DigitalTwinSnapshot node,
                                        NodeEligibilityResult eligibility) {
        CapabilityAssessment cap = capabilityEngine.assess(task, node, T0);
        ReliabilityAssessment rel = reliabilityEngine.assess(
                new ReliabilityInput(task, node, eligibility, cap));
        return new SchedulingCandidate(eligibility, cap, rel);
    }

    private NodeEligibilityResult eligible(Task task, String nodeId) {
        return new NodeEligibilityResult(task.taskId(), nodeId, true, false, List.of(),
                List.of(), T0);
    }

    @Test
    void selectsHighestReliabilityAmongEligible() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals(SchedulingStatus.SELECTED, decision.status());
        assertEquals("node-b", decision.selectedNodeId());
        assertEquals(PHI_2, decision.selectedReliability(), 1e-6);
        assertTrue(decision.reasons().contains(SchedulingReason.SELECTED_HIGHEST_RELIABILITY));
        assertNull(decision.policyThreshold());
    }

    @Test
    void enforcesPerTaskThreshold() {
        Task task = latencyTask(100.0);
        PCSTScheduler s = new PCSTScheduler(SchedulingPolicyConfig.of(0.99));
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0))); // ~0.8413
        SchedulingDecision decision = s.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a"))));
        assertEquals(SchedulingStatus.DEFER_OR_REJECT, decision.status());
        assertNull(decision.selectedNodeId());
        assertTrue(decision.reasons().contains(SchedulingReason.ALL_RANKED_CANDIDATES_BELOW_POLICY_THRESHOLD));
    }

    @Test
    void tieBreakerIsLowestNodeId() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, b, eligible(task, "node-b")),
                candidate(task, a, eligible(task, "node-a"))));
        assertEquals(SchedulingStatus.SELECTED, decision.status());
        assertEquals("node-a", decision.selectedNodeId());
        assertTrue(decision.reasons().contains(SchedulingReason.TIE_BROKEN_BY_NODE_ID));
    }

    @Test
    void noFeasibleNodeWhenAllIneligible() {
        Task task = latencyTask(100.0);
        NodeEligibilityResult rejected = new NodeEligibilityResult(task.taskId(), "node-a",
                false, false, List.of(), List.of(RejectionReason.NETWORK_LATENCY_EXCEEDED), T0);
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0))), rejected)));
        assertEquals(SchedulingStatus.NO_FEASIBLE_NODE, decision.status());
        assertNull(decision.selectedNodeId());
        assertTrue(decision.candidates().get(0).disposition() == CandidateDisposition.EXCLUDED_HARD_CONSTRAINT);
    }

    @Test
    void noSelectionWhenAllUnresolved() {
        Task task = Task.builder("task-qos")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, 100.0, null, null, "gpu"))
                .build();
        DigitalTwinSnapshot node = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingCandidate cand = candidate(task, node, eligible(task, "node-a"));
        assertEquals(ReliabilityStatus.UNRESOLVED_MODEL, cand.reliability().status());
        SchedulingDecision decision = scheduler.select(task, T0, List.of(cand));
        assertEquals(SchedulingStatus.NO_SELECTION_UNRESOLVED, decision.status());
        assertNull(decision.selectedNodeId());
        assertNull(decision.selectedReliability());
        assertTrue(decision.candidates().get(0).disposition() == CandidateDisposition.UNRESOLVED_RELIABILITY);
    }

    @Test
    void unresolvedNotRankedAndTraceExposed() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot good = snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        Task badTask = Task.builder("task-qos")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, 50.0, null, null, "gpu"))
                .build();
        DigitalTwinSnapshot bad = snapshot("node-b", T0, beliefs(belief(LATENCY, 40.0, 100.0)));
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, good, eligible(task, "node-a")),
                candidate(badTask, bad, eligible(badTask, "node-b"))));
        assertEquals(SchedulingStatus.SELECTED, decision.status());
        assertEquals("node-a", decision.selectedNodeId());
        CandidateDecision b = decision.candidateFor("node-b");
        assertNotNull(b);
        assertEquals(CandidateDisposition.UNRESOLVED_RELIABILITY, b.disposition());
        assertNull(b.reliability());
        assertTrue(decision.reasons().contains(SchedulingReason.SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE));
    }

    @Test
    void ineligibilityNeverOverriddenByReliability() {
        Task task = latencyTask(100.0);
        NodeEligibilityResult rejected = new NodeEligibilityResult(task.taskId(), "node-a",
                false, false, List.of(), List.of(RejectionReason.NETWORK_LATENCY_EXCEEDED), T0);
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, snapshot("node-a", T0, beliefs(belief(LATENCY, 10.0, 100.0))), rejected)));
        assertEquals(SchedulingStatus.NO_FEASIBLE_NODE, decision.status());
        assertNull(decision.selectedNodeId());
        assertFalse(decision.reasons().contains(SchedulingReason.SELECTED_HIGHEST_RELIABILITY));
    }

    @Test
    void fallbackPolicyLowestNodeIdWhenAllUnresolved() {
        PCSTScheduler s = new PCSTScheduler(
                SchedulingPolicyConfig.none().withFallbackPolicy(FallbackPolicy.LOWEST_NODE_ID));
        Task task = Task.builder("task-qos")
                .workloadReference("ref")
                .expectedDurationMillis(HORIZON)
                .constraints(new TaskConstraints(null, null, null, 100.0, null, null, "gpu"))
                .build();
        SchedulingDecision decision = s.select(task, T0, List.of(
                candidate(task, snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0))), eligible(task, "node-b")),
                candidate(task, snapshot("node-a", T0, beliefs(belief(LATENCY, 80.0, 100.0))), eligible(task, "node-a"))));
        assertEquals(SchedulingStatus.FALLBACK_SELECTED, decision.status());
        assertEquals("node-a", decision.selectedNodeId());
        assertNull(decision.selectedReliability());
        assertTrue(decision.policyFallback());
        assertTrue(decision.reasons().contains(SchedulingReason.POLICY_FALLBACK_LOWEST_NODE_ID));
    }

    @Test
    void decisionTraceIncludesEveryCandidate() {
        Task task = latencyTask(100.0);
        SchedulingDecision decision = scheduler.select(task, T0, List.of(
                candidate(task, snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0))), eligible(task, "node-b")),
                candidate(task, snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0))), eligible(task, "node-a"))));
        assertEquals(2, decision.candidates().size());
        assertEquals("node-a", decision.candidates().get(0).nodeId());
        assertEquals("node-b", decision.candidates().get(1).nodeId());
        assertEquals("node-b", decision.selectedNodeId());
    }

    @Test
    void resourceOnlyContractStillProducesReliabilityAndRanking() {
        Task task = latencyTask(100.0);
        DigitalTwinSnapshot a = snapshot("node-a", T0, beliefs(belief(LATENCY, 90.0, 100.0)));
        DigitalTwinSnapshot b = snapshot("node-b", T0, beliefs(belief(LATENCY, 80.0, 100.0)));
        SchedulingDecision d = scheduler.select(task, T0, List.of(
                candidate(task, a, eligible(task, "node-a")),
                candidate(task, b, eligible(task, "node-b"))));
        assertEquals(SchedulingStatus.SELECTED, d.status());
        assertEquals(PHI_2, d.selectedReliability(), 1e-6);
    }
}
