package com.omni.pcst.master.benchmark;

import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskClass;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generates a deterministic sequence of tasks for benchmarking.
 *
 * <p>Tasks express latency and/or packet-loss constraints — the only resource
 * conditions the current PCST capability pipeline can evaluate numerically.
 * Tasks with deadlines, battery minimums, or QoS profiles produce unresolved
 * reliability in PCST and are explicitly flagged as unsupported for PCST
 * comparison.
 */
public final class TaskGenerator {

    private final Random random;
    private final long baseTimestampMillis;

    private TaskGenerator(Random random, long baseTimestampMillis) {
        this.random = random;
        this.baseTimestampMillis = baseTimestampMillis;
    }

    /**
     * Generates {@code count} latency-bound tasks.
     *
     * @param count number of tasks to generate
     * @return list of tasks with {@code maximumNetworkLatencyMillis} set,
     *         no deadline, no battery, no QoS, no interruption tolerance
     */
    public List<Task> latencyTasks(int count) {
        List<Task> tasks = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            double maxLatency = 80.0 + random.nextDouble() * 40.0; // 80-120 ms
            long duration = 30_000L + (long) (random.nextDouble() * 60_000L); // 30-90s
            tasks.add(Task.builder("lat-task-" + i)
                    .taskClass(TaskClass.NETWORK_BOUND)
                    .workloadReference("ref-lat")
                    .expectedDurationMillis(duration)
                    .constraints(new TaskConstraints(
                            null, duration, null, maxLatency, null, null, null))
                    .build());
        }
        return tasks;
    }

    /**
     * Generates {@code count} packet-loss-bound tasks.
     *
     * @param count number of tasks to generate
     * @return list of tasks with {@code maximumPacketLossPercent} set,
     *         no deadline, no battery, no QoS, no interruption tolerance
     */
    public List<Task> packetLossTasks(int count) {
        List<Task> tasks = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            double maxLoss = 0.5 + random.nextDouble() * 4.5; // 0.5-5.0 %
            long duration = 30_000L + (long) (random.nextDouble() * 60_000L);
            tasks.add(Task.builder("pl-task-" + i)
                    .taskClass(TaskClass.NETWORK_BOUND)
                    .workloadReference("ref-pl")
                    .expectedDurationMillis(duration)
                    .constraints(new TaskConstraints(
                            null, duration, null, null, maxLoss, null, null))
                    .build());
        }
        return tasks;
    }

    /**
     * Generates {@code count} mixed constraint tasks (latency + packet loss).
     *
     * @param count number of tasks to generate
     * @return list of tasks with both {@code maximumNetworkLatencyMillis} and
     *         {@code maximumPacketLossPercent} set
     */
    public List<Task> mixedTasks(int count) {
        List<Task> tasks = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            double maxLatency = 80.0 + random.nextDouble() * 40.0;
            double maxLoss = 0.5 + random.nextDouble() * 4.5;
            long duration = 30_000L + (long) (random.nextDouble() * 60_000L);
            tasks.add(Task.builder("mixed-task-" + i)
                    .taskClass(TaskClass.NETWORK_BOUND)
                    .workloadReference("ref-mixed")
                    .expectedDurationMillis(duration)
                    .constraints(new TaskConstraints(
                            null, duration, null, maxLatency, maxLoss, null, null))
                    .build());
        }
        return tasks;
    }

    /**
     * Generates {@code count} unsupported tasks with deadlines.
     *
     * <p>These tasks express a deadline, which PCST cannot evaluate numerically
     * (no completion-time model). They produce unresolved reliability and are
     * used to verify that PCST correctly defers rather than fabricates a value.
     *
     * @param count number of tasks to generate
     * @return list of tasks with {@code deadlineEpochMillis} set
     */
    public List<Task> deadlineTasks(int count) {
        List<Task> tasks = new ArrayList<>(count);
        long future = baseTimestampMillis + 3_600_000L; // 1 hour from base
        for (int i = 0; i < count; i++) {
            long deadline = future + (long) (random.nextDouble() * 3_600_000L);
            long duration = 60_000L;
            tasks.add(Task.builder("dl-task-" + i)
                    .taskClass(TaskClass.CPU_BOUND)
                    .workloadReference("ref-dl")
                    .expectedDurationMillis(duration)
                    .constraints(new TaskConstraints(
                            deadline, duration, null, 100.0, null, null, null))
                    .build());
        }
        return tasks;
    }

    /** Builder for {@link TaskGenerator}. */
    public static class Builder {
        private long seed = 42L;
        private long baseTimestampMillis = 1_700_000_000_000L;

        public Builder seed(long seed) {
            this.seed = seed;
            return this;
        }

        public Builder baseTimestampMillis(long baseTimestampMillis) {
            this.baseTimestampMillis = baseTimestampMillis;
            return this;
        }

        public TaskGenerator build() {
            return new TaskGenerator(new Random(seed), baseTimestampMillis);
        }
    }
}
