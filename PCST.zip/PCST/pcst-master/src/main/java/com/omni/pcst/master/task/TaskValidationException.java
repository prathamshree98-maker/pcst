package com.omni.pcst.master.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Raised when a task or a task value object fails validation.
 *
 * <p>Carries <em>all</em> violations found during construction rather than only
 * the first, so a caller can see every invalid field at once. This follows the
 * repository convention of rejecting invalid state at construction time (as
 * {@code TelemetryEvaluationRecord} and the predictor request types do) rather
 * than deferring the check.
 */
public class TaskValidationException extends IllegalArgumentException {

    private static final long serialVersionUID = 1L;

    private final transient List<ValidationViolation> violations;

    public TaskValidationException(List<ValidationViolation> violations) {
        super(buildMessage(violations));
        this.violations = List.copyOf(violations);
    }

    public TaskValidationException(String field, String reason) {
        this(List.of(new ValidationViolation(field, reason)));
    }

    /** @return every violation found, in discovery order */
    public List<ValidationViolation> violations() {
        return violations;
    }

    /** @return the dotted field paths of the violations */
    public List<String> fields() {
        return violations.stream().map(ValidationViolation::field).collect(Collectors.toList());
    }

    private static String buildMessage(List<ValidationViolation> violations) {
        if (violations == null || violations.isEmpty()) {
            return "invalid task";
        }
        StringBuilder sb = new StringBuilder("invalid task definition: ");
        List<ValidationViolation> safe = new ArrayList<>(violations);
        for (int i = 0; i < safe.size(); i++) {
            if (i > 0) {
                sb.append("; ");
            }
            sb.append(safe.get(i));
        }
        return sb.toString();
    }

    static List<ValidationViolation> emptyViolations() {
        return Collections.emptyList();
    }
}