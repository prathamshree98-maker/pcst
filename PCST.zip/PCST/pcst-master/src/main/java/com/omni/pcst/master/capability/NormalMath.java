package com.omni.pcst.master.capability;

/**
 * Minimal, dependency-free normal-distribution arithmetic used by the capability
 * engine.
 *
 * <p>The capability event for a one-sided resource threshold under a Gaussian
 * predictive distribution is a tail probability of the standard normal CDF
 * &Phi;. The Java standard library does not expose the error function, so this
 * class implements {@code erf} with the rational approximation of Abramowitz and
 * Stegun, <i>Handbook of Mathematical Functions</i>, equation 7.1.26:
 *
 * <pre>
 *   t   = 1 / (1 + p&#183;|x|),   p = 0.3275911
 *   erf(x) &asymp; sign(x) &#183; (1 &minus; (a&#8321;t + a&#8322;t&#178; + a&#8323;t&#179; + a&#8324;t&#8308; + a&#8325;t&#8309;) e^{&minus;x&#178;})
 * </pre>
 *
 * with a maximum absolute error of 1.5&times;10<sup>&minus;7</sup>. That is well
 * inside the 10<sup>&minus;6</sup> tolerance the capability tests assert, and the
 * approximation is documented here rather than hidden, because it is an explicit
 * numerical choice.
 *
 * <p>This class is stateless, deterministic and safe for concurrent use.
 */
public final class NormalMath {

    /** A&S 7.1.26 fitting constant. */
    private static final double P = 0.3275911;
    private static final double A1 = 0.254829592;
    private static final double A2 = -0.284496736;
    private static final double A3 = 1.421413741;
    private static final double A4 = -1.453152027;
    private static final double A5 = 1.061405429;

    private static final double SQRT_TWO = Math.sqrt(2.0);

    private NormalMath() {
    }

    /**
     * Error function approximated by A&S 7.1.26.
     *
     * @param x any finite value; a non-finite value is returned unchanged
     * @return {@code erf(x)} with absolute error at most 1.5e-7
     */
    public static double erf(double x) {
        if (!Double.isFinite(x)) {
            return x;
        }
        double sign = Math.signum(x);
        double ax = Math.abs(x);
        double t = 1.0 / (1.0 + P * ax);
        double poly = (((((A5 * t + A4) * t) + A3) * t + A2) * t + A1) * t;
        double y = 1.0 - poly * Math.exp(-ax * ax);
        return sign * y;
    }

    /**
     * Standard normal cumulative distribution function
     * {@code &Phi;(z) = 0.5&#183;(1 + erf(z/&radic;2))}.
     *
     * @param z standardised value
     * @return probability that a standard normal variable is &le; z
     */
    public static double standardNormalCdf(double z) {
        return 0.5 * (1.0 + erf(z / SQRT_TWO));
    }

    /**
     * Probability that {@code X &le; threshold} when {@code X ~ Normal(mean, variance)}.
     *
     * @param mean      predictive mean
     * @param variance  predictive variance; must be finite and strictly positive
     * @param threshold the one-sided upper threshold
     * @return {@code P(X &le; threshold)}
     * @throws IllegalArgumentException when the variance is not finite and positive
     */
    public static double probabilityAtMost(double mean, double variance, double threshold) {
        if (!(variance > 0.0) || !Double.isFinite(variance)) {
            throw new IllegalArgumentException("variance must be finite and > 0 (was " + variance + ")");
        }
        double sd = Math.sqrt(variance);
        return standardNormalCdf((threshold - mean) / sd);
    }

    /**
     * Probability that {@code X &ge; threshold} when {@code X ~ Normal(mean, variance)}.
     * Provided for completeness and testing; the capability engine's supported
     * network thresholds are all upper bounds and use {@link #probabilityAtMost}.
     *
     * @param mean      predictive mean
     * @param variance  predictive variance; must be finite and strictly positive
     * @param threshold the one-sided lower threshold
     * @return {@code P(X &ge; threshold)}
     */
    public static double probabilityAtLeast(double mean, double variance, double threshold) {
        return 1.0 - probabilityAtMost(mean, variance, threshold);
    }
}
