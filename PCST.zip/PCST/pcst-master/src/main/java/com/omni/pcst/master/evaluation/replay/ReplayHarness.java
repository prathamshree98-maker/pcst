package com.omni.pcst.master.evaluation.replay;

import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import com.omni.pcst.master.prediction.ForecastRequest;
import com.omni.pcst.master.prediction.ForecastableResource;
import com.omni.pcst.master.prediction.PersistenceResourcePredictor;
import com.omni.pcst.master.prediction.ResourceForecast;
import com.omni.pcst.master.prediction.TrendResourcePredictor;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Offline replay and scoring harness for PCST resource predictors.
 *
 * <p>This is an evaluation tool. It runs predictors over previously persisted
 * telemetry and reports error statistics; it does not predict anything at
 * runtime, does not schedule work, and produces no reliability or capability
 * claim.
 *
 * <h2>Leakage prevention</h2>
 * Leakage is prevented <b>by construction</b>, not by convention. At a prediction
 * origin with event time {@code t}, the harness builds a
 * {@link DigitalTwinSnapshot} whose observation history contains only
 * observations with {@code observationTimestamp <= t}, newest first, and then
 * asks the predictor for a forecast at {@code t + horizon}. The target is the
 * first eligible observation strictly after {@code t}, so no target or later
 * observation can reach the predictor input. The existing predictors already
 * discard future-dated observations; the harness additionally never supplies
 * them, so the two mechanisms reinforce each other.
 *
 * <p>Prediction origins and targets stay inside one {@code (node, session)}
 * group, so a session boundary can never be crossed when looking for a target.
 *
 * <h2>Baseline relationship</h2>
 * {@link PersistenceResourcePredictor} <em>is</em> the persistence baseline: its
 * estimate is defined as the newest valid in-window observation, held constant.
 * The harness therefore evaluates it once and documents that it doubles as the
 * naive baseline, instead of duplicating the same maths under a second name.
 *
 * <h2>Honest coverage reporting</h2>
 * Every prediction opportunity is counted, and separately: how many produced a
 * usable forecast, how many had a scoreable target, and how many were scored.
 * Selecting only successful forecasts would make a weak predictor look strong,
 * so non-forecasting outcomes are reported explicitly rather than discarded.
 */
public final class ReplayHarness {

    /** Identifier of each evaluated predictor, in deterministic report order. */
    public enum PredictorId {
        /** The persistence baseline (also the naive reference forecast). */
        PERSISTENCE,
        /** The OLS trend challenger. */
        TREND
    }

    /** Why a prediction opportunity produced no scored pair. */
    public enum UnscoredReason {
        /** No eligible target observation near the requested instant. */
        NO_TARGET_OBSERVATION,
        /** The target resource value was absent or non-finite. */
        TARGET_VALUE_UNAVAILABLE,
        /** The predictor returned a non-OK status. */
        FORECAST_UNAVAILABLE,
        /** Fewer history observations than the configured minimum. */
        INSUFFICIENT_HISTORY
    }

    /** Statistics for one (predictor, resource, horizon) cell. */
    public record MetricCell(PredictorId predictor,
                             String resourceIdentifier,
                             String unit,
                             long horizonMillis,
                             long scoredPairs,
                             Double meanAbsoluteError,
                             Double rootMeanSquaredError,
                             Double meanSignedError,
                             Double maxAbsoluteError,
                             long predictionOpportunities,
                             long forecastsProduced,
                             long targetCoverageFailures,
                             Map<UnscoredReason, Long> unscoredReasons) {

        /** @return coverage of scored pairs against all prediction opportunities */
        public double scoredCoverage() {
            return predictionOpportunities == 0L
                    ? 0.0
                    : (double) scoredPairs / predictionOpportunities;
        }
    }

    /** Per-node/session observation counts. */
    public record GroupCoverage(String nodeId, String sessionId, int observations,
                                long firstTimestamp, long lastTimestamp) {
    }

    /** Complete, deterministic result of one evaluation run. */
    public record EvaluationReport(String protocol,
                                   String inputPath,
                                   String inputFingerprint,
                                   boolean deterministicOutput,
                                   long[] horizonsMillis,
                                   Long targetToleranceMillis,
                                   Long observationWindowMillis,
                                   Integer minimumObservations,
                                   ReplayDataset.LoadedDataset dataset,
                                   List<GroupCoverage> groupCoverage,
                                   List<MetricCell> metrics,
                                   List<String> warnings) {
    }

    private final ReplayConfig config;
    private final PersistenceResourcePredictor persistencePredictor;
    private final TrendResourcePredictor trendPredictor;

    public ReplayHarness(ReplayConfig config) {
        this.config = config;
        this.persistencePredictor = new PersistenceResourcePredictor();
        this.trendPredictor = new TrendResourcePredictor();
    }

    /**
     * Loads a dataset and evaluates every supported predictor against it.
     *
     * @param path JSON Lines input file; only ever read
     * @return a deterministic report
     * @throws java.io.IOException if the input cannot be read
     */
    public EvaluationReport evaluate(Path path) throws java.io.IOException {
        ReplayDataset.LoadedDataset dataset = ReplayDataset.load(path);
        return evaluate(dataset, path, config);
    }

    /**
     * Evaluates an already-loaded dataset. The configuration actually applied is
     * carried into the report so the output always states the horizons and
     * tolerance that produced it, even when a caller overrides the defaults.
     */
    EvaluationReport evaluate(ReplayDataset.LoadedDataset dataset, Path path, ReplayConfig applied) {
        ReplayConfig config = applied == null ? this.config : applied;
        Map<String, MetricCell> cells = new LinkedHashMap<>();
        List<GroupCoverage> coverage = new ArrayList<>();
        List<String> warnings = new ArrayList<>();

        for (String key : dataset.groupKeys()) {
            List<ReplayDataset.ReplayObservation> observations = dataset.group(key);
            if (observations.isEmpty()) {
                continue;
            }
            ReplayDataset.ReplayObservation first = observations.get(0);
            ReplayDataset.ReplayObservation last = observations.get(observations.size() - 1);
            coverage.add(new GroupCoverage(first.nodeId(), first.sessionId(), observations.size(),
                    first.observationTimestamp(), last.observationTimestamp()));

            if (observations.size() < config.minimumObservations()) {
                warnings.add("group '" + key + "' has only " + observations.size()
                        + " observation(s); predictors requiring at least "
                        + config.minimumObservations() + " cannot be evaluated");
                continue;
            }

            for (ForecastableResource resource : ForecastableResource.values()) {
                evaluateResource(cells, observations, resource, config);
            }
        }

        if (dataset.eligibleObservationCount() == 0L) {
            warnings.add("no eligible observations: every record was excluded or unreadable");
        }

        List<MetricCell> metrics = new ArrayList<>(cells.values());
        metrics.sort((a, b) -> {
            int c = Integer.compare(a.predictor().ordinal(), b.predictor().ordinal());
            if (c != 0) return c;
            c = a.resourceIdentifier().compareTo(b.resourceIdentifier());
            if (c != 0) return c;
            return Long.compare(a.horizonMillis(), b.horizonMillis());
        });

        return new EvaluationReport(ReplayConfig.PROTOCOL,
                path.toString(),
                fingerprint(dataset),
                true,
                config.horizonsMillis(),
                config.targetToleranceMillis(),
                config.observationWindowMillis(),
                config.minimumObservations(),
                dataset, Collections.unmodifiableList(coverage),
                Collections.unmodifiableList(metrics),
                Collections.unmodifiableList(warnings));
    }

    /** Horizons in the exact order they were configured. */


    /** Evaluates every (predictor, horizon) combination for one resource. */
    private void evaluateResource(Map<String, MetricCell> cells,
                                  List<ReplayDataset.ReplayObservation> observations,
                                  ForecastableResource resource,
                                  ReplayConfig config) {
        String unit = unitFor(resource);
        for (long horizon : config.horizonsMillis()) {
            for (PredictorId predictor : PredictorId.values()) {
                ErrorAccumulator accumulator = new ErrorAccumulator(unit);
                Map<UnscoredReason, Long> unscored = new EnumMap<>(UnscoredReason.class);
                long opportunities = 0L;
                long forecasts = 0L;

                for (int originIndex = 0; originIndex < observations.size(); originIndex++) {
                    long origin = observations.get(originIndex).observationTimestamp();
                    // A target must exist strictly after the origin, so the last
                    // observation can never be an origin.
                    Double actual = findTarget(observations, originIndex, origin, horizon, resource, config);
                    if (actual == null) {
                        if (hasAnyValueAfter(observations, originIndex, resource)) {
                            unscored.merge(UnscoredReason.NO_TARGET_OBSERVATION, 1L, Long::sum);
                        }
                        continue;
                    }
                    opportunities++;

                    // --- Leakage-free predictor input ------------------------
                    DigitalTwinSnapshot snapshot = snapshotAt(observations, originIndex);

                    ResourceForecast forecast = predictor == PredictorId.PERSISTENCE
                            ? persistencePredictor.forecast(new ForecastRequest(
                                    snapshot, resource.identifier(), horizon,
                                    config.observationWindowMillis(), origin,
                                    config.minimumObservations()))
                            : trendPredictor.forecast(new ForecastRequest(
                                    snapshot, resource.identifier(), horizon,
                                    config.observationWindowMillis(), origin,
                                    config.minimumObservations()));

                    if (forecast.status() != ResourceForecast.Status.OK
                            || !forecast.hasPointEstimate()
                            || !Double.isFinite(forecast.pointEstimate())) {
                        UnscoredReason reason = forecast.observationCount() == 0
                                ? UnscoredReason.INSUFFICIENT_HISTORY
                                : UnscoredReason.FORECAST_UNAVAILABLE;
                        unscored.merge(reason, 1L, Long::sum);
                        continue;
                    }
                    forecasts++;
                    accumulator.add(forecast.pointEstimate(), actual);
                }

                String cellKey = predictor.name() + "|" + resource.identifier() + "|" + horizon;
                cells.put(cellKey, new MetricCell(predictor, resource.identifier(), unit, horizon,
                        accumulator.sampleCount(),
                        accumulator.meanAbsoluteError(),
                        accumulator.rootMeanSquaredError(),
                        accumulator.meanSignedError(),
                        accumulator.maxAbsoluteError(),
                        opportunities, forecasts,
                        unscored.getOrDefault(UnscoredReason.NO_TARGET_OBSERVATION, 0L)
                                + unscored.getOrDefault(UnscoredReason.TARGET_VALUE_UNAVAILABLE, 0L),
                        Collections.unmodifiableMap(new TreeMap<>(
                                unscored.isEmpty() ? new EnumMap<>(UnscoredReason.class) : unscored))));
            }
        }
    }

    /**
     * Finds the actual value to score against.
     *
     * <p>Target policy: same group (so same node and session), strictly later
     * than the origin, and within {@code targetToleranceMillis} of the requested
     * instant {@code origin + horizon}. Returns {@code null} when no valid
     * target exists; {@link Double#NaN} is never returned, so a missing target
     * is always distinguishable from a target that happened to be zero.
     */
    private Double findTarget(List<ReplayDataset.ReplayObservation> observations,
                              int originIndex, long origin, long horizon,
                              ForecastableResource resource, ReplayConfig config) {
        long requested = origin + horizon;
        long earliest = requested - config.targetToleranceMillis();
        long latest = requested + config.targetToleranceMillis();
        for (int i = originIndex + 1; i < observations.size(); i++) {
            long candidate = observations.get(i).observationTimestamp();
            if (candidate <= origin) {
                continue;   // strictly later only; guards ties and out-of-order input
            }
            if (candidate < earliest) {
                // Arrived too early to be the target: keep looking forward.
                continue;
            }
            if (candidate > latest) {
                // The group is time-ordered, so nothing later can match either.
                return null;
            }
            Double value = resource.measureFrom(observations.get(i).observation());
            if (value == null || !Double.isFinite(value)) {
                return null;
            }
            return value;
        }
        return null;
    }

    private boolean hasAnyValueAfter(List<ReplayDataset.ReplayObservation> observations,
                                     int originIndex, ForecastableResource resource) {
        for (int i = originIndex + 1; i < observations.size(); i++) {
            if (observations.get(i).observationTimestamp() > observations.get(originIndex).observationTimestamp()) {
                Double v = resource.measureFrom(observations.get(i).observation());
                if (v != null && Double.isFinite(v)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Builds a snapshot containing only observations at or before the origin.
     *
     * <p>The history is newest-first, matching the documented
     * {@link DigitalTwinSnapshot#observationHistory()} contract. The belief state
     * is left {@link BeliefState#UNINITIALIZED} deliberately: replay evaluates
     * predictors, and re-deriving belief here would blend a second model into an
     * evaluation of the first.
     */
    private static DigitalTwinSnapshot snapshotAt(List<ReplayDataset.ReplayObservation> observations,
                                                  int originIndex) {
        List<TelemetryObservation> history = new ArrayList<>(originIndex + 1);
        for (int i = originIndex; i >= 0; i--) {
            history.add(observations.get(i).observation());
        }
        ReplayDataset.ReplayObservation origin = observations.get(originIndex);
        return new DigitalTwinSnapshot(
                origin.nodeId(),
                "replay", 0, "replay",
                origin.observationTimestamp(), origin.observationTimestamp(), 0L,
                origin.observation(),
                Collections.unmodifiableList(history),
                origin.observationTimestamp(),
                0L,
                BeliefState.UNINITIALIZED);
    }

    /**
     * @return the unit in which a resource is measured. Units are never mixed
     * across resources in a combined figure.
     */
    public static String unitFor(ForecastableResource resource) {
        return switch (resource) {
            case CPU_UTILIZATION_PERCENT, MEMORY_UTILIZATION_PERCENT,
                 BATTERY_LEVEL_PERCENT, NETWORK_PACKET_LOSS_PERCENT -> "percent";
            case NETWORK_LATENCY_MS -> "milliseconds";
        };
    }

    /**
     * Content fingerprint of the evaluated observations, so two runs can be
     * compared for equivalence without trusting wall-clock timestamps.
     */
    private static String fingerprint(ReplayDataset.LoadedDataset dataset) {
        long hash = 1125899906842597L;
        for (String key : dataset.groupKeys()) {
            for (ReplayDataset.ReplayObservation o : dataset.group(key)) {
                hash = 31L * hash + o.observationTimestamp();
                hash = 31L * hash + (o.telemetrySequence() == null ? 0L : o.telemetrySequence());
                hash = 31L * hash + (o.observation() == null ? 0L : o.observation().hashCode());
            }
        }
        return "obs-" + Long.toUnsignedString(hash, 16);
    }
}