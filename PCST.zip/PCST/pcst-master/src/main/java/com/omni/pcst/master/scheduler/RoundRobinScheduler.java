package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.reliability.ReliabilityStatus;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Round-robin scheduler that cycles through eligible candidates in order.
 * <p>
 * Baseline policy for scientific comparison with PCST.
 * Respects hard constraints (eligibility) but does not model
 * capability or reliability. Every eligible candidate is equally
 * valid; selection cycles through them in order.
 * </p>
 * <p>
 * Deterministic: selects candidates in fixed order; no randomness.
 * The first call selects the first eligible candidate, the next
 * call selects the second, wrapping around at the end.
 * </p>
 * <p>
 * Tie-breaking: when the eligible set has multiple candidates and the
 * rotation index points to a position, the candidate at that position
 * in sorted node-ID order is selected. This ensures deterministic
 * behaviour when capabilities are equal (which is the common case
 * for this capability-agnostic policy).
 * </p>
 */
public final class RoundRobinScheduler implements Scheduler {

    private final List<String> selectedOrder = new ArrayList<>();
    private int nextIndex = 0;

    @Override
    public SchedulingDecision select(Task task, long decisionTimeMillis,
                                     Collection<SchedulingCandidate> candidates) {
        // Filter to eligible candidates only
        List<SchedulingCandidate> eligible = candidates.stream()
                .filter(c -> c.eligible())
                .collect(Collectors.toList());

        if (eligible.isEmpty()) {
            // No eligible candidates
            return new SchedulingDecision(
                    task.taskId(), decisionTimeMillis,
                    SchedulingStatus.NO_FEASIBLE_NODE, null, null, null, false,
                    List.of(),
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no candidate passed hard eligibility; feasible set F_t(tau) is empty");
        }

        // Deduplicate by node id, preserving first occurrence order
        LinkedHashMap<String, SchedulingCandidate> byNodeId = new LinkedHashMap<>();
        for (SchedulingCandidate c : eligible) {
            byNodeId.putIfAbsent(c.nodeId(), c);
        }
        List<SchedulingCandidate> uniqueEligible = new ArrayList<>(byNodeId.values());

        // Advance rotation state and select
        // On first use, sort by node ID for deterministic tie-breaking
        if (selectedOrder.isEmpty()) {
            selectedOrder.clear();
            for (SchedulingCandidate c : uniqueEligible) {
                selectedOrder.add(c.nodeId());
            }
            Collections.sort(selectedOrder);
        }
        nextIndex = nextIndex % selectedOrder.size();
        String selectedNodeId = selectedOrder.get(nextIndex);
        nextIndex++;

        // Build candidate trace: all eligible candidates get a disposition
        List<CandidateDecision> trace = new ArrayList<>(uniqueEligible.size());
        for (SchedulingCandidate c : uniqueEligible) {
            boolean isSelected = c.nodeId().equals(selectedNodeId);
            // Access reliability via accessor methods (per SchedulingCandidate record components)
            ReliabilityStatus relStatus = c.reliability().status();
            // Access capability status via accessor method
            String capStatus = c.reliability().capabilityStatus();
            // Access capability probability via accessor method
            Double capValue = c.capability() == null ? null : c.capability().capability();
            trace.add(new CandidateDecision(
                    c.nodeId(), c.eligible(),
                    isSelected ? CandidateDisposition.SELECTED
                            : CandidateDisposition.LOWER_RELIABILITY,
                    c.eligibility().reasons(),
                    relStatus,
                    c.reliability().reliability(),
                    capStatus,
                    capValue,
                    isSelected ? "selected by round-robin policy"
                            : "eligible but not selected by round-robin rotation"
            ));
        }

        // Compute max reliability among eligible candidates
        Double maxReliability = eligible.stream()
                .map(c -> c.reliability().reliability())
                .max(Double::compare)
                .orElse(null);

        List<SchedulingReason> reasons = new ArrayList<>();
        reasons.add(SchedulingReason.SELECTED_HIGHEST_RELIABILITY);
        reasons.add(SchedulingReason.NO_POLICY_THRESHOLD_CONFIGURED);

        String derivation = "selected node " + selectedNodeId + " via round-robin rotation "
                + "(policy does not rank by reliability; all eligible candidates are equally valid)";

        return new SchedulingDecision(
                task.taskId(), decisionTimeMillis,
                SchedulingStatus.SELECTED,
                selectedNodeId, maxReliability, null, false,
                trace, reasons, derivation);
    }
}