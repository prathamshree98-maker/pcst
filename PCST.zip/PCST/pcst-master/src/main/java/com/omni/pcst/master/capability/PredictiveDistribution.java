package com.omni.pcst.master.capability;

import java.util.Objects;

/**
 * A Gaussian predictive distribution over a resource's value, together with a
 * record of where it came from and under which assumptions.
 *
 * <p>Provenance is part of the type on purpose. Capability probabilities are only
 * as good as the distribution they are computed from, so every distribution names
 * its source and states its assumption in human-readable form rather than being
 * an anonymous pair of numbers.
 *
 * @param mean      predictive mean
 * @param variance  predictive variance; must be finite and strictly positive
 * @param source    stable identifier of the distribution source
 * @param assumption the modeling assumption that makes this distribution the
 *                   predictive law for the execution interval
 */
public record PredictiveDistribution(
        double mean,
        double variance,
        String source,
        String assumption) {

    public PredictiveDistribution {
        Objects.requireNonNull(source, "source");
        assumption = assumption == null ? "" : assumption;
        if (!Double.isFinite(mean)) {
            throw new IllegalArgumentException("mean must be finite (was " + mean + ")");
        }
        if (!(variance > 0.0) || !Double.isFinite(variance)) {
            throw new IllegalArgumentException(
                    "variance must be finite and > 0 (was " + variance + ")");
        }
    }

    /** @return the standard deviation of the predictive distribution */
    public double standardDeviation() {
        return Math.sqrt(variance);
    }
}
