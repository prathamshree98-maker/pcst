package com.omni.pcst.master.digitaltwin;

import java.util.List;

/**
 * Immutable point-in-time view of one node's Digital Twin.
 *
 * <p>Returned by {@link DigitalTwinManager#getSnapshot(String)} for future
 * consumers (scheduler, UI). All fields are plain values or immutable objects;
 * the history is a copy, so callers can never mutate twin state.
 *
 * @param nodeId stable node identifier
 * @param hostname hostname from the latest accepted registration
 * @param port node port from the latest accepted registration
 * @param agentVersion agent version from the latest accepted registration
 * @param registeredAtMillis Master clock time of the first accepted registration
 * @param lastRegistrationMillis Master clock time of the latest accepted (re-)registration
 * @param lastHeartbeatMillis Master clock time of the last accepted heartbeat (0 if none)
 * @param latestObservation latest accepted raw observation ({@code null} if none yet)
 * @param observationHistory bounded history of recent observations, newest first
 * @param lastTelemetryReceivedAtMillis Master clock time the latest observation was received
 * @param staleObservationsRejected number of observations rejected as stale/out-of-order
 * @param beliefState probabilistic belief state; {@link BeliefState#UNINITIALIZED}
 *         until the first accepted observation is processed by the Bayesian engine
 */
public record DigitalTwinSnapshot(
        String nodeId,
        String hostname,
        int port,
        String agentVersion,
        long registeredAtMillis,
        long lastRegistrationMillis,
        long lastHeartbeatMillis,
        TelemetryObservation latestObservation,
        List<TelemetryObservation> observationHistory,
        long lastTelemetryReceivedAtMillis,
        long staleObservationsRejected,
        BeliefState beliefState) {
}
