package com.omni.pcst.master.execution;

import com.omni.pcst.master.task.Task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

/**
 * In-memory registry of task execution records.
 *
 * <p>Thread-safe using a concurrent map. All mutations return new immutable
 * {@link TaskRecord} snapshots; the registry itself holds a mutable reference
 * to the current snapshot for each taskId.
 *
 * <p>State is lost on Master restart; tasks are not persisted. Active when
 * {@code pcst.persistence.jdbc.enabled} is false or absent (the default).
 */
@Component
@ConditionalOnProperty(name = "pcst.persistence.jdbc.enabled", havingValue = "false", matchIfMissing = true)
public class InMemoryTaskRegistry implements TaskRegistry {

    private static final Logger log = LoggerFactory.getLogger(InMemoryTaskRegistry.class);

    private final ConcurrentMap<String, TaskRecord> tasks = new ConcurrentHashMap<>();

    /**
     * Creates a new task record in the ACCEPTED state.
     *
     * @param task the submitted task
     * @param now  server timestamp
     * @return the created record
     * @throws IllegalArgumentException if a task with the same taskId already exists
     */
    @Override
    public TaskRecord create(Task task, long now) {
        String attemptId = UUID.randomUUID().toString();
        TaskRecord record = TaskRecord.createAccepted(task, attemptId, now);
        TaskRecord existing = tasks.putIfAbsent(task.taskId(), record);
        if (existing != null) {
            throw new IllegalArgumentException("Task with taskId " + task.taskId() + " already exists");
        }
        return record;
    }

    /**
     * Atomically updates a task record using a function.
     *
     * @param taskId the task identifier
     * @param updater a function from current record to new record; may return
     *               the same record to indicate no change
     * @return the new record, or empty if taskId not found
     */
    @Override
    public Optional<TaskRecord> update(String taskId, java.util.function.Function<TaskRecord, TaskRecord> updater) {
        int maxRetries = 3;
        while (maxRetries >= 0) {
            TaskRecord current = tasks.get(taskId);
            if (current == null) {
                return Optional.empty();
            }
            TaskRecord updated = updater.apply(current);
            if (updated == current) {
                return Optional.of(current);
            }
            if (tasks.replace(taskId, current, updated)) {
                return Optional.of(updated);
            }
            maxRetries--;
            if (maxRetries == 0) {
                log.warn("Failed to update task record after 3 retries: taskId={}", taskId);
                return Optional.empty();
            }
        }
        return Optional.empty();
    }

    /**
     * @return the current snapshot for a taskId, or empty if not found
     */
    @Override
    public Optional<TaskRecord> get(String taskId) {
        return Optional.ofNullable(tasks.get(taskId));
    }

    /** @return all current task records */
    @Override
    public Collection<TaskRecord> all() {
        return tasks.values();
    }

    /** @return count of tracked tasks */
    @Override
    public int size() {
        return tasks.size();
    }

    /** Removes a task record (for testing/cleanup). */
    @Override
    public void remove(String taskId) {
        tasks.remove(taskId);
    }

    /** Returns tasks in a specific state. */
    @Override
    public List<TaskRecord> tasksInState(TaskState state) {
        return tasks.values().stream()
                .filter(t -> t.state() == state)
                .collect(Collectors.toList());
    }
}
