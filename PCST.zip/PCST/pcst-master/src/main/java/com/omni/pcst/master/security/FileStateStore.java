package com.omni.pcst.master.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Durable file-based store for enrollment state.
 *
 * <p>State is serialized to JSON and written to a single file. When an
 * encryption passphrase is configured, the file contents are encrypted with
 * AES-256-GCM using a key derived from the passphrase via PBKDF2-SHA-256, so
 * device credentials are never stored in plaintext on disk.
 *
 * <h2>Failure semantics</h2>
 * <ul>
 *   <li>No state file exists: returns an empty snapshot (first startup).</li>
 *   <li>State file exists but cannot be read (permissions, I/O): throws
 *       {@link StateStoreException} so the Master fails startup rather than
 *       silently starting with empty enrollment state.</li>
 *   <li>State file exists but is corrupt, truncated, or encrypted with a
 *       different passphrase: throws {@link StateStoreException}. A partially
 *       loaded state is never accepted.</li>
 *   <li>State file is empty (zero bytes): returns an empty snapshot. This can
 *       occur if a previous write was interrupted before any bytes were written.</li>
 * </ul>
 *
 * <p>Writes use atomic file replacement (temp file + move) so a crash never
 * leaves a partial state file. Writes are serialized through an internal lock.
 */
public class FileStateStore {

    private static final Logger log = LoggerFactory.getLogger(FileStateStore.class);

    private static final int GCM_TAG_BITS = 128;
    private static final int IV_BYTES = 12;
    private static final int PBKDF2_ITERATIONS = 100_000;
    private static final int KEY_BITS = 256;
    private static final byte FORMAT_VERSION = 1;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final Path path;
    private final SecretKey key; // null when encryption is not configured
    private final ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    private final java.util.concurrent.locks.ReentrantLock writeLock = new java.util.concurrent.locks.ReentrantLock();

    /**
     * Thrown when the state store cannot be loaded or saved. The Master must
     * treat this as a fatal startup condition rather than proceeding with
     * incomplete enrollment state.
     */
    public static class StateStoreException extends RuntimeException {
        public StateStoreException(String message, Throwable cause) {
            super(message, cause);
        }
        public StateStoreException(String message) {
            super(message);
        }
    }

    /**
     * @param path        file path for persistence
     * @param passphrase  encryption passphrase, or null/blank to store plaintext
     */
    public FileStateStore(Path path, String passphrase) {
        this.path = path;
        this.key = (passphrase == null || passphrase.isBlank())
                ? null
                : deriveKey(passphrase);
        mapper.findAndRegisterModules();
    }

    /**
     * Loads the persisted snapshot.
     *
     * @return the loaded snapshot, or empty when no state file exists or it is
     *         zero bytes (first startup).
     * @throws StateStoreException when the file exists but cannot be read, is
     *         corrupt/truncated, uses an unsupported format version, or cannot
     *         be decrypted (wrong passphrase or authentication-tag failure).
     */
    public StateSnapshot load() {
        if (!Files.isRegularFile(path)) {
            log.debug("State file does not exist: {}", path);
            return StateSnapshot.empty();
        }

        byte[] data;
        try {
            data = Files.readAllBytes(path);
        } catch (Exception e) {
            throw new StateStoreException(
                    "Could not read state file " + path + ": " + e.getMessage(), e);
        }

        if (data.length == 0) {
            log.debug("State file is empty: {}", path);
            return StateSnapshot.empty();
        }

        try {
            if (key != null) {
                data = decrypt(data);
            }
            String json = new String(data, StandardCharsets.UTF_8);
            StateSnapshot snapshot = mapper.readValue(json, StateSnapshot.class);
            if (snapshot == null) {
                throw new StateStoreException("State file " + path + " parsed to null");
            }
            return snapshot;
        } catch (StateStoreException e) {
            throw e;
        } catch (Exception e) {
            throw new StateStoreException(
                    "Could not parse state file " + path + " (corrupt, truncated, or "
                            + "encrypted with a different passphrase): " + e.getMessage(), e);
        }
    }

    /**
     * Persists the given snapshot to the file. Writes to a temporary file then
     * atomically replaces the target, so a crash never leaves a partial file.
     *
     * @param snapshot the snapshot to persist
     * @throws StateStoreException when the file cannot be written (fail closed)
     */
    public void save(StateSnapshot snapshot) {
        writeLock.lock();
        try {
            byte[] jsonBytes;
            try {
                String json = mapper.writeValueAsString(snapshot);
                jsonBytes = json.getBytes(StandardCharsets.UTF_8);
            } catch (JsonProcessingException e) {
                throw new StateStoreException("Could not serialize state snapshot: "
                        + e.getMessage(), e);
            }

            byte[] outBytes = (key != null) ? encrypt(jsonBytes) : jsonBytes;

            Path parent = path.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Path temp = path.resolveSibling(path.getFileName() + ".tmp." + System.nanoTime());
            try {
                Files.write(temp, outBytes, StandardOpenOption.CREATE,
                        StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
                Files.move(temp, path, java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                // Restrictive permissions on POSIX systems
                try {
                    java.util.Set<java.nio.file.attribute.PosixFilePermission> perms =
                            java.util.Set.of(
                                    java.nio.file.attribute.PosixFilePermission.OWNER_READ,
                                    java.nio.file.attribute.PosixFilePermission.OWNER_WRITE);
                    Files.setPosixFilePermissions(path, perms);
                } catch (UnsupportedOperationException e) {
                    // Windows or non-POSIX filesystem: best effort
                }
                log.debug("State persisted to {} (encrypted={})", path, key != null);
            } finally {
                if (Files.isRegularFile(temp)) {
                    try {
                        Files.delete(temp);
                    } catch (Exception e) {
                        log.debug("Could not delete temp state file {}: {}", temp,
                                e.getMessage());
                    }
                }
            }
        } catch (StateStoreException e) {
            throw e;
        } catch (Exception e) {
            throw new StateStoreException("Could not persist state to " + path + ": "
                    + e.getMessage(), e);
        } finally {
            writeLock.unlock();
        }
    }

    /* ---------------------------------------------------------------- encryption */

    private SecretKey deriveKey(String passphrase) {
        try {
            byte[] salt = readOrCreateSalt();
            KeySpec spec = new PBEKeySpec(passphrase.toCharArray(), salt, PBKDF2_ITERATIONS,
                    KEY_BITS);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            SecretKey tmp = factory.generateSecret(spec);
            return new javax.crypto.spec.SecretKeySpec(tmp.getEncoded(), "AES");
        } catch (Exception e) {
            throw new StateStoreException("Could not derive encryption key: "
                    + e.getMessage(), e);
        }
    }

    private byte[] readOrCreateSalt() {
        Path saltFile = path.resolveSibling(path.getFileName() + ".salt");
        if (Files.isRegularFile(saltFile)) {
            try {
                return Files.readAllBytes(saltFile);
            } catch (Exception e) {
                throw new StateStoreException("Could not read salt file " + saltFile
                        + ": " + e.getMessage(), e);
            }
        }
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        try {
            Path parent = saltFile.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.write(saltFile, salt, StandardOpenOption.CREATE,
                    StandardOpenOption.WRITE);
            try {
                java.util.Set<java.nio.file.attribute.PosixFilePermission> perms =
                        java.util.Set.of(
                                java.nio.file.attribute.PosixFilePermission.OWNER_READ,
                                java.nio.file.attribute.PosixFilePermission.OWNER_WRITE);
                Files.setPosixFilePermissions(saltFile, perms);
            } catch (UnsupportedOperationException e) {
                // best effort
            }
        } catch (Exception e) {
            throw new StateStoreException("Could not write salt file " + saltFile
                    + ": " + e.getMessage(), e);
        }
        return salt;
    }

    private byte[] encrypt(byte[] plaintext) {
        try {
            byte[] iv = new byte[IV_BYTES];
            RANDOM.nextBytes(iv);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
            byte[] ciphertext = cipher.doFinal(plaintext);
            byte[] out = new byte[1 + IV_BYTES + ciphertext.length];
            out[0] = FORMAT_VERSION; // format version byte
            System.arraycopy(iv, 0, out, 1, IV_BYTES);
            System.arraycopy(ciphertext, 0, out, 1 + IV_BYTES, ciphertext.length);
            return out;
        } catch (Exception e) {
            throw new StateStoreException("Could not encrypt state: " + e.getMessage(), e);
        }
    }

    private byte[] decrypt(byte[] data) {
        try {
            if (data.length < 1 + IV_BYTES) {
                throw new IllegalArgumentException("Encrypted data too short");
            }
            int version = data[0] & 0xFF;
            if (version != FORMAT_VERSION) {
                throw new IllegalArgumentException(
                        "Unsupported encrypted format version: " + version);
            }
            byte[] iv = new byte[IV_BYTES];
            System.arraycopy(data, 1, iv, 0, IV_BYTES);
            byte[] ciphertext = new byte[data.length - 1 - IV_BYTES];
            System.arraycopy(data, 1 + IV_BYTES, ciphertext, 0, ciphertext.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
            return cipher.doFinal(ciphertext);
        } catch (Exception e) {
            throw new StateStoreException("Could not decrypt state: " + e.getMessage(), e);
        }
    }
}
