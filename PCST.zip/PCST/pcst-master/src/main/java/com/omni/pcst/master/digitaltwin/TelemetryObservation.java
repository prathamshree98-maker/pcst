package com.omni.pcst.master.digitaltwin;

import com.omni.pcst.proto.TelemetryRequest;

/**
 * Immutable raw telemetry observation held by the Master for one node.
 *
 * <p>This is a <b>raw observation</b>: it contains exactly what the Node Agent
 * reported, nothing more. No probabilities, predictions, confidence scores, or
 * reliability scores belong here — those will live in the separate belief state
 * populated by a future Bayesian update engine.
 *
 * <p>Missing measurements are represented by {@code null} (boxed types), which
 * keeps them distinct from legitimate zero values. For example a node without a
 * GPU reports {@code gpuUtilizationPercent = null}, never {@code 0.0}.
 *
 * <p>Instances are created from the protobuf request via {@link #from(TelemetryRequest)};
 * the proto contract marks genuinely optional measurements with explicit presence
 * ({@code optional} fields) so absence on the wire maps to {@code null} here.
 */
public record TelemetryObservation(
        long timestamp,
        Double cpuUtilizationPercent,
        Long totalMemoryBytes,
        Long usedMemoryBytes,
        Long availableMemoryBytes,
        Boolean gpuAvailable,
        Double gpuUtilizationPercent,
        Double batteryLevelPercent,
        Boolean batteryCharging,
        Double temperatureCelsius,
        Double latencyMs,
        Double packetLossPercent,
        Long totalDiskBytes,
        Long freeDiskBytes,
        Integer processCount,
        Boolean userActive) {

    /**
     * Maps a protobuf telemetry request to an immutable observation.
     *
     * <p>Fields the agent omitted (no explicit presence on the wire) become
     * {@code null}; fields the agent sent — including explicit zeros — keep their
     * values. CPU, memory, disk and process count are always sent by the agent
     * and are therefore always non-null in practice.
     */
    public static TelemetryObservation from(TelemetryRequest request) {
        return new TelemetryObservation(
                request.getTimestamp(),
                request.getCpu().getUtilizationPercent(),
                request.getMemory().getTotalBytes(),
                request.getMemory().getUsedBytes(),
                request.getMemory().getAvailableBytes(),
                request.getGpu().getAvailable(),
                request.getGpu().hasUtilizationPercent() ? request.getGpu().getUtilizationPercent() : null,
                request.hasBattery() && request.getBattery().hasLevelPercent()
                        ? request.getBattery().getLevelPercent() : null,
                request.hasBattery() && request.getBattery().hasCharging()
                        ? request.getBattery().getCharging() : null,
                request.hasTemperature() && request.getTemperature().hasCelsius()
                        ? request.getTemperature().getCelsius() : null,
                request.hasNetwork() && request.getNetwork().hasLatencyMs()
                        ? request.getNetwork().getLatencyMs() : null,
                request.hasNetwork() && request.getNetwork().hasPacketLossPercent()
                        ? request.getNetwork().getPacketLossPercent() : null,
                request.getDisk().getTotalBytes(),
                request.getDisk().getFreeBytes(),
                request.getProcesses().getProcessCount(),
                request.hasUserState() ? request.getUserState().getActive() : null);
    }
}
