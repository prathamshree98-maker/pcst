package com.omni.pcst.master.evaluation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Wires the evaluation-telemetry store into the Master Spring context.
 *
 * <p>Lifecycle:
 * <ul>
 *   <li>The store is created by {@link #telemetryEvaluationStore()} and is the
 *       single store bean in the context. Its destroy method is disabled on the
 *       bean declaration; shutdown is owned by this configuration's
 *       {@link DisposableBean#destroy()} so that draining, result reporting and
 *       lock release happen in one place.</li>
 *   <li>{@link #periodicFlush()} is a {@code @Scheduled} method on this Spring
 *       bean, so scheduling works whenever {@code @EnableScheduling} is active
 *       (declared on {@code PcstMasterApplication}).</li>
 *   <li>Shutdown stops periodic flushing, closes the store (draining the queue),
 *       reports whether draining succeeded, and releases the writer lock.</li>
 * </ul>
 *
 * <p>No durability is claimed when a write fails: failures are counted and
 * surfaced through {@link TelemetryEvaluationDiagnostics} and the logs.
 */
@Configuration
@EnableConfigurationProperties(TelemetryEvaluationProperties.class)
public class TelemetryEvaluationStoreConfig implements DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(TelemetryEvaluationStoreConfig.class);

    private final TelemetryEvaluationProperties properties;
    private volatile TelemetryEvaluationStore store;
    private volatile boolean shuttingDown = false;

    public TelemetryEvaluationStoreConfig(TelemetryEvaluationProperties properties) {
        this.properties = properties;
    }

    /**
     * Creates the single evaluation store. The bean is absent when
     * {@code pcst.evaluation.enabled=false}; in that case the Digital Twin
     * continues to process telemetry but nothing is persisted.
     */
    @Bean(destroyMethod = "")
    @ConditionalOnProperty(prefix = "pcst.evaluation", name = "enabled", havingValue = "true", matchIfMissing = true)
    public TelemetryEvaluationStore telemetryEvaluationStore() {
        properties.validate();
        Path outputPath = Paths.get(properties.getPath()).toAbsolutePath().normalize();
        try {
            Path parent = outputPath.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
        } catch (IOException e) {
            throw new IllegalStateException(
                    "Cannot create telemetry evaluation output directory for " + outputPath, e);
        }

        TelemetryEvaluationStore created = new TelemetryEvaluationStore(
                outputPath,
                properties.getFlushLimit(),
                properties.getQueueCapacity(),
                properties.isFileLocking());
        this.store = created;
        log.info("Telemetry evaluation store initialised: path={} flushLimit={} queueCapacity={} "
                        + "flushIntervalMs={} fileLocking={}",
                outputPath, properties.getFlushLimit(), properties.getQueueCapacity(),
                properties.getFlushIntervalMs(), properties.isFileLocking());
        return created;
    }

    /**
     * Periodic flush of queued records. Uses the configured interval with a
     * fixed delay so a slow flush never overlaps the next one. No-op while
     * shutting down or when persistence is disabled.
     */
    @Scheduled(fixedDelayString = "${pcst.evaluation.flush-interval-ms:30000}")
    public void periodicFlush() {
        TelemetryEvaluationStore current = store;
        if (shuttingDown || current == null) {
            return;
        }
        try {
            current.flush();
        } catch (RuntimeException e) {
            log.error("Periodic telemetry evaluation flush failed: {}", e.getMessage(), e);
        }
    }

    /**
     * Stops periodic flushing, drains the queue by closing the store, reports
     * whether draining succeeded, and releases the writer lock.
     */
    @Override
    public void destroy() {
        shuttingDown = true;
        TelemetryEvaluationStore current = store;
        if (current == null) {
            log.info("Telemetry evaluation store was not created (persistence disabled or never initialised)");
            return;
        }
        log.info("Shutting down telemetry evaluation store...");
        current.close();
        int retained = current.getQueueSize();
        if (retained > 0) {
            log.error("Telemetry evaluation shutdown could NOT drain {} queued record(s); last error: {}",
                    retained, current.getLastWriteError());
        } else {
            log.info("Telemetry evaluation shutdown drained all queued records "
                            + "(accepted={} persisted={} rejected={} flushFailures={})",
                    current.getAcceptedRecords(), current.getPersistedRecords(),
                    current.getRejectedRecords(), current.getFlushFailures());
        }
    }

    /** @return the store bean, or null when persistence is disabled */
    public TelemetryEvaluationStore getStore() {
        return store;
    }

    /**
     * @return the bound evaluation configuration, including the collection
     * configuration provenance recorded on every persisted record.
     */
    public TelemetryEvaluationProperties getProperties() {
        return properties;
    }

    @Bean
    public TelemetryEvaluationDiagnostics telemetryEvaluationDiagnostics() {
        return new TelemetryEvaluationDiagnostics(this);
    }

    /**
     * Read-only diagnostics facade over the store's thread-safe counters.
     * "Accepted" never implies "persisted".
     */
    public static class TelemetryEvaluationDiagnostics {

        private final TelemetryEvaluationStoreConfig config;

        public TelemetryEvaluationDiagnostics(TelemetryEvaluationStoreConfig config) {
            this.config = config;
        }

        /** Records accepted by the store (queued), not necessarily on disk. */
        public long getAcceptedCount() {
            return config.store == null ? 0 : config.store.getAcceptedRecords();
        }

        /** Records confirmed written to disk. */
        public long getPersistedCount() {
            return config.store == null ? 0 : config.store.getPersistedRecords();
        }

        /** Records rejected because the queue was full or the store was closed. */
        public long getRejectedCount() {
            return config.store == null ? 0 : config.store.getRejectedRecords();
        }

        /** Number of failed flush attempts. */
        public long getFlushFailures() {
            return config.store == null ? 0 : config.store.getFlushFailures();
        }

        /** Current number of queued (unpersisted) records. */
        public long getQueuedCount() {
            return config.store == null ? 0 : config.store.getQueueSize();
        }

        /** Last flush/write error message, or null. */
        public String getLastWriteError() {
            return config.store == null ? null : config.store.getLastWriteError();
        }

        /**
         * Lines skipped by the most recent read because they were malformed or
         * carried an unknown schema version. A non-zero value means the log
         * contains data that must not be replayed.
         */
        public long getMalformedLinesSkipped() {
            return config.store == null ? 0L : config.store.getLastReadSkippedLines();
        }

        /** Backward-compatible alias for {@link #getRejectedCount()}. */
        public int getRejectedAppends() {
            return (int) getRejectedCount();
        }
    }
}
