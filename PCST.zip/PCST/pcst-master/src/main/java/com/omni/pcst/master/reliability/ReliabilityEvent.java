package com.omni.pcst.master.reliability;

/**
 * The named events whose intersection defines task-success, from specification
 * section 9:
 *
 * <pre>
 *   Esucc = Eresource &cap; Edeadline &cap; Eenergy &cap; EQoS &cap; Estability
 * </pre>
 *
 * <p>Each event is part of a task's success contract <b>only when the task
 * expresses the corresponding requirement</b> (specification section 9: "Security
 * or other requirements should be added only when they are part of the task's
 * success contract"). An event the task never mentions is reported as
 * {@code required == false} and contributes nothing to the intersection.
 *
 * <p>{@link #RESOURCE} is the one event the capability stage evaluates; it is
 * always part of the contract (possibly vacuously, when the task states no
 * resource conditions). The remaining events have no predictive model on the
 * current node model and are reported, never guessed.
 */
public enum ReliabilityEvent {

    /** {@code Eresource}: every required resource condition holds over the interval. */
    RESOURCE("Eresource", "the task's required resource conditions hold over its execution interval"),

    /** {@code Edeadline}: the task completes before its deadline. */
    DEADLINE("Edeadline", "the task completes before its deadline"),

    /** {@code Eenergy}: the node keeps enough energy for the whole task. */
    ENERGY("Eenergy", "the node retains enough energy to finish the task"),

    /** {@code EQoS}: the task's quality-of-service / compatibility target is met. */
    QOS("EQoS", "the task's quality-of-service or compatibility target is met"),

    /** {@code Estability}: the node stays stable and uninterrupted for the whole task. */
    STABILITY("Estability", "the node stays stable and uninterrupted for the whole task");

    private final String label;
    private final String description;

    ReliabilityEvent(String label, String description) {
        this.label = label;
        this.description = description;
    }

    /** @return the specification symbol, e.g. {@code "Edeadline"} */
    public String label() {
        return label;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
