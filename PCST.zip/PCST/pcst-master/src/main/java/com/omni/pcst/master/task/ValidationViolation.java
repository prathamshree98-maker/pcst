package com.omni.pcst.master.task;

import java.util.List;

/**
 * A single identified reason why a task value is invalid.
 *
 * @param field  dotted path of the offending field, e.g.
 *               {@code resources.requiredMemoryBytes}
 * @param reason human-readable explanation; never used programmatically
 */
public record ValidationViolation(String field, String reason) {

    public ValidationViolation {
        field = (field == null || field.isBlank()) ? "<unknown>" : field;
        reason = (reason == null || reason.isBlank()) ? "invalid value" : reason;
    }

    @Override
    public String toString() {
        return field + ": " + reason;
    }
}