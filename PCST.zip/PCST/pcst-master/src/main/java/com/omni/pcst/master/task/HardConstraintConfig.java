package com.omni.pcst.master.task;

/**
 * Configuration of the hard-constraint filter.
 *
 * @param maxEvidenceAgeMillis how old the latest observation may be before it is
 *                            treated as stale evidence. Stale evidence never
 *                            proves satisfaction or violation; affected
 *                            constraints become
 *                            {@link ConstraintOutcome#INDETERMINATE}.
 * @param indeterminatePolicy what to do with a constraint that cannot be decided
 */
public record HardConstraintConfig(long maxEvidenceAgeMillis,
                                   IndeterminatePolicy indeterminatePolicy) {

    /**
     * Default maximum evidence age.
     *
     * <p><b>This is an engineering approximation, not a specification-derived
     * constant.</b> Specification section 4.1 explicitly allows a conservative
     * maximum-age gate for V1 and states that such a gate is an engineering
     * approximation rather than the full mathematical solution. The default is
     * set to three times the Node Agent's default 5 s telemetry interval, which is
     * a deliberately forgiving value: it tolerates one missed cycle without
     * rejecting an otherwise healthy node. Deployments with a different sampling
     * interval must override it; nothing in the current node model derives a
     * freshness threshold automatically.
     */
    public static final long DEFAULT_MAX_EVIDENCE_AGE_MILLIS = 15_000L;

    public HardConstraintConfig {
        if (maxEvidenceAgeMillis < 0L) {
            throw new IllegalArgumentException(
                    "maxEvidenceAgeMillis must be >= 0 (was " + maxEvidenceAgeMillis + ")");
        }
        if (indeterminatePolicy == null) {
            throw new IllegalArgumentException("indeterminatePolicy must not be null");
        }
    }

    /** Conservative default: unproven constraints exclude a node. */
    public static HardConstraintConfig defaults() {
        return new HardConstraintConfig(DEFAULT_MAX_EVIDENCE_AGE_MILLIS,
                IndeterminatePolicy.REJECT);
    }

    public static HardConstraintConfig withMaxEvidenceAgeMillis(long millis) {
        return new HardConstraintConfig(millis, IndeterminatePolicy.REJECT);
    }

    public static HardConstraintConfig of(long maxEvidenceAgeMillis,
                                          IndeterminatePolicy policy) {
        return new HardConstraintConfig(maxEvidenceAgeMillis, policy);
    }
}