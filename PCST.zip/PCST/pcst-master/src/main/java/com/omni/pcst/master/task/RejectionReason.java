package com.omni.pcst.master.task;

/**
 * Stable reason codes explaining why a candidate was not accepted.
 *
 * <p>Codes are the programmatic contract; the accompanying description is for
 * humans only. Callers must branch on the enum, never on message text.
 *
 * <p>Each code states whether it is a <b>proven</b> violation or an
 * <b>unproven</b> (indeterminate) condition, so a caller can distinguish "this
 * node cannot do it" from "we cannot tell yet".
 */
public enum RejectionReason {

    /** Valid evidence shows available memory below the task's demand. PROVEN. */
    MEMORY_INSUFFICIENT(false, "available memory is below the task requirement"),

    /** Valid evidence shows free storage below the task's demand. PROVEN. */
    STORAGE_INSUFFICIENT(false, "free storage is below the task requirement"),

    /** The task requires an accelerator and the node reports none. PROVEN. */
    ACCELERATOR_ABSENT(false, "task requires an accelerator and the node reports none"),

    /** Accelerator memory cannot be evidenced: no device-memory field exists. UNPROVEN. */
    ACCELERATOR_MEMORY_UNVERIFIABLE(true,
            "no accelerator device-memory capacity is exposed by the current node model"),

    /** Compute capacity cannot be evidenced: utilization is load, not capacity. UNPROVEN. */
    COMPUTE_CAPACITY_UNVERIFIABLE(true,
            "benchmark-normalized compute capacity is not exposed; utilization is load, not capacity"),

    /** The deadline cannot be met given the task's own duration. PROVEN. */
    DEADLINE_INFEASIBLE(false, "task duration cannot fit before its deadline"),

    /** The deadline cannot be assessed because the task states no duration. UNPROVEN. */
    DEADLINE_UNVERIFIABLE(true, "task expresses a deadline but no expected duration"),

    /** Valid evidence shows battery level below the task's minimum. PROVEN. */
    BATTERY_BELOW_MINIMUM(false, "observed battery level is below the task minimum"),

    /** No battery observation is available. UNPROVEN. */
    BATTERY_UNKNOWN(true, "no battery observation is available for this node"),

    /** Valid evidence shows latency above the task's maximum. PROVEN. */
    NETWORK_LATENCY_EXCEEDED(false, "observed network latency exceeds the task maximum"),

    /** No latency observation is available. UNPROVEN. */
    NETWORK_LATENCY_UNKNOWN(true, "no network latency observation is available for this node"),

    /** Valid evidence shows packet loss above the task's maximum. PROVEN. */
    PACKET_LOSS_EXCEEDED(false, "observed packet loss exceeds the task maximum"),

    /** No packet-loss observation is available. UNPROVEN. */
    PACKET_LOSS_UNKNOWN(true, "no packet loss observation is available for this node"),

    /** The execution profile cannot be compared: the node model exposes none. UNPROVEN. */
    EXECUTION_PROFILE_UNVERIFIABLE(true,
            "node model does not expose an execution profile to compare against"),

    /** The latest observation is older than the configured maximum evidence age. UNPROVEN. */
    STALE_EVIDENCE(true, "the latest observation is older than the configured evidence age"),

    /** The node has no observation at all. UNPROVEN. */
    NO_OBSERVATION(true, "node has never reported telemetry"),

    /** The node id is not registered. PROVEN. */
    NODE_UNKNOWN(false, "node id is not registered with the Master"),

    /** The candidate snapshot could not be evaluated; other candidates are unaffected. UNPROVEN. */
    EVALUATION_ERROR(true, "candidate could not be evaluated");

    private final boolean indeterminate;
    private final String description;

    RejectionReason(boolean indeterminate, String description) {
        this.indeterminate = indeterminate;
        this.description = description;
    }

    /**
     * @return true when this reason reflects missing or stale evidence rather
     * than a proven violation of a hard constraint
     */
    public boolean isIndeterminate() {
        return indeterminate;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}