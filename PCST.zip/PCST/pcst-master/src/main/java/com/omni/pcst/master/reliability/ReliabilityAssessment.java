package com.omni.pcst.master.reliability;

import java.util.List;
import java.util.Objects;

/**
 * Overall completion-reliability assessment for one task on one candidate node:
 * {@code R(n, τ) = P(Esucc | I_t, assignment τ → n)} with
 * {@code Esucc = Eresource ∩ Edeadline ∩ Eenergy ∩ EQoS ∩ Estability}.
 *
 * <p>This is a probability and its diagnostics, never a weighted resource score
 * and never a copy of capability. When the overall probability is not defined the
 * {@link #reliability} field is {@code null} and {@link #status} and
 * {@link #reasons} explain why; the per-event account remains available for
 * inspection.
 *
 * <p>{@link #derivedFromCapability} is true only in the one case the current
 * model supports: when the task's entire success contract reduces to
 * {@code Eresource}, so {@code R = C} legitimately. It is false in every other
 * case, including whenever a non-resource event (deadline, energy, QoS, stability)
 * is expressed.
 *
 * @param taskId                 identity of the assessed task
 * @param nodeId                 identity of the assessed node
 * @param status                 how far the assessment got
 * @param reliability            completion reliability in [0, 1], or {@code null}
 * @param events                 one entry per specification success event
 * @param reasons                distinct reason codes, in event declaration order
 * @param requestedAtMillis      the decision instant {@code t}
 * @param capabilityStatus       the Step 6B status name, or {@code "MISSING"}
 * @param derivedFromCapability  true when {@code R} equals the capability estimate
 *                               because {@code Eresource} is the entire contract
 * @param derivation             human-readable account of how {@code R} was (or
 *                               was not) obtained
 */
public record ReliabilityAssessment(
        String taskId,
        String nodeId,
        ReliabilityStatus status,
        Double reliability,
        List<SuccessEventAssessment> events,
        List<ReliabilityReason> reasons,
        long requestedAtMillis,
        String capabilityStatus,
        boolean derivedFromCapability,
        String derivation) {

    public ReliabilityAssessment {
        Objects.requireNonNull(taskId, "taskId");
        Objects.requireNonNull(nodeId, "nodeId");
        Objects.requireNonNull(status, "status");
        events = events == null ? List.of() : List.copyOf(events);
        reasons = reasons == null ? List.of() : List.copyOf(reasons);
        capabilityStatus = capabilityStatus == null ? "" : capabilityStatus;
        derivation = derivation == null ? "" : derivation;
        if (reliability != null && (reliability < 0.0 || reliability > 1.0)) {
            throw new IllegalArgumentException(
                    "reliability must be within [0, 1] (was " + reliability + ")");
        }
        if (status.hasProbability() != (reliability != null)) {
            throw new IllegalArgumentException(
                    "reliability must be non-null exactly for COMPUTABLE (status=" + status + ")");
        }
        if (derivedFromCapability && !status.hasProbability()) {
            throw new IllegalArgumentException(
                    "derivedFromCapability requires a defined reliability (status=" + status + ")");
        }
    }

    /** @return true when {@link #reliability} is a defined probability */
    public boolean isComputable() {
        return status.hasProbability();
    }

    /** @return the event entry for an event, or {@code null} when absent */
    public SuccessEventAssessment eventFor(ReliabilityEvent event) {
        return events.stream()
                .filter(e -> e.event() == event)
                .findFirst()
                .orElse(null);
    }

    /** @return the events that are part of the task's success contract */
    public List<SuccessEventAssessment> requiredEvents() {
        return events.stream().filter(SuccessEventAssessment::required).toList();
    }
}
