package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.task.NodeEligibilityResult;

import java.util.Objects;

/**
 * One candidate node as seen by the Step 6D policy: the composed result of the
 * hard-constraint filter (Step 6A), the capability estimator (Step 6B), and the
 * completion-reliability estimator (Step 6C).
 *
 * <p>This is a pure composition type. It holds the upstream results as produced
 * and recomputes nothing, so the decision trace can report the hard-constraint
 * outcome, the capability estimate, and the reliability estimate for every
 * candidate.
 *
 * <p>{@link #eligibility()} and {@link #reliability()} must describe the same task
 * and node; a mismatch is a programming error, not a scheduling outcome, and is
 * rejected at construction. {@link #capability()} may be {@code null} when it was
 * not supplied; the trace then reports the capability status carried by the
 * reliability assessment.
 *
 * @param eligibility the hard-constraint result for this candidate; must not be null
 * @param capability  the capability result, or {@code null} when absent
 * @param reliability the reliability result for this candidate; must not be null
 */
public record SchedulingCandidate(
        NodeEligibilityResult eligibility,
        CapabilityAssessment capability,
        ReliabilityAssessment reliability) {

    public SchedulingCandidate {
        Objects.requireNonNull(eligibility, "eligibility");
        Objects.requireNonNull(reliability, "reliability");
        if (!Objects.equals(eligibility.taskId(), reliability.taskId())) {
            throw new IllegalArgumentException(
                    "eligibility and reliability must describe the same task ("
                            + eligibility.taskId() + " vs " + reliability.taskId() + ")");
        }
        if (!Objects.equals(eligibility.nodeId(), reliability.nodeId())) {
            throw new IllegalArgumentException(
                    "eligibility and reliability must describe the same node ("
                            + eligibility.nodeId() + " vs " + reliability.nodeId() + ")");
        }
        if (capability != null) {
            if (!Objects.equals(capability.taskId(), eligibility.taskId())
                    || !Objects.equals(capability.nodeId(), eligibility.nodeId())) {
                throw new IllegalArgumentException(
                        "capability must describe the same task and node as the eligibility result");
            }
        }
    }

    /** @return the candidate node id */
    public String nodeId() {
        return eligibility.nodeId();
    }

    /** @return the candidate task id */
    public String taskId() {
        return eligibility.taskId();
    }

    /** @return true when the candidate passed hard eligibility */
    public boolean eligible() {
        return eligibility.eligible();
    }

    /** @return true when the candidate carries a defined completion-reliability probability */
    public boolean hasReliability() {
        return reliability.isComputable();
    }
}
