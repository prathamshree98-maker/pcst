package com.omni.pcst.master.capability;

import java.util.List;
import java.util.Objects;

/**
 * Overall capability assessment for one task assigned to one candidate node:
 * {@code C(n, τ) = P(Ares(n, τ) | I_t, assignment τ → n)}.
 *
 * <p>This is a probability and its diagnostics, never a weighted resource score.
 * When the overall probability is not defined the {@link #capability} field is
 * {@code null} and the {@link #status} and {@link #reasons} explain why; the
 * per-requirement marginals remain available for inspection.
 *
 * @param taskId             identity of the assessed task
 * @param nodeId             identity of the assessed node
 * @param status             how far the assessment got
 * @param capability         overall capability probability in [0, 1], or {@code null}
 * @param requirements       one entry per requirement the task expresses
 * @param reasons            distinct reason codes, in requirement declaration order
 * @param requestedAtMillis  the decision instant {@code t}
 * @param horizonMillis      execution horizon used, or {@code null} when the task states none
 * @param combinerName       identifier of the combiner used for multiple marginals
 * @param combinerAssumption the assumption under which the combiner's result is valid
 */
public record CapabilityAssessment(
        String taskId,
        String nodeId,
        CapabilityStatus status,
        Double capability,
        List<RequirementCapability> requirements,
        List<CapabilityReason> reasons,
        long requestedAtMillis,
        Long horizonMillis,
        String combinerName,
        String combinerAssumption) {

    public CapabilityAssessment {
        Objects.requireNonNull(taskId, "taskId");
        Objects.requireNonNull(nodeId, "nodeId");
        Objects.requireNonNull(status, "status");
        requirements = requirements == null ? List.of() : List.copyOf(requirements);
        reasons = reasons == null ? List.of() : List.copyOf(reasons);
        if (capability != null && (capability < 0.0 || capability > 1.0)) {
            throw new IllegalArgumentException(
                    "capability must be within [0, 1] (was " + capability + ")");
        }
        if (status.hasProbability() != (capability != null)) {
            throw new IllegalArgumentException(
                    "capability must be non-null exactly for COMPUTABLE (status=" + status + ")");
        }
        combinerName = combinerName == null ? "" : combinerName;
        combinerAssumption = combinerAssumption == null ? "" : combinerAssumption;
    }

    /** @return true when {@link #capability} is a defined probability */
    public boolean isComputable() {
        return status.hasProbability();
    }

    /** @return the requirement entry for a dimension, or {@code null} when not expressed */
    public RequirementCapability requirementFor(CapabilityDimension dimension) {
        return requirements.stream()
                .filter(r -> r.dimension() == dimension)
                .findFirst()
                .orElse(null);
    }

    /** @return true when any requirement is an unsupported resource condition */
    public boolean hasUnsupportedResourceCondition() {
        return requirements.stream()
                .anyMatch(r -> r.isResourceCondition()
                        && !r.dimension().supported());
    }
}
