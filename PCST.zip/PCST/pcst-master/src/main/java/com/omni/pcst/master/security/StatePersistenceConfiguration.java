package com.omni.pcst.master.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.file.Paths;

/**
 * Configuration for durable enrollment-state persistence.
 *
 * <p>When {@code pcst.state.persistence.enabled} is {@code true}, device
 * credentials and revocation state are persisted to a file so they survive a
 * Master restart. An encryption passphrase is required in this mode; without
 * one, the application context fails to close (fail closed) so that no
 * credentials are ever stored in plaintext unintentionally.
 *
 * <p>When disabled (the default), all state is in-memory and lost on restart,
 * matching the previous behavior.
 */
@Configuration
public class StatePersistenceConfiguration {

    /**
     * Creates the {@link FileStateStore} bean when persistence is enabled.
     * Returns {@code null} when disabled, in which case
     * {@link DeviceCredentialService} operates purely in memory.
     *
     * @throws IllegalStateException when persistence is enabled but no
     *         encryption passphrase is configured (fail closed)
     */
    @Bean
    public FileStateStore fileStateStore(
            @Value("${pcst.state.persistence.enabled:false}") boolean enabled,
            @Value("${pcst.state.persistence.path:./data/node-state.json}") String path,
            @Value("${pcst.state.encryption.passphrase:}") String passphrase) {
        if (!enabled) {
            return null;
        }
        if (passphrase == null || passphrase.isBlank()) {
            throw new IllegalStateException(
                    "pcst.state.persistence.enabled=true requires a non-blank "
                            + "pcst.state.encryption.passphrase. Credentials must never "
                            + "be stored in plaintext.");
        }
        return new FileStateStore(Paths.get(path), passphrase);
    }
}
