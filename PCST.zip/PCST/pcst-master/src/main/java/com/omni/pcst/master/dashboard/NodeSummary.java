package com.omni.pcst.master.dashboard;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Summary view of a node for cluster overview.
 */
public record NodeSummary(
        String nodeId,
        String hostname,
        int port,
        String agentVersion,
        long registeredAtMillis,
        long lastHeartbeatMillis,
        long lastTelemetryReceivedAtMillis,
        long staleObservationsRejected,
        boolean hasBeliefState,
        TelemetrySummary latestTelemetry,
        Map<String, ResourceBeliefSummary> beliefs) {

    public static NodeSummary fromSnapshot(com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot snapshot) {
        TelemetrySummary telemetry = snapshot.latestObservation() != null
                ? TelemetrySummary.from(snapshot.latestObservation())
                : null;

        Map<String, ResourceBeliefSummary> beliefs = Map.of();
        if (snapshot.beliefState() != null && !snapshot.beliefState().beliefs().isEmpty()) {
            beliefs = snapshot.beliefState().beliefs().entrySet().stream()
                    .collect(java.util.stream.Collectors.toMap(
                            Map.Entry::getKey,
                            e -> ResourceBeliefSummary.from(e.getValue())));
        }

        return new NodeSummary(
                snapshot.nodeId(),
                snapshot.hostname(),
                snapshot.port(),
                snapshot.agentVersion(),
                snapshot.registeredAtMillis(),
                snapshot.lastHeartbeatMillis(),
                snapshot.lastTelemetryReceivedAtMillis(),
                snapshot.staleObservationsRejected(),
                snapshot.beliefState() != null && !snapshot.beliefState().beliefs().isEmpty(),
                telemetry,
                beliefs);
    }

    /**
     * Summary of the latest telemetry observation.
     */
    public record TelemetrySummary(
            long timestamp,
            Double cpuUtilizationPercent,
            Long totalMemoryBytes,
            Long usedMemoryBytes,
            Long availableMemoryBytes,
            Boolean gpuAvailable,
            Double gpuUtilizationPercent,
            Double batteryLevelPercent,
            Boolean batteryCharging,
            Double temperatureCelsius,
            Double latencyMs,
            Double packetLossPercent,
            Long totalDiskBytes,
            Long freeDiskBytes,
            Integer processCount,
            Boolean userActive) {

        public static TelemetrySummary from(com.omni.pcst.master.digitaltwin.TelemetryObservation obs) {
            return new TelemetrySummary(
                    obs.timestamp(),
                    obs.cpuUtilizationPercent(),
                    obs.totalMemoryBytes(),
                    obs.usedMemoryBytes(),
                    obs.availableMemoryBytes(),
                    obs.gpuAvailable(),
                    obs.gpuUtilizationPercent(),
                    obs.batteryLevelPercent(),
                    obs.batteryCharging(),
                    obs.temperatureCelsius(),
                    obs.latencyMs(),
                    obs.packetLossPercent(),
                    obs.totalDiskBytes(),
                    obs.freeDiskBytes(),
                    obs.processCount(),
                    obs.userActive());
        }

        public Optional<Double> memoryUtilizationPercent() {
            if (totalMemoryBytes != null && usedMemoryBytes != null && totalMemoryBytes > 0) {
                return Optional.of((double) usedMemoryBytes / totalMemoryBytes * 100.0);
            }
            return Optional.empty();
        }
    }

    /**
     * Summary of a resource belief.
     */
    public record ResourceBeliefSummary(
            String resourceName,
            double posteriorMean,
            double posteriorVariance,
            long observationCount,
            long lastObservationTimestamp) {

        public static ResourceBeliefSummary from(com.omni.pcst.master.digitaltwin.ResourceBelief belief) {
            return new ResourceBeliefSummary(
                    belief.resourceName(),
                    belief.posteriorMean(),
                    belief.posteriorVariance(),
                    belief.observationCount(),
                    belief.lastObservationTimestamp());
        }
    }
}