package com.omni.pcst.master.execution;

import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.reliability.ReliabilityEngine;
import com.omni.pcst.master.scheduler.PCSTScheduler;
import com.omni.pcst.master.scheduler.SchedulingDecision;
import com.omni.pcst.master.scheduler.SchedulingPolicyConfig;
import com.omni.pcst.master.task.HardConstraintFilter;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.TaskDispatchRequest;
import com.omni.pcst.proto.TaskDispatchResponse;
import com.omni.pcst.proto.TaskLifecycleUpdate;
import com.omni.pcst.proto.TaskResult;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Coordinates task scheduling, dispatch, and lifecycle management.
 *
 * <p>This component owns the vertical slice from task acceptance through
 * execution result ingestion. It uses the existing PCST scheduling pipeline
 * (hard constraints → capability → reliability → policy) and the existing
 * gRPC client architecture to dispatch tasks to Node Agents.
 *
 * <p>Thread-safety: the coordinator uses the TaskRegistry for atomic state
 * updates. Network calls (gRPC dispatch) are made outside of any registry
 * lock to avoid blocking other tasks.
 */
@Component
public class TaskExecutionCoordinator {

    private static final Logger log = LoggerFactory.getLogger(TaskExecutionCoordinator.class);

    private final TaskRegistry taskRegistry;
    private final DigitalTwinManager digitalTwinManager;
    private final PCSTScheduler scheduler;
    private final DispatchClient dispatchClient;
    private final ScheduledExecutorService timeoutScheduler;
    private final long dispatchTimeoutMillis;

    // Tracks in-flight dispatches for timeout handling: taskId -> (attemptId, nodeId, deadline)
    private final ConcurrentMap<String, InFlightDispatch> inFlight = new ConcurrentHashMap<>();

    public TaskExecutionCoordinator(TaskRegistry taskRegistry,
                                    DigitalTwinManager digitalTwinManager,
                                    PCSTScheduler scheduler,
                                    @Value("${pcst.execution.dispatch-timeout-ms:30000}") long dispatchTimeoutMillis) {
        this.taskRegistry = taskRegistry;
        this.digitalTwinManager = digitalTwinManager;
        this.scheduler = scheduler;
        this.dispatchTimeoutMillis = dispatchTimeoutMillis;
        this.dispatchClient = new DispatchClient();
        this.timeoutScheduler = Executors.newSingleThreadScheduledExecutor(
                r -> { Thread t = new Thread(r, "pcst-dispatch-timeout"); t.setDaemon(true); return t; });
    }

    /**
     * Submits a task for execution.
     *
     * @param task the task to execute
     * @return the created task record (ACCEPTED state)
     */
    public TaskRecord submitTask(Task task) {
        long now = System.currentTimeMillis();
        TaskRecord record = taskRegistry.create(task, now);
        log.info("Task submitted: taskId={}, attemptId={}", task.taskId(), record.attemptId());
        // Schedule asynchronously to avoid blocking the submission thread
        scheduleAndDispatch(record);
        return record;
    }

    /**
     * Handles a task lifecycle update from a Node Agent.
     *
     * @param update the lifecycle update
     * @return true if the update was applied, false if task not found or update invalid
     */
    public boolean handleLifecycleUpdate(TaskLifecycleUpdate update) {
        String taskId = update.getTaskId();
        String attemptId = update.getAttemptId();

        // Distinguishes an update that was actually applied from one that was a
        // no-op (attempt mismatch, already terminal, unhandled state). A no-op
        // must be reported as not-applied so the agent does not treat a stale or
        // duplicate message as authoritative.
        java.util.concurrent.atomic.AtomicBoolean applied =
                new java.util.concurrent.atomic.AtomicBoolean(false);
        try {
            return taskRegistry.update(taskId, record -> {
                if (!record.attemptId().equals(attemptId)) {
                    log.warn("Lifecycle update for taskId={} attemptId={} rejected: attempt mismatch (current={})",
                            taskId, attemptId, record.attemptId());
                    return record;
                }
                com.omni.pcst.proto.TaskState newState = update.getState();

                // A terminal state is authoritative: a late ACCEPTED/RUNNING or a
                // duplicate terminal update must never move the task backwards or
                // overwrite the recorded result.
                if (record.isTerminal()) {
                    log.warn("Lifecycle update {} for taskId={} ignored: task is already terminal ({})",
                            newState, taskId, record.state());
                    return record;
                }

                long now = System.currentTimeMillis();
                final TaskRecord updated;
                switch (newState) {
                    case ACCEPTED -> updated = record.withDispatchAccepted(now);
                    case RUNNING -> updated = record.withRunning(now);
                    case SUCCEEDED, FAILED -> {
                        TaskResult result = update.getResult();
                        if (result == null) {
                            log.warn("Lifecycle update for taskId={} missing result", taskId);
                            return record;
                        }
                        inFlight.remove(taskId);
                        updated = record.withResult(result, now);
                    }
                    case REJECTED -> {
                        inFlight.remove(taskId);
                        updated = record.withDispatchRejected(now, update.getMessage());
                    }
                    default -> {
                        log.warn("Unhandled lifecycle state {} for taskId={}", newState, taskId);
                        return record;
                    }
                }
                applied.set(true);
                return updated;
            }).isPresent() && applied.get();
        } catch (IllegalStateException e) {
            // A duplicate or delayed transition against an already-terminal state: reject
            // cleanly without corrupting the authoritative terminal state.
            log.warn("Lifecycle update rejected for taskId={} attemptId={}: {}",
                    taskId, attemptId, e.getMessage());
            return false;
        }
    }

    /**
     * Gets the current task record.
     */
    public Optional<TaskRecord> getTask(String taskId) {
        return taskRegistry.get(taskId);
    }

    /**
     * Lists all task records.
     */
    public Collection<TaskRecord> listTasks() {
        return taskRegistry.all();
    }

    // ------------------------------------------------------------------ internal

    private void scheduleAndDispatch(TaskRecord record) {
        // Get current candidate snapshots from Digital Twin. An empty set is not
        // special-cased here: the scheduler produces the authoritative
        // NO_FEASIBLE_NODE decision (with its empty candidate trace), which is then
        // retained on the task record like any other failed scheduling decision.
        Collection<DigitalTwinSnapshot> snapshots = digitalTwinManager.allSnapshots();
        if (snapshots.isEmpty()) {
            log.warn("No registered nodes available for taskId={}", record.taskId());
        }

        // Run scheduling
        SchedulingDecision decision;
        try {
            decision = scheduler.schedule(record.task(), System.currentTimeMillis(), snapshots);
        } catch (Exception e) {
            log.error("Scheduling failed for taskId={}: {}", record.taskId(), e.getMessage());
            taskRegistry.update(record.taskId(), r -> r.transitionTo(TaskState.NO_FEASIBLE_NODE,
                    System.currentTimeMillis(), "scheduling error: " + e.getMessage()));
            return;
        }

        // Apply scheduling decision
        if (!decision.hasSelection()) {
            TaskState terminalState = switch (decision.status()) {
                case NO_FEASIBLE_NODE -> TaskState.NO_FEASIBLE_NODE;
                case DEFER_OR_REJECT -> TaskState.NO_FEASIBLE_NODE; // treat as no feasible for now
                case NO_SELECTION_UNRESOLVED -> TaskState.UNRESOLVED_SCHEDULING;
                case FALLBACK_SELECTED -> TaskState.NO_FEASIBLE_NODE; // fallback not enabled by default
                default -> TaskState.NO_FEASIBLE_NODE;
            };
            // Retain the full decision and candidate trace so the rejection (and its
            // reasons) remain retrievable through GET /tasks/{id}/decision.
            taskRegistry.update(record.taskId(), r -> r.withFailedSchedulingDecision(terminalState,
                    decision, System.currentTimeMillis()));
            log.info("Scheduling produced no selection for taskId={}: status={}",
                    record.taskId(), decision.status());
            return;
        }

        // Schedule selected - transition to DISPATCHING
        taskRegistry.update(record.taskId(), r -> r.withSchedulingDecision(decision, System.currentTimeMillis()));

        // Dispatch to selected node
        String selectedNodeId = decision.selectedNodeId();
        dispatchToNode(record.taskId(), record.attemptId(), selectedNodeId, record.task());
    }

    private void dispatchToNode(String taskId, String attemptId, String nodeId, Task task) {
        // Get node endpoint from digital twin
        Optional<DigitalTwinSnapshot> snapshotOpt = digitalTwinManager.getSnapshot(nodeId);
        if (snapshotOpt.isEmpty()) {
            log.error("Selected node {} not found in digital twin for taskId={}", nodeId, taskId);
            taskRegistry.update(taskId, r -> r.withDispatchRejected(System.currentTimeMillis(),
                    "selected node not found in registry"));
            return;
        }

        DigitalTwinSnapshot snapshot = snapshotOpt.get();
        String host = snapshot.hostname();
        int port = snapshot.port();

        // Build dispatch request
        TaskDispatchRequest request = TaskDispatchRequest.newBuilder()
                .setTaskId(taskId)
                .setAttemptId(attemptId)
                .setWorkloadType(task.workloadReference())
                .setPayload(task.inputCharacteristics())
                .setDispatchTime(System.currentTimeMillis())
                .setDeadlineEpochMillis(task.constraints().deadlineEpochMillis() != null
                        ? task.constraints().deadlineEpochMillis() : 0)
                .build();

        // Track in-flight dispatch
        long deadline = System.currentTimeMillis() + dispatchTimeoutMillis;
        InFlightDispatch inFlightDispatch = new InFlightDispatch(attemptId, nodeId, deadline);
        inFlight.put(taskId, inFlightDispatch);

        // Schedule timeout check
        timeoutScheduler.schedule(() -> checkDispatchTimeout(taskId), dispatchTimeoutMillis, TimeUnit.MILLISECONDS);

        // Send dispatch asynchronously
        CompletableFuture.supplyAsync(() -> dispatchClient.dispatch(host, port, request))
                .thenAccept(response -> handleDispatchResponse(taskId, attemptId, nodeId, response))
                .exceptionally(ex -> {
                    log.error("Dispatch to node {} for taskId={} failed: {}", nodeId, taskId, ex.getMessage());
                    handleDispatchResponse(taskId, attemptId, nodeId,
                            TaskDispatchResponse.newBuilder()
                                    .setAccepted(false)
                                    .setMessage("dispatch failed: " + ex.getMessage())
                                    .setServerTime(System.currentTimeMillis())
                                    .build());
                    return null;
                });
    }

    private void handleDispatchResponse(String taskId, String attemptId, String nodeId,
                                        TaskDispatchResponse response) {
        long now = System.currentTimeMillis();
        boolean accepted = response.getAccepted();
        // Keep the in-flight entry when the agent accepts dispatch: the dispatch
        // timeout must still be able to fire if the agent goes silent after
        // accepting (node disconnect during execution). Only a rejected dispatch
        // clears the in-flight entry immediately.
        if (!accepted) {
            inFlight.remove(taskId);
        }
        taskRegistry.update(taskId, record -> {
            if (!record.attemptId().equals(attemptId)) {
                log.warn("Dispatch response for taskId={} attemptId={} ignored: attempt mismatch",
                        taskId, attemptId);
                return record;
            }
            if (record.state() != TaskState.DISPATCHING) {
                // The task has already progressed through a lifecycle update (or is
                // terminal). The dispatch response is then redundant and must not move
                // the task; a fast workload can report completion before this response
                // is even observed.
                log.debug("Dispatch response for taskId={} ignored: already in state {}",
                        taskId, record.state());
                return record;
            }
            if (accepted) {
                return record.withDispatchAccepted(now);
            } else {
                return record.withDispatchRejected(now, response.getMessage());
            }
        });
    }

    private void checkDispatchTimeout(String taskId) {
        InFlightDispatch dispatch = inFlight.remove(taskId);
        if (dispatch == null) {
            return; // already handled
        }
        log.warn("Dispatch timeout for taskId={} (attemptId={}, nodeId={})",
                taskId, dispatch.attemptId(), dispatch.nodeId());
        taskRegistry.update(taskId, record -> {
            if (!record.attemptId().equals(dispatch.attemptId())) {
                return record;
            }
            if (record.state() == TaskState.DISPATCHING
                    || record.state() == TaskState.DISPATCH_ACCEPTED
                    || record.state() == TaskState.RUNNING) {
                return record.withOutcomeUnknown(System.currentTimeMillis(),
                        "dispatch timeout after " + dispatchTimeoutMillis + " ms");
            }
            return record;
        });
    }

    /**
     * Shuts down the coordinator.
     */
    public void shutdown() {
        timeoutScheduler.shutdown();
        try {
            if (!timeoutScheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                timeoutScheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            timeoutScheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
        dispatchClient.shutdown();
    }

    // ------------------------------------------------------------------ inner classes

    /**
     * Simple gRPC dispatch client using blocking stubs.
     */
    private static class DispatchClient {

        private final ConcurrentMap<String, ManagedChannel> channels = new ConcurrentHashMap<>();

        TaskDispatchResponse dispatch(String host, int port, TaskDispatchRequest request) {
            ManagedChannel channel = getOrCreateChannel(host, port);
            try {
                com.omni.pcst.proto.NodeServiceGrpc.NodeServiceBlockingStub stub =
                        com.omni.pcst.proto.NodeServiceGrpc.newBlockingStub(channel);
                return stub.dispatchTask(request);
            } catch (StatusRuntimeException e) {
                // Channel may be bad; remove it so next attempt creates fresh
                channels.remove(host + ":" + port);
                return TaskDispatchResponse.newBuilder()
                        .setAccepted(false)
                        .setMessage("gRPC error: " + e.getStatus().getDescription())
                        .setServerTime(System.currentTimeMillis())
                        .build();
            }
        }

        private ManagedChannel getOrCreateChannel(String host, int port) {
            String key = host + ":" + port;
            return channels.computeIfAbsent(key, k ->
                    ManagedChannelBuilder.forAddress(host, port).usePlaintext().build());
        }

        void shutdown() {
            for (ManagedChannel channel : channels.values()) {
                channel.shutdownNow();
            }
            channels.clear();
        }
    }

    private record InFlightDispatch(String attemptId, String nodeId, long deadline) {}
}