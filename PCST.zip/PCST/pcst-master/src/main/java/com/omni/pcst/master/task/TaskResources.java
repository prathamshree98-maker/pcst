package com.omni.pcst.master.task;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Workload demand of a task: what the task needs from a node.
 *
 * <p>Specification section 3.1 requires resource constraints for
 * "memory, storage, accelerator requirements, minimum throughput or
 * benchmark-normalized compute demand, and any required network conditions".
 *
 * <h2>Absent is not zero</h2>
 * Every optional field is a boxed type where {@code null} means
 * <b>"no requirement is expressed"</b> and a numeric {@code 0} means
 * <b>"the task explicitly demands zero"</b>. These are different statements and
 * are never conflated: a {@code null} requirement imposes no hard constraint,
 * while an explicit zero is a real demand that happens to be zero and is still
 * validated and still evaluated.
 *
 * <h2>Units</h2>
 * <ul>
 *   <li>memory: bytes</li>
 *   <li>storage: bytes</li>
 *   <li>accelerator memory: bytes</li>
 *   <li>compute demand: benchmark-normalized units (dimensionless)</li>
 * </ul>
 *
 * <p>Specification section 3.2 warns that compute capacity is currently a
 * modelling gap; the corresponding field is therefore carried faithfully but the
 * current node model cannot evidence it, and filtering reports that honestly
 * rather than deriving it from utilization.
 */
public record TaskResources(
        Long requiredMemoryBytes,
        Long requiredStorageBytes,
        boolean acceleratorRequired,
        Long requiredAcceleratorMemoryBytes,
        Double requiredComputeUnits) {

    /** No requirements at all. Distinct from a task that demands zero of something. */
    public static final TaskResources NONE = new TaskResources(null, null, false, null, null);

    public TaskResources {
        List<ValidationViolation> violations = new ArrayList<>();
        violations.addAll(validateBytes("requiredMemoryBytes", requiredMemoryBytes));
        violations.addAll(validateBytes("requiredStorageBytes", requiredStorageBytes));
        violations.addAll(validateBytes("requiredAcceleratorMemoryBytes", requiredAcceleratorMemoryBytes));
        violations.addAll(validateNonNegative("requiredComputeUnits", requiredComputeUnits));
        if (!violations.isEmpty()) {
            throw new TaskValidationException(violations);
        }
    }

    /** Convenience factory for a task that only demands memory. */
    public static TaskResources requiringMemory(long bytes) {
        return new TaskResources(bytes, null, false, null, null);
    }

    /** Convenience factory for an accelerator-bound task with device memory demand. */
    public static TaskResources requiringAccelerator(long acceleratorMemoryBytes) {
        return new TaskResources(null, null, true, acceleratorMemoryBytes, null);
    }

    /** @return true when this task expresses no resource demand whatsoever */
    @JsonIgnore
    public boolean isEmpty() {
        return requiredMemoryBytes == null
                && requiredStorageBytes == null
                && !acceleratorRequired
                && requiredAcceleratorMemoryBytes == null
                && requiredComputeUnits == null;
    }

    static List<ValidationViolation> validateBytes(String field, Long value) {
        if (value == null) {
            return TaskValidationException.emptyViolations();
        }
        if (value < 0L) {
            return List.of(new ValidationViolation(field,
                    "must be >= 0 bytes when present (was " + value + ")"));
        }
        return TaskValidationException.emptyViolations();
    }

    static List<ValidationViolation> validateNonNegative(String field, Double value) {
        if (value == null) {
            return TaskValidationException.emptyViolations();
        }
        if (!Double.isFinite(value) || value < 0.0) {
            return List.of(new ValidationViolation(field,
                    "must be a finite value >= 0 when present (was " + value + ")"));
        }
        return TaskValidationException.emptyViolations();
    }

    static List<ValidationViolation> validatePercent(String field, Double value) {
        if (value == null) {
            return TaskValidationException.emptyViolations();
        }
        if (!Double.isFinite(value) || value < 0.0 || value > 100.0) {
            return List.of(new ValidationViolation(field,
                    "must be a finite percentage within [0, 100] when present (was " + value + ")"));
        }
        return TaskValidationException.emptyViolations();
    }
}