package com.omni.pcst.master.reliability;

import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityReason;
import com.omni.pcst.master.capability.CapabilityStatus;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Step 6C completion-reliability engine: the task-relative probability
 * {@code R(n, τ) = P(Esucc | I_t, assignment τ → n)}.
 *
 * <p>{@code Esucc} is the intersection of the success events the task expresses
 * (specification section 9). The engine composes two upstream results — the hard
 * filter's {@link NodeEligibilityResult} and the Step 6B
 * {@link CapabilityAssessment} — and evaluates the contract event by event. It
 * never recomputes capability and never ranks or dispatches anything.
 *
 * <h2>What the current model can evaluate</h2>
 * Only {@code Eresource} has a probabilistic model, and only through the
 * capability stage, and only for network latency and packet-loss conditions.
 * {@code Edeadline}, {@code Eenergy}, {@code EQoS} and {@code Estability} have no
 * predictive model, and no joint model exists across events. Consequently a
 * numerical {@code R} is produced <b>only</b> when the task's entire success
 * contract reduces to {@code Eresource}, i.e. when the task expresses no deadline,
 * battery minimum, QoS/compatibility target, or interruption-tolerance
 * requirement and the capability estimate is {@code COMPUTABLE}. In that one case
 * {@code Esucc = Eresource} and {@code R = C} by the definition itself. In every
 * other case the engine reports an explicit unresolved/unsupported/insufficient
 * status with a numeric {@code null}.
 *
 * <h2>No double counting</h2>
 * The engine never forms {@code C × P(Edeadline) × P(Eenergy) × …}
 * (specification section 9.1). The events the capability stage already owns are
 * not re-multiplied, and an unsupported event is never silently treated as
 * certain. A proven hard-constraint rejection is never overturned by a favourable
 * resource estimate.
 *
 * <h2>Determinism and boundaries</h2>
 * The engine reads immutable inputs and mutates nothing. Identical inputs produce
 * identical assessments. It estimates reliability only: it does not schedule,
 * rank, dispatch, or execute, and does not modify the task model, the belief
 * engine, the capability stage, or the hard-constraint policy.
 */
public final class ReliabilityEngine {

    /** Creates a stateless reliability engine. */
    public ReliabilityEngine() {
    }

    /**
     * Assesses completion reliability for one task on one candidate node.
     *
     * @param input the immutable assessment input
     * @return the assessment; never {@code null}
     * @throws NullPointerException when {@code input} is null
     */
    public ReliabilityAssessment assess(ReliabilityInput input) {
        Objects.requireNonNull(input, "input");
        Task task = input.task();
        DigitalTwinSnapshot snapshot = input.snapshot();
        CapabilityAssessment capability = input.capability();
        String taskId = task.taskId();
        String nodeId = snapshot.nodeId();

        if (capability == null) {
            return base(taskId, nodeId, ReliabilityStatus.INVALID_INPUT, null,
                    List.of(), List.of(ReliabilityReason.MISSING_CAPABILITY_ASSESSMENT),
                    0L, "MISSING",
                    "no step 6B capability assessment was supplied");
        }

        String capabilityStatus = capability.status().name();
        long requestedAt = capability.requestedAtMillis();

        if (!Objects.equals(nodeId, capability.nodeId())
                || (input.eligibility() != null
                        && !Objects.equals(nodeId, input.eligibility().nodeId()))) {
            return base(taskId, nodeId, ReliabilityStatus.INVALID_INPUT, null,
                    List.of(), List.of(ReliabilityReason.INVALID_INPUT), requestedAt,
                    capabilityStatus,
                    "node identity is inconsistent across the snapshot, eligibility and capability inputs");
        }

        List<SuccessEventAssessment> events = buildEvents(task, capability);

        NodeEligibilityResult eligibility = input.eligibility();
        if (eligibility != null && !eligibility.eligible()) {
            boolean proven = eligibility.reasons().stream().anyMatch(r -> !r.isIndeterminate());
            List<ReliabilityReason> extra = new ArrayList<>();
            if (proven) {
                extra.add(ReliabilityReason.HARD_CONSTRAINT_VIOLATION);
            }
            if (eligibility.indeterminate()) {
                extra.add(ReliabilityReason.HARD_CONSTRAINT_INDETERMINATE);
            }
            if (extra.isEmpty()) {
                extra.add(ReliabilityReason.HARD_CONSTRAINT_INDETERMINATE);
            }
            return base(taskId, nodeId, ReliabilityStatus.REJECTED_HARD_CONSTRAINT, null,
                    events, merge(extra, events), requestedAt, capabilityStatus,
                    proven
                            ? "the candidate is excluded by a proven hard-constraint violation; no reliability is estimated"
                            : "the candidate is excluded by an unproven (indeterminate) hard constraint; no reliability is estimated");
        }

        if (capability.status() == CapabilityStatus.INVALID_INPUT) {
            return base(taskId, nodeId, ReliabilityStatus.INVALID_INPUT, null,
                    events, merge(List.of(ReliabilityReason.CAPABILITY_INVALID_INPUT), events),
                    requestedAt, capabilityStatus,
                    "the step 6B capability input was malformed");
        }

        if (eligibility != null && eligibility.eligible() && eligibility.indeterminate()) {
            return base(taskId, nodeId, ReliabilityStatus.UNRESOLVED_MODEL, null,
                    events, merge(List.of(ReliabilityReason.HARD_CONSTRAINT_INDETERMINATE), events),
                    requestedAt, capabilityStatus,
                    "the candidate is admitted with unproven constraints; an unproven condition is not evidence of success");
        }

        return compose(taskId, nodeId, capability, requestedAt, events);
    }

    /**
     * Assesses completion reliability for every distinct node in a collection,
     * ordered by node id for determinism. Null entries are ignored.
     *
     * @param inputs candidate inputs, in any order
     * @return one assessment per distinct node, ordered by node id
     */
    public List<ReliabilityAssessment> assessAll(Collection<ReliabilityInput> inputs) {
        Objects.requireNonNull(inputs, "inputs");
        Map<String, ReliabilityInput> deduplicated = new LinkedHashMap<>();
        for (ReliabilityInput input : inputs) {
            if (input == null) {
                continue;
            }
            deduplicated.putIfAbsent(nodeKey(input), input);
        }
        List<ReliabilityAssessment> results = new ArrayList<>(deduplicated.size());
        for (ReliabilityInput input : deduplicated.values()) {
            results.add(assess(input));
        }
        results.sort(Comparator.comparing(ReliabilityAssessment::nodeId));
        return List.copyOf(results);
    }

    // ---------------------------------------------------------------- contract

    private ReliabilityAssessment compose(String taskId,
                                          String nodeId,
                                          CapabilityAssessment capability,
                                          long requestedAt,
                                          List<SuccessEventAssessment> events) {
        CapabilityStatus capabilityStatus = capability.status();
        String capabilityName = capabilityStatus.name();

        if (capabilityStatus == CapabilityStatus.INSUFFICIENT_EVIDENCE) {
            return base(taskId, nodeId, ReliabilityStatus.INSUFFICIENT_EVIDENCE, null,
                    events, merge(List.of(ReliabilityReason.CAPABILITY_INSUFFICIENT_EVIDENCE), events),
                    requestedAt, capabilityName,
                    "the step 6B resource-event evidence is missing or unusable");
        }

        List<SuccessEventAssessment> required = events.stream()
                .filter(SuccessEventAssessment::required)
                .toList();
        List<SuccessEventAssessment> computed = required.stream()
                .filter(SuccessEventAssessment::isComputed)
                .toList();

        if (computed.size() == required.size()) {
            SuccessEventAssessment resource = event(events, ReliabilityEvent.RESOURCE);
            boolean vacuous = capability.requirements().isEmpty();
            ReliabilityReason overall = vacuous
                    ? ReliabilityReason.VACUOUS_SUCCESS_CONTRACT
                    : ReliabilityReason.RESOURCE_EVENT_IS_ENTIRE_CONTRACT;
            String derivation = vacuous
                    ? "the task expresses no success events, so Esucc is the empty intersection and is vacuously true"
                    : "Eresource is the task's entire success contract, so R equals the step 6B capability probability C";
            return base(taskId, nodeId, ReliabilityStatus.COMPUTABLE, resource.probability(),
                    events, merge(List.of(overall), events), requestedAt, capabilityName, derivation);
        }

        boolean anyPartial = capabilityStatus == CapabilityStatus.PARTIALLY_COMPUTABLE;
        ReliabilityStatus status = (computed.isEmpty() && !anyPartial)
                ? ReliabilityStatus.UNSUPPORTED_MODEL
                : ReliabilityStatus.UNRESOLVED_MODEL;
        String derivation = status == ReliabilityStatus.UNSUPPORTED_MODEL
                ? "no required success event has a model on the current node model"
                : "one or more required success events cannot be evaluated (no model or an unresolved joint), so no single reliability is defined";
        return base(taskId, nodeId, status, null, events, merge(List.of(), events),
                requestedAt, capabilityName, derivation);
    }

    private List<SuccessEventAssessment> buildEvents(Task task, CapabilityAssessment capability) {
        TaskConstraints constraints = task.constraints();
        List<SuccessEventAssessment> events = new ArrayList<>(5);
        events.add(resourceEvent(capability));
        events.add(new SuccessEventAssessment(
                ReliabilityEvent.DEADLINE, constraints.hasDeadline(),
                constraints.hasDeadline()
                        ? ReliabilityReason.NO_COMPLETION_TIME_MODEL
                        : ReliabilityReason.EVENT_NOT_IN_CONTRACT,
                null,
                constraints.hasDeadline()
                        ? "the task states a deadline but no completion-time distribution exists to evaluate it"
                        : "the task expresses no deadline"));
        boolean energy = constraints.minimumBatteryPercent() != null;
        events.add(new SuccessEventAssessment(
                ReliabilityEvent.ENERGY, energy,
                energy ? ReliabilityReason.NO_ENERGY_PROCESS_MODEL
                        : ReliabilityReason.EVENT_NOT_IN_CONTRACT,
                null,
                energy
                        ? "the task states a battery minimum but no energy/drain process model exists to evaluate it"
                        : "the task expresses no battery requirement"));
        boolean qos = constraints.requiredExecutionProfile() != null
                && !constraints.requiredExecutionProfile().isBlank();
        events.add(new SuccessEventAssessment(
                ReliabilityEvent.QOS, qos,
                qos ? ReliabilityReason.NO_QOS_MODEL
                        : ReliabilityReason.EVENT_NOT_IN_CONTRACT,
                null,
                qos
                        ? "the task states a QoS/compatibility target but no QoS model exists to evaluate it"
                        : "the task expresses no QoS target"));
        boolean stability = constraints.interruptionTolerance() != null;
        events.add(new SuccessEventAssessment(
                ReliabilityEvent.STABILITY, stability,
                stability ? ReliabilityReason.NO_STABILITY_MODEL
                        : ReliabilityReason.EVENT_NOT_IN_CONTRACT,
                null,
                stability
                        ? "the task states an interruption tolerance but no node-stability model exists to evaluate it"
                        : "the task expresses no interruption tolerance"));
        return List.copyOf(events);
    }

    private SuccessEventAssessment resourceEvent(CapabilityAssessment capability) {
        switch (capability.status()) {
            case COMPUTABLE:
                return new SuccessEventAssessment(ReliabilityEvent.RESOURCE, true,
                        ReliabilityReason.COMPUTED, capability.capability(),
                        "Eresource taken from the step 6B capability assessment");
            case PARTIALLY_COMPUTABLE:
                boolean jointUnresolved = capability.reasons()
                        .contains(CapabilityReason.JOINT_MODEL_UNRESOLVED);
                return new SuccessEventAssessment(ReliabilityEvent.RESOURCE, true,
                        jointUnresolved
                                ? ReliabilityReason.RESOURCE_JOINT_MODEL_UNRESOLVED
                                : ReliabilityReason.RESOURCE_UNSUPPORTED_MODEL,
                        null,
                        jointUnresolved
                                ? "multiple resource conditions are computable but no justified joint model exists"
                                : "some required resource conditions have no predictive model");
            case UNSUPPORTED_MODEL:
                return new SuccessEventAssessment(ReliabilityEvent.RESOURCE, true,
                        ReliabilityReason.RESOURCE_UNSUPPORTED_MODEL, null,
                        "no resource condition has a predictive model on this node");
            case INSUFFICIENT_EVIDENCE:
                return new SuccessEventAssessment(ReliabilityEvent.RESOURCE, true,
                        ReliabilityReason.CAPABILITY_INSUFFICIENT_EVIDENCE, null,
                        "the step 6B resource-event evidence is missing or unusable");
            case INVALID_INPUT:
                return new SuccessEventAssessment(ReliabilityEvent.RESOURCE, true,
                        ReliabilityReason.CAPABILITY_INVALID_INPUT, null,
                        "the step 6B capability input was malformed");
            default:
                throw new IllegalStateException("unhandled capability status: " + capability.status());
        }
    }

    // ---------------------------------------------------------------- assembly

    private ReliabilityAssessment base(String taskId,
                                       String nodeId,
                                       ReliabilityStatus status,
                                       Double reliability,
                                       List<SuccessEventAssessment> events,
                                       List<ReliabilityReason> reasons,
                                       long requestedAtMillis,
                                       String capabilityStatus,
                                       String derivation) {
        return new ReliabilityAssessment(taskId, nodeId, status, reliability, events, reasons,
                requestedAtMillis, capabilityStatus, status == ReliabilityStatus.COMPUTABLE, derivation);
    }

    private static SuccessEventAssessment event(List<SuccessEventAssessment> events,
                                                ReliabilityEvent which) {
        return events.stream()
                .filter(e -> e.event() == which)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("missing event entry: " + which));
    }

    private static List<ReliabilityReason> merge(List<ReliabilityReason> extra,
                                                 List<SuccessEventAssessment> events) {
        List<ReliabilityReason> reasons = new ArrayList<>();
        for (SuccessEventAssessment event : events) {
            if (event.reason() != ReliabilityReason.EVENT_NOT_IN_CONTRACT
                    && !reasons.contains(event.reason())) {
                reasons.add(event.reason());
            }
        }
        for (ReliabilityReason reason : extra) {
            if (!reasons.contains(reason)) {
                reasons.add(reason);
            }
        }
        return List.copyOf(reasons);
    }

    private static String nodeKey(ReliabilityInput input) {
        if (input.capability() != null && input.capability().nodeId() != null) {
            return input.capability().nodeId();
        }
        return input.snapshot().nodeId();
    }
}
