package com.omni.pcst.master.capability;

/**
 * Outcome of a capability assessment for one task / one candidate node.
 *
 * <p>The status states exactly how far the assessment got. It is deliberately
 * explicit: a value of {@code null} capability with a non-computable status is
 * more honest than a fabricated number, and callers can branch on the enum.
 */
public enum CapabilityStatus {

    /**
     * The overall capability probability is defined. {@code capability()} carries
     * the value in [0, 1].
     */
    COMPUTABLE("the overall capability probability is defined"),

    /**
     * Some requirement marginals were computed, but the overall joint probability
     * is not defined: an unsupported resource condition is present, or more than
     * one computable condition exists without a justified joint model.
     * {@code capability()} is {@code null}.
     */
    PARTIALLY_COMPUTABLE("some marginals were computed but the overall probability is not defined"),

    /**
     * No resource condition of the task has a predictive model on the current node
     * model, so no capability probability is defined at all. {@code capability()}
     * is {@code null}.
     */
    UNSUPPORTED_MODEL("no resource condition has a predictive model on the current node model"),

    /**
     * Computable resource conditions exist but the belief evidence is missing,
     * stale, or dated after the decision instant. {@code capability()} is
     * {@code null}.
     */
    INSUFFICIENT_EVIDENCE("resource conditions are modelled but belief evidence is missing or unusable"),

    /**
     * The inputs were malformed for a capability assessment: a non-finite or
     * non-positive variance, or a missing execution horizon when a computable
     * condition is present. {@code capability()} is {@code null}.
     */
    INVALID_INPUT("the inputs were malformed for a capability assessment");

    private final String description;

    CapabilityStatus(String description) {
        this.description = description;
    }

    /** @return true only for {@link #COMPUTABLE} */
    public boolean hasProbability() {
        return this == COMPUTABLE;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
