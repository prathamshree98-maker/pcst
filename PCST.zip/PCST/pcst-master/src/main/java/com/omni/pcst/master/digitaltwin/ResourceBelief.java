package com.omni.pcst.master.digitaltwin;

/**
 * Probabilistic belief about one node resource, produced by the Bayesian
 * update engine from accepted {@link TelemetryObservation} history.
 *
 * <p>The belief is a Gaussian posterior over the resource's true value:
 * {@code posteriorMean} is the best point estimate and {@code posteriorVariance}
 * is the remaining uncertainty. Both are the direct output of the conjugate
 * update math — no prediction, capability, reliability, or scheduling
 * interpretation is attached.
 *
 * @param resourceName stable resource identifier, see
 *        {@link com.omni.pcst.master.belief.BayesianBeliefEngine} constants
 * @param posteriorMean posterior mean of the resource value
 * @param posteriorVariance posterior variance (&gt; 0); smaller means more certainty
 * @param observationCount number of non-missing measurements incorporated
 * @param lastObservationTimestamp timestamp of the newest observation incorporated
 */
public record ResourceBelief(
        String resourceName,
        double posteriorMean,
        double posteriorVariance,
        long observationCount,
        long lastObservationTimestamp) {
}
