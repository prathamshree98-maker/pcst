package com.omni.pcst.master.task;

import java.util.List;
import java.util.Objects;

/**
 * Structured eligibility result for one (task, node) pair.
 *
 * <p>Every evaluated constraint is retained, not only the first failure, so a
 * rejected node explains all of its disqualifications at once. The
 * specification defines the feasible set as
 * {@code F*(τ) = { n : n passes every hard eligibility predicate for τ at time t }};
 * {@link #eligible()} is the per-node membership test for that set.
 *
 * @param taskId             identity of the evaluated task
 * @param nodeId             identity of the evaluated node
 * @param eligible           true when the node satisfies every stated hard
 *                           constraint under the configured indeterminate policy
 * @param indeterminate      true when at least one reason is unproven rather than
 *                           a proven violation
 * @param constraints        all evaluated constraints, in declaration order
 * @param reasons            blocking reason codes, in constraint declaration order
 * @param decisionTimeMillis decision instant used for staleness arithmetic
 */
public record NodeEligibilityResult(
        String taskId,
        String nodeId,
        boolean eligible,
        boolean indeterminate,
        List<ConstraintEvaluation> constraints,
        List<RejectionReason> reasons,
        long decisionTimeMillis) {

    public NodeEligibilityResult {
        Objects.requireNonNull(taskId, "taskId");
        Objects.requireNonNull(nodeId, "nodeId");
        constraints = constraints == null ? List.of() : List.copyOf(constraints);
        reasons = reasons == null ? List.of() : List.copyOf(reasons);
    }

    /** @return constraints whose outcome was not a proven success */
    public List<ConstraintEvaluation> blockingConstraints() {
        return constraints.stream().filter(ConstraintEvaluation::isBlocking).toList();
    }

    /** @return the outcome recorded for one constraint, or null when not evaluated */
    public ConstraintEvaluation outcomeOf(HardConstraint constraint) {
        return constraints.stream()
                .filter(c -> c.constraint() == constraint)
                .findFirst()
                .orElse(null);
    }

    /**
     * Derives the feasible candidate set F*(τ) from a set of results.
     *
     * <p>This is the specification's feasible-set extraction and nothing more; it
     * performs no ranking, scoring or reliability estimate.
     *
     * @return the eligible candidates, ordered by node id for determinism
     */
    public static List<NodeEligibilityResult> eligibleCandidates(
            List<NodeEligibilityResult> results) {
        return results.stream()
                .filter(NodeEligibilityResult::eligible)
                .sorted(java.util.Comparator.comparing(NodeEligibilityResult::nodeId))
                .toList();
    }
}