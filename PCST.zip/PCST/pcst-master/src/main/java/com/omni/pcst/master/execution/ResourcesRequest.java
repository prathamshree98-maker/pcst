package com.omni.pcst.master.execution;

/**
 * Resource requirements for a task submission.
 */
public record ResourcesRequest(
        Long requiredMemoryBytes,
        Long requiredStorageBytes,
        Boolean acceleratorRequired,
        Long requiredAcceleratorMemoryBytes,
        Double requiredComputeUnits) {}