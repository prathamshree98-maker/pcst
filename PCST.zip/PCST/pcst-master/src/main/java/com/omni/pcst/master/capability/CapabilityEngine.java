package com.omni.pcst.master.capability;

import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.task.HardConstraintConfig;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.Function;

/**
 * Step 6B capability engine: the task-relative capability probability
 * {@code C(n, τ) = P(Ares(n, τ) | I_t, assignment τ → n)}.
 *
 * <p>{@code Ares} is the event that every resource condition the task requires
 * holds over its execution interval. The engine computes this as an
 * <b>event probability</b> from the candidate's belief state. It is deliberately
 * <b>not</b> a weighted resource score: there is no code path that multiplies
 * resource values by coefficients.
 *
 * <h2>What the current model can and cannot evaluate</h2>
 * Only the network latency and packet-loss requirements are supported, because
 * they are the only required quantities whose units match a tracked belief
 * (milliseconds and percent). Every other requirement is reported with the reason
 * it cannot be evaluated — memory/storage unit mismatch, accelerator/compute
 * without a model, energy and deadline deferred to reliability — and is never
 * silently converted or guessed. See {@link CapabilityDimension}.
 *
 * <h2>Where the predictive distribution comes from</h2>
 * The default {@link PredictiveDistributionSource} uses the Bayesian belief
 * posterior as the predictive law under the documented persistence assumption
 * (static latent value, no process noise). It never reuses a heuristic forecast
 * spread as a variance.
 *
 * <h2>Joint event probability</h2>
 * When more than one condition is computable the engine asks the configured
 * {@link CapabilityCombiner} for the joint probability. The default combiner
 * refuses, because cross-resource dependence is not modelled; multiplying
 * marginals is available only as a clearly labelled opt-in.
 *
 * <h2>Determinism and boundaries</h2>
 * The engine reads an immutable {@link DigitalTwinSnapshot} and mutates nothing.
 * It estimates capability only: it does not estimate completion reliability, rank
 * candidates, or dispatch work.
 */
public final class CapabilityEngine {

    private final PredictiveDistributionSource distributionSource;
    private final CapabilityCombiner combiner;
    private final long maxEvidenceAgeMillis;

    /** Creates an engine with the default distribution source, combiner and evidence age. */
    public CapabilityEngine() {
        this(new BeliefPosteriorDistributionSource(),
                CapabilityCombiner.unresolved(),
                HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS);
    }

    /**
     * @param distributionSource maps a belief posterior to a predictive distribution
     * @param combiner           combines multiple marginals, or refuses to
     * @param maxEvidenceAgeMillis maximum age of belief evidence before it is stale
     */
    public CapabilityEngine(PredictiveDistributionSource distributionSource,
                            CapabilityCombiner combiner,
                            long maxEvidenceAgeMillis) {
        this.distributionSource = Objects.requireNonNull(distributionSource, "distributionSource");
        this.combiner = Objects.requireNonNull(combiner, "combiner");
        if (maxEvidenceAgeMillis < 0L) {
            throw new IllegalArgumentException(
                    "maxEvidenceAgeMillis must be >= 0 (was " + maxEvidenceAgeMillis + ")");
        }
        this.maxEvidenceAgeMillis = maxEvidenceAgeMillis;
    }

    public PredictiveDistributionSource distributionSource() {
        return distributionSource;
    }

    public CapabilityCombiner combiner() {
        return combiner;
    }

    public long maxEvidenceAgeMillis() {
        return maxEvidenceAgeMillis;
    }

    /**
     * Assesses capability for one task on one candidate node.
     *
     * @param task              the task to assess
     * @param snapshot          the candidate's immutable snapshot
     * @param requestedAtMillis decision instant {@code t}
     * @return the assessment; never {@code null}
     */
    public CapabilityAssessment assess(Task task, DigitalTwinSnapshot snapshot, long requestedAtMillis) {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(snapshot, "snapshot");
        Long horizon = horizonOf(task);
        List<RequirementCapability> requirements =
                buildRequirements(task, snapshot, requestedAtMillis, horizon);
        return aggregate(task.taskId(), snapshot.nodeId(), requirements, requestedAtMillis, horizon);
    }

    /**
     * Assesses capability for every distinct node in a collection, ordered by node
     * id for determinism. Null snapshots and blank node ids are ignored.
     *
     * @param task              the task to assess
     * @param snapshots         candidate snapshots, in any order
     * @param requestedAtMillis decision instant {@code t}
     * @return one assessment per distinct node, ordered by node id
     */
    public List<CapabilityAssessment> assessAll(Task task,
                                                Collection<DigitalTwinSnapshot> snapshots,
                                                long requestedAtMillis) {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(snapshots, "snapshots");

        Map<String, DigitalTwinSnapshot> deduplicated = new LinkedHashMap<>();
        for (DigitalTwinSnapshot snapshot : snapshots) {
            if (snapshot == null) {
                continue;
            }
            String nodeId = snapshot.nodeId();
            if (nodeId == null || nodeId.isBlank()) {
                continue;
            }
            deduplicated.putIfAbsent(nodeId, snapshot);
        }

        List<CapabilityAssessment> results = new ArrayList<>(deduplicated.size());
        for (DigitalTwinSnapshot snapshot : deduplicated.values()) {
            results.add(assess(task, snapshot, requestedAtMillis));
        }
        results.sort(Comparator.comparing(CapabilityAssessment::nodeId));
        return List.copyOf(results);
    }

    /**
     * Assesses capability for the eligible candidates of a hard-constraint filter
     * result. This is the intended integration point after
     * {@code com.omni.pcst.master.task.HardConstraintFilter}: ineligible nodes are
     * skipped, and an eligible node whose snapshot cannot be resolved yields an
     * {@link CapabilityStatus#INVALID_INPUT} assessment rather than being dropped.
     *
     * @param task              the task to assess
     * @param eligibility       per-node eligibility results
     * @param resolver          maps a node id to its snapshot, or {@code null} when unknown
     * @param requestedAtMillis decision instant {@code t}
     * @return assessments for eligible candidates, ordered by node id
     */
    public List<CapabilityAssessment> assessEligible(
            Task task,
            Collection<NodeEligibilityResult> eligibility,
            Function<String, DigitalTwinSnapshot> resolver,
            long requestedAtMillis) {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(eligibility, "eligibility");
        Objects.requireNonNull(resolver, "resolver");

        Long horizon = horizonOf(task);
        List<CapabilityAssessment> results = new ArrayList<>();
        for (NodeEligibilityResult result : eligibility) {
            if (result == null || !result.eligible()) {
                continue;
            }
            DigitalTwinSnapshot snapshot = resolver.apply(result.nodeId());
            if (snapshot == null) {
                results.add(notAssessable(task.taskId(), result.nodeId(), requestedAtMillis,
                        horizon, CapabilityReason.INVALID_INPUT));
            } else {
                results.add(assess(task, snapshot, requestedAtMillis));
            }
        }
        results.sort(Comparator.comparing(CapabilityAssessment::nodeId));
        return List.copyOf(results);
    }

    // ------------------------------------------------------------- requirements

    private List<RequirementCapability> buildRequirements(Task task,
                                                          DigitalTwinSnapshot snapshot,
                                                          long requestedAtMillis,
                                                          Long horizon) {
        TaskResources resources = task.resources();
        TaskConstraints constraints = task.constraints();
        List<RequirementCapability> requirements = new ArrayList<>();

        if (resources != null) {
            if (resources.requiredMemoryBytes() != null) {
                requirements.add(unsupported(CapabilityDimension.MEMORY_AVAILABILITY,
                        resources.requiredMemoryBytes().doubleValue()));
            }
            if (resources.requiredStorageBytes() != null) {
                requirements.add(unsupported(CapabilityDimension.STORAGE_AVAILABILITY,
                        resources.requiredStorageBytes().doubleValue()));
            }
            if (resources.acceleratorRequired()) {
                requirements.add(unsupported(CapabilityDimension.ACCELERATOR_PRESENCE, null));
            }
            if (resources.requiredAcceleratorMemoryBytes() != null) {
                requirements.add(unsupported(CapabilityDimension.ACCELERATOR_MEMORY,
                        resources.requiredAcceleratorMemoryBytes().doubleValue()));
            }
            if (resources.requiredComputeUnits() != null) {
                Double computeUnits = resources.requiredComputeUnits();
                if (Double.isFinite(computeUnits)) {
                    requirements.add(unsupported(CapabilityDimension.COMPUTE_CAPACITY, computeUnits));
                }
            }
        }

        if (constraints != null) {
            if (constraints.maximumNetworkLatencyMillis() != null) {
                requirements.add(supported(CapabilityDimension.NETWORK_LATENCY,
                        constraints.maximumNetworkLatencyMillis(), snapshot, requestedAtMillis, horizon));
            }
            if (constraints.maximumPacketLossPercent() != null) {
                requirements.add(supported(CapabilityDimension.PACKET_LOSS,
                        constraints.maximumPacketLossPercent(), snapshot, requestedAtMillis, horizon));
            }
            if (constraints.minimumBatteryPercent() != null) {
                requirements.add(deferred(CapabilityDimension.BATTERY_ENERGY,
                        constraints.minimumBatteryPercent(), "deferred to the energy reliability event"));
            }
            if (constraints.deadlineEpochMillis() != null) {
                requirements.add(deferred(CapabilityDimension.DEADLINE,
                        constraints.deadlineEpochMillis().doubleValue(),
                        "deferred to the deadline reliability event"));
            }
            if (constraints.requiredExecutionProfile() != null
                    && !constraints.requiredExecutionProfile().isBlank()) {
                requirements.add(deferred(CapabilityDimension.EXECUTION_PROFILE, null,
                        "profile=" + constraints.requiredExecutionProfile()));
            }
        }
        return requirements;
    }

    private RequirementCapability supported(CapabilityDimension dimension,
                                            double required,
                                            DigitalTwinSnapshot snapshot,
                                            long requestedAtMillis,
                                            Long horizon) {
        String unit = dimension.unit();
        if (horizon == null) {
            return new RequirementCapability(dimension, required, unit,
                    CapabilityReason.MISSING_HORIZON, null, null,
                    "no execution horizon; the interval over which the condition must hold is undefined");
        }

        Optional<ResourceBelief> maybeBelief = snapshot.beliefState().beliefFor(dimension.beliefKey());
        if (maybeBelief.isEmpty()) {
            return new RequirementCapability(dimension, required, unit,
                    CapabilityReason.MISSING_BELIEF, null, null,
                    "no belief posterior for " + dimension.beliefKey());
        }

        EvidenceClass evidence = classifyEvidence(snapshot, requestedAtMillis);
        if (evidence == EvidenceClass.AFTER_ORIGIN) {
            return new RequirementCapability(dimension, required, unit,
                    CapabilityReason.EVIDENCE_AFTER_ORIGIN, null, null,
                    "evidence received at " + snapshot.lastTelemetryReceivedAtMillis()
                            + " is after the decision instant " + requestedAtMillis);
        }
        if (evidence != EvidenceClass.FRESH) {
            return new RequirementCapability(dimension, required, unit,
                    CapabilityReason.STALE_EVIDENCE, null, null,
                    "belief evidence is stale or has no usable timestamp for " + dimension.beliefKey());
        }

        ResourceBelief belief = maybeBelief.get();
        double mean = belief.posteriorMean();
        double variance = belief.posteriorVariance();
        if (!Double.isFinite(mean) || !Double.isFinite(variance)) {
            return new RequirementCapability(dimension, required, unit,
                    CapabilityReason.NON_FINITE_PARAMETER, null, null,
                    "belief mean=" + mean + ", variance=" + variance);
        }
        if (!(variance > 0.0)) {
            return new RequirementCapability(dimension, required, unit,
                    CapabilityReason.NON_POSITIVE_VARIANCE, null, null,
                    "belief variance=" + variance + " is not strictly positive");
        }

        Optional<PredictiveDistribution> distribution = distributionSource.distributionFor(belief);
        if (distribution.isEmpty()) {
            return new RequirementCapability(dimension, required, unit,
                    CapabilityReason.NO_PREDICTIVE_MODEL, null, null,
                    "the distribution source produced no predictive law for " + dimension.beliefKey());
        }

        PredictiveDistribution predictive = distribution.get();
        double probability = NormalMath.probabilityAtMost(
                predictive.mean(), predictive.variance(), required);
        return new RequirementCapability(dimension, required, unit,
                CapabilityReason.COMPUTED, probability, predictive,
                "P(X <= " + required + " " + unit + ") under " + predictive.source());
    }

    private RequirementCapability unsupported(CapabilityDimension dimension, Double required) {
        return new RequirementCapability(dimension, required, dimension.unit(),
                dimension.unsupportedReason(), null, null, dimension.note());
    }

    private RequirementCapability deferred(CapabilityDimension dimension, Double required, String detail) {
        return new RequirementCapability(dimension, required, dimension.unit(),
                dimension.unsupportedReason(), null, null, detail);
    }

    // ---------------------------------------------------------------- assembly

    private CapabilityAssessment aggregate(String taskId,
                                           String nodeId,
                                           List<RequirementCapability> requirements,
                                           long requestedAtMillis,
                                           Long horizon) {
        List<RequirementCapability> resourceConditions = requirements.stream()
                .filter(RequirementCapability::isResourceCondition)
                .toList();
        List<RequirementCapability> computed = resourceConditions.stream()
                .filter(RequirementCapability::isComputed)
                .toList();
        List<RequirementCapability> unsupported = resourceConditions.stream()
                .filter(r -> r.reason() == CapabilityReason.NO_PREDICTIVE_MODEL
                        || r.reason() == CapabilityReason.UNIT_MISMATCH)
                .toList();
        boolean anyInvalid = resourceConditions.stream()
                .anyMatch(r -> isInvalid(r.reason()));
        boolean anyEvidenceBlocked = resourceConditions.stream()
                .anyMatch(r -> isEvidenceBlocked(r.reason()));

        CapabilityStatus status;
        Double capability = null;
        boolean jointUnresolved = false;

        if (resourceConditions.isEmpty()) {
            status = CapabilityStatus.COMPUTABLE;
            capability = 1.0;
        } else if (anyInvalid) {
            status = CapabilityStatus.INVALID_INPUT;
        } else if (resourceConditions.stream().noneMatch(r -> r.dimension().supported())) {
            status = CapabilityStatus.UNSUPPORTED_MODEL;
        } else if (!unsupported.isEmpty()) {
            status = computed.isEmpty()
                    ? CapabilityStatus.UNSUPPORTED_MODEL
                    : CapabilityStatus.PARTIALLY_COMPUTABLE;
        } else if (computed.isEmpty()) {
            status = CapabilityStatus.INSUFFICIENT_EVIDENCE;
        } else if (computed.size() == 1) {
            status = CapabilityStatus.COMPUTABLE;
            capability = computed.get(0).probability();
        } else {
            List<Double> marginals = computed.stream()
                    .map(RequirementCapability::probability)
                    .toList();
            OptionalDouble combined = combiner.combine(marginals);
            if (combined.isPresent()) {
                status = CapabilityStatus.COMPUTABLE;
                capability = combined.getAsDouble();
            } else {
                status = CapabilityStatus.PARTIALLY_COMPUTABLE;
                jointUnresolved = true;
            }
        }

        List<CapabilityReason> reasons = new ArrayList<>();
        for (RequirementCapability requirement : requirements) {
            if (!reasons.contains(requirement.reason())) {
                reasons.add(requirement.reason());
            }
        }
        if (resourceConditions.isEmpty() && !reasons.contains(CapabilityReason.VACUOUS_NO_REQUIREMENTS)) {
            reasons.add(CapabilityReason.VACUOUS_NO_REQUIREMENTS);
        }
        if (jointUnresolved && !reasons.contains(CapabilityReason.JOINT_MODEL_UNRESOLVED)) {
            reasons.add(CapabilityReason.JOINT_MODEL_UNRESOLVED);
        }

        return new CapabilityAssessment(taskId, nodeId, status, capability, requirements, reasons,
                requestedAtMillis, horizon, combiner.identifier(), combiner.assumption());
    }

    private CapabilityAssessment notAssessable(String taskId, String nodeId, long requestedAtMillis,
                                               Long horizon, CapabilityReason reason) {
        return new CapabilityAssessment(taskId, nodeId, CapabilityStatus.INVALID_INPUT, null,
                List.of(), List.of(reason), requestedAtMillis, horizon,
                combiner.identifier(), combiner.assumption());
    }

    private static boolean isInvalid(CapabilityReason reason) {
        return reason == CapabilityReason.NON_FINITE_PARAMETER
                || reason == CapabilityReason.NON_POSITIVE_VARIANCE
                || reason == CapabilityReason.MISSING_HORIZON;
    }

    private static boolean isEvidenceBlocked(CapabilityReason reason) {
        return reason == CapabilityReason.MISSING_BELIEF
                || reason == CapabilityReason.STALE_EVIDENCE
                || reason == CapabilityReason.EVIDENCE_AFTER_ORIGIN;
    }

    private EvidenceClass classifyEvidence(DigitalTwinSnapshot snapshot, long requestedAtMillis) {
        long receivedAt = snapshot.lastTelemetryReceivedAtMillis();
        if (receivedAt <= 0L) {
            return EvidenceClass.ABSENT;
        }
        long age = requestedAtMillis - receivedAt;
        if (age < 0L) {
            return EvidenceClass.AFTER_ORIGIN;
        }
        if (age > maxEvidenceAgeMillis) {
            return EvidenceClass.STALE;
        }
        return EvidenceClass.FRESH;
    }

    private static Long horizonOf(Task task) {
        if (task.expectedDurationMillis() != null) {
            return task.expectedDurationMillis();
        }
        return task.constraints().expectedDurationMillis();
    }

    /** Freshness classification of a candidate's belief evidence against the decision instant. */
    private enum EvidenceClass {
        FRESH,
        STALE,
        ABSENT,
        AFTER_ORIGIN
    }
}
