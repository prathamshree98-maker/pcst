package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.task.Task;

import java.util.Collection;

/**
 * The PCST scheduler contract: choose the node to assign a task to at a decision
 * epoch.
 *
 * <p>Specification section 14.2 names the interface as
 * {@code Scheduler.selectNode(task, eligibleCandidates, reliabilityResults) → decision}
 * and section 10.1 defines the rule it must implement:
 * {@code n* = arg max R(n, τ)} over the feasible set {@code F_t(τ)}, subject to
 * {@code R(n*, τ) ≥ θτ}. Implementations receive the already-composed per-candidate
 * results (hard eligibility, capability, reliability) so the {@link Scheduler}
 * itself stays free of belief, prediction, or execution concerns; the concrete
 * {@link PCSTScheduler} also offers an end-to-end entry point that composes them.
 *
 * <p>The interface is deliberately policy-agnostic so that baseline schedulers
 * (round robin, least loaded) can implement the same contract for comparison
 * without changing the infrastructure.
 */
public interface Scheduler {

    /**
     * Applies the policy to a set of prepared candidates.
     *
     * @param task               the task to place; must not be null
     * @param decisionTimeMillis the decision instant {@code t}
     * @param candidates         the candidate results, in any order; null entries are ignored
     * @return the decision; never {@code null}
     */
    SchedulingDecision select(Task task, long decisionTimeMillis,
                              Collection<SchedulingCandidate> candidates);
}
