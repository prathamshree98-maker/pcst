package com.omni.pcst.master.task;

import java.util.ArrayList;
import java.util.List;

/**
 * Execution constraints of a task, from specification section 3.1:
 * "Execution constraints: deadline, energy/battery policy if relevant, QoS target,
 * security/compatibility restrictions, and interruption tolerance."
 *
 * <p>As with {@link TaskResources}, {@code null} means <b>no requirement is
 * expressed</b> while an explicit numeric value is a real requirement. No
 * constraint here is silently defaulted to zero or to "unrestricted".
 *
 * <h2>Units</h2>
 * <ul>
 *   <li>{@code deadlineEpochMillis}: epoch millis, absolute</li>
 *   <li>{@code minimumBatteryPercent}: percent in [0, 100]</li>
 *   <li>{@code maximumNetworkLatencyMillis}: milliseconds, &ge; 0</li>
 *   <li>{@code maximumPacketLossPercent}: percent in [0, 100]</li>
 * </ul>
 */
public record TaskConstraints(
        Long deadlineEpochMillis,
        Long expectedDurationMillis,
        Double minimumBatteryPercent,
        Double maximumNetworkLatencyMillis,
        Double maximumPacketLossPercent,
        InterruptionTolerance interruptionTolerance,
        String requiredExecutionProfile) {

    /** No execution constraints expressed. */
    public static final TaskConstraints NONE =
            new TaskConstraints(null, null, null, null, null, null, null);

    public TaskConstraints {
        List<ValidationViolation> violations = new ArrayList<>();
        violations.addAll(TaskResources.validateBytes("deadlineEpochMillis", deadlineEpochMillis));
        violations.addAll(TaskResources.validateBytes("expectedDurationMillis", expectedDurationMillis));
        violations.addAll(TaskResources.validatePercent("minimumBatteryPercent", minimumBatteryPercent));
        violations.addAll(TaskResources.validateNonNegative("maximumNetworkLatencyMillis",
                maximumNetworkLatencyMillis));
        violations.addAll(TaskResources.validatePercent("maximumPacketLossPercent",
                maximumPacketLossPercent));
        if (!violations.isEmpty()) {
            throw new TaskValidationException(violations);
        }
    }

    /**
     * @return a copy with an absolute deadline derived from a decision instant and
     * the task's expected duration, or empty when either is absent. An explicit
     * zero duration yields a deadline equal to the decision instant, which is
     * legal; that case is deliberately distinguishable from "no duration".
     */
    public List<ValidationViolation> validateAgainstDecisionTime(long decisionTimeMillis) {
        List<ValidationViolation> violations = new ArrayList<>();
        if (deadlineEpochMillis != null && expectedDurationMillis != null) {
            long latestStart = deadlineEpochMillis - expectedDurationMillis;
            if (latestStart < decisionTimeMillis) {
                violations.add(new ValidationViolation("constraints.deadlineEpochMillis",
                        "deadline " + deadlineEpochMillis + " minus expected duration "
                                + expectedDurationMillis + " yields latest start " + latestStart
                                + ", which is already past the decision time " + decisionTimeMillis));
            }
        }
        return violations;
    }

    public boolean hasDeadline() {
        return deadlineEpochMillis != null;
    }

    public boolean hasDuration() {
        return expectedDurationMillis != null;
    }
}