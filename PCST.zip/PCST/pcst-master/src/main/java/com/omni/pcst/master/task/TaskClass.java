package com.omni.pcst.master.task;

/**
 * Task class (workload type), from specification section 3.1
 * ("Identity and workload type: taskId, task class, ...").
 *
 * <p>The specification names a task class but does not enumerate one. The values
 * below are the smallest set that the current PCST telemetry model can actually
 * reason about, and each maps to a resource that the model can evidence.
 *
 * <p><b>This enum is an engineering assumption, not a specification-defined
 * taxonomy.</b> It is deliberately closed and versionable; adding a class is a
 * deliberate act rather than a free-form string.
 */
public enum TaskClass {

    /** No specific class asserted by the submitter. */
    UNSPECIFIED,

    /** Primarily demands processor time. */
    CPU_BOUND,

    /** Primarily demands RAM residency. */
    MEMORY_BOUND,

    /** Requires an accelerator (GPU) to be present. */
    ACCELERATOR_BOUND,

    /** Primarily demands storage throughput or storage residency. */
    IO_BOUND,

    /** Primarily demands network conditions. */
    NETWORK_BOUND
}