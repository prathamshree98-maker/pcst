package com.omni.pcst.master.task;

import java.util.ArrayList;
import java.util.List;

/**
 * An immutable task description, specified independently of any node
 * (specification section 3.1: "A task must be specified independently of a node").
 *
 * <p>The task description is never rewritten to fit a candidate. Node-specific
 * fitting is the job of the hard-constraint filter and, later, of capability and
 * reliability estimation.
 *
 * <h2>Fields</h2>
 * <ul>
 *   <li>{@code taskId} — stable task identity (compliance matrix G6).</li>
 *   <li>{@code taskClass} — workload type.</li>
 *   <li>{@code workloadReference} — executable / container / function reference.</li>
 *   <li>{@code inputCharacteristics} — free-form but validated description of the
 *       input, defaulting to an empty string when the submitter asserts none.</li>
 *   <li>{@code expectedDurationMillis} — the task's duration model. An absent
 *       duration is legal and is preserved as absent; it is never replaced by a
 *       default horizon.</li>
 *   <li>{@code resources} — workload demand.</li>
 *   <li>{@code constraints} — execution constraints.</li>
 * </ul>
 */
public record Task(
        String taskId,
        TaskClass taskClass,
        String workloadReference,
        String inputCharacteristics,
        Long expectedDurationMillis,
        TaskResources resources,
        TaskConstraints constraints) {

    public Task {
        List<ValidationViolation> violations = new ArrayList<>();

        if (taskId == null || taskId.isBlank()) {
            violations.add(new ValidationViolation("taskId", "must be non-blank"));
        }
        if (taskClass == null) {
            violations.add(new ValidationViolation("taskClass", "must not be null"));
        }
        violations.addAll(TaskResources.validateBytes("expectedDurationMillis", expectedDurationMillis));
        if (resources == null) {
            violations.add(new ValidationViolation("resources", "must not be null"));
        }
        if (constraints == null) {
            violations.add(new ValidationViolation("constraints", "must not be null"));
        }
        if (!violations.isEmpty()) {
            throw new TaskValidationException(violations);
        }

        taskClass = taskClass == null ? TaskClass.UNSPECIFIED : taskClass;
        inputCharacteristics = inputCharacteristics == null ? "" : inputCharacteristics;
    }

    /** Minimal valid task: identity, workload reference, and no stated requirements. */
    public static Task minimal(String taskId, String workloadReference) {
        return new Task(taskId, TaskClass.UNSPECIFIED, workloadReference, null, null,
                TaskResources.NONE, TaskConstraints.NONE);
    }

    /** Builder for tasks that express resource or execution requirements. */
    public static Builder builder(String taskId) {
        return new Builder(taskId);
    }

    /** Convenience accessors for the duration model. */
    public boolean hasExpectedDuration() {
        return expectedDurationMillis != null;
    }

    /** Convenience accessor for a workload reference. */
    public boolean hasWorkloadReference() {
        return workloadReference != null && !workloadReference.isBlank();
    }

    /** Mutable builder; produces an immutable {@link Task} on {@link #build()}. */
    public static final class Builder {
        private final String taskId;
        private TaskClass taskClass = TaskClass.UNSPECIFIED;
        private String workloadReference;
        private String inputCharacteristics = "";
        private Long expectedDurationMillis;
        private TaskResources resources = TaskResources.NONE;
        private TaskConstraints constraints = TaskConstraints.NONE;

        private Builder(String taskId) {
            this.taskId = taskId;
        }

        public Builder taskClass(TaskClass value) {
            this.taskClass = value;
            return this;
        }

        public Builder workloadReference(String value) {
            this.workloadReference = value;
            return this;
        }

        public Builder inputCharacteristics(String value) {
            this.inputCharacteristics = value;
            return this;
        }

        public Builder expectedDurationMillis(Long value) {
            this.expectedDurationMillis = value;
            return this;
        }

        public Builder resources(TaskResources value) {
            this.resources = value;
            return this;
        }

        public Builder constraints(TaskConstraints value) {
            this.constraints = value;
            return this;
        }

        public Task build() {
            return new Task(taskId, taskClass, workloadReference, inputCharacteristics,
                    expectedDurationMillis, resources, constraints);
        }
    }
}