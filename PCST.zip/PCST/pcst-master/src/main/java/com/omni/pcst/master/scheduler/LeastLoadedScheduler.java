package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.task.Task;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @deprecated replaced by {@link CapabilityBasedScheduler}
 * Least-loaded scheduler that selects the candidate node with the highest
 * observed capability probability (or highest reliability) as a baseline
 * for scientific comparison with PCST.
 * <p>
 * Policy: selects the candidate with the highest capability {@code capability}
 * value. If capability is null for all candidates, falls back to highest
 * reliability probability.
 * </p>
 * <p>
 * Deterministic tie-breaking: if multiple candidates share the same best
 * capability or reliability value, the first one encountered in the input
 * collection is selected.
 * </p>
 * <p>
 * Note: This scheduler does NOT model CPU utilization, memory pressure, or any
 * observed resource load. It selects purely on the basis of capability
 * probability derived from the Bayesian belief engine and capability engine.
 * Use {@link CapabilityBasedScheduler} instead.
 * </p>
 *
 * @deprecated replaced by {@link CapabilityBasedScheduler}
 */
@Deprecated
public final class LeastLoadedScheduler implements Scheduler {

    private static final CapabilityBasedScheduler DELEGATE = new CapabilityBasedScheduler();

    @Deprecated
    @Override
    public SchedulingDecision select(Task task, long decisionTimeMillis,
                                     Collection<SchedulingCandidate> candidates) {
        return DELEGATE.select(task, decisionTimeMillis, candidates);
    }
}