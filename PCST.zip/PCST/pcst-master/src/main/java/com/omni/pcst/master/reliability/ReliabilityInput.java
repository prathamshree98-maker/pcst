package com.omni.pcst.master.reliability;

import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.Task;

import java.util.Objects;

/**
 * Immutable input for a completion-reliability assessment.
 *
 * <p>It bundles exactly the four things specification section 9 depends on:
 * <ul>
 *   <li>the task {@code τ} (its success contract);</li>
 *   <li>the candidate node's immutable state ({@link DigitalTwinSnapshot});</li>
 *   <li>the hard-constraint outcome ({@link NodeEligibilityResult}), or
 *       {@code null} when hard filtering has not been run; and</li>
 *   <li>the Step 6B capability result ({@link CapabilityAssessment}), which
 *       supplies {@code Eresource}.</li>
 * </ul>
 *
 * <p>Reliability is a composition step: this type carries the capability output
 * in, and the engine never recomputes capability. The capability key may be
 * {@code null} so a caller can ask what happens when it is missing; that is
 * reported as {@link ReliabilityStatus#INVALID_INPUT} rather than guessed.
 *
 * @param task        the task being assessed; must not be null
 * @param snapshot    the candidate node's immutable snapshot; must not be null
 * @param eligibility the hard-constraint outcome, or {@code null} when not run
 * @param capability  the Step 6B capability result, or {@code null} when absent
 */
public record ReliabilityInput(
        Task task,
        DigitalTwinSnapshot snapshot,
        NodeEligibilityResult eligibility,
        CapabilityAssessment capability) {

    public ReliabilityInput {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(snapshot, "snapshot");
    }
}
