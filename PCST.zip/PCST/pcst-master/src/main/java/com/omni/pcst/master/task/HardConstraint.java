package com.omni.pcst.master.task;

/**
 * The hard constraints this milestone can evaluate, from specification section
 * 9 (line 337): "Exclude nodes that cannot run the task due to architecture,
 * required accelerator, security, memory, capacity reservation, node health, or
 * other non-negotiable constraints."
 *
 * <p>Only constraints whose semantics are grounded in the current PCST node
 * model appear here. Constraints that would require capability probabilities
 * (compute throughput over an execution horizon) are represented but are
 * reported as {@link ConstraintOutcome#INDETERMINATE} rather than guessed.
 */
public enum HardConstraint {

    /** Required RAM residency versus observed available memory. Unit: bytes. */
    MEMORY_AVAILABILITY,

    /** Required storage residency versus observed free disk. Unit: bytes. */
    STORAGE_AVAILABILITY,

    /** Accelerator presence. Grounded in the observed accelerator flag. */
    ACCELERATOR_PRESENCE,

    /** Required accelerator device memory. No device-memory field exists today. */
    ACCELERATOR_MEMORY,

    /**
     * Benchmark-normalized compute demand. Specification section 3.2 records
     * this as a modelling gap: the telemetry pipeline observes utilization, which
     * is load and not capacity, so this constraint cannot be evidenced today.
     */
    COMPUTE_CAPACITY,

    /** Absolute deadline feasibility from the task's own duration model. */
    DEADLINE_FEASIBILITY,

    /** Minimum battery level versus observed battery percentage. Unit: percent. */
    BATTERY_LEVEL,

    /** Maximum network latency versus observed latency. Unit: milliseconds. */
    NETWORK_LATENCY,

    /** Maximum packet loss versus observed packet loss. Unit: percent. */
    PACKET_LOSS,

    /** Execution-profile / compatibility restriction. Not evidenced today. */
    EXECUTION_PROFILE
}