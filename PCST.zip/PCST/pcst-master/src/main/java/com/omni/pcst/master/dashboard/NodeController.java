package com.omni.pcst.master.dashboard;

import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * REST API for cluster/node observability.
 */
@RestController
@RequestMapping("/api/v1/nodes")
public class NodeController {

    private final DigitalTwinManager digitalTwinManager;

    public NodeController(DigitalTwinManager digitalTwinManager) {
        this.digitalTwinManager = digitalTwinManager;
    }

    /**
     * Lists all registered nodes with summary information.
     *
     * Response:
     * [
     *   {
     *     "nodeId": "node-1",
     *     "hostname": "host1",
     *     "port": 9091,
     *     "agentVersion": "1.0.0",
     *     "registeredAtMillis": 1700000000000,
     *     "lastHeartbeatMillis": 1700000005000,
     *     "lastTelemetryReceivedAtMillis": 1700000006000,
     *     "staleObservationsRejected": 0,
     *     "hasBeliefState": true,
     *     "latestTelemetry": { ... },
     *     "beliefs": { "cpu_utilization_percent": { ... } }
     *   }
     * ]
     */
    @GetMapping
    public ResponseEntity<List<NodeSummary>> listNodes() {
        Collection<DigitalTwinSnapshot> snapshots = digitalTwinManager.allSnapshots();
        List<NodeSummary> nodes = snapshots.stream()
                .map(NodeSummary::fromSnapshot)
                .collect(Collectors.toList());
        return ResponseEntity.ok(nodes);
    }

    /**
     * Gets detailed information for a specific node.
     *
     * Response:
     * {
     *   "nodeId": "node-1",
     *   "hostname": "host1",
     *   "port": 9091,
     *   "agentVersion": "1.0.0",
     *   "registeredAtMillis": 1700000000000,
     *   "lastRegistrationMillis": 1700000000000,
     *   "lastHeartbeatMillis": 1700000005000,
     *   "lastTelemetryReceivedAtMillis": 1700000006000,
     *   "staleObservationsRejected": 0,
     *   "latestTelemetry": { ... },
     *   "observationHistory": [ ... ],
     *   "beliefState": { ... }
     * }
     */
    @GetMapping("/{nodeId}")
    public ResponseEntity<NodeDetail> getNode(@PathVariable String nodeId) {
        Optional<DigitalTwinSnapshot> snapshotOpt = digitalTwinManager.getSnapshot(nodeId);
        if (snapshotOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        NodeDetail detail = NodeDetail.fromSnapshot(snapshotOpt.get());
        return ResponseEntity.ok(detail);
    }

    /**
     * Gets the count of registered nodes.
     */
    @GetMapping("/count")
    public ResponseEntity<Map<String, Integer>> getNodeCount() {
        return ResponseEntity.ok(Map.of("count", digitalTwinManager.trackedNodeCount()));
    }
}