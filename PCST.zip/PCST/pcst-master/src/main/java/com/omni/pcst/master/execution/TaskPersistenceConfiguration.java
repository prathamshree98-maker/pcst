package com.omni.pcst.master.execution;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.Optional;

/**
 * Conditionally enables Spring Boot's Flyway auto-configuration and defines a
 * {@link DataSource} bean only when {@code pcst.persistence.jdbc.enabled=true}.
 *
 * <p>{@link DataSourceAutoConfiguration} is excluded from {@link
 * PcstMasterApplication} to prevent a connection pool from being created when
 * JDBC persistence is disabled. When enabled, this configuration defines a
 * {@link DataSource} bean from {@code spring.datasource.url} (which may be a
 * Neon libpq URL) and imports {@link FlywayAutoConfiguration} so migrations run
 * on startup.
 *
 * <p>Startup fails closed if the datasource or Flyway migration is unavailable;
 * there is no silent fallback to in-memory persistence.
 */
@Configuration
@ConditionalOnProperty(name = "pcst.persistence.jdbc.enabled", havingValue = "true")
@ImportAutoConfiguration(FlywayAutoConfiguration.class)
class TaskPersistenceConfiguration {

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    DataSourceProperties dataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    DataSource dataSource(DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().build();
    }
}

/**
 * Normalizes the Neon datasource URL into a form the PostgreSQL JDBC driver
 * accepts. Active only when {@code pcst.persistence.jdbc.enabled=true}.
 *
 * <p>Neon connection strings use the libpq {@code postgresql://} scheme with a
 * {@code channel_binding} parameter. The JDBC driver requires the
 * {@code jdbc:postgresql://} scheme and uses {@code channelBinding} (not
 * {@code channel_binding}). This normalizer translates accordingly so that
 * TLS and channel-binding security are preserved rather than silently dropped.
 *
 * <p>Credentials embedded in the URL userinfo are moved into the datasource
 * username/password properties so they are not retained in the JDBC URL.
 */
@Component
@ConditionalOnProperty(name = "pcst.persistence.jdbc.enabled", havingValue = "true")
@Order(Ordered.LOWEST_PRECEDENCE)
class NeonDataSourceUrlNormalizer implements BeanPostProcessor {

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        if (bean instanceof DataSourceProperties props) {
            normalize(props);
        }
        return bean;
    }

    private void normalize(DataSourceProperties props) {
        String url = Optional.ofNullable(props.getUrl()).orElse("");
        if (url.isBlank()) {
            return;
        }
        String normalized = toJdbcUrl(url);
        normalized = stripUserinfo(normalized, props);
        props.setUrl(normalized);
    }

    private static String toJdbcUrl(String url) {
        String u = url;
        if (!u.startsWith("jdbc:")) {
            u = "jdbc:" + u;
        }
        // The PostgreSQL JDBC driver uses channelBinding; translate the libpq
        // channel_binding parameter instead of dropping it.
        u = u.replace("channel_binding=require", "channelBinding=require");
        u = u.replace("channel_binding=prefer", "channelBinding=prefer");
        u = u.replace("?&", "?").replace("&&", "&");
        if (u.endsWith("?") || u.endsWith("&")) {
            u = u.substring(0, u.length() - 1);
        }
        return u;
    }

    private static String stripUserinfo(String url, DataSourceProperties props) {
        int schemeEnd = url.indexOf("://");
        if (schemeEnd < 0) {
            return url;
        }
        int at = url.indexOf('@', schemeEnd);
        if (at <= 0) {
            return url;
        }
        String userInfo = url.substring(schemeEnd + 3, at);
        int colon = userInfo.indexOf(':');
        if (colon > 0) {
            String user = userInfo.substring(0, colon);
            String password = userInfo.substring(colon + 1);
            if (props.getUsername() == null || props.getUsername().isBlank()) {
                props.setUsername(user);
            }
            if (props.getPassword() == null) {
                props.setPassword(password);
            }
        }
        int pathStart = url.indexOf('/', at);
        String hostPort = (pathStart > 0) ? url.substring(at + 1, pathStart) : url.substring(at + 1);
        String rest = (pathStart > 0) ? url.substring(pathStart) : "";
        return url.substring(0, schemeEnd + 3) + hostPort + rest;
    }
}
