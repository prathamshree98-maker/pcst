package com.omni.pcst.master.evaluation.replay;

import com.omni.pcst.master.evaluation.TelemetryEvaluationStore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;

/**
 * Renders an {@link ReplayHarness.EvaluationReport} as JSON or Markdown.
 *
 * <p>Output is deterministic: no wall-clock timestamp is emitted, resources,
 * predictors, horizons and diagnostic categories are written in a fixed order,
 * and numbers are formatted with a fixed locale and precision. Two runs over the
 * same input and configuration therefore produce byte-identical output.
 *
 * <p>Output is always written to a separate destination. Nothing here can
 * overwrite the telemetry JSONL that was evaluated.
 */
public final class ReplayReportWriter {

    private ReplayReportWriter() {
        throw new AssertionError("static factory only");
    }

    /** Renders the report as JSON. */
    public static String toJson(ReplayHarness.EvaluationReport report) {
        ReplayDataset.LoadedDataset dataset = report.dataset();
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"protocol\": \"").append(report.protocol()).append("\",\n");
        sb.append("  \"inputPath\": \"").append(escape(report.inputPath())).append("\",\n");
        sb.append("  \"inputFingerprint\": \"").append(escape(report.inputFingerprint())).append("\",\n");
        sb.append("  \"deterministicOutput\": ").append(report.deterministicOutput()).append(",\n");
        sb.append("  \"horizonsMillis\": ").append(joinLongs(report.horizonsMillis())).append(",\n");
        sb.append("  \"targetToleranceMillis\": ").append(report.targetToleranceMillis()).append(",\n");
        sb.append("  \"observationWindowMillis\": ").append(report.observationWindowMillis()).append(",\n");
        sb.append("  \"minimumObservations\": ").append(report.minimumObservations()).append(",\n");

        sb.append("  \"counts\": {\n");
        sb.append("    \"linesRead\": ").append(dataset.linesRead()).append(",\n");
        sb.append("    \"recordsParsed\": ").append(dataset.recordsParsed()).append(",\n");
        sb.append("    \"eligibleObservations\": ").append(dataset.eligibleObservationCount()).append(",\n");
        sb.append("    \"groups\": ").append(dataset.groups().size()).append("\n");
        sb.append("  },\n");

        sb.append("  \"parseSkips\": {");
        boolean first = true;
        for (Map.Entry<TelemetryEvaluationStore.SkipReason, Long> e : dataset.skipReasons().entrySet()) {
            if (!first) sb.append(", ");
            first = false;
            sb.append("\"").append(e.getKey().name()).append("\": ").append(e.getValue());
        }
        sb.append(" },\n");

        sb.append("  \"eligibilityExclusions\": {");
        first = true;
        for (Map.Entry<ReplayDataset.ExclusionReason, Long> e : dataset.exclusionCounts().entrySet()) {
            if (!first) sb.append(", ");
            first = false;
            sb.append("\"").append(e.getKey().name()).append("\": ").append(e.getValue());
        }
        sb.append(" },\n");

        sb.append("  \"groupCoverage\": [");
        for (int i = 0; i < report.groupCoverage().size(); i++) {
            ReplayHarness.GroupCoverage g = report.groupCoverage().get(i);
            if (i > 0) sb.append(",");
            sb.append("\n    {\"nodeId\": \"").append(escape(g.nodeId()))
                    .append("\", \"sessionId\": \"").append(escape(g.sessionId()))
                    .append("\", \"observations\": ").append(g.observations())
                    .append(", \"firstTimestamp\": ").append(g.firstTimestamp())
                    .append(", \"lastTimestamp\": ").append(g.lastTimestamp()).append("}");
        }
        sb.append(report.groupCoverage().isEmpty() ? "]" : "\n  ]").append(",\n");

        sb.append("  \"metrics\": [");
        for (int i = 0; i < report.metrics().size(); i++) {
            ReplayHarness.MetricCell m = report.metrics().get(i);
            if (i > 0) sb.append(",");
            sb.append("\n    {\"predictor\": \"").append(m.predictor().name())
                    .append("\", \"resource\": \"").append(m.resourceIdentifier())
                    .append("\", \"unit\": \"").append(m.unit())
                    .append("\", \"horizonMillis\": ").append(m.horizonMillis())
                    .append(", \"scoredPairs\": ").append(m.scoredPairs())
                    .append(", \"predictionOpportunities\": ").append(m.predictionOpportunities())
                    .append(", \"forecastsProduced\": ").append(m.forecastsProduced())
                    .append(", \"targetCoverageFailures\": ").append(m.targetCoverageFailures())
                    .append(", \"scoredCoverage\": ").append(fmt(m.scoredCoverage()))
                    .append(", \"mae\": ").append(fmt(m.meanAbsoluteError()))
                    .append(", \"rmse\": ").append(fmt(m.rootMeanSquaredError()))
                    .append(", \"bias\": ").append(fmt(m.meanSignedError()))
                    .append(", \"maxAbsError\": ").append(fmt(m.maxAbsoluteError()))
                    .append(", \"unscoredReasons\": {");
            boolean firstReason = true;
            for (Map.Entry<ReplayHarness.UnscoredReason, Long> e : m.unscoredReasons().entrySet()) {
                if (!firstReason) sb.append(", ");
                firstReason = false;
                sb.append("\"").append(e.getKey().name()).append("\": ").append(e.getValue());
            }
            sb.append("}}");
        }
        sb.append(report.metrics().isEmpty() ? "]" : "\n  ]").append(",\n");

        sb.append("  \"warnings\": [");
        for (int i = 0; i < report.warnings().size(); i++) {
            if (i > 0) sb.append(",");
            sb.append("\n    \"").append(escape(report.warnings().get(i))).append("\"");
        }
        sb.append(report.warnings().isEmpty() ? "]\n" : "\n  ]\n");
        sb.append("}\n");
        return sb.toString();
    }

    /** Renders the report as human-readable Markdown. */
    public static String toMarkdown(ReplayHarness.EvaluationReport report) {
        ReplayDataset.LoadedDataset dataset = report.dataset();
        StringBuilder sb = new StringBuilder();
        sb.append("# PCST Offline Replay Evaluation\n\n");
        sb.append("- **Protocol**: `").append(report.protocol()).append("`\n");
        sb.append("- **Input**: `").append(report.inputPath()).append("`\n");
        sb.append("- **Fingerprint**: `").append(report.inputFingerprint()).append("`\n");
        sb.append("- **Horizons (ms)**: ").append(joinLongs(report.horizonsMillis())).append('\n');
        sb.append("- **Target tolerance (ms)**: ").append(report.targetToleranceMillis()).append('\n');
        sb.append("- **Observation window (ms)**: ").append(report.observationWindowMillis()).append('\n');
        sb.append("- **Minimum observations**: ").append(report.minimumObservations()).append('\n');
        sb.append("- **Deterministic output**: ").append(report.deterministicOutput())
                .append(" (no wall-clock time is recorded)\n\n");

        sb.append("## Record accounting\n\n");
        sb.append("| Category | Count |\n|---|---:|\n");
        sb.append("| Lines read | ").append(dataset.linesRead()).append(" |\n");
        sb.append("| Records parsed | ").append(dataset.recordsParsed()).append(" |\n");
        sb.append("| Eligible observations | ").append(dataset.eligibleObservationCount()).append(" |\n");
        sb.append("| Node/session groups | ").append(dataset.groups().size()).append(" |\n\n");

        if (!dataset.skipReasons().isEmpty()) {
            sb.append("### Parse skips\n\n| Reason | Count |\n|---|---:|\n");
            for (Map.Entry<TelemetryEvaluationStore.SkipReason, Long> e : dataset.skipReasons().entrySet()) {
                sb.append("| ").append(e.getKey().name()).append(" | ").append(e.getValue()).append(" |\n");
            }
            sb.append('\n');
        }
        if (!dataset.exclusionCounts().isEmpty()) {
            sb.append("### Eligibility exclusions\n\n| Reason | Count |\n|---|---:|\n");
            for (Map.Entry<ReplayDataset.ExclusionReason, Long> e : dataset.exclusionCounts().entrySet()) {
                sb.append("| ").append(e.getKey().name()).append(" | ").append(e.getValue()).append(" |\n");
            }
            sb.append('\n');
        }

        sb.append("## Per node/session coverage\n\n");
        sb.append("| Node | Session | Observations | First ts | Last ts |\n");
        sb.append("|---|---|---:|---:|---:|\n");
        for (ReplayHarness.GroupCoverage g : report.groupCoverage()) {
            sb.append("| ").append(g.nodeId()).append(" | ").append(g.sessionId())
                    .append(" | ").append(g.observations())
                    .append(" | ").append(g.firstTimestamp())
                    .append(" | ").append(g.lastTimestamp()).append(" |\n");
        }
        sb.append('\n');

        sb.append("## Metrics\n\n");
        sb.append("MAE / RMSE / bias are in each resource's native unit. ")
                .append("`null` means no scored pairs, never zero error.\n\n");
        sb.append("| Predictor | Resource | Unit | Horizon | Scored | Opps | Coverage | MAE | RMSE | Bias | Max abs |\n");
        sb.append("|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|\n");
        for (ReplayHarness.MetricCell m : report.metrics()) {
            sb.append("| ").append(m.predictor().name())
                    .append(" | ").append(m.resourceIdentifier())
                    .append(" | ").append(m.unit())
                    .append(" | ").append(m.horizonMillis())
                    .append(" | ").append(m.scoredPairs())
                    .append(" | ").append(m.predictionOpportunities())
                    .append(" | ").append(fmt(m.scoredCoverage()))
                    .append(" | ").append(fmt(m.meanAbsoluteError()))
                    .append(" | ").append(fmt(m.rootMeanSquaredError()))
                    .append(" | ").append(fmt(m.meanSignedError()))
                    .append(" | ").append(fmt(m.maxAbsoluteError()))
                    .append(" |\n");
        }
        sb.append('\n');

        sb.append("## Interpretation limits\n\n");
        sb.append("- Metrics measure forecast error only. They are **not** evidence of ")
                .append("calibration, reliability, capability or production readiness.\n");
        sb.append("- Persistence is both an evaluated predictor and the naive reference baseline.\n");
        sb.append("- A sequence gap is a discontinuity in the received stream, not proof of permanent loss.\n");
        sb.append("- Errors are never combined across resources; units differ.\n");

        if (!report.warnings().isEmpty()) {
            sb.append("\n## Warnings\n\n");
            for (String w : report.warnings()) {
                sb.append("- ").append(w).append('\n');
            }
        }
        return sb.toString();
    }

    /**
     * Writes both renderings to an output directory, creating it if needed.
     * The output directory is always distinct from the evaluated input file.
     *
     * @return the JSON file written
     */
    public static Path write(ReplayHarness.EvaluationReport report, Path outputDir) throws IOException {
        Files.createDirectories(outputDir);
        Path jsonPath = outputDir.resolve("replay-evaluation.json");
        Path markdownPath = outputDir.resolve("replay-evaluation.md");
        Files.writeString(jsonPath, toJson(report), StandardCharsets.UTF_8);
        Files.writeString(markdownPath, toMarkdown(report), StandardCharsets.UTF_8);
        return jsonPath;
    }

    private static String joinLongs(long[] values) {
        if (values == null) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(values[i]);
        }
        return sb.append(']').toString();
    }

    /** Fixed-locale, fixed-precision number formatting so output is byte-stable. */
    private static String fmt(Double value) {
        return value == null ? "null" : String.format(Locale.ROOT, "%.6f", value);
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }
}