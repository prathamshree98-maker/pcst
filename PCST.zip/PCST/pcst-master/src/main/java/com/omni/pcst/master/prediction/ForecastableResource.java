package com.omni.pcst.master.prediction;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * The explicit, closed set of resources the prediction stage can forecast.
 *
 * <p>This is the single source of truth for prediction-time resource
 * identifiers. Membership is exact: identifiers are compared with
 * {@link String#equals(Object)} via an immutable lookup map, never with
 * substring matching, so {@code "cpu"} or {@code "gpu"} can never be
 * mistaken for {@code "cpu_utilization_percent"}.
 *
 * <p>The identifiers deliberately reuse the belief keys defined by
 * {@link BayesianBeliefEngine} so that the belief stage and the prediction
 * stage cannot drift apart. Exactly this set is supported: any other
 * identifier is unsupported and must be reported as such rather than
 * silently coerced.
 */
public enum ForecastableResource {

    /** CPU utilization in percent. */
    CPU_UTILIZATION_PERCENT(BayesianBeliefEngine.CPU_UTILIZATION_PERCENT),

    /** Memory utilization in percent, derived from used/total bytes. */
    MEMORY_UTILIZATION_PERCENT(BayesianBeliefEngine.MEMORY_UTILIZATION_PERCENT),

    /** Battery level in percent. */
    BATTERY_LEVEL_PERCENT(BayesianBeliefEngine.BATTERY_LEVEL_PERCENT),

    /** Network round-trip latency in milliseconds. */
    NETWORK_LATENCY_MS(BayesianBeliefEngine.NETWORK_LATENCY_MS),

    /** Network packet loss in percent. */
    NETWORK_PACKET_LOSS_PERCENT(BayesianBeliefEngine.NETWORK_PACKET_LOSS_PERCENT);

    /**
     * Immutable identifier → resource lookup. Built from the enum constants so
     * lookup is O(1) and exact.
     */
    private static final Map<String, ForecastableResource> BY_NAME;

    static {
        Map<String, ForecastableResource> byName = new HashMap<>();
        for (ForecastableResource resource : values()) {
            if (byName.put(resource.identifier, resource) != null) {
                throw new IllegalStateException(
                        "duplicate resource identifier detected: " + resource.identifier);
            }
        }
        BY_NAME = Collections.unmodifiableMap(byName);
    }

    /** Immutable view of every supported identifier, in declaration order. */
    private static final Set<String> IDENTIFIERS =
            Collections.unmodifiableSet(new LinkedHashSet<>(BY_NAME.keySet()));

    private final String identifier;

    ForecastableResource(String identifier) {
        this.identifier = Objects.requireNonNull(identifier, "identifier");
    }

    /** @return the stable resource identifier (identical to the belief key) */
    public String identifier() {
        return identifier;
    }

    /**
     * Exact membership lookup.
     *
     * @param name resource identifier to resolve
     * @return the matching resource, or empty when {@code name} is null or not
     *         a supported identifier
     */
    public static Optional<ForecastableResource> fromIdentifier(String name) {
        if (name == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(BY_NAME.get(name));
    }

    /** @return an immutable, unmodifiable set of every supported identifier */
    public static Set<String> supportedIdentifiers() {
        return IDENTIFIERS;
    }

    /**
     * Extracts one resource's measurement from an observation, applying the
     * required derivation for memory utilization.
     *
     * @param observation raw observation; must not be null
     * @return the measurement value, or {@code null} when the measurement is
     *         unavailable (missing on the wire) or not derivable
     */
    public Double measureFrom(TelemetryObservation observation) {
        Objects.requireNonNull(observation, "observation");
        switch (this) {
            case CPU_UTILIZATION_PERCENT:
                return observation.cpuUtilizationPercent();
            case MEMORY_UTILIZATION_PERCENT:
                return memoryUtilizationPercent(observation);
            case BATTERY_LEVEL_PERCENT:
                return observation.batteryLevelPercent();
            case NETWORK_LATENCY_MS:
                return observation.latencyMs();
            case NETWORK_PACKET_LOSS_PERCENT:
                return observation.packetLossPercent();
            default:
                throw new IllegalStateException("unhandled resource: " + this);
        }
    }

    /**
     * Derives memory utilization as {@code usedMemoryBytes / totalMemoryBytes * 100}.
     *
     * <p>Derivation is attempted only when both byte counts are present and the
     * total is strictly positive; otherwise the measurement is unavailable and
     * carries no information. There is no {@code memoryUtilizationPercent}
     * field on {@link TelemetryObservation}, so this derivation is the only
     * path to a memory utilization figure.
     */
    private static Double memoryUtilizationPercent(TelemetryObservation observation) {
        Long total = observation.totalMemoryBytes();
        Long used = observation.usedMemoryBytes();
        if (total == null || used == null || total <= 0L) {
            return null;
        }
        return used * 100.0 / total;
    }
}
