package com.omni.pcst.master.security;

import java.util.Collections;
import java.util.Map;

/**
 * Immutable snapshot of all persistent enrollment state.
 *
 * <p>This is the unit of serialization for the {@link FileStateStore}. It
 * contains only device credentials and their revocation state. Pairing codes
 * are intentionally excluded: they are short-lived and ephemeral by design, and
 * are not expected to survive a Master restart.
 */
public record StateSnapshot(
        Map<String, CredentialRecord> credentials
) {
    public StateSnapshot {
        if (credentials == null) {
            throw new NullPointerException("credentials must not be null");
        }
    }

    /**
     * Returns an empty snapshot with no credentials.
     */
    public static StateSnapshot empty() {
        return new StateSnapshot(Collections.emptyMap());
    }

    /**
     * Record of one issued device credential.
     */
    public record CredentialRecord(
            String nodeId,
            long issuedAtMillis,
            boolean revoked
    ) {
        public CredentialRecord {
            if (nodeId == null || nodeId.isBlank()) {
                throw new IllegalArgumentException("nodeId must not be blank");
            }
        }
    }
}
