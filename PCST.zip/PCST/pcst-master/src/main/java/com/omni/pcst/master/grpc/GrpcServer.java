package com.omni.pcst.master.grpc;

import io.grpc.Server;
import io.grpc.netty.shaded.io.grpc.netty.NettyServerBuilder;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

@Component
public class GrpcServer {

    private static final Logger log = LoggerFactory.getLogger(GrpcServer.class);

    private final int port;
    private final NodeServiceImpl nodeService;
    private final String tlsMode;
    private final String certChainFile;
    private final String privateKeyFile;
    private Server server;

    public GrpcServer(@Value("${grpc.server.port:9090}") int port,
                      NodeServiceImpl nodeService,
                      @Value("${pcst.grpc.tls.mode:disabled}") String tlsMode,
                      @Value("${pcst.grpc.tls.cert-chain-file:}") String certChainFile,
                      @Value("${pcst.grpc.tls.private-key-file:}") String privateKeyFile) {
        this.port = port;
        this.nodeService = nodeService;
        this.tlsMode = (tlsMode == null) ? "disabled" : tlsMode.trim().toLowerCase();
        this.certChainFile = (certChainFile == null) ? "" : certChainFile.trim();
        this.privateKeyFile = (privateKeyFile == null) ? "" : privateKeyFile.trim();
        validateTlsConfiguration();
    }

    /**
     * Validates the TLS configuration. In {@code production} mode, a certificate chain
     * and private key are mandatory; the server fails closed when they are missing.
     */
    private void validateTlsConfiguration() {
        if ("production".equals(tlsMode)) {
            if (certChainFile.isEmpty()) {
                throw new IllegalStateException(
                        "TLS production mode requires pcst.grpc.tls.cert-chain-file to be set");
            }
            if (privateKeyFile.isEmpty()) {
                throw new IllegalStateException(
                        "TLS production mode requires pcst.grpc.tls.private-key-file to be set");
            }
        } else if ("development".equals(tlsMode)) {
            if (certChainFile.isEmpty() || privateKeyFile.isEmpty()) {
                throw new IllegalStateException(
                        "TLS development mode requires pcst.grpc.tls.cert-chain-file and "
                                + "pcst.grpc.tls.private-key-file to be set");
            }
        } else if (!"disabled".equals(tlsMode)) {
            throw new IllegalStateException(
                    "Unknown TLS mode: " + tlsMode + ". Use 'disabled', 'development', or 'production'.");
        }
    }

    @PostConstruct
    public void start() throws IOException {
        NettyServerBuilder builder = NettyServerBuilder.forPort(port)
                .addService(nodeService);

        if (!"disabled".equals(tlsMode)) {
            File certChain = Paths.get(certChainFile).toFile();
            File privateKey = Paths.get(privateKeyFile).toFile();
            if (!certChain.isFile()) {
                throw new IOException("TLS certificate chain not found: " + certChain.getAbsolutePath());
            }
            if (!privateKey.isFile()) {
                throw new IOException("TLS private key not found: " + privateKey.getAbsolutePath());
            }
            builder.useTransportSecurity(certChain, privateKey);
            log.info("gRPC server TLS enabled (mode={}, cert={}, key={})",
                    tlsMode, certChain.getAbsolutePath(), privateKey.getAbsolutePath());
        } else {
            log.info("gRPC server plaintext (TLS disabled)");
        }

        server = builder.build().start();
        log.info("gRPC server started, listening on port {}", port);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Shutting down gRPC server due to JVM shutdown");
            GrpcServer.this.stop();
        }));
    }

    @PreDestroy
    public void stop() {
        if (server != null) {
            log.info("Stopping gRPC server...");
            server.shutdown();
            try {
                if (!server.awaitTermination(5, TimeUnit.SECONDS)) {
                    server.shutdownNow();
                }
            } catch (InterruptedException e) {
                server.shutdownNow();
                Thread.currentThread().interrupt();
            }
            log.info("gRPC server stopped.");
        }
    }

    public int getPort() {
        return port;
    }
}
