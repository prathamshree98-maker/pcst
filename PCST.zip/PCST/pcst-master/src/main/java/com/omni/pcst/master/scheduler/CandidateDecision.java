package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.reliability.ReliabilityStatus;
import com.omni.pcst.master.task.RejectionReason;

import java.util.List;
import java.util.Objects;

/**
 * The policy's per-candidate account within one scheduling decision.
 *
 * <p>Every candidate the decision considered appears exactly once, whether it was
 * selected, ranked lower, below threshold, unresolved, or excluded by a hard
 * constraint. This is the decision trace required by specification section 13.1
 * and the compliance matrix: capability and reliability estimates for every
 * evaluated candidate, plus the exclusion reasons for the rest.
 *
 * @param nodeId            the candidate node id
 * @param eligible          whether the candidate passed hard eligibility
 * @param disposition       what the policy did with the candidate
 * @param rejectionReasons  hard-constraint rejection reasons, in filter order
 * @param reliabilityStatus the Step 6C reliability status
 * @param reliability       the reliability estimate in [0, 1], or {@code null} when undefined
 * @param capabilityStatus  the Step 6B capability status name, or {@code "MISSING"}
 * @param capability        the capability estimate in [0, 1], or {@code null} when absent
 * @param explanation       human-readable account of this candidate's outcome
 */
public record CandidateDecision(
        String nodeId,
        boolean eligible,
        CandidateDisposition disposition,
        List<RejectionReason> rejectionReasons,
        ReliabilityStatus reliabilityStatus,
        Double reliability,
        String capabilityStatus,
        Double capability,
        String explanation) {

    public CandidateDecision {
        Objects.requireNonNull(nodeId, "nodeId");
        Objects.requireNonNull(disposition, "disposition");
        Objects.requireNonNull(reliabilityStatus, "reliabilityStatus");
        rejectionReasons = rejectionReasons == null ? List.of() : List.copyOf(rejectionReasons);
        capabilityStatus = capabilityStatus == null ? "" : capabilityStatus;
        explanation = explanation == null ? "" : explanation;
        if (reliability != null && (reliability < 0.0 || reliability > 1.0)) {
            throw new IllegalArgumentException(
                    "reliability must be within [0, 1] (was " + reliability + ")");
        }
        if (capability != null && (capability < 0.0 || capability > 1.0)) {
            throw new IllegalArgumentException(
                    "capability must be within [0, 1] (was " + capability + ")");
        }
        if (reliabilityStatus.hasProbability() != (reliability != null)) {
            throw new IllegalArgumentException(
                    "reliability must be non-null exactly for COMPUTABLE (status=" + reliabilityStatus + ")");
        }
    }

    /** @return true when this candidate was the selected node */
    public boolean selected() {
        return disposition.isSelected();
    }
}
