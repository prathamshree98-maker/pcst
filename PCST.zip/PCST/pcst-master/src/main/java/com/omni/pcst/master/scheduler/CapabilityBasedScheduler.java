package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityDimension;
import com.omni.pcst.master.capability.RequirementCapability;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityStatus;
import com.omni.pcst.master.task.Task;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Capability-based scheduler that selects the candidate node with the highest
 * observed capability probability, as a baseline for scientific comparison with PCST.
 * <p>
 * Policy: selects the candidate with the highest capability {@code capability}
 * value. If capability is null for all candidates, falls back to highest
 * reliability probability.
 * </p>
 * <p>
 * Deterministic tie-breaking: if multiple candidates share the same best
 * capability or reliability value, the first one encountered in the input
 * collection is selected.
 * </p>
 * <p>
 * This scheduler does NOT model CPU utilization, memory pressure, or any
 * observed resource load. It selects purely on the basis of capability
 * probability derived from the Bayesian belief engine and capability engine.
 * </p>
 */
public final class CapabilityBasedScheduler implements Scheduler {

    @Override
    public SchedulingDecision select(Task task, long decisionTimeMillis,
                                     Collection<SchedulingCandidate> candidates) {
        // Filter to eligible candidates only
        List<SchedulingCandidate> eligible = candidates.stream()
                .filter(c -> c.eligible())
                .collect(Collectors.toList());

        if (eligible.isEmpty()) {
            // No eligible candidates
            return new SchedulingDecision(
                    task.taskId(), decisionTimeMillis,
                    SchedulingStatus.NO_FEASIBLE_NODE, null, null, null, false,
                    List.of(),
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no candidate passed hard eligibility; feasible set F_t(tau) is empty");
        }

        // Deduplicate by node id, preserving first occurrence order
        LinkedHashMap<String, SchedulingCandidate> byNodeId = new LinkedHashMap<>();
        for (SchedulingCandidate c : eligible) {
            byNodeId.putIfAbsent(c.nodeId(), c);
        }
        List<SchedulingCandidate> uniqueEligible = new ArrayList<>(byNodeId.values());

        // Find candidate with highest capability probability
        // Deterministic tie-breaking: if multiple candidates share the same
        // best capability value, the first by node-id order is selected.
        List<SchedulingCandidate> sortedByNodeId = new ArrayList<>(uniqueEligible);
        sortedByNodeId.sort(Comparator.comparing(SchedulingCandidate::nodeId));

        SchedulingCandidate bestCandidate = null;
        Double bestCapability = null;

        for (SchedulingCandidate c : sortedByNodeId) {
            Double cap = c.capability() == null ? null : c.capability().capability();
            if (cap != null && (bestCapability == null || cap > bestCapability)) {
                bestCapability = cap;
                bestCandidate = c;
            }
        }

        String selectedNodeId;
        double selectedReliability = 0.0;
        boolean usedReliabilityFallback = false;

        if (bestCandidate != null && bestCapability != null) {
            selectedNodeId = bestCandidate.nodeId();
            selectedReliability = bestCandidate.reliability().reliability();
            usedReliabilityFallback = false;
        } else {
            // Fallback: select candidate with highest reliability probability
            Double bestReliability = null;
            for (SchedulingCandidate c : uniqueEligible) {
                Double rel = c.reliability().reliability();
                if (rel != null && (bestReliability == null || rel > bestReliability)) {
                    bestReliability = rel;
                    bestCandidate = c;
                }
            }
            selectedNodeId = bestCandidate.nodeId();
            selectedReliability = bestCandidate.reliability().reliability();
            usedReliabilityFallback = true;
        }

        // Build candidate trace: all eligible candidates get a disposition
        List<CandidateDecision> trace = new ArrayList<>(uniqueEligible.size());
        for (SchedulingCandidate c : uniqueEligible) {
            boolean isSelected = c.nodeId().equals(selectedNodeId);
            // Access reliability via accessor methods (per SchedulingCandidate record components)
            ReliabilityStatus relStatus = c.reliability().status();
            // Access capability status via accessor method
            String capStatus = c.reliability().capabilityStatus();
            // Access capability probability via accessor method
            Double capValue = c.capability() == null ? null : c.capability().capability();
            CandidateDisposition disposition;
            if (isSelected) {
                disposition = CandidateDisposition.SELECTED;
            } else if (usedReliabilityFallback && c == bestCandidate) {
                disposition = CandidateDisposition.SELECTED;
            } else {
                disposition = CandidateDisposition.LOWER_RELIABILITY;
            }
            trace.add(new CandidateDecision(
                    c.nodeId(), c.eligible(),
                    disposition,
                    c.eligibility().reasons(),
                    relStatus,
                    c.reliability().reliability(),
                    capStatus,
                    capValue,
                    isSelected ? "selected by capability-based policy (best capability)"
                            : "eligible but not selected by capability-based policy")
            );
        }

        // Build reasons list
        List<SchedulingReason> reasons = new ArrayList<>();
        if (usedReliabilityFallback) {
            reasons.add(SchedulingReason.SELECTED_HIGHEST_RELIABILITY);
        } else {
            reasons.add(SchedulingReason.SELECTED_HIGHEST_RELIABILITY);
        }
        reasons.add(SchedulingReason.NO_POLICY_THRESHOLD_CONFIGURED);
        // Report if the selected candidate has unresolved reliability
        for (SchedulingCandidate c : uniqueEligible) {
            if (c.nodeId().equals(selectedNodeId) && c.reliability().status() != ReliabilityStatus.COMPUTABLE) {
                reasons.add(SchedulingReason.SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE);
                break;
            }
        }

        String derivation;
        if (usedReliabilityFallback) {
            derivation = "selected node " + selectedNodeId + " via capability-based policy "
                    + "(fallback to highest reliability; capability not available for any eligible candidate)";
        } else {
            derivation = "selected node " + selectedNodeId + " via capability-based policy "
                    + "(best capability probability = " + bestCapability + "; "
                    + "selected node reliability = " + selectedReliability + ")";
        }

        return new SchedulingDecision(
                task.taskId(), decisionTimeMillis,
                SchedulingStatus.SELECTED,
                selectedNodeId, selectedReliability, null, false,
                trace, reasons, derivation);
    }
}