package com.omni.pcst.master.evaluation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Smallest append-only persistence mechanism for evaluation telemetry.
 *
 * <p>Concurrency model: {@link #append(TelemetryEvaluationRecord)},
 * {@link #flush()} and {@link #close()} are all {@code synchronized} on this
 * instance. Because no append can interleave with a flush, a failed flush can
 * always put the drained batch back into the (now empty) bounded queue without
 * losing or duplicating records. This serializes ingestion with disk writes,
 * which is acceptable for telemetry rates and guarantees a consistent log.
 *
 * <p>Requirements satisfied:
 * <ul>
 *   <li>Append-only JSON Lines format ({@code .jsonl}) with an explicit schema
 *       version ({@value #FORMAT_VERSION}). The schema version describes the
 *       record shape only; collection provenance is carried separately in each
 *       record's {@code collectionConfigVersion} field. Existing files are
 *       opened in append mode and never truncated.</li>
 *   <li><b>All 16 {@link TelemetryObservation} components are persisted</b>, with
 *       absent measurements represented as explicit JSON {@code null} and never
 *       as zero, and never omitted.</li>
 *   <li>Unreadable lines are skipped and <b>reported by reason</b> through
 *       {@link ReadResult}; they are never re-interpreted under a different
 *       schema version and never fabricated.</li>
 *   <li>Validated, independently configurable flush threshold and queue
 *       capacity (no silent derivation).</li>
 *   <li>Bounded in-memory queue: overflow is counted and reported, never
 *       silently dropped.</li>
 *   <li>Write failure is retained (unwritten records are re-queued) and exposed
 *       via {@link #getLastWriteError()} / {@link #getFlushFailures()}.</li>
 *   <li>Optional fail-fast single-writer file lock so two Masters cannot write
 *       the same file.</li>
 *   <li>No database dependency. JSON is handled by Jackson, already present via
 *       {@code spring-boot-starter-web}; no dependency was added.</li>
 * </ul>
 *
 * <p>Not a guaranteed clock-sync mechanism: {@code observationTimestamp}
 * originates from the telemetry request and {@code ingestionTimestamp} from the
 * Master clock. {@code append()} returning does <em>not</em> mean a record has
 * reached disk; only {@link #getPersistedRecords()} reflects durable writes.
 */
public final class TelemetryEvaluationStore implements AutoCloseable {

    /**
     * Schema (record format) version written into every record and required on
     * read.
     *
     * <p><b>Schema version is NOT collection provenance.</b> This constant
     * describes the <em>shape of the JSON record</em> and changes only when that
     * shape changes. The collection configuration under which a record was
     * gathered is a separate value carried in each record's
     * {@code collectionConfigVersion} field; see
     * {@link TelemetryEvaluationRecord#collectionConfigVersion()}.
     */
    public static final String FORMAT_VERSION = "pcst-eval-v4";

    /**
     * Previous schema versions, retained only to recognise and report legacy
     * lines. None is readable:
     * <ul>
     *   <li>{@code v1} persisted only 8 of the 16 observation components.</li>
     *   <li>{@code v2} persisted all 16 observation components but carried no
     *       {@code agentSessionId} / {@code telemetrySequence} metadata.</li>
     *   <li>{@code v3} added session and sequence metadata but recorded neither
     *       the sequence classification nor whether the Digital Twin accepted the
     *       observation.</li>
     * </ul>
     * Reading any of them under the current schema would silently present absent
     * data (dropped fields, invented sequence values, invented classifications or
     * invented acceptance decisions) as real telemetry. Lines carrying them are
     * skipped and reported as {@link SkipReason#UNSUPPORTED_SCHEMA_VERSION}. They
     * are never re-interpreted and never back-filled with fabricated evidence.
     */
    public static final String LEGACY_FORMAT_VERSION = "pcst-eval-v1";

    /** Superseded schema version: complete observations, no sequence metadata. */
    public static final String LEGACY_FORMAT_VERSION_V2 = "pcst-eval-v2";

    /** Superseded schema version: session/sequence metadata, no acceptance evidence. */
    public static final String LEGACY_FORMAT_VERSION_V3 = "pcst-eval-v3";

    /** Every schema version this store recognises but will not read. */
    public static final Set<String> LEGACY_FORMAT_VERSIONS = Set.of(
            LEGACY_FORMAT_VERSION, LEGACY_FORMAT_VERSION_V2, LEGACY_FORMAT_VERSION_V3);

    /** Schema versions this store can read. Only {@link #FORMAT_VERSION}. */
    public static final Set<String> READABLE_FORMAT_VERSIONS = Set.of(FORMAT_VERSION);

    /**
     * Explicit marker written into {@code collectionConfigVersion} when no
     * collection configuration version was supplied. Recorded as
     * {@link SkipReason}-free data with explicit unknown provenance rather than
     * being silently replaced by the schema version or any invented value.
     */
    public static final String UNKNOWN_COLLECTION_CONFIG_VERSION = "unknown";

    /** Default number of queued records that triggers a threshold flush. */
    public static final int DEFAULT_FLUSH_LIMIT = 50;

    /** Default bounded queue capacity. */
    public static final int DEFAULT_QUEUE_CAPACITY = 10000;

    /**
     * JSON codec. Jackson is already present on the compile classpath via
     * {@code spring-boot-starter-web}; no dependency was added. It provides
     * correct, symmetric escaping/unescaping of quotes, backslashes, control
     * characters and non-ASCII text, which the previous hand-written
     * concatenation/regular-expression codec did not (it escaped on write but
     * never unescaped on read).
     */
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** Encodings for non-finite doubles so they stay valid, lossless JSON. */
    private static final String ENC_NAN = "NaN";
    private static final String ENC_POS_INF = "Infinity";
    private static final String ENC_NEG_INF = "-Infinity";

    private final Path outputPath;
    private final ArrayBlockingQueue<TelemetryEvaluationRecord> queue;
    private final int flushLimit;
    private final int queueCapacity;
    private final boolean fileLocking;

    private final AtomicLong acceptedRecords = new AtomicLong();
    private final AtomicLong persistedRecords = new AtomicLong();
    private final AtomicLong rejectedRecords = new AtomicLong();
    private final AtomicLong flushFailures = new AtomicLong();
    private final AtomicLong flushCount = new AtomicLong();

    private volatile String lastWriteError = null;
    private volatile long lastReadSkippedLines = 0L;
    private volatile Map<SkipReason, Long> lastReadSkipReasons = Map.of();
    private volatile boolean closing = false;
    private volatile boolean closed = false;

    private RandomAccessFile lockFile;
    private FileLock fileLock;

    /**
     * Full constructor.
     *
     * @param outputPath   JSON Lines output path
     * @param flushLimit   record count that triggers an immediate flush (&gt;= 1
     *                     and &lt;= {@code queueCapacity})
     * @param queueCapacity bounded queue capacity (&gt;= 1)
     * @param fileLocking  when true, hold an exclusive lock on
     *                     {@code <outputPath>.lock}; fails fast if unavailable
     */
    public TelemetryEvaluationStore(Path outputPath, int flushLimit, int queueCapacity, boolean fileLocking) {
        this.outputPath = Objects.requireNonNull(outputPath, "outputPath");
        if (flushLimit < 1) {
            throw new IllegalArgumentException("flushLimit must be >= 1 (was " + flushLimit + ")");
        }
        if (queueCapacity < 1) {
            throw new IllegalArgumentException("queueCapacity must be >= 1 (was " + queueCapacity + ")");
        }
        if (flushLimit > queueCapacity) {
            throw new IllegalArgumentException(
                    "flushLimit (" + flushLimit + ") must not exceed queueCapacity (" + queueCapacity + ")");
        }
        this.flushLimit = flushLimit;
        this.queueCapacity = queueCapacity;
        this.fileLocking = fileLocking;
        this.queue = new ArrayBlockingQueue<>(queueCapacity);
        if (fileLocking) {
            acquireFileLock();
        }
    }

    /** Backward-compatible constructor: single-writer locking disabled. */
    public TelemetryEvaluationStore(Path outputPath, int flushLimit, int queueCapacity) {
        this(outputPath, flushLimit, queueCapacity, false);
    }

    /** Backward-compatible constructor: default queue capacity, locking disabled. */
    public TelemetryEvaluationStore(Path outputPath, int flushLimit) {
        this(outputPath, flushLimit, DEFAULT_QUEUE_CAPACITY, false);
    }

    /** Backward-compatible constructor: documented defaults, locking disabled. */
    public TelemetryEvaluationStore(Path outputPath) {
        this(outputPath, DEFAULT_FLUSH_LIMIT, DEFAULT_QUEUE_CAPACITY, false);
    }

    /**
     * Append one record. When the queue reaches the configured flush threshold a
     * synchronous flush is triggered. A full queue or a closed store is counted
     * as a rejection; appending to a closed store also throws.
     *
     * @throws IllegalStateException when the store is already closed
     */
    public synchronized void append(TelemetryEvaluationRecord record) {
        Objects.requireNonNull(record, "record");
        if (closing || closed) {
            rejectedRecords.incrementAndGet();
            throw new IllegalStateException("Store is closed; append rejected");
        }
        if (!queue.offer(record)) {
            rejectedRecords.incrementAndGet();
            lastWriteError = "Queue overflow: record rejected (capacity=" + queueCapacity + ")";
            return;
        }
        acceptedRecords.incrementAndGet();
        if (queue.size() >= flushLimit) {
            flush();
        }
    }

    /**
     * Flush queued records to disk. Safe to call concurrently (it serializes on
     * this instance). On write failure the unwritten records are retained and
     * counted; nothing is silently discarded.
     */
    public synchronized void flush() {
        if (queue.isEmpty()) {
            return;
        }
        List<TelemetryEvaluationRecord> batch = new ArrayList<>();
        queue.drainTo(batch);
        try {
            writeBatch(batch);
            lastWriteError = null;
            flushCount.incrementAndGet();
        } catch (IOException e) {
            flushFailures.incrementAndGet();
            lastWriteError = "Flush failed: " + e.getMessage()
                    + " (" + queue.size() + " record(s) retained)";
        }
    }

    private void writeBatch(List<TelemetryEvaluationRecord> batch) throws IOException {
        Path parent = outputPath.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
        int written = 0;
        try {
            for (TelemetryEvaluationRecord rec : batch) {
                Files.writeString(outputPath, serializeRecord(rec) + System.lineSeparator(),
                        StandardOpenOption.CREATE,
                        StandardOpenOption.APPEND,
                        StandardOpenOption.SYNC);
                written++;
            }
        } finally {
            if (written > 0) {
                persistedRecords.addAndGet(written);
            }
            if (written < batch.size()) {
                // Retain the unwritten remainder. Serialization on this monitor
                // guarantees the drained remainder fits back into the empty queue,
                // so records are never lost and already-written records are never
                // re-written (no duplication).
                queue.addAll(batch.subList(written, batch.size()));
            }
        }
    }

    /** @return the last write/flush failure message, or null if the last flush succeeded */
    public String getLastWriteError() {
        return lastWriteError;
    }

    /** @return whether an error was recorded since creation or last successful flush */
    public boolean hasWriteError() {
        return lastWriteError != null;
    }

    /**
     * Read all persisted records in event-timestamp order. Lines with an unknown
     * schema version or malformed content are preserved in the file and skipped
     * here rather than destroyed; the skip is surfaced through
     * {@link #readAllWithDiagnostics()} and {@link #getLastReadSkippedLines()}.
     *
     * <p>Repeatable: this method always re-reads the whole file from the start
     * and maintains no read cursor, so calling it repeatedly yields the same
     * result for an unchanged file.
     */
    public List<TelemetryEvaluationRecord> readAll() throws IOException {
        return readAllWithDiagnostics().records();
    }

    /**
     * Read all persisted records together with a per-call diagnostic describing
     * which lines were skipped and why. Skipped lines are malformed or carry an
     * unsupported schema version; they are never converted into synthetic
     * telemetry and never re-interpreted under a different schema.
     */
    public ReadResult readAllWithDiagnostics() throws IOException {
        // Delegates to the single shared read path so that the store and the
        // offline evaluation harness cannot diverge in how they parse a record.
        ReadResult result = readFile(outputPath);
        lastReadSkippedLines = result.skippedLineCount();
        lastReadSkipReasons = result.skipReasons();
        return result;
    }

    /** Why a line present in the log was not returned as a record. */
    public enum SkipReason {
        /** Line is not parseable JSON, or is not a JSON object. */
        MALFORMED_JSON,
        /** {@code v} names a schema version this store cannot read. */
        UNSUPPORTED_SCHEMA_VERSION,
        /** A field required by the schema is absent or JSON null. */
        MISSING_REQUIRED_FIELD,
        /** A field is present but has the wrong JSON type. */
        INVALID_FIELD_TYPE,
        /** Field values are structurally present but semantically unusable. */
        SENTINEL_VALUE
    }

    /**
     * One skipped line and the reason it was skipped.
     *
     * @param rawLine the offending line, preserved verbatim for diagnosis
     * @param reason  why it was not returned
     */
    public record SkippedRecord(String rawLine, SkipReason reason) {
    }

    /** Internal parse outcome: either a record or a reason it was rejected. */
    private record ParseOutcome(TelemetryEvaluationRecord record, SkipReason reason) {
        static ParseOutcome ok(TelemetryEvaluationRecord r) {
            return new ParseOutcome(r, null);
        }

        static ParseOutcome skip(SkipReason reason) {
            return new ParseOutcome(null, reason);
        }
    }

    /**
     * Immutable result of {@link #readAllWithDiagnostics()}.
     *
     * @param records      parsed, deterministically ordered records
     * @param skipReasons  count of skipped lines per {@link SkipReason}
     * @param skipped      the offending lines themselves, for diagnosis
     */
    public record ReadResult(List<TelemetryEvaluationRecord> records,
                             Map<SkipReason, Long> skipReasons,
                             List<SkippedRecord> skipped) {

        /** @return total number of non-empty lines that were not returned */
        public long skippedLineCount() {
            return skipped.stream().map(SkippedRecord::rawLine).distinct().count();
        }

        /** @return count skipped for one reason, or 0 when none */
        public long count(SkipReason reason) {
            return skipReasons.getOrDefault(reason, 0L);
        }
    }

    /**
     * Prevents new appends, attempts to drain the queue, and releases the writer
     * lock. If the drain fails the failure is exposed via
     * {@link #getLastWriteError()} and {@link #getQueueSize()}; the caller must
     * not assume every queued record reached disk.
     */
    @Override
    public synchronized void close() {
        if (closed) {
            return;
        }
        closing = true;
        flush();
        closed = true;
        if (!queue.isEmpty()) {
            lastWriteError = "Close did not drain all queued records (retained=" + queue.size() + ")";
        }
        releaseFileLock();
    }

    private void acquireFileLock() {
        Path parent = outputPath.getParent();
        try {
            if (parent != null && !Files.exists(parent)) {
                Files.createDirectories(parent);
            }
            Path lockPath = lockPath();
            lockFile = new RandomAccessFile(lockPath.toFile(), "rw");
            FileChannel channel = lockFile.getChannel();
            fileLock = channel.tryLock();
            if (fileLock == null) {
                closeQuietly(lockFile);
                lockFile = null;
                throw new IllegalStateException(
                        "Telemetry evaluation output is already locked by another writer: " + lockPath);
            }
        } catch (OverlappingFileLockException e) {
            closeQuietly(lockFile);
            lockFile = null;
            throw new IllegalStateException(
                    "Telemetry evaluation output is already locked by this JVM: " + lockPath(), e);
        } catch (IOException e) {
            closeQuietly(lockFile);
            lockFile = null;
            throw new IllegalStateException(
                    "Could not acquire telemetry evaluation output lock: " + lockPath(), e);
        }
    }

    private void releaseFileLock() {
        try {
            if (fileLock != null && fileLock.isValid()) {
                fileLock.release();
            }
        } catch (IOException ignored) {
            // Best-effort release; the OS also releases locks on process exit.
        } finally {
            fileLock = null;
            closeQuietly(lockFile);
            lockFile = null;
        }
    }

    private Path lockPath() {
        return outputPath.resolveSibling(outputPath.getFileName() + ".lock");
    }

    private static void closeQuietly(RandomAccessFile file) {
        if (file != null) {
            try {
                file.close();
            } catch (IOException ignored) {
                // nothing further to do
            }
        }
    }

    // ---------------------------------------------------------------- diagnostics

    /** @return records accepted into the queue (not a persistence guarantee) */
    public long getAcceptedRecords() {
        return acceptedRecords.get();
    }

    /** @return records confirmed written to disk */
    public long getPersistedRecords() {
        return persistedRecords.get();
    }

    /** @return records rejected because the queue was full or the store was closed */
    public long getRejectedRecords() {
        return rejectedRecords.get();
    }

    /** @return number of flush attempts that failed */
    public long getFlushFailures() {
        return flushFailures.get();
    }

    /** @return number of successful flush attempts */
    public long getFlushCount() {
        return flushCount.get();
    }

    /**
     * @return how many non-empty lines the most recent read skipped because they
     * were malformed or carried an unsupported schema version. These lines
     * remain in the file for diagnosis; they are never returned as telemetry.
     */
    public long getLastReadSkippedLines() {
        return lastReadSkippedLines;
    }

    /**
     * @return why the most recent read skipped lines, per {@link SkipReason}.
     * Unmodifiable; empty when nothing was skipped.
     */
    public Map<SkipReason, Long> getLastReadSkipReasons() {
        return lastReadSkipReasons;
    }

    /**
     * @return true once {@link #close()} has started. Observability only: it
     * allows callers and tests to assert store state without appending to (and
     * therefore mutating) the store.
     */
    public boolean isClosed() {
        return closing || closed;
    }

    /**
     * Reads every record from an arbitrary JSON Lines file using this store's
     * codec, without creating a store or touching the file.
     *
     * <p>This is the single read path used by both the store instance and the
     * offline evaluation harness, so there is exactly one JSON parser for the
     * {@code pcst-eval-v*} schemas. The file is only ever read; it is never
     * opened for writing and never truncated.
     *
     * @param path JSON Lines file to read
     * @return parsed records plus per-reason skip diagnostics
     * @throws IOException if the file cannot be read
     */
    public static ReadResult readFile(Path path) throws IOException {
        Objects.requireNonNull(path, "path");
        if (!Files.exists(path) || Files.size(path) == 0) {
            return new ReadResult(Collections.emptyList(), Map.of(), List.of());
        }
        List<TelemetryEvaluationRecord> all = new ArrayList<>();
        List<SkippedRecord> skipped = new ArrayList<>();
        Map<SkipReason, Long> reasons = new EnumMap<>(SkipReason.class);
        for (String rawLine : Files.readAllLines(path)) {
            String trimmed = rawLine.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            ParseOutcome outcome = parseLine(trimmed);
            if (outcome.record() != null) {
                all.add(outcome.record());
            } else {
                skipped.add(new SkippedRecord(trimmed, outcome.reason()));
                reasons.merge(outcome.reason(), 1L, Long::sum);
            }
        }
        // Total order: observation time, then node id, then ingestion time.
        // The third key makes the ordering total even for exact duplicates, so
        // the result of a read is deterministic for a given file.
        all.sort(java.util.Comparator
                .comparingLong(TelemetryEvaluationRecord::observationTimestamp)
                .thenComparing(TelemetryEvaluationRecord::nodeId)
                .thenComparingLong(TelemetryEvaluationRecord::ingestionTimestamp));
        return new ReadResult(Collections.unmodifiableList(all),
                Collections.unmodifiableMap(reasons),
                List.copyOf(skipped));
    }

    /** @return current number of queued (unpersisted) records */
    public int getQueueSize() {
        return queue.size();
    }

    /** Backward-compatible alias for {@link #getRejectedRecords()} as an int. */
    public int getRejectedAppends() {
        return (int) rejectedRecords.get();
    }

    public int getFlushLimit() {
        return flushLimit;
    }

    public int getQueueCapacity() {
        return queueCapacity;
    }

    public boolean isFileLocking() {
        return fileLocking;
    }

    /** @return the configured output path */
    public Path getOutputPath() {
        return outputPath;
    }

    // ---------------------------------------------------------------- serialization

    /**
     * Serializes one record to a single JSON line.
     *
     * <p>Every one of the 16 {@link TelemetryObservation} components is written.
     * A missing measurement is written as an explicit JSON {@code null}; it is
     * never omitted and never replaced by a zero or a default. Non-finite
     * doubles ({@code NaN}, {@code Infinity}) are written as the JSON strings
     * {@code "NaN"} / {@code "Infinity"} / {@code "-Infinity"} so that
     * non-standard JSON tokens are never emitted and the value survives the
     * round trip exactly.
     */
    private static String serializeRecord(TelemetryEvaluationRecord r) {
        ObjectNode root = MAPPER.createObjectNode();
        root.put("v", FORMAT_VERSION);
        root.put("nodeId", r.nodeId());
        root.put("observationTimestamp", r.observationTimestamp());
        root.put("ingestionTimestamp", r.ingestionTimestamp());
        root.put("collectionConfigVersion", r.collectionConfigVersion());
        root.put("validForReplay", r.validForReplay());
        // Sequence metadata is written only when reported. An agent that sends no
        // sequence metadata yields absent fields, which read back as null and are
        // therefore distinguishable from a reported id or sequence.
        if (r.agentSessionId() != null) {
            root.put("agentSessionId", r.agentSessionId());
        }
        putNullableLong(root, "telemetrySequence", r.telemetrySequence());
        // Transport classification and gap interval, present only when a
        // classification was recorded. Never invented for legacy records.
        if (r.sequenceClassification() != null) {
            root.put("sequenceClassification", r.sequenceClassification());
        }
        putNullableLong(root, "sequenceGapFrom", r.sequenceGapFrom());
        putNullableLong(root, "sequenceGapTo", r.sequenceGapTo());
        // Explicit acceptance evidence so an audit-only record can never be
        // mistaken for an accepted observation.
        root.put("acceptedByDigitalTwin", r.acceptedByDigitalTwin());

        TelemetryObservation o = r.observation();
        ObjectNode obs = root.putObject("observation");
        obs.put("timestamp", o.timestamp());
        putDouble(obs, "cpuUtilizationPercent", o.cpuUtilizationPercent());
        putLong(obs, "totalMemoryBytes", o.totalMemoryBytes());
        putLong(obs, "usedMemoryBytes", o.usedMemoryBytes());
        putLong(obs, "availableMemoryBytes", o.availableMemoryBytes());
        putBoolean(obs, "gpuAvailable", o.gpuAvailable());
        putDouble(obs, "gpuUtilizationPercent", o.gpuUtilizationPercent());
        putDouble(obs, "batteryLevelPercent", o.batteryLevelPercent());
        putBoolean(obs, "batteryCharging", o.batteryCharging());
        putDouble(obs, "temperatureCelsius", o.temperatureCelsius());
        putDouble(obs, "latencyMs", o.latencyMs());
        putDouble(obs, "packetLossPercent", o.packetLossPercent());
        putLong(obs, "totalDiskBytes", o.totalDiskBytes());
        putLong(obs, "freeDiskBytes", o.freeDiskBytes());
        putInt(obs, "processCount", o.processCount());
        putBoolean(obs, "userActive", o.userActive());

        try {
            return MAPPER.writeValueAsString(root);
        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            // Unreachable for the types above, but never silently swallow it.
            throw new IllegalStateException("failed to serialize evaluation record", e);
        }
    }

    private static void putDouble(ObjectNode node, String field, Double value) {
        if (value == null) {
            node.putNull(field);
        } else if (value.isNaN()) {
            node.put(field, ENC_NAN);
        } else if (value == Double.POSITIVE_INFINITY) {
            node.put(field, ENC_POS_INF);
        } else if (value == Double.NEGATIVE_INFINITY) {
            node.put(field, ENC_NEG_INF);
        } else {
            node.put(field, value.doubleValue());
        }
    }

private static void putLong(ObjectNode node, String field, Long value) {
        if (value == null) {
            node.putNull(field);
        } else {
            node.put(field, value.longValue());
        }
    }

    /** Writes a nullable long on the record root (null becomes explicit JSON null). */
    private static void putNullableLong(ObjectNode node, String field, Long value) {
        putLong(node, field, value);
    }

    private static void putInt(ObjectNode node, String field, Integer value) {
        if (value == null) {
            node.putNull(field);
        } else {
            node.put(field, value.intValue());
        }
    }

    private static void putBoolean(ObjectNode node, String field, Boolean value) {
        if (value == null) {
            node.putNull(field);
        } else {
            node.put(field, value.booleanValue());
        }
    }

    /** Internal control-flow signal carrying the skip reason for one line. */
    private static final class SkipSignal extends RuntimeException {
        private static final long serialVersionUID = 1L;
        private final transient SkipReason reason;

        SkipSignal(SkipReason reason) {
            super(null, null, false, false);
            this.reason = reason;
        }
    }

    /**
     * Parses one JSON line into a record, or reports exactly why it was skipped.
     *
     * <p>Never fabricates telemetry: a line that cannot be read yields a
     * {@link SkipReason}, never a placeholder record. A record whose schema
     * version is not {@link #FORMAT_VERSION} is skipped rather than re-interpreted
     * under the current schema.
     */
    private static ParseOutcome parseLine(String line) {
        try {
            JsonNode root;
            try {
                root = MAPPER.readTree(line);
            } catch (Exception e) {
                return ParseOutcome.skip(SkipReason.MALFORMED_JSON);
            }
            if (root == null || !root.isObject()) {
                return ParseOutcome.skip(SkipReason.MALFORMED_JSON);
            }

            JsonNode versionNode = root.get("v");
            if (versionNode == null || !versionNode.isTextual()) {
                return ParseOutcome.skip(SkipReason.MALFORMED_JSON);
            }
            String version = versionNode.textValue();
            if (!READABLE_FORMAT_VERSIONS.contains(version)) {
                // Explicitly unsupported: never re-interpret a legacy or future
                // schema under the current one.
                return ParseOutcome.skip(SkipReason.UNSUPPORTED_SCHEMA_VERSION);
            }

            String nodeId = readRequiredText(root, "nodeId");
            long observationTimestamp = readRequiredLong(root, "observationTimestamp");
            long ingestionTimestamp = readRequiredLong(root, "ingestionTimestamp");
String collectionConfigVersion = readRequiredText(root, "collectionConfigVersion");
            boolean validForReplay = readRequiredBoolean(root, "validForReplay");

            // Sequence metadata is optional. Absent or null means "not reported";
            // a legacy record is never given a fabricated session id or sequence.
            String agentSessionId = readOptionalText(root, "agentSessionId");
            Long telemetrySequence = readOptionalPositiveLong(root, "telemetrySequence");
            if (telemetrySequence != null && telemetrySequence <= 0L) {
                // A present but non-positive sequence is malformed metadata; it is
                // reported rather than silently coerced to null.
                return ParseOutcome.skip(SkipReason.SENTINEL_VALUE);
            }
            String sequenceClassification = readOptionalText(root, "sequenceClassification");
            Long sequenceGapFrom = readOptionalPositiveLong(root, "sequenceGapFrom");
            Long sequenceGapTo = readOptionalPositiveLong(root, "sequenceGapTo");
            // Required in v4: acceptance evidence must never be inferred or
            // invented for a record that does not state it.
            boolean acceptedByDigitalTwin = readRequiredBoolean(root, "acceptedByDigitalTwin");

            JsonNode obsNode = root.get("observation");
            if (obsNode == null || !obsNode.isObject()) {
                return ParseOutcome.skip(SkipReason.MISSING_REQUIRED_FIELD);
            }

            long observationTimestampField = readRequiredLong(obsNode, "timestamp");
            Double cpu = readNullableDouble(obsNode, "cpuUtilizationPercent");
            Long totalMemory = readNullableLong(obsNode, "totalMemoryBytes");
            Long usedMemory = readNullableLong(obsNode, "usedMemoryBytes");
            Long availableMemory = readNullableLong(obsNode, "availableMemoryBytes");
            Boolean gpuAvailable = readNullableBoolean(obsNode, "gpuAvailable");
            Double gpuUtilization = readNullableDouble(obsNode, "gpuUtilizationPercent");
            Double batteryLevel = readNullableDouble(obsNode, "batteryLevelPercent");
            Boolean batteryCharging = readNullableBoolean(obsNode, "batteryCharging");
            Double temperature = readNullableDouble(obsNode, "temperatureCelsius");
            Double latencyMs = readNullableDouble(obsNode, "latencyMs");
            Double packetLoss = readNullableDouble(obsNode, "packetLossPercent");
            Long totalDisk = readNullableLong(obsNode, "totalDiskBytes");
            Long freeDisk = readNullableLong(obsNode, "freeDiskBytes");
            Integer processCount = readNullableInt(obsNode, "processCount");
            Boolean userActive = readNullableBoolean(obsNode, "userActive");

            if (nodeId.isBlank() || observationTimestamp < 0 || ingestionTimestamp < 0) {
                return ParseOutcome.skip(SkipReason.SENTINEL_VALUE);
            }

            TelemetryObservation observation = new TelemetryObservation(
                    observationTimestampField,
                    cpu, totalMemory, usedMemory, availableMemory,
                    gpuAvailable, gpuUtilization, batteryLevel, batteryCharging,
                    temperature, latencyMs, packetLoss, totalDisk, freeDisk,
                    processCount, userActive);

return ParseOutcome.ok(new TelemetryEvaluationRecord(
                    nodeId, observationTimestamp, observation, ingestionTimestamp,
                    collectionConfigVersion, validForReplay, agentSessionId, telemetrySequence,
                    sequenceClassification, sequenceGapFrom, sequenceGapTo, acceptedByDigitalTwin));
        } catch (SkipSignal e) {
            return ParseOutcome.skip(e.reason);
        } catch (RuntimeException e) {
            return ParseOutcome.skip(SkipReason.MALFORMED_JSON);
        }
    }

    private static String readRequiredText(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v == null || v.isNull()) {
            throw new SkipSignal(SkipReason.MISSING_REQUIRED_FIELD);
        }
        if (!v.isTextual()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        return v.textValue();
    }

    private static long readRequiredLong(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v == null || v.isNull()) {
            throw new SkipSignal(SkipReason.MISSING_REQUIRED_FIELD);
        }
        if (!v.isIntegralNumber()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        return v.longValue();
    }

    private static boolean readRequiredBoolean(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v == null || v.isNull()) {
            throw new SkipSignal(SkipReason.MISSING_REQUIRED_FIELD);
        }
        if (!v.isBoolean()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        return v.booleanValue();
    }

    /** @return the value, or {@code null} for an explicit JSON null */
    private static Double readNullableDouble(JsonNode node, String field) {
        JsonNode v = requirePresent(node, field);
        if (v.isNull()) {
            return null;
        }
        if (v.isNumber()) {
            return v.doubleValue();
        }
        if (v.isTextual()) {
            // Encoded non-finite values only.
            return switch (v.textValue()) {
                case ENC_NAN -> Double.NaN;
                case ENC_POS_INF -> Double.POSITIVE_INFINITY;
                case ENC_NEG_INF -> Double.NEGATIVE_INFINITY;
                default -> throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
            };
        }
        throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
    }

    /** @return the value, or {@code null} for an explicit JSON null */
    private static Long readNullableLong(JsonNode node, String field) {
        JsonNode v = requirePresent(node, field);
        if (v.isNull()) {
            return null;
        }
        if (!v.isIntegralNumber()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        return v.longValue();
    }

    /** @return the value, or {@code null} for an explicit JSON null */
    private static Integer readNullableInt(JsonNode node, String field) {
        JsonNode v = requirePresent(node, field);
        if (v.isNull()) {
            return null;
        }
        if (!v.isIntegralNumber()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        return v.intValue();
    }

    /** @return the value, or {@code null} for an explicit JSON null */
    private static Boolean readNullableBoolean(JsonNode node, String field) {
        JsonNode v = requirePresent(node, field);
        if (v.isNull()) {
            return null;
        }
        if (!v.isBoolean()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        return v.booleanValue();
    }

/**
     * Reads optional string metadata. Returns {@code null} when the field is
     * absent or an explicit JSON null; never invents a value.
     */
    private static String readOptionalText(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v == null || v.isNull()) {
            return null;
        }
        if (!v.isTextual()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        String value = v.textValue();
        return value.isEmpty() ? null : value;
    }

    /**
     * Reads optional integral metadata. Returns {@code null} when absent or an
     * explicit JSON null.
     */
    private static Long readOptionalPositiveLong(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v == null || v.isNull()) {
            return null;
        }
        if (!v.isIntegralNumber()) {
            throw new SkipSignal(SkipReason.INVALID_FIELD_TYPE);
        }
        return v.longValue();
    }

    /**
     * Every schema-v3 observation field must be present. An absent field is a
     * malformed record rather than a missing measurement, so a field dropped by
     * a writer can never be silently reinterpreted as "not measured".
     */
    private static JsonNode requirePresent(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v == null) {
            throw new SkipSignal(SkipReason.MISSING_REQUIRED_FIELD);
        }
        return v;
    }
}
