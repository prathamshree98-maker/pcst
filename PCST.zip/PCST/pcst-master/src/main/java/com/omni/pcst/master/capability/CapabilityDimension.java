package com.omni.pcst.master.capability;

import com.omni.pcst.master.belief.BayesianBeliefEngine;

/**
 * The requirement categories a task can express, and how the capability engine
 * treats each one.
 *
 * <p>This enum is the single place where the gap between the specification's
 * success events and the current node model is written down. Each entry declares:
 * <ul>
 *   <li>{@code resourceCondition} — whether the requirement is part of the
 *       resource event {@code Ares} of capability, or belongs to a different
 *       reliability event ({@code Edeadline}, {@code Eenergy}) or is not a
 *       resource condition at all;</li>
 *   <li>{@code supported} — whether the current model can actually form a
 *       predictive distribution for it;</li>
 *   <li>{@code beliefKey} — the Bayesian belief key used, when supported;</li>
 *   <li>{@code unit} — the required quantity's unit, so unit coherence is explicit;</li>
 *   <li>{@code unsupportedReason} — why an unsupported resource condition cannot be
 *       evaluated, or the deferral reason for non-resource events.</li>
 * </ul>
 *
 * <p>Only {@link #NETWORK_LATENCY} and {@link #PACKET_LOSS} are supported, because
 * they are the only required quantities whose units match a tracked belief
 * (milliseconds and percent respectively). Memory and storage requirements are in
 * <b>bytes</b> while the belief layer tracks a <b>utilization percentage</b>: the
 * two are not commensurate, and turning one into the other would require a
 * fabricated conversion. Accelerator and compute requirements have no predictive
 * model at all on the current node model. These gaps are reported, never guessed.
 */
public enum CapabilityDimension {

    /** Required available memory in bytes. Belief tracks utilization percent, not free bytes. */
    MEMORY_AVAILABILITY(true, false, null, "bytes", CapabilityReason.UNIT_MISMATCH,
            "the belief layer tracks memory utilization percent, which is not commensurate with a byte demand"),

    /** Required free storage in bytes. No storage belief exists. */
    STORAGE_AVAILABILITY(true, false, null, "bytes", CapabilityReason.NO_PREDICTIVE_MODEL,
            "no storage belief is tracked by the current node model"),

    /** Accelerator presence. No probabilistic model of presence exists. */
    ACCELERATOR_PRESENCE(true, false, null, "boolean", CapabilityReason.NO_PREDICTIVE_MODEL,
            "accelerator presence is handled as a hard constraint and has no predictive model"),

    /** Required accelerator device memory in bytes. No device-memory belief exists. */
    ACCELERATOR_MEMORY(true, false, null, "bytes", CapabilityReason.NO_PREDICTIVE_MODEL,
            "no accelerator device-memory capacity or belief is exposed by the node model"),

    /** Benchmark-normalized compute demand. Utilization is load, not capacity. */
    COMPUTE_CAPACITY(true, false, null, "compute units", CapabilityReason.NO_PREDICTIVE_MODEL,
            "compute capacity is not exposed and utilization is load, not capacity"),

    /** Maximum network latency in milliseconds. Supported via the latency belief. */
    NETWORK_LATENCY(true, true, BayesianBeliefEngine.NETWORK_LATENCY_MS, "milliseconds", null,
            "the latency belief is a Gaussian posterior in milliseconds, commensurate with the requirement"),

    /** Maximum packet loss in percent. Supported via the packet-loss belief. */
    PACKET_LOSS(true, true, BayesianBeliefEngine.NETWORK_PACKET_LOSS_PERCENT, "percent", null,
            "the packet-loss belief is a Gaussian posterior in percent, commensurate with the requirement"),

    /** Minimum battery level in percent. A reliability event, not a capability condition. */
    BATTERY_ENERGY(false, false, null, "percent", CapabilityReason.DEFERRED_ENERGY_RELIABILITY,
            "specification section 9 places energy in the reliability success event, not in Ares"),

    /** Absolute deadline. A reliability event, not a capability condition. */
    DEADLINE(false, false, null, "epoch millis", CapabilityReason.DEFERRED_DEADLINE_RELIABILITY,
            "specification section 9 places the deadline in the reliability success event, not in Ares"),

    /** Execution-profile / compatibility restriction. Not a resource condition. */
    EXECUTION_PROFILE(false, false, null, "profile", CapabilityReason.NOT_A_RESOURCE_CONDITION,
            "compatibility is a hard constraint, not a probabilistic resource condition");

    private final boolean resourceCondition;
    private final boolean supported;
    private final String beliefKey;
    private final String unit;
    private final CapabilityReason unsupportedReason;
    private final String note;

    CapabilityDimension(boolean resourceCondition, boolean supported, String beliefKey,
                        String unit, CapabilityReason unsupportedReason, String note) {
        this.resourceCondition = resourceCondition;
        this.supported = supported;
        this.beliefKey = beliefKey;
        this.unit = unit;
        this.unsupportedReason = unsupportedReason;
        this.note = note;
    }

    /** @return true when the requirement is part of the capability resource event {@code Ares} */
    public boolean resourceCondition() {
        return resourceCondition;
    }

    /** @return true when a predictive distribution can currently be formed for this requirement */
    public boolean supported() {
        return supported;
    }

    /** @return the belief key backing a supported condition, or {@code null} */
    public String beliefKey() {
        return beliefKey;
    }

    /** @return the requirement's unit */
    public String unit() {
        return unit;
    }

    /** @return why an unsupported resource condition or deferred event cannot be evaluated */
    public CapabilityReason unsupportedReason() {
        return unsupportedReason;
    }

    /** @return explanatory note for diagnostics; not part of the programmatic contract */
    public String note() {
        return note;
    }
}
