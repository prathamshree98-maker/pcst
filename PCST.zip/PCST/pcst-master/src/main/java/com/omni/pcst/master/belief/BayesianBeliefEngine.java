package com.omni.pcst.master.belief;

import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Bayesian Belief Update Engine (Step 4B).
 *
 * <p>Transforms successive raw {@link TelemetryObservation}s into probabilistic
 * beliefs: one Gaussian posterior per tracked resource. The engine is purely
 * mathematical and deterministic — it consumes observation history and returns
 * an immutable {@link BeliefState}. It does NOT predict future values, score
 * capability or reliability, and feeds no scheduling decision; those stages
 * consume the belief state later.
 *
 * <h2>Model and explicit assumptions</h2>
 * <ol>
 *   <li><b>Static value per resource.</b> Each metric is modelled as i.i.d.
 *       Gaussian draws around an unknown but <em>constant</em> true value within
 *       the observation window. Drift, trends and seasonality are NOT modelled
 *       (prediction is a later stage).</li>
 *   <li><b>Known sensor noise.</b> Each measurement is the true value plus
 *       Gaussian noise of fixed, assumed variance (per-resource
 *       {@code sensorVariance}). The defaults below are documented assumptions,
 *       not learned values; they are constructor-overridable for calibration.</li>
 *   <li><b>Fixed, documented prior.</b> Every resource starts from a stated
 *       Gaussian prior (mean, variance). Weakly informative: centred on a
 *       neutral midpoint with a large variance so data dominates quickly.</li>
 *   <li><b>Missing measurements carry no information.</b> A {@code null}
 *       field (no proto presence on the wire) is skipped: the posterior is
 *       unchanged for that resource. No imputation, no zero-filling.</li>
 *   <li><b>Independence across resources.</b> Per-resource posteriors are
 *       updated independently; cross-resource correlation is not modelled yet.</li>
 *   <li><b>Memory utilization is derived.</b> Used/total bytes are converted
 *       to a utilization percentage before the update; if either is missing
 *       or total is zero, the measurement carries no information.</li>
 * </ol>
 *
 * <h2>Update math (Normal–Normal conjugate)</h2>
 * <p>Prior N(&mu;<sub>0</sub>, &sigma;<sub>0</sub><sup>2</sup>) with n
 * measurements x<sub>i</sub> of noise variance r:
 * <pre>
 *   posterior precision:  1/<i>s</i><sub>n</sub><sup>2</sup> = 1/<i>s</i><sub>0</sub><sup>2</sup> + n/r
 *   posterior mean:        <i>m</i><sub>n</sub> = <i>s</i><sub>n</sub><sup>2</sup> &middot; (<i>m</i><sub>0</sub>/<i>s</i><sub>0</sub><sup>2</sup> + &Sigma;x<sub>i</sub>/r)
 * </pre>
 * The engine recomputes the posterior from the full accepted history on every
 * call, so the result depends only on the history contents, never on call
 * ordering or previous engine state (the engine is stateless).
 *
 * <p>Thread-safety: stateless and safe for concurrent use.
 */
@Component
public class BayesianBeliefEngine {

    /** Belief key for CPU utilization in percent. */
    public static final String CPU_UTILIZATION_PERCENT = "cpu_utilization_percent";

    /** Belief key for memory utilization in percent (used / total). */
    public static final String MEMORY_UTILIZATION_PERCENT = "memory_utilization_percent";

    /** Belief key for battery level in percent. */
    public static final String BATTERY_LEVEL_PERCENT = "battery_level_percent";

    /** Belief key for network latency in milliseconds. */
    public static final String NETWORK_LATENCY_MS = "network_latency_ms";

    /** Belief key for network packet loss in percent. */
    public static final String NETWORK_PACKET_LOSS_PERCENT = "network_packet_loss_percent";

    /**
     * One resource's statistical model: a fixed prior and an assumed sensor
     * noise variance.
     *
     * @param resourceName stable belief key
     * @param priorMean prior mean of the resource value
     * @param priorVariance prior variance (&gt; 0); larger means a weaker prior
     * @param sensorVariance assumed per-measurement noise variance (&gt; 0)
     */
    public record ResourceModel(String resourceName, double priorMean, double priorVariance,
                                double sensorVariance) {
        public ResourceModel {
            Objects.requireNonNull(resourceName, "resourceName");
            if (resourceName.isBlank()) {
                throw new IllegalArgumentException("resourceName must not be blank");
            }
            if (!(priorVariance > 0.0) || !Double.isFinite(priorVariance)) {
                throw new IllegalArgumentException("priorVariance must be positive and finite: " + priorVariance);
            }
            if (!(sensorVariance > 0.0) || !Double.isFinite(sensorVariance)) {
                throw new IllegalArgumentException("sensorVariance must be positive and finite: " + sensorVariance);
            }
            if (!Double.isFinite(priorMean)) {
                throw new IllegalArgumentException("priorMean must be finite: " + priorMean);
            }
        }
    }

    /**
     * Default resource models. Prior means are neutral midpoints (0 for packet
     * loss, which is naturally near zero); prior variances are large
     * (&sigma;=50) so the prior is weak; sensor variances are the documented
     * noise assumptions.
     */
    private static final List<ResourceModel> DEFAULT_MODELS = List.of(
            new ResourceModel(CPU_UTILIZATION_PERCENT, 50.0, 2500.0, 100.0),
            new ResourceModel(MEMORY_UTILIZATION_PERCENT, 50.0, 2500.0, 100.0),
            new ResourceModel(BATTERY_LEVEL_PERCENT, 50.0, 2500.0, 25.0),
            new ResourceModel(NETWORK_LATENCY_MS, 50.0, 2500.0, 100.0),
            new ResourceModel(NETWORK_PACKET_LOSS_PERCENT, 0.0, 100.0, 25.0));

    private final List<ResourceModel> models;

    /** Creates the engine with the default documented resource models. */
    public BayesianBeliefEngine() {
        this(DEFAULT_MODELS);
    }

    /**
     * Creates the engine with custom resource models (e.g. calibrated sensor
     * noise). The order of {@code models} determines the iteration order of
     * produced beliefs.
     */
    public BayesianBeliefEngine(List<ResourceModel> models) {
        Objects.requireNonNull(models, "models");
        if (models.isEmpty()) {
            throw new IllegalArgumentException("models must not be empty");
        }
        List<ResourceModel> copy = new ArrayList<>(models);
        for (int i = 0; i < copy.size(); i++) {
            for (int j = i + 1; j < copy.size(); j++) {
                if (copy.get(i).resourceName().equals(copy.get(j).resourceName())) {
                    throw new IllegalArgumentException(
                            "duplicate resourceName: " + copy.get(i).resourceName());
                }
            }
        }
        this.models = List.copyOf(copy);
    }

    /**
     * Recomputes the belief state from accepted observation history.
     *
     * @param historyNewestFirst bounded history of accepted observations, newest
     *        first (as stored by the Digital Twin)
     * @return {@link BeliefState#UNINITIALIZED} when the history is null or
     *         empty; otherwise a populated state with one posterior per resource
     *         that has at least one non-missing measurement
     */
    public BeliefState update(List<TelemetryObservation> historyNewestFirst) {
        if (historyNewestFirst == null || historyNewestFirst.isEmpty()) {
            return BeliefState.UNINITIALIZED;
        }

        int total = historyNewestFirst.size();
        Map<String, Double> sums = new HashMap<>();
        Map<String, Integer> counts = new HashMap<>();
        for (int i = total - 1; i >= 0; i--) {
            TelemetryObservation observation = historyNewestFirst.get(i);
            for (ResourceModel model : models) {
                Double value = extract(model.resourceName(), observation);
                if (value != null && Double.isFinite(value)) {
                    sums.merge(model.resourceName(), value, Double::sum);
                    counts.merge(model.resourceName(), 1, Integer::sum);
                }
            }
        }

        long latestTimestamp = historyNewestFirst.get(0).timestamp();
        Map<String, ResourceBelief> beliefs = new LinkedHashMap<>();
        for (ResourceModel model : models) {
            int count = counts.getOrDefault(model.resourceName(), 0);
            if (count == 0) {
                continue;
            }
            double priorPrecision = 1.0 / model.priorVariance();
            double dataPrecision = count / model.sensorVariance();
            double posteriorVariance = 1.0 / (priorPrecision + dataPrecision);
            double posteriorMean = posteriorVariance
                    * (model.priorMean() * priorPrecision + sums.get(model.resourceName()) / model.sensorVariance());
            beliefs.put(model.resourceName(), new ResourceBelief(
                    model.resourceName(), posteriorMean, posteriorVariance, count, latestTimestamp));
        }

        return BeliefState.of(beliefs, total, latestTimestamp, System.currentTimeMillis());
    }

    /**
     * Extracts one resource's measurement from an observation, applying any
     * derivation. Returns {@code null} when the measurement is unavailable
     * (missing on the wire) or not derivable — such observations carry no
     * information for that resource.
     */
    private static Double extract(String resourceName, TelemetryObservation observation) {
        return switch (resourceName) {
            case CPU_UTILIZATION_PERCENT -> observation.cpuUtilizationPercent();
            case MEMORY_UTILIZATION_PERCENT -> memoryUtilizationPercent(observation);
            case BATTERY_LEVEL_PERCENT -> observation.batteryLevelPercent();
            case NETWORK_LATENCY_MS -> observation.latencyMs();
            case NETWORK_PACKET_LOSS_PERCENT -> observation.packetLossPercent();
            default -> null;
        };
    }

    private static Double memoryUtilizationPercent(TelemetryObservation observation) {
        Long total = observation.totalMemoryBytes();
        Long used = observation.usedMemoryBytes();
        if (total == null || used == null || total <= 0) {
            return null;
        }
        return used * 100.0 / total;
    }
}
