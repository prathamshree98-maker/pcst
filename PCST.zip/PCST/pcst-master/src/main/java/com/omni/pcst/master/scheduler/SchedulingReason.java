package com.omni.pcst.master.scheduler;

/**
 * Stable reason codes describing how a scheduling decision was reached.
 *
 * <p>Codes are the programmatic contract; the accompanying description is for
 * humans only. Callers branch on the enum, never on message text. A code records
 * <em>why</em> the decision has the status it has; it never encodes a probability
 * and never carries a numeric weight.
 */
public enum SchedulingReason {

    /** The selected node had the highest defined reliability among eligible candidates. */
    SELECTED_HIGHEST_RELIABILITY("the selected node has the highest estimated reliability among eligible candidates"),

    /** The selected node's reliability cleared the configured policy threshold. */
    SELECTED_MEETS_POLICY_THRESHOLD("the selected reliability is at or above the policy threshold"),

    /**
     * No policy threshold was configured, so the highest estimated reliability
     * among eligible nodes was used. Specification section 19 records this as the
     * fallback rule when a threshold is absent, with its limitation exposed.
     */
    NO_POLICY_THRESHOLD_CONFIGURED("no reliability threshold is configured; the highest estimate was used"),

    /** Two or more candidates shared the maximum reliability; the lowest node id was chosen deterministically. */
    TIE_BROKEN_BY_NODE_ID("a reliability tie was broken deterministically by the lowest node id"),

    /** No candidate passed hard eligibility. */
    NO_CANDIDATE_PASSED_HARD_ELIGIBILITY("no candidate passed hard eligibility"),

    /** Eligible candidates with reliability estimates exist, but all are below the policy threshold. */
    ALL_RANKED_CANDIDATES_BELOW_POLICY_THRESHOLD("all eligible candidates with a reliability estimate are below the policy threshold"),

    /** Eligible candidates exist but none carries a defined reliability estimate. */
    NO_ELIGIBLE_CANDIDATE_HAS_A_RELIABILITY_ESTIMATE("no eligible candidate has a defined reliability estimate"),

    /**
     * A ranking was possible, but some eligible candidates had no defined
     * reliability estimate. They were deliberately not ranked rather than being
     * assigned a fabricated value; the limitation is exposed.
     */
    SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE("some eligible candidates have no reliability estimate and were not ranked"),

    /** A configured policy fallback selected the lowest node id among unresolved eligible candidates. */
    POLICY_FALLBACK_LOWEST_NODE_ID("the configured policy fallback selected the lowest node id"),

    /** A candidate was excluded by a proven hard-constraint violation. */
    CANDIDATE_EXCLUDED_BY_PROVEN_HARD_CONSTRAINT("a candidate was excluded by a proven hard-constraint violation"),

    /** A candidate was excluded by an unproven (indeterminate) hard constraint. */
    CANDIDATE_EXCLUDED_BY_INDETERMINATE_HARD_CONSTRAINT("a candidate was excluded by an unproven hard constraint");

    private final String description;

    SchedulingReason(String description) {
        this.description = description;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
