package com.omni.pcst.master.capability;

import java.util.List;
import java.util.OptionalDouble;

/**
 * Combines marginal capability probabilities into an overall capability.
 *
 * <p>Specification sections 8.1 and 8.3 are explicit that multiplying marginal
 * probabilities is valid <b>only</b> when the events are independent, or when a
 * valid conditional factorization is used, and that the preferred definition is a
 * joint event probability. The current model has no joint distribution over
 * resources (the belief engine updates each resource independently as an explicit
 * modelling assumption, not a validated fact), so the default combiner refuses to
 * combine and reports the joint model as unresolved.
 *
 * <p>The independence product is available as a clearly labelled opt-in for
 * callers who consciously accept the approximation; it is never the default.
 */
public interface CapabilityCombiner {

    /**
     * @param marginals marginal probabilities, in declaration order; never null
     * @return the combined capability, or empty when this combiner cannot
     *         justifiably combine them
     */
    OptionalDouble combine(List<Double> marginals);

    /** @return stable identifier of this combiner, for logging and diagnostics */
    String identifier();

    /** @return the assumption under which this combiner's result is valid */
    String assumption();

    /**
     * @return the default combiner that refuses to combine marginals because no
     *         joint model justifies it
     */
    static CapabilityCombiner unresolved() {
        return UnresolvedCapabilityCombiner.INSTANCE;
    }

    /**
     * @return an opt-in combiner that multiplies marginals under an explicit,
     *         unvalidated independence assumption
     */
    static CapabilityCombiner independenceProduct() {
        return IndependenceProductCapabilityCombiner.INSTANCE;
    }

    /** Default: refuses to multiply, because dependence is not modelled. */
    enum UnresolvedCapabilityCombiner implements CapabilityCombiner {
        INSTANCE;

        @Override
        public OptionalDouble combine(List<Double> marginals) {
            return OptionalDouble.empty();
        }

        @Override
        public String identifier() {
            return "unresolved-joint-model";
        }

        @Override
        public String assumption() {
            return "cross-resource dependence is not modelled, so marginal probabilities are not "
                    + "multiplied; an overall capability probability is therefore not defined";
        }
    }

    /** Opt-in: multiplies marginals under a stated independence assumption. */
    enum IndependenceProductCapabilityCombiner implements CapabilityCombiner {
        INSTANCE;

        @Override
        public OptionalDouble combine(List<Double> marginals) {
            double product = 1.0;
            for (double marginal : marginals) {
                product *= marginal;
            }
            return OptionalDouble.of(product);
        }

        @Override
        public String identifier() {
            return "independence-product";
        }

        @Override
        public String assumption() {
            return "assumes the required resource-condition events are mutually independent; this is "
                    + "an explicit approximation, not a validated property of the current model";
        }
    }
}
