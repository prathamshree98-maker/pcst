package com.omni.pcst.master.prediction;

import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Trend-aware challenger predictor (Step 5D) — experimental baseline.
 *
 * <p>Fits OLS linear trend on valid in-window measurements using actual
 * timestamps (with numerical-reference subtraction for stability), then
 * projects to {@code requestedAt + horizon}. This is the smallest defensible
 * trend challenger; it does not claim model superiority or calibration.
 *
 * <p>Model assumption (explicit, per spec §502): linear drift with constant
 * slope across the observation window. Non-linearity, multimodality, or
 * validated non-Gaussian dynamics justify stronger estimators in a later
 * step. No transition model, task conditioning, or reserve treatment is
 * included (G4 deferred to 5E+).
 *
 * <p>When only one valid measurement exists, behavior reproduces the
 * persistence baseline (documented fallback, no fabrication).
 *
 * <p>Uncertainty: omitted rather than mislabelled. The result type carries
 * a single numeric field; with exactly two distinct-time observations OLS
 * fits both points exactly (zero residual), which cannot be distinguished
 * from true certainty in this representation. Therefore the diagnostic is
 * not reported. For three or more points a residual spread could be stated,
 * but is also omitted here to avoid any ambiguity between fit residual and
 * predictive uncertainty. See clarification 5.
 */
public final class TrendResourcePredictor {

    public TrendResourcePredictor() {
    }

    /**
     * Forecast using linear trend challenger.
     *
     * @param request validated forecast request
     * @return result with status; pointEstimate present only for OK
     */
    public ResourceForecast forecast(ForecastRequest request) {
        Objects.requireNonNull(request, "request must not be null");

        if (request.minimumObservations() < 1) {
            return withoutEstimate(ResourceForecast.Status.INVALID_REQUEST,
                    request.resourceIdentifier());
        }

        Optional<ForecastableResource> resource =
                ForecastableResource.fromIdentifier(request.resourceIdentifier());
        if (resource.isEmpty()) {
            return withoutEstimate(ResourceForecast.Status.UNSUPPORTED_RESOURCE,
                    request.resourceIdentifier());
        }
        ForecastableResource target = resource.get();
        DigitalTwinSnapshot snapshot = request.snapshot();

        // --- 1. Resolve history (same as 5C) -------------------------------
        List<TelemetryObservation> history = new ArrayList<>();
        List<TelemetryObservation> stored = snapshot.observationHistory();
        if (stored != null && !stored.isEmpty()) {
            history.addAll(stored);
        } else if (snapshot.latestObservation() != null) {
            history.add(snapshot.latestObservation());
        }
        if (history.isEmpty()) {
            return withoutEstimate(ResourceForecast.Status.MISSING_OBSERVATIONS,
                    target.identifier());
        }

        long requestedAt = request.requestedAtMillis();
        long window = request.observationWindowMillis();
        long windowStart = window <= 0L ? Long.MIN_VALUE : requestedAt - window;

        // --- 2. Filter by window / timestamp (same semantics as 5C) -------
        List<Measurement> candidates = new ArrayList<>();
        int discardedFuture = 0;
        int discardedTooOld = 0;
        for (TelemetryObservation observation : history) {
            if (observation == null) continue;
            long ts = observation.timestamp();
            if (ts > requestedAt) {
                discardedFuture++;
                continue;
            }
            if (ts < windowStart) {
                discardedTooOld++;
                continue;
            }
            Double value = target.measureFrom(observation);
            candidates.add(new Measurement(ts, value));
        }

        if (candidates.isEmpty()) {
            return withoutEstimate(ResourceForecast.Status.STALE_OBSERVATIONS,
                    target.identifier());
        }

        // --- 3. Classify valid / null / non-finite ------------------------
        List<Measurement> valid = new ArrayList<>();
        int nullCount = 0;
        int nonFiniteCount = 0;
        for (Measurement m : candidates) {
            Double v = m.value();
            if (v == null) {
                nullCount++;
                continue;
            }
            if (!Double.isFinite(v)) {
                nonFiniteCount++;
                continue;
            }
            valid.add(m);
        }

        if (valid.isEmpty()) {
            ResourceForecast.Status status = nonFiniteCount > 0
                    ? ResourceForecast.Status.NON_FINITE_MEASUREMENT
                    : ResourceForecast.Status.MISSING_MEASUREMENT;
            return withoutEstimate(status, target.identifier());
        }

        if (valid.size() < request.minimumObservations()) {
            return withoutEstimate(ResourceForecast.Status.INSUFFICIENT_HISTORY,
                    target.identifier());
        }

        // --- 4. Single-point fallback (persistence reproduction) -----------
        if (valid.size() == 1) {
            Measurement newest = valid.get(0);
            return new ResourceForecast(
                    ResourceForecast.Status.OK,
                    target.identifier(),
                    newest.value(),
                    null, // uncertainty omitted per clarification 5
                    newest.timestamp(),
                    1,
                    newest.timestamp(),
                    requestedAt - newest.timestamp());
        }

        // --- 5. OLS trend (timestamp-based, reference-subtracted) ----------
        // Numerical stability: subtract newest timestamp (or mean) from all.
        // Using newest timestamp as reference keeps x close to zero.
        long ref = valid.get(0).timestamp();
        for (Measurement m : valid) {
            if (m.timestamp() > ref) ref = m.timestamp();
        }

        double sumX = 0.0, sumY = 0.0, sumXY = 0.0, sumXX = 0.0;
        int n = valid.size();
        for (Measurement m : valid) {
            double x = (double) (m.timestamp() - ref);
            double y = m.value();
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumXX += x * x;
        }

        double meanX = sumX / n;
        double meanY = sumY / n;
        double denom = sumXX - n * meanX * meanX; // = sum((x-meanX)^2)

        // Defensive: all duplicate timestamps -> denominator ~ 0
        if (Math.abs(denom) < 1e-12) {
            // Cannot compute slope; fall back to persistence (documented)
            Measurement newest = valid.get(0);
            for (Measurement m : valid) {
                if (m.timestamp() > newest.timestamp()) newest = m;
            }
            return new ResourceForecast(
                    ResourceForecast.Status.OK,
                    target.identifier(),
                    newest.value(),
                    null,
                    newest.timestamp(),
                    valid.size(),
                    newest.timestamp(),
                    requestedAt - newest.timestamp());
        }

        double slope = (sumXY - n * meanX * meanY) / denom;
        double intercept = meanY - slope * meanX;

        // Safe arithmetic: compute in double to avoid long overflow.
        // Very large epoch values may lose sub-millisecond precision in double,
        // which is acceptable for this baseline; non-finite result is rejected.
        double targetTime = (double) requestedAt + (double) request.horizonMillis();
        if (!Double.isFinite(targetTime)) {
            return withoutEstimate(ResourceForecast.Status.INVALID_REQUEST,
                    target.identifier());
        }
        double targetX = targetTime - (double) ref;
        double projection = intercept + slope * targetX;

        // If projection is non-finite (overflow/underflow), fall back
        if (!Double.isFinite(projection)) {
            Measurement newest = valid.get(0);
            for (Measurement m : valid) {
                if (m.timestamp() > newest.timestamp()) newest = m;
            }
            return new ResourceForecast(
                    ResourceForecast.Status.OK,
                    target.identifier(),
                    newest.value(),
                    null,
                    newest.timestamp(),
                    valid.size(),
                    newest.timestamp(),
                    requestedAt - newest.timestamp());
        }

        // Newest observation timestamp for provenance
        Measurement newest = valid.get(0);
        for (Measurement m : valid) {
            if (m.timestamp() > newest.timestamp()) newest = m;
        }

        return new ResourceForecast(
                ResourceForecast.Status.OK,
                target.identifier(),
                projection,
                null, // diagnostic omitted per clarification 5
                newest.timestamp(),
                valid.size(),
                newest.timestamp(),
                requestedAt - newest.timestamp());
    }

    private static ResourceForecast withoutEstimate(ResourceForecast.Status status,
                                                     String resourceIdentifier) {
        return ResourceForecast.withoutEstimate(status, resourceIdentifier);
    }

    private record Measurement(long timestamp, Double value) {
    }
}
