package com.omni.pcst.master.evaluation;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration properties for evaluation-telemetry persistence.
 *
 * <p>All properties are independently configurable under the
 * {@code pcst.evaluation} prefix and carry documented defaults. Validation is
 * explicit (see {@link #validate()}) so invalid settings fail at startup with a
 * clear message without requiring a Jakarta Bean Validation provider on the
 * classpath.
 *
 * <p>Semantics of {@code pcst.evaluation.enabled}: when {@code true} (default)
 * exactly one {@link TelemetryEvaluationStore} bean is created and accepted
 * telemetry observations are queued for persistence. When {@code false} no store
 * bean is registered: accepted telemetry is still processed by the Digital Twin
 * but is deliberately <em>not</em> persisted, and the Master logs that the
 * collection run is disabled. This is the safe opt-out for runs that must not
 * write evaluation data.
 */
@ConfigurationProperties(prefix = "pcst.evaluation")
public class TelemetryEvaluationProperties {

    /** Whether evaluation-telemetry persistence is enabled. Disabled means no writes. */
    private boolean enabled = true;

    /**
     * Version label of the <em>collection configuration</em> that produced each
     * record, recorded verbatim in every record's
     * {@code collectionConfigVersion} field.
     *
     * <p>This is provenance and is deliberately independent of the record schema
     * version ({@link TelemetryEvaluationStore#FORMAT_VERSION}), which describes
     * the JSON shape and changes only when that shape changes. Changing this
     * value changes the provenance written to the log and leaves the schema
     * version untouched.
     *
     * <p>When left blank the store records the explicit marker
     * {@link TelemetryEvaluationStore#UNKNOWN_COLLECTION_CONFIG_VERSION}
     * ({@value TelemetryEvaluationStore#UNKNOWN_COLLECTION_CONFIG_VERSION})
     * rather than inventing a version or reusing the schema version.
     */
    private String collectionConfigVersion = "";

    /** Output JSON Lines file for evaluation telemetry. */
    private String path = "./data/eval-telemetry.jsonl";

    /** Bounded in-memory queue capacity for pending records. */
    private int queueCapacity = 10000;

    /** Number of queued records that triggers an immediate (threshold) flush. */
    private int flushLimit = 50;

    /** Periodic flush interval in milliseconds. */
    private long flushIntervalMs = 30000;

    /**
     * Whether to hold an exclusive single-writer lock on the output file.
     * Enabled by default so a second Master targeting the same file fails fast
     * instead of corrupting the log. Tests may disable it when sharing a path.
     */
    private boolean fileLocking = true;

    /**
     * Validates this configuration. Throws {@link IllegalArgumentException}
     * with a precise message when any value is invalid. Never silently derives
     * one value from another.
     */
    public void validate() {
        if (path == null || path.isBlank()) {
            throw new IllegalArgumentException("pcst.evaluation.path must not be blank");
        }
        if (collectionConfigVersion == null) {
            throw new IllegalArgumentException(
                    "pcst.evaluation.collection-config-version must not be null "
                            + "(use an empty value to record provenance as unknown)");
        }
        if (queueCapacity < 1) {
            throw new IllegalArgumentException(
                    "pcst.evaluation.queue-capacity must be >= 1 (was " + queueCapacity + ")");
        }
        if (flushLimit < 1) {
            throw new IllegalArgumentException(
                    "pcst.evaluation.flush-limit must be >= 1 (was " + flushLimit + ")");
        }
        if (flushLimit > queueCapacity) {
            throw new IllegalArgumentException(
                    "pcst.evaluation.flush-limit (" + flushLimit
                            + ") must not exceed pcst.evaluation.queue-capacity (" + queueCapacity + ")");
        }
        if (flushIntervalMs < 1) {
            throw new IllegalArgumentException(
                    "pcst.evaluation.flush-interval-ms must be >= 1 (was " + flushIntervalMs + ")");
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * @return the effective collection configuration provenance: the configured
     * value when present, otherwise the explicit
     * {@link TelemetryEvaluationStore#UNKNOWN_COLLECTION_CONFIG_VERSION} marker.
     * Never returns the schema version and never invents a value.
     */
    public String effectiveCollectionConfigVersion() {
        if (collectionConfigVersion == null || collectionConfigVersion.isBlank()) {
            return TelemetryEvaluationStore.UNKNOWN_COLLECTION_CONFIG_VERSION;
        }
        return collectionConfigVersion;
    }

    public String getCollectionConfigVersion() {
        return collectionConfigVersion;
    }

    public void setCollectionConfigVersion(String collectionConfigVersion) {
        this.collectionConfigVersion = collectionConfigVersion;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getQueueCapacity() {
        return queueCapacity;
    }

    public void setQueueCapacity(int queueCapacity) {
        this.queueCapacity = queueCapacity;
    }

    public int getFlushLimit() {
        return flushLimit;
    }

    public void setFlushLimit(int flushLimit) {
        this.flushLimit = flushLimit;
    }

    public long getFlushIntervalMs() {
        return flushIntervalMs;
    }

    public void setFlushIntervalMs(long flushIntervalMs) {
        this.flushIntervalMs = flushIntervalMs;
    }

    public boolean isFileLocking() {
        return fileLocking;
    }

    public void setFileLocking(boolean fileLocking) {
        this.fileLocking = fileLocking;
    }
}
