package com.omni.pcst.master.execution;

import com.omni.pcst.master.scheduler.SchedulingDecision;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.proto.TaskResult;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;

/**
 * Immutable snapshot of a task's execution state.
 *
 * <p>The actual mutable state is held inside {@link TaskRecord.MutableState};
 * this record provides a safe, thread-confined view for callers.
 *
 * @param taskId            stable task identity
 * @param attemptId         unique attempt identity
 * @param task              the submitted task
 * @param state             current lifecycle state
 * @param createdAt         submission timestamp (server time)
 * @param updatedAt         last state change timestamp
 * @param schedulingDecision the scheduling decision, if scheduling was attempted
 * @param selectedNodeId    node selected by scheduler, if any
 * @param dispatchTime      time dispatch was sent to agent, if any
 * @param result            execution result, if terminal
 * @param errorMessage      error detail for failed/rejected states
 * @param history           ordered state transition history
 */
public record TaskRecord(
        String taskId,
        String attemptId,
        Task task,
        TaskState state,
        long createdAt,
        long updatedAt,
        SchedulingDecision schedulingDecision,
        String selectedNodeId,
        Long dispatchTime,
        TaskResult result,
        String errorMessage,
        List<StateTransition> history) {

    public TaskRecord {
        Objects.requireNonNull(taskId, "taskId");
        Objects.requireNonNull(attemptId, "attemptId");
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(state, "state");
        history = history == null ? List.of() : List.copyOf(history);
    }

    /**
     * @return a new record with the state transitioned, or throws if illegal
     */
    public TaskRecord transitionTo(TaskState newState, long now, String errorMessage) {
        if (!state.canTransitionTo(newState)) {
            throw new IllegalStateException("Illegal transition from " + state + " to " + newState);
        }
        List<StateTransition> newHistory = new ArrayList<>(history);
        newHistory.add(new StateTransition(state, newState, now, errorMessage));
        return new TaskRecord(taskId, attemptId, task, newState, createdAt, now,
                schedulingDecision, selectedNodeId, dispatchTime, result, errorMessage, newHistory);
    }

    public TaskRecord withSchedulingDecision(SchedulingDecision decision, long now) {
        List<StateTransition> newHistory = new ArrayList<>(history);
        newHistory.add(new StateTransition(state, TaskState.DISPATCHING, now,
                "scheduling decision: " + decision.status().description()));
        return new TaskRecord(taskId, attemptId, task, TaskState.DISPATCHING, createdAt, now,
                decision, decision.selectedNodeId(), null, null, null, newHistory);
    }

    /**
     * Records a scheduling decision that produced no selection, applying the
     * correct terminal state while retaining the complete decision and its
     * candidate trace so the rejection remains inspectable.
     *
     * <p>Unlike {@link #transitionTo}, this preserves {@code schedulingDecision}
     * (and its derivation as the error detail) instead of discarding it, so
     * {@code GET /tasks/{id}/decision} can report the actual rejection reasons
     * for both successful and unsuccessful scheduling attempts.
     */
    public TaskRecord withFailedSchedulingDecision(TaskState terminalState,
                                                   SchedulingDecision decision,
                                                   long now) {
        if (!state.canTransitionTo(terminalState)) {
            throw new IllegalStateException("Illegal transition from " + state + " to " + terminalState);
        }
        List<StateTransition> newHistory = new ArrayList<>(history);
        newHistory.add(new StateTransition(state, terminalState, now,
                "scheduling decision: " + decision.status().description()));
        return new TaskRecord(taskId, attemptId, task, terminalState, createdAt, now,
                decision, decision.selectedNodeId(), null, null, decision.derivation(), newHistory);
    }

    public TaskRecord withDispatchSent(long now) {
        List<StateTransition> newHistory = new ArrayList<>(history);
        newHistory.add(new StateTransition(state, state, now, "dispatch sent to " + selectedNodeId));
        return new TaskRecord(taskId, attemptId, task, state, createdAt, now,
                schedulingDecision, selectedNodeId, now, result, errorMessage, newHistory);
    }

    public TaskRecord withDispatchAccepted(long now) {
        return transitionTo(TaskState.DISPATCH_ACCEPTED, now, null);
    }

    public TaskRecord withDispatchRejected(long now, String reason) {
        return transitionTo(TaskState.DISPATCH_REJECTED, now, reason);
    }

    public TaskRecord withRunning(long now) {
        return transitionTo(TaskState.RUNNING, now, null);
    }

    public TaskRecord withResult(TaskResult result, long now) {
        TaskState terminal = result.getSuccess() ? TaskState.SUCCEEDED : TaskState.FAILED;
        // Transition through the guarded state machine so duplicate or delayed
        // terminal results against an already-terminal state are rejected rather
        // than re-recorded into the history.
        return transitionTo(terminal, now,
                result.getSuccess() ? "completed successfully" : "failed: " + result.getError())
                .withResultFields(result, now);
    }

    private TaskRecord withResultFields(TaskResult result, long now) {
        return new TaskRecord(taskId, attemptId, task, state, createdAt, now,
                schedulingDecision, selectedNodeId, dispatchTime, result, result.getError(), history);
    }

    public TaskRecord withOutcomeUnknown(long now, String reason) {
        return transitionTo(TaskState.OUTCOME_UNKNOWN, now, reason);
    }

    /** @return true when the task has reached a terminal state */
    public boolean isTerminal() {
        return state.isTerminal();
    }

    /** @return a defensive copy of the transition history */
    public List<StateTransition> history() {
        return List.copyOf(history);
    }

    /**
     * Creates a new accepted task record.
     */
    public static TaskRecord createAccepted(Task task, String attemptId, long now) {
        return new TaskRecord(task.taskId(), attemptId, task, TaskState.ACCEPTED, now, now,
                null, null, null, null, null, List.of());
    }

    /** A single state transition entry. */
    public record StateTransition(TaskState from, TaskState to, long timestamp, String detail) {
        public StateTransition {
            Objects.requireNonNull(from);
            Objects.requireNonNull(to);
            if (detail == null) detail = "";
        }
    }
}