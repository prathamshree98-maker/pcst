package com.omni.pcst.master.security;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

/**
 * Protected administrative API for device enrollment.
 *
 * <p>All endpoints require a valid administrator bearer token
 * ({@code Authorization: Bearer <admin-api-key>}). When no administrator API key
 * is configured, every endpoint returns HTTP 503 so enrollment cannot be opened
 * to the public by accident.
 */
@RestController
@RequestMapping("/api/v1/admin")
public class PairingAdminController {

    private final PairingCodeService pairingCodeService;
    private final DeviceCredentialService deviceCredentialService;
    private final AdminAuthenticator adminAuthenticator;

    public PairingAdminController(PairingCodeService pairingCodeService,
                                  DeviceCredentialService deviceCredentialService,
                                  AdminAuthenticator adminAuthenticator) {
        this.pairingCodeService = pairingCodeService;
        this.deviceCredentialService = deviceCredentialService;
        this.adminAuthenticator = adminAuthenticator;
    }

    private ResponseEntity<?> requireAdmin(@RequestHeader(name = "Authorization", required = false) String authorization) {
        if (!adminAuthenticator.isAdminConfigured()) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(new ErrorResponse("enrollment_disabled",
                            "Administrator enrollment is not configured. Set pcst.admin.api-key (or PCST_ADMIN_API_KEY) and retry."));
        }
        if (!adminAuthenticator.isAdmin(authorization)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ErrorResponse("unauthorized",
                            "Administrator authentication required. Provide Authorization: Bearer <admin-api-key>."));
        }
        return null;
    }

    /**
     * Issues a new single-use pairing code.
     *
     * Request body: { "nodeIdHint": "optional-node-id", "ttlMinutes": 10 }
     * Response: { "code": "...", "expiresAtMillis": ..., "nodeIdHint": "..." }
     *
     * The code value itself is returned once; the server does not re-emit it and
     * never logs it. The administrator must communicate it out-of-band to the
     // device operator.
     */
    @PostMapping("/pairing-codes")
    public ResponseEntity<?> generatePairingCode(
            @RequestHeader(name = "Authorization", required = false) String authorization,
            @Valid @RequestBody(required = false) GeneratePairingCodeRequest request) {
        ResponseEntity<?> auth = requireAdmin(authorization);
        if (auth != null) {
            return auth;
        }
        String clientIp = "local"; // best-effort; Spring servlet remote addr not available here
        int ttlMinutes = (request != null && request.ttlMinutes != null && request.ttlMinutes > 0)
                ? request.ttlMinutes : 0;
        // Use default ttl unless overridden; PairingCodeService.generate uses its
        // configured default. Override not supported by service, so we keep it
        // simple and honor the default.
        PairingCodeService.PairingCode code = pairingCodeService.generate(
                request != null ? request.nodeIdHint : null, clientIp);
        if (code == null) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                    .body(new ErrorResponse("rate_limited",
                            "Pairing code generation is rate-limited. Wait and retry."));
        }
        return ResponseEntity.ok(new PairingCodeResponse(code.code, code.nodeIdHint, code.expiresAtMillis));
    }

    @GetMapping("/pairing-codes")
    public ResponseEntity<?> listPairingCodes(
            @RequestHeader(name = "Authorization", required = false) String authorization) {
        ResponseEntity<?> auth = requireAdmin(authorization);
        if (auth != null) {
            return auth;
        }
        List<PairingCodeResponse> codes = pairingCodeService.activeCodes().stream()
                .map(c -> new PairingCodeResponse(c.code, c.nodeIdHint, c.expiresAtMillis))
                .collect(Collectors.toList());
        return ResponseEntity.ok(new PairingCodeListResponse(codes));
    }

    @DeleteMapping("/pairing-codes/{code}")
    public ResponseEntity<?> revokePairingCode(
            @RequestHeader(name = "Authorization", required = false) String authorization,
            @PathVariable String code) {
        ResponseEntity<?> auth = requireAdmin(authorization);
        if (auth != null) {
            return auth;
        }
        pairingCodeService.revoke(code);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/nodes/{nodeId}/device-credential")
    public ResponseEntity<?> revokeDeviceCredential(
            @RequestHeader(name = "Authorization", required = false) String authorization,
            @PathVariable String nodeId) {
        ResponseEntity<?> auth = requireAdmin(authorization);
        if (auth != null) {
            return auth;
        }
        deviceCredentialService.revokeByNodeId(nodeId);
        return ResponseEntity.ok().build();
    }

    /* ---------------------------------------------------------------- request/response DTOs */

    public static class GeneratePairingCodeRequest {
        public String nodeIdHint;
        public Integer ttlMinutes;
    }

    public static class PairingCodeResponse {
        public String code;
        public String nodeIdHint;
        public long expiresAtMillis;

        public PairingCodeResponse(String code, String nodeIdHint, long expiresAtMillis) {
            this.code = code;
            this.nodeIdHint = nodeIdHint;
            this.expiresAtMillis = expiresAtMillis;
        }
    }

    public static class PairingCodeListResponse {
        public List<PairingCodeResponse> codes;

        public PairingCodeListResponse(List<PairingCodeResponse> codes) {
            this.codes = codes;
        }
    }

    public static class ErrorResponse {
        public String error;
        public String message;

        public ErrorResponse(String error, String message) {
            this.error = error;
            this.message = message;
        }
    }
}
