package com.omni.pcst.master.task;

/**
 * How a single hard constraint was resolved against a candidate node.
 *
 * <p>Three states are distinguished and never collapsed:
 * <ul>
 *   <li><b>SATISFIED</b> — valid, fresh evidence proves the constraint holds.</li>
 *   <li><b>VIOLATED</b> — valid, fresh evidence proves the constraint does not hold.</li>
 *   <li><b>INDETERMINATE</b> — the available evidence can establish neither.</li>
 * </ul>
 *
 * <p>Indeterminate is never silently promoted to SATISFIED, and never silently
 * demoted to VIOLATED. What an indeterminate result means for overall
 * eligibility is decided by an explicit, configurable policy
 * ({@link IndeterminatePolicy}), not by an implicit branch.
 */
public enum ConstraintOutcome {

    /** Sufficient valid evidence proves the constraint is met. */
    SATISFIED,

    /** Valid evidence proves the constraint is not met. */
    VIOLATED,

    /** Available evidence can neither prove nor disprove the constraint. */
    INDETERMINATE;

    /** @return true when this outcome is not a proven success */
    public boolean isNotSatisfied() {
        return this != SATISFIED;
    }
}
