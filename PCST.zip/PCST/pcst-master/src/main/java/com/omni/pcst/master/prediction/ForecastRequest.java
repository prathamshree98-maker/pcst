package com.omni.pcst.master.prediction;

import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;

import java.util.Objects;

/**
 * Immutable, validated input for a resource forecast.
 *
 * <p>The request makes its dependency on an actual immutable
 * {@link DigitalTwinSnapshot} explicit: the predictor never fabricates a
 * snapshot and never reads global mutable state. All time values are the same
 * epoch-millis units used by the Digital Twin ({@code DigitalTwinSnapshot}
 * timestamps and the observation timestamps it carries).
 *
 * @param snapshot the immutable point-in-time twin view to forecast from
 * @param resourceIdentifier exact identifier of the resource to forecast
 * @param horizonMillis how far ahead the forecast is required, in epoch millis.
 *        Recorded for provenance and future horizon-aware models; the
 *        persistence baseline's estimate does not depend on it. Must be &gt;= 0.
 * @param observationWindowMillis how much history, in epoch millis ending at
 *        {@code requestedAtMillis}, is considered relevant. Must be &gt;= 0.
 * @param requestedAtMillis epoch millis the forecast is requested for, i.e. the
 *        newest timestamp a useful observation may carry
 * @param minimumObservations minimum number of valid in-window measurements
 *        required before an estimate is produced; must be &gt;= 1
 */
public record ForecastRequest(
        DigitalTwinSnapshot snapshot,
        String resourceIdentifier,
        long horizonMillis,
        long observationWindowMillis,
        long requestedAtMillis,
        int minimumObservations) {

    public ForecastRequest {
        Objects.requireNonNull(snapshot, "snapshot must not be null");
        Objects.requireNonNull(resourceIdentifier, "resourceIdentifier must not be null");
        if (horizonMillis < 0L) {
            throw new IllegalArgumentException(
                    "horizonMillis must be >= 0 but was " + horizonMillis);
        }
        if (observationWindowMillis < 0L) {
            throw new IllegalArgumentException(
                    "observationWindowMillis must be >= 0 but was " + observationWindowMillis);
        }
    }

    /**
     * Convenience constructor requiring a single valid measurement. Note that
     * {@code minimumObservations} is validated by the predictor, not here, so a
     * nonsensical value is reported as an {@code INVALID_REQUEST} result rather
     * than as an exception.
     */
    public ForecastRequest(DigitalTwinSnapshot snapshot, String resourceIdentifier,
                           long horizonMillis, long observationWindowMillis,
                           long requestedAtMillis) {
        this(snapshot, resourceIdentifier, horizonMillis, observationWindowMillis,
                requestedAtMillis, 1);
    }
}
