package com.omni.pcst.master.scheduler;

/**
 * What the policy does when eligible candidates exist but none has a defined
 * reliability estimate.
 *
 * <p>The specification requires that a missing or unresolved reliability is never
 * silently treated as a numeric rank. It does not itself define a recovery rule
 * for that case, so the rule is made explicit here rather than hidden in a
 * branch, and defaults to selecting nothing.
 */
public enum FallbackPolicy {

    /**
     * Select no node when no eligible candidate has a defined reliability
     * estimate. The decision outcome is {@link SchedulingStatus#NO_SELECTION_UNRESOLVED}.
     *
     * <p>This is the default because it is the only choice that does not fabricate
     * a probabilistic conclusion: an unresolved estimate is not evidence that a
     * node is good or bad.
     */
    NONE("select no node when no eligible candidate has a reliability estimate"),

    /**
     * Select the eligible candidate with the lowest node id when no candidate has
     * a defined reliability estimate.
     *
     * <p>This is an explicitly configured <b>policy fallback</b>, not a
     * probabilistic decision: the selected candidate has no reliability value and
     * the outcome is labelled {@link SchedulingStatus#FALLBACK_SELECTED}. It is
     * deterministic (lowest node id) and never overrides hard eligibility. Enable
     * it only when continuing without a probabilistic estimate is operationally
     * acceptable for the workload.
     */
    LOWEST_NODE_ID("select the lowest node id among eligible candidates when no reliability estimate exists");

    private final String description;

    FallbackPolicy(String description) {
        this.description = description;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
