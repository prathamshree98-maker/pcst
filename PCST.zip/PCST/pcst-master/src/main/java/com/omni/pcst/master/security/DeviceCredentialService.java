package com.omni.pcst.master.security;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Issues and validates device credentials for authenticated re-registration,
 * with optional durable persistence.
 *
 * <p>After a device successfully pairs with a pairing code, the Master issues a
 * unique device credential. The agent stores it and presents it on future
 * reconnections. The Master binds the credential to a specific node id and
 * rejects it if the requesting node_id does not match, or if the credential has
 * been revoked.
 *
 * <p>When a {@link FileStateStore} is injected (persistence enabled), credentials
 * and revocation state are loaded from disk on startup. A load failure (for
 * example corrupt state, wrong passphrase, or unreadable file) fails Master
 * startup rather than proceeding with incomplete enrollment state. Credentials
 * and revocation state are written back on every issue or revoke so that a
 * revoked credential cannot become valid after a Master restart and enrolled
 * devices can reconnect without re-pairing. Device credentials are never
 * logged.
 *
 * <p>Write ordering: the store is persisted <em>before</em> in-memory state is
 * updated. If persistence fails, the in-memory state is left unchanged and the
 * caller receives an exception, so a failed write is never reported as durable.
 *
 * <p>When no store is injected (persistence disabled), all state is in-memory
 * and lost on restart, matching the previous behavior. This is the default for
 * local development.
 */
@Component
public class DeviceCredentialService {

    private static final Logger log = LoggerFactory.getLogger(DeviceCredentialService.class);
    private static final SecureRandom RANDOM = new SecureRandom();

    private final ConcurrentMap<String, DeviceCredentialRecord> credentialsByToken = new ConcurrentHashMap<>();
    /** Reverse index: node id -> active (non-revoked) credential token. */
    private final ConcurrentMap<String, String> tokenByNodeId = new ConcurrentHashMap<>();
    private final FileStateStore store;

    public DeviceCredentialService(
            @Value("${pcst.state.persistence.enabled:false}") boolean persistenceEnabled,
            @Autowired(required = false) FileStateStore store) {
        this.store = store;
        if (store != null) {
            loadFromStore();
            log.info("Device credential persistence enabled; loaded {} credential(s) from store",
                    credentialsByToken.size());
        } else if (persistenceEnabled) {
            log.warn("Persistence requested but no FileStateStore bean is available; "
                    + "operating in-memory only (state lost on restart)");
        } else {
            log.debug("Device credential persistence disabled; operating in-memory only");
        }
    }

    /**
     * Loads persisted credentials from the store into memory. A load failure
     * (corrupt state, wrong passphrase, unreadable file) throws
     * {@link FileStateStore.StateStoreException}, failing Master startup rather
     * than proceeding with incomplete enrollment state.
     */
    private void loadFromStore() {
        StateSnapshot snapshot = store.load();
        for (Map.Entry<String, StateSnapshot.CredentialRecord> entry :
                snapshot.credentials().entrySet()) {
            String token = entry.getKey();
            StateSnapshot.CredentialRecord record = entry.getValue();
            DeviceCredentialRecord dcr = new DeviceCredentialRecord(
                    token, record.nodeId(), record.issuedAtMillis(), record.revoked());
            credentialsByToken.put(token, dcr);
            if (!record.revoked()) {
                tokenByNodeId.put(record.nodeId(), token);
            }
        }
    }

    /**
     * Persists the given snapshot to the store. Fail closed on error:
     * throws {@link FileStateStore.StateStoreException} so the caller knows the
     * change was not durably saved.
     */
    private void persistToStore(StateSnapshot snapshot) {
        if (store == null) {
            return;
        }
        store.save(snapshot);
    }

    /**
     * Builds a copy of all current credentials as a snapshot map, without
     * modifying in-memory state.
     */
    private Map<String, StateSnapshot.CredentialRecord> snapshotCredentials() {
        Map<String, StateSnapshot.CredentialRecord> credentials = new HashMap<>();
        for (Map.Entry<String, DeviceCredentialRecord> entry : credentialsByToken.entrySet()) {
            DeviceCredentialRecord record = entry.getValue();
            credentials.put(entry.getKey(), new StateSnapshot.CredentialRecord(
                    record.nodeId, record.issuedAtMillis, record.revoked));
        }
        return credentials;
    }

    public String issue(String nodeId) {
        String token = generateToken();
        DeviceCredentialRecord record = new DeviceCredentialRecord(token, nodeId,
                System.currentTimeMillis(), false);

        // Build the full credential set including the new entry, persist it, and
        // only then update in-memory state. If persistence fails, the in-memory
        // state is unchanged and the caller receives an exception.
        Map<String, StateSnapshot.CredentialRecord> credentials = snapshotCredentials();
        credentials.put(token, new StateSnapshot.CredentialRecord(nodeId,
                record.issuedAtMillis, false));
        try {
            persistToStore(new StateSnapshot(credentials));
        } catch (Exception e) {
            throw new RuntimeException("Failed to persist device credential "
                    + "(fail closed): " + e.getMessage(), e);
        }
        credentialsByToken.put(token, record);
        tokenByNodeId.put(nodeId, token);
        log.info("Device credential issued for node_id={} (value not logged)", nodeId);
        return token;
    }

    /**
     * Validates that the credential exists, is not revoked, and is bound to the
     * requesting node_id. This prevents a device from impersonating another by
     * presenting a credential issued to a different node.
     *
     * @return {@code true} when the credential is valid for the given node_id
     */
    public boolean validate(String credential, String nodeId) {
        if (credential == null || credential.isBlank() || nodeId == null || nodeId.isBlank()) {
            return false;
        }
        DeviceCredentialRecord record = credentialsByToken.get(credential);
        if (record == null || record.revoked) {
            log.warn("Device credential validation failed: unknown or revoked credential for node_id={}",
                    nodeId);
            return false;
        }
        boolean matches = nodeId.equals(record.nodeId);
        if (!matches) {
            log.warn("Device credential validation failed: credential bound to node_id={} "
                    + "presented by node_id={} (impersonation attempt)", record.nodeId, nodeId);
        }
        return matches;
    }

    public void revoke(String credential) {
        if (credential == null || credential.isBlank()) {
            return;
        }
        DeviceCredentialRecord record = credentialsByToken.get(credential);
        if (record != null) {
            // Build the full credential set with this entry revoked, persist it,
            // and only then update in-memory state. If persistence fails, the
            // in-memory state is unchanged and the caller receives an exception.
            Map<String, StateSnapshot.CredentialRecord> credentials = snapshotCredentials();
            credentials.put(credential, new StateSnapshot.CredentialRecord(
                    record.nodeId, record.issuedAtMillis, true));
            try {
                persistToStore(new StateSnapshot(credentials));
            } catch (Exception e) {
                throw new RuntimeException("Failed to persist credential revocation "
                        + "(fail closed): " + e.getMessage(), e);
            }
            record.revoked = true;
            tokenByNodeId.remove(record.nodeId, credential);
            log.info("Device credential revoked (value not logged)");
        }
    }

    public void revokeByNodeId(String nodeId) {
        if (nodeId == null || nodeId.isBlank()) {
            return;
        }
        String token = tokenByNodeId.get(nodeId);
        if (token != null) {
            revoke(token);
        }
    }

    public Optional<String> tokenForNodeId(String nodeId) {
        return Optional.ofNullable(tokenByNodeId.get(nodeId));
    }

    /* ---------------------------------------------------------------- internals */

    private String generateToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private static final class DeviceCredentialRecord {
        public final String token;
        public final String nodeId;
        public final long issuedAtMillis;
        public volatile boolean revoked;

        DeviceCredentialRecord(String token, String nodeId, long issuedAtMillis, boolean revoked) {
            this.token = token;
            this.nodeId = nodeId;
            this.issuedAtMillis = issuedAtMillis;
            this.revoked = revoked;
        }
    }
}
