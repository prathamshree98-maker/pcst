package com.omni.pcst.master.reliability;

import java.util.Objects;

/**
 * The reliability assessment of one success event, for one task / one candidate
 * node.
 *
 * <p>Every one of the specification's success events gets an entry, whether or not
 * the task expresses it, so the result is a complete account of what could and
 * could not be evaluated. An event that contributes no probability still carries
 * the {@link ReliabilityReason} that says why, so nothing is silently dropped.
 *
 * @param event       which success event this entry describes
 * @param required    true when the task expresses the requirement this event
 *                    represents, i.e. the event is part of {@code Esucc}
 * @param reason      how this event was resolved
 * @param probability the event probability in [0, 1], or {@code null} when none
 *                    was computed
 * @param detail      short diagnostic text
 */
public record SuccessEventAssessment(
        ReliabilityEvent event,
        boolean required,
        ReliabilityReason reason,
        Double probability,
        String detail) {

    public SuccessEventAssessment {
        Objects.requireNonNull(event, "event");
        Objects.requireNonNull(reason, "reason");
        detail = detail == null ? "" : detail;
        if (probability != null && (probability < 0.0 || probability > 1.0)) {
            throw new IllegalArgumentException(
                    "probability must be within [0, 1] (was " + probability + ")");
        }
        if ((probability != null) != (reason == ReliabilityReason.COMPUTED)) {
            throw new IllegalArgumentException(
                    "probability must be non-null exactly when the reason is COMPUTED (reason=" + reason + ")");
        }
        boolean inContract = reason != ReliabilityReason.EVENT_NOT_IN_CONTRACT;
        if (required != inContract) {
            throw new IllegalArgumentException(
                    "required must be true exactly when the event is in the success contract");
        }
    }

    /** @return true when a probability was actually computed for this event */
    public boolean isComputed() {
        return reason == ReliabilityReason.COMPUTED && probability != null;
    }
}
