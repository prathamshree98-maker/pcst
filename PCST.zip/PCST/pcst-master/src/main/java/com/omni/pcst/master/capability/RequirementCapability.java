package com.omni.pcst.master.capability;

import java.util.Objects;

/**
 * The capability assessment of one task requirement, for one candidate node.
 *
 * <p>Every requirement the task expresses gets an entry so the result is a
 * complete account of what could and could not be evaluated. A requirement that
 * contributes no probability still carries the {@link CapabilityReason} that says
 * why, so nothing is silently dropped.
 *
 * @param dimension              the requirement category
 * @param requiredValue          the task's required quantity, or {@code null} for a
 *                               boolean/profile requirement
 * @param requiredUnit           the requirement's unit
 * @param reason                 how this requirement was resolved
 * @param probability            the marginal probability in [0, 1], or {@code null}
 * @param predictiveDistribution the distribution the probability came from, or {@code null}
 * @param detail                 short diagnostic text
 */
public record RequirementCapability(
        CapabilityDimension dimension,
        Double requiredValue,
        String requiredUnit,
        CapabilityReason reason,
        Double probability,
        PredictiveDistribution predictiveDistribution,
        String detail) {

    public RequirementCapability {
        Objects.requireNonNull(dimension, "dimension");
        Objects.requireNonNull(reason, "reason");
        requiredUnit = requiredUnit == null ? dimension.unit() : requiredUnit;
        detail = detail == null ? "" : detail;
        if (probability != null && (probability < 0.0 || probability > 1.0)) {
            throw new IllegalArgumentException(
                    "probability must be within [0, 1] (was " + probability + ")");
        }
    }

    /** @return true when this requirement is part of capability's resource event */
    public boolean isResourceCondition() {
        return dimension.resourceCondition();
    }

    /** @return true when a marginal probability was actually computed */
    public boolean isComputed() {
        return reason == CapabilityReason.COMPUTED && probability != null;
    }
}
