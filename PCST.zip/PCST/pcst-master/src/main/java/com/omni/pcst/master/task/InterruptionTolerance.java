package com.omni.pcst.master.task;

/**
 * Whether a task tolerates being interrupted or preempted, from specification
 * section 3.1 ("Execution constraints: ..., and interruption tolerance").
 *
 * <p>Step 6A does not use this to exclude any node: no node field in the current
 * model expresses preemption capability. It is carried so that later scheduling
 * and retry layers (G6) can consume it without redefining the task contract.
 */
public enum InterruptionTolerance {

    /** The task may be paused or preempted and resumed elsewhere. */
    PREEMPTIBLE,

    /** The task must run to completion on its assigned node. */
    NON_PREEMPTIBLE
}