package com.omni.pcst.master.reliability;

/**
 * Stable reason codes describing how one success event, or the assessment as a
 * whole, was resolved.
 *
 * <p>Codes are the programmatic contract; the accompanying description is for
 * humans only. Callers branch on the enum, never on message text. A code records
 * <em>why</em> something has the status it has; it never encodes a probability
 * and never carries a numeric weight.
 */
public enum ReliabilityReason {

    /** A probability was computed for this event. */
    COMPUTED("a probability was computed for this success event"),

    /**
     * The only success event the task expresses is {@code Eresource}, so the
     * completion reliability equals the capability probability {@code C}. This is
     * the specification equation applied to a contract whose intersection has one
     * term, not a relabelling of capability.
     */
    RESOURCE_EVENT_IS_ENTIRE_CONTRACT("Eresource is the task's entire success contract, so R = C"),

    /**
     * The task expresses no success events at all, so {@code Esucc} is the empty
     * intersection and is vacuously true. Reported explicitly rather than left
     * implicit.
     */
    VACUOUS_SUCCESS_CONTRACT("the task expresses no success events; Esucc is vacuously true"),

    /** The event is not part of the task's success contract. */
    EVENT_NOT_IN_CONTRACT("the task does not express this success event"),

    /** {@code Eresource} is only partially modelled: some resource conditions are unsupported. */
    RESOURCE_UNSUPPORTED_MODEL("some required resource conditions have no predictive model"),

    /** Multiple resource conditions are computable but no justified joint model exists. */
    RESOURCE_JOINT_MODEL_UNRESOLVED("multiple resource conditions with no justified joint model"),

    /** The task states a deadline but there is no completion-time distribution to evaluate it. */
    NO_COMPLETION_TIME_MODEL("no completion-time distribution exists to evaluate Edeadline"),

    /** The task states a battery minimum but there is no energy/drain process model. */
    NO_ENERGY_PROCESS_MODEL("no energy/drain process model exists to evaluate Eenergy"),

    /** The task states a QoS/compatibility target but there is no QoS model. */
    NO_QOS_MODEL("no quality-of-service model exists to evaluate EQoS"),

    /** The task states an interruption tolerance but there is no node-stability model. */
    NO_STABILITY_MODEL("no node-stability model exists to evaluate Estability"),

    /** No Step 6B capability assessment was supplied, so {@code Eresource} cannot be evaluated. */
    MISSING_CAPABILITY_ASSESSMENT("no step 6B capability assessment was supplied"),

    /** The Step 6B capability assessment reported insufficient evidence. */
    CAPABILITY_INSUFFICIENT_EVIDENCE("the step 6B capability assessment lacked usable evidence"),

    /** The Step 6B capability assessment reported malformed input. */
    CAPABILITY_INVALID_INPUT("the step 6B capability assessment input was malformed"),

    /** A hard constraint is provably violated for this candidate. */
    HARD_CONSTRAINT_VIOLATION("a hard constraint is provably violated for this candidate"),

    /** A hard constraint is unproven (indeterminate); it is not a proven violation. */
    HARD_CONSTRAINT_INDETERMINATE("a hard constraint is unproven and is not evidence of success"),

    /** The reliability inputs were not usable (e.g. mismatched node identities). */
    INVALID_INPUT("the reliability inputs were not usable");

    private final String description;

    ReliabilityReason(String description) {
        this.description = description;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
