package com.omni.pcst.master.execution;

import com.omni.pcst.master.task.Task;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

/**
 * Registry of task execution records.
 *
 * <p>Two implementations exist:
 * <ul>
 *   <li>{@link InMemoryTaskRegistry} — concurrent map, state lost on restart (default).</li>
 *   <li>{@link JdbcTaskRegistry} — PostgreSQL-backed via {@link JdbcTaskRepository}, enabled when
 *       {@code pcst.persistence.jdbc.enabled=true}. Startup fails closed if the datasource or
 *       Flyway migration is unavailable; there is no silent fallback to in-memory persistence.</li>
 * </ul>
 *
 * <p>Only one implementation bean is active at a time (conditional wiring). All mutations return
 * new immutable {@link TaskRecord} snapshots.
 */
public interface TaskRegistry {

    /**
     * Creates a new task record in the ACCEPTED state.
     *
     * @param task the submitted task
     * @param now  server timestamp
     * @return the created record
     * @throws IllegalArgumentException if a task with the same taskId already exists
     */
    TaskRecord create(Task task, long now);

    /**
     * Atomically updates a task record using a function.
     *
     * @param taskId the task identifier
     * @param updater a function from current record to new record; may return
     *               the same record to indicate no change
     * @return the new record, or empty if taskId not found
     */
    Optional<TaskRecord> update(String taskId, Function<TaskRecord, TaskRecord> updater);

    /**
     * @return the current snapshot for a taskId, or empty if not found
     */
    Optional<TaskRecord> get(String taskId);

    /** @return all current task records */
    Collection<TaskRecord> all();

    /** @return count of tracked tasks */
    int size();

    /** Removes a task record (for testing/cleanup). */
    void remove(String taskId);

    /** Returns tasks in a specific state. */
    List<TaskRecord> tasksInState(TaskState state);
}
