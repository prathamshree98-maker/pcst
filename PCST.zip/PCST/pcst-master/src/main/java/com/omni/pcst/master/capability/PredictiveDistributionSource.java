package com.omni.pcst.master.capability;

import com.omni.pcst.master.digitaltwin.ResourceBelief;

import java.util.Optional;

/**
 * Supplies the predictive distribution used to compute a capability marginal.
 *
 * <p>This is a deliberate seam. The capability engine does not itself decide how a
 * belief posterior becomes a predictive law; that mapping is a modelling choice
 * that belongs to the prediction stage. Isolating it here means the engine's
 * event arithmetic is independent of the chosen predictive model, and a future
 * task-conditioned forecast can be substituted without rewriting capability.
 */
@FunctionalInterface
public interface PredictiveDistributionSource {

    /**
     * @param belief the posterior belief for the required resource
     * @return the predictive distribution for the execution interval, or empty
     *         when this source cannot produce one
     */
    Optional<PredictiveDistribution> distributionFor(ResourceBelief belief);
}
