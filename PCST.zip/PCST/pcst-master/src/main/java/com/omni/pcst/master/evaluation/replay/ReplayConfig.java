package com.omni.pcst.master.evaluation.replay;

/**
 * Immutable configuration for one offline evaluation run.
 *
 * <p>Horizons, target tolerance and the observation window are explicit
 * configuration rather than hard-coded assumptions: none of them is validated by
 * the repository, so the harness never presents a default as a validated choice.
 *
 * @param horizonsMillis        forecast horizons to evaluate, in epoch millis
 * @param targetToleranceMillis how far the actual observation may sit from the
 *                              requested target instant ({@code origin + horizon})
 * @param observationWindowMillis how much history each predictor may see; 0 means
 *                              "all history up to the prediction origin"
 * @param minimumObservations   minimum valid in-window measurements a predictor
 *                              requires before producing an estimate
 */
public record ReplayConfig(long[] horizonsMillis,
                           long targetToleranceMillis,
                           long observationWindowMillis,
                           int minimumObservations) {

    /**
     * Protocol identifier written into every report, so a result file can be
     * traced back to the protocol that produced it.
     */
    public static final String PROTOCOL = "pcst-replay-eval-v1";

    /**
     * Default horizons (in millis). These are engineering defaults chosen to be
     * representable at the Node Agent's default 5 s telemetry interval; they are
     * <em>not</em> validated horizons and are fully configurable.
     */
    public static final long[] DEFAULT_HORIZONS_MILLIS = {30_000L, 60_000L, 300_000L};

    /** Default target tolerance: half a default telemetry interval, plus slack. */
    public static final long DEFAULT_TARGET_TOLERANCE_MILLIS = 10_000L;

    /** Default observation window: long enough to cover several intervals. */
    public static final long DEFAULT_OBSERVATION_WINDOW_MILLIS = 600_000L;

    /** Default minimum in-window observations required from a predictor. */
    public static final int DEFAULT_MINIMUM_OBSERVATIONS = 2;

    public ReplayConfig {
        if (horizonsMillis == null || horizonsMillis.length == 0) {
            throw new IllegalArgumentException("at least one horizon is required");
        }
        for (long horizon : horizonsMillis) {
            if (horizon <= 0L) {
                throw new IllegalArgumentException("horizons must be positive (was " + horizon + ")");
            }
        }
        if (targetToleranceMillis < 0L) {
            throw new IllegalArgumentException("targetToleranceMillis must be >= 0");
        }
        if (observationWindowMillis < 0L) {
            throw new IllegalArgumentException("observationWindowMillis must be >= 0");
        }
        if (minimumObservations < 1) {
            throw new IllegalArgumentException("minimumObservations must be >= 1");
        }
        horizonsMillis = horizonsMillis.clone();
    }

    public static ReplayConfig defaults() {
        return new ReplayConfig(DEFAULT_HORIZONS_MILLIS.clone(),
                DEFAULT_TARGET_TOLERANCE_MILLIS,
                DEFAULT_OBSERVATION_WINDOW_MILLIS,
                DEFAULT_MINIMUM_OBSERVATIONS);
    }

    public static ReplayConfig withHorizons(long[] horizonsMillis) {
        return new ReplayConfig(horizonsMillis.clone(),
                DEFAULT_TARGET_TOLERANCE_MILLIS,
                DEFAULT_OBSERVATION_WINDOW_MILLIS,
                DEFAULT_MINIMUM_OBSERVATIONS);
    }

    @Override
    public long[] horizonsMillis() {
        return horizonsMillis.clone();
    }
}