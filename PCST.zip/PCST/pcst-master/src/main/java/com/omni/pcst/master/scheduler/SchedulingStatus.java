package com.omni.pcst.master.scheduler;

/**
 * Outcome of a scheduling decision for one task at one decision epoch.
 *
 * <p>The names follow the specification's V1 decision contraction (section 10.1
 * and Appendix A): a node is selected only when its modelled reliability is
 * defined and clears the configured policy threshold; otherwise the outcome is
 * one of the explicit no-selection states rather than a forced assignment.
 */
public enum SchedulingStatus {

    /**
     * A node was selected by the greedy maximum-reliability policy, with a
     * defined reliability estimate that cleared the policy threshold (or no
     * threshold was configured).
     */
    SELECTED("a node was selected by the maximum-reliability policy"),

    /**
     * No node passed hard eligibility, so the feasible set {@code F_t(τ)} is
     * empty. This is the specification's {@code NO_FEASIBLE_NODE}. No node is
     * selected even if some ineligible node carried a reliability estimate.
     */
    NO_FEASIBLE_NODE("no node passed hard eligibility; the feasible set is empty"),

    /**
     * Eligible candidates with defined reliability exist, but every one of them
     * is below the configured policy threshold. This is the specification's
     * {@code DEFER_OR_REJECT}. No node is selected.
     */
    DEFER_OR_REJECT("every eligible candidate with a reliability estimate is below the policy threshold"),

    /**
     * Eligible candidates exist, but none has a defined reliability estimate, so
     * no probabilistic ranking is possible. No node is selected. A node is never
     * selected here by inventing a value or treating an unresolved estimate as
     * zero, one, or a valid rank.
     */
    NO_SELECTION_UNRESOLVED("eligible candidates exist but none has a reliability estimate"),

    /**
     * Eligible candidates exist, none has a defined reliability estimate, and an
     * explicitly configured policy fallback selected one of them. The selection
     * is a deterministic tie/recovery rule, <b>not</b> a probabilistic
     * conclusion: the selected candidate has no reliability value.
     */
    FALLBACK_SELECTED("a policy fallback selected a node; this is not a probabilistic conclusion");

    private final String description;

    SchedulingStatus(String description) {
        this.description = description;
    }

    /** @return true when this outcome carries a selected node */
    public boolean hasSelection() {
        return this == SELECTED || this == FALLBACK_SELECTED;
    }

    /** @return true when this outcome is a probabilistic maximum-reliability selection */
    public boolean isProbabilityBased() {
        return this == SELECTED;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
