package com.omni.pcst.master.scheduler;

/**
 * What the policy did with one candidate in a scheduling decision.
 *
 * <p>Every candidate appears in the decision trace with exactly one disposition,
 * so a decision can be explained candidate by candidate, not only by its overall
 * outcome.
 */
public enum CandidateDisposition {

    /** The candidate was selected as the maximum-reliability node. */
    SELECTED("selected as the maximum-reliability node"),

    /** The candidate was selected by an explicit policy fallback, not by reliability. */
    SELECTED_BY_FALLBACK("selected by the configured policy fallback"),

    /** The candidate was eligible with a defined reliability but was not the maximum. */
    LOWER_RELIABILITY("eligible with a lower reliability estimate than the selected node"),

    /** The candidate was eligible with a defined reliability but was below the policy threshold. */
    BELOW_THRESHOLD("eligible with a reliability estimate below the policy threshold"),

    /** The candidate was eligible but had no defined reliability estimate and so was not ranked. */
    UNRESOLVED_RELIABILITY("eligible but carries no defined reliability estimate"),

    /** The candidate was excluded by the hard-constraint filter before any probabilistic ranking. */
    EXCLUDED_HARD_CONSTRAINT("excluded by hard eligibility");

    private final String description;

    CandidateDisposition(String description) {
        this.description = description;
    }

    /** @return true when this disposition denotes the selected candidate */
    public boolean isSelected() {
        return this == SELECTED || this == SELECTED_BY_FALLBACK;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
