package com.omni.pcst.master.digitaltwin;

import com.omni.pcst.master.belief.BayesianBeliefEngine;
import com.omni.pcst.master.evaluation.TelemetryEvaluationRecord;
import com.omni.pcst.master.evaluation.TelemetryEvaluationStore;
import com.omni.pcst.master.telemetry.TelemetrySequenceTracker;
import com.omni.pcst.proto.TelemetryRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Maintains one {@link DigitalTwin} per registered node.
 *
 * <p>Deliberate policies, consistent with the registration contract (only
 * RegisterNode creates nodes):
 *
 * <ul>
 *   <li><b>Registration</b> creates the twin on first accept and refreshes
 *       registration metadata on every subsequent accept; observation history
 *       and freshness state survive re-registration.</li>
 *   <li><b>Heartbeat</b> updates freshness only for known nodes. Heartbeats from
 *       unknown node ids are not acknowledged and never create state.</li>
 *   <li><b>Telemetry</b> is accepted only from known nodes and only when its
 *       timestamp is newer than the latest accepted observation. Unknown-node
 *       telemetry and stale/out-of-order observations are rejected without
 *       corrupting existing state.</li>
 * </ul>
 *
 * <p>State is in-memory only: it is lost when the Master restarts. Nodes
 * re-register and rebuild their state through the normal registration flow.
 *
 * <p>When a {@link BayesianBeliefEngine} is configured (Spring injects the
 * default one), every accepted observation also recomputes the twin's
 * {@link BeliefState} from the accepted history. Without an engine the belief
 * state stays {@link BeliefState#UNINITIALIZED}.
 */
@Component
public class DigitalTwinManager {

    private static final Logger log = LoggerFactory.getLogger(DigitalTwinManager.class);

    private final ConcurrentMap<String, DigitalTwin> twins = new ConcurrentHashMap<>();

    /**
     * Per-node ingestion locks, created on first telemetry for a node and removed
     * when the node is no longer tracked. Bounds the ingestion critical section to
     * a single node; no global Master lock is taken.
     */
    private final ConcurrentMap<String, ReentrantLock> ingestionLocks = new ConcurrentHashMap<>();
    private final int maxHistorySize;
    private final BayesianBeliefEngine beliefEngine;
    private final TelemetryEvaluationStore evaluationStore;
    private final String collectionConfigVersion;

    /**
     * Telemetry sequence tracker. Observational only: it never rejects a message
     * and never mutates twin state. Kept separate from belief updates.
     */
    private final TelemetrySequenceTracker sequenceTracker;

    @Autowired
    public DigitalTwinManager(@Value("${pcst.digitaltwin.history-size:100}") int maxHistorySize,
                               BayesianBeliefEngine beliefEngine,
                               ObjectProvider<TelemetryEvaluationStore> evaluationStoreProvider,
                               @Value("${pcst.evaluation.collection-config-version:}")
                               String collectionConfigVersion) {
        this.maxHistorySize = maxHistorySize;
        this.beliefEngine = beliefEngine;
        this.evaluationStore = evaluationStoreProvider.getIfAvailable();
        this.collectionConfigVersion =
                (collectionConfigVersion == null || collectionConfigVersion.isBlank())
                        ? TelemetryEvaluationStore.UNKNOWN_COLLECTION_CONFIG_VERSION
                        : collectionConfigVersion;
        this.sequenceTracker = new TelemetrySequenceTracker();
    }

    /**
     * Test/standalone constructor with an explicit evaluation store. Collection
     * provenance is recorded as explicitly unknown.
     */
    public DigitalTwinManager(int maxHistorySize, BayesianBeliefEngine beliefEngine,
                              TelemetryEvaluationStore evaluationStore) {
        this(maxHistorySize, beliefEngine, evaluationStore,
                TelemetryEvaluationStore.UNKNOWN_COLLECTION_CONFIG_VERSION);
    }

    /**
     * Full standalone constructor, including the collection configuration
     * provenance recorded on every persisted record.
     */
    public DigitalTwinManager(int maxHistorySize, BayesianBeliefEngine beliefEngine,
                              TelemetryEvaluationStore evaluationStore,
                              String collectionConfigVersion) {
        this.maxHistorySize = maxHistorySize;
        this.beliefEngine = beliefEngine;
        this.evaluationStore = evaluationStore;
        this.collectionConfigVersion =
                (collectionConfigVersion == null || collectionConfigVersion.isBlank())
                        ? TelemetryEvaluationStore.UNKNOWN_COLLECTION_CONFIG_VERSION
                        : collectionConfigVersion;
        this.sequenceTracker = new TelemetrySequenceTracker();
    }

    /**
     * Test/standalone constructor without a belief engine or evaluation store:
     * belief state then stays {@link BeliefState#UNINITIALIZED}.
     */
    public DigitalTwinManager(int maxHistorySize) {
        this(maxHistorySize, null, (TelemetryEvaluationStore) null);
    }

    public DigitalTwinManager(int maxHistorySize, BayesianBeliefEngine beliefEngine) {
        this(maxHistorySize, beliefEngine, (TelemetryEvaluationStore) null);
    }

    /**
     * Handles an accepted registration: creates the twin on first registration,
     * otherwise refreshes its registration metadata.
     */
public void onNodeRegistered(String nodeId, String hostname, int port, String agentVersion,
                                 long serverTimeMillis) {
        onNodeRegistered(nodeId, hostname, port, agentVersion, serverTimeMillis, null);
    }

    /**
     * Handles an accepted registration that may carry an agent session id, which
     * makes an agent restart explicit. A changed session id is recorded so the
     * restart is observable; it does not by itself alter twin state or belief.
     */
    public void onNodeRegistered(String nodeId, String hostname, int port, String agentVersion,
                                 long serverTimeMillis, String agentSessionId) {
        if (sequenceTracker != null && agentSessionId != null && !agentSessionId.isBlank()) {
            boolean changed = sequenceTracker.noteRegistrationSession(nodeId, agentSessionId);
            if (changed) {
                log.info("Agent session changed for node_id={}: new session={} (sequence tracking restarts)",
                        nodeId, agentSessionId);
            }
        }
        twins.compute(nodeId, (id, existing) -> {
            if (existing == null) {
                log.info("Digital Twin created for node_id={}", nodeId);
                return new DigitalTwin(nodeId, hostname, port, agentVersion, serverTimeMillis, maxHistorySize, beliefEngine);
            }
            existing.refreshRegistration(hostname, port, agentVersion, serverTimeMillis);
            return existing;
        });
    }

    /**
     * Handles a heartbeat.
     *
     * @return {@code true} when the heartbeat was accepted (known node); a
     *         {@code false} return tells the caller to not acknowledge it.
     */
    public boolean onHeartbeat(String nodeId, long serverTimeMillis) {
        DigitalTwin twin = twins.get(nodeId);
        if (twin == null) {
            log.warn("Heartbeat rejected: unknown node_id={} (not registered)", nodeId);
            return false;
        }
        twin.recordHeartbeat(serverTimeMillis);
        return true;
    }

    /**
     * Outcome of a telemetry ingestion attempt.
     *
     * <p>{@link #DUPLICATE_SEQUENCE} and {@link #OBSOLETE_SESSION} are distinct
     * from {@link #STALE_OR_OUT_OF_ORDER}: the former two are decided by the
     * transport sequence layer before the observation is ever offered to the
     * Digital Twin, while the latter is decided by the timestamp gate inside
     * {@link DigitalTwin#applyObservation}.
     */
    public enum TelemetryIngestion {
        ACCEPTED,
        UNKNOWN_NODE,
        STALE_OR_OUT_OF_ORDER,
        /** Sequence already observed in this session; not applied a second time. */
        DUPLICATE_SEQUENCE,
        /** Arrived from a session that has been superseded; not applied. */
        OBSOLETE_SESSION
    }

    /**
     * Ingests one telemetry request from a node.
     *
     * <p>The request is validated, mapped to an immutable observation, and applied
     * to the node's twin. Invalid requests (blank node id) never reach this
     * method; unknown nodes and stale timestamps are rejected without touching
     * existing state.
     *
     * <p><b>Validation order.</b> Sequence metadata is observed first, purely for
     * diagnostics, and never gates acceptance. Acceptance is decided solely by the
     * existing timestamp staleness rule in {@link DigitalTwin#applyObservation};
     * a sequence anomaly is logged and persisted as an annotation, not used to
     * reject telemetry. This keeps sequence tracking a separate, non-blocking
     * mechanism.
     */
    public TelemetryIngestion onTelemetry(String nodeId, TelemetryRequest request, long receivedAtMillis) {
        DigitalTwin twin = twins.get(nodeId);
        if (twin == null) {
            log.warn("Telemetry rejected: unknown node_id={} (not registered)", nodeId);
            return TelemetryIngestion.UNKNOWN_NODE;
        }

        String agentSessionId = request.hasAgentSessionId() ? request.getAgentSessionId() : null;
        Long telemetrySequence = request.hasTelemetrySequence() ? request.getTelemetrySequence() : null;
        TelemetryObservation observation = TelemetryObservation.from(request);

        // A per-node lock serialises sequence classification and the acceptance
        // decision so that two simultaneous requests can never both apply the
        // same sequence as two ordinary observations. It is held for the whole
        // decision but never across unrelated nodes.
        ReentrantLock nodeLock = nodeIngestionLock(nodeId);
        nodeLock.lock();
        try {
            TelemetrySequenceTracker.Observation sequenceObservation =
                    sequenceTracker.observe(nodeId, agentSessionId,
                            telemetrySequence != null ? telemetrySequence : 0L);
            logSequenceAnomaly(nodeId, sequenceObservation);

            if (sequenceObservation.suppressesObservation()) {
                // A proven duplicate or a message from a superseded session must
                // not modify the Digital Twin, must not trigger a Bayesian belief
                // recomputation, and must not change the latest accepted
                // timestamp. The evidence is still retained as an audit-only
                // record so the anomaly stays auditable.
                persistAuditRecord(nodeId, observation, agentSessionId, telemetrySequence,
                        sequenceObservation);
                return sequenceObservation.classification()
                        == TelemetrySequenceTracker.Classification.OBSOLETE_SESSION
                        ? TelemetryIngestion.OBSOLETE_SESSION
                        : TelemetryIngestion.DUPLICATE_SEQUENCE;
            }

            if (!twin.applyObservation(observation, receivedAtMillis)) {
                log.warn("Telemetry rejected: stale/out-of-order timestamp={} for node_id={}",
                        observation.timestamp(), nodeId);
                return TelemetryIngestion.STALE_OR_OUT_OF_ORDER;
            }
            log.debug("Telemetry accepted for node_id={}: timestamp={}", nodeId, observation.timestamp());
            persistAcceptedRecord(nodeId, observation, agentSessionId, telemetrySequence,
                    sequenceObservation);
            return TelemetryIngestion.ACCEPTED;
        } finally {
            nodeLock.unlock();
        }
    }

    /**
     * Persists an accepted observation together with its transport classification
     * and, for a forward gap, the missing-sequence interval. Best-effort: a store
     * failure is logged and never fails ingestion.
     */
    private void persistAcceptedRecord(String nodeId, TelemetryObservation observation,
                                       String agentSessionId, Long telemetrySequence,
                                       TelemetrySequenceTracker.Observation sequenceObservation) {
        if (evaluationStore == null) {
            return;
        }
        try {
            evaluationStore.append(TelemetryEvaluationRecord.of(
                    nodeId, observation, System.currentTimeMillis(), collectionConfigVersion,
                    agentSessionId, telemetrySequence,
                    sequenceObservation.classification().name(),
                    sequenceObservation.classification()
                            == TelemetrySequenceTracker.Classification.FORWARD_GAP
                            ? sequenceObservation.gapFrom() : null,
                    sequenceObservation.classification()
                            == TelemetrySequenceTracker.Classification.FORWARD_GAP
                            ? sequenceObservation.gapTo() : null));
        } catch (Exception e) {
            log.warn("Telemetry evaluation persistence failed for node_id={}: {}", nodeId, e.getMessage());
        }
    }

    /**
     * Persists an audit-only record for telemetry deliberately not applied to the
     * Digital Twin. The record is marked ineligible for replay.
     */
    private void persistAuditRecord(String nodeId, TelemetryObservation observation,
                                    String agentSessionId, Long telemetrySequence,
                                    TelemetrySequenceTracker.Observation sequenceObservation) {
        if (evaluationStore == null) {
            return;
        }
        try {
            evaluationStore.append(TelemetryEvaluationRecord.auditOnly(
                    nodeId, observation, System.currentTimeMillis(), collectionConfigVersion,
                    agentSessionId, telemetrySequence,
                    sequenceObservation.classification().name()));
        } catch (Exception e) {
            log.warn("Telemetry audit persistence failed for node_id={}: {}", nodeId, e.getMessage());
        }
    }

    /**
     * @return an immutable view of all registered node snapshots.
     */
    public Collection<DigitalTwinSnapshot> allSnapshots() {
        return twins.values().stream()
                .map(DigitalTwin::snapshot)
                .toList();
    }

    /**
     * @return an immutable view of the node's twin, or empty when the node is
     *         not registered.
     */
    public Optional<DigitalTwinSnapshot> getSnapshot(String nodeId) {
        DigitalTwin twin = twins.get(nodeId);
        return twin == null ? Optional.empty() : Optional.of(twin.snapshot());
    }

    /**
     * @return number of registered nodes currently tracked.
     */
    public int trackedNodeCount() {
        return twins.size();
    }

    /**
     * Removes a tracked node twin. Intended for test cleanup between scenarios so
     * that one test's registered node does not leak into another's scheduling
     * decisions. State is in-memory only; removal is immediate.
     */
    public void removeNode(String nodeId) {
        twins.remove(nodeId);
    }

    /**
     * Returns the ingestion lock for a node, creating it on first use. The lock
     * map is bounded by the number of known nodes, so it introduces no unbounded
     * memory growth.
     */
    private ReentrantLock nodeIngestionLock(String nodeId) {
        ReentrantLock existing = ingestionLocks.get(nodeId);
        if (existing != null) {
            return existing;
        }
        ReentrantLock created = new ReentrantLock();
        ReentrantLock prior = ingestionLocks.putIfAbsent(nodeId, created);
        return prior != null ? prior : created;
    }

    /**
     * @return the collection configuration provenance recorded on every persisted
     * record; {@link TelemetryEvaluationStore#UNKNOWN_COLLECTION_CONFIG_VERSION}
     * when none was configured. Independent of the record schema version.
     */
    public String getCollectionConfigVersion() {
        return collectionConfigVersion;
    }

    /**
     * @return the telemetry sequence tracker. Observational only; it never gates
     * telemetry acceptance and is independent of belief updates.
     */
    public TelemetrySequenceTracker getSequenceTracker() {
        return sequenceTracker;
    }

    /**
     * Logs a sequence anomaly. A forward gap is described as a discontinuity in
     * the received stream, never as proven message loss: the message may have
     * failed to transmit, may still be in flight, or may arrive out of order.
     */
    private void logSequenceAnomaly(String nodeId, TelemetrySequenceTracker.Observation observation) {
        switch (observation.classification()) {
            case FORWARD_GAP -> log.warn(
                    "Telemetry sequence discontinuity for node_id={}, session={}: sequence={} followed highest={} "
                            + "(missing {}..{} in received stream; NOT proof of permanent loss)",
                    nodeId, observation.sessionId(), observation.sequence(),
                    observation.highestSequence(), observation.gapFrom(), observation.gapTo());
            case DUPLICATE -> log.warn(
                    "Duplicate telemetry sequence for node_id={}, session={}: sequence={} already received",
                    nodeId, observation.sessionId(), observation.sequence());
            case OUT_OF_ORDER -> log.warn(
                    "Out-of-order telemetry sequence for node_id={}, session={}: sequence={} below highest={}",
                    nodeId, observation.sessionId(), observation.sequence(), observation.highestSequence());
            case SESSION_CHANGED -> log.info(
                    "New agent session for node_id={}: session={} (sequence-scoped tracking restarted)",
                    nodeId, observation.sessionId());
            case OBSOLETE_SESSION -> log.warn(
                    "Telemetry from superseded session for node_id={}: session={} (not applied)",
                    nodeId, observation.sessionId());
            case TRACKING_STATE_EVICTED -> log.warn(
                    "Sequence tracking state for node_id={} was evicted; sequence={} cannot be "
                            + "classified against prior history (duplicate detection unavailable)",
                    nodeId, observation.sequence());
            case INVALID_METADATA -> log.warn(
                    "Invalid telemetry sequence metadata for node_id={}: session='{}', sequence={}",
                    nodeId, observation.sessionId(), observation.sequence());
            case FIRST_SEQUENCE -> log.debug(
                    "First telemetry sequence for node_id={}, session={}: sequence={}",
                    nodeId, observation.sessionId(), observation.sequence());
            case NOT_REPORTED, CONSECUTIVE -> {
                // No anomaly; nothing to log.
            }
        }
    }
}
