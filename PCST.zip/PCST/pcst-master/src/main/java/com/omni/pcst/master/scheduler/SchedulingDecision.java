package com.omni.pcst.master.scheduler;

import java.util.List;
import java.util.Objects;

/**
 * The Step 6D scheduling decision for one task at one decision epoch:
 * {@code n* = arg max R(n, τ)} over the feasible set {@code F_t(τ)}, subject to
 * the policy threshold {@code θτ} (specification section 10.1, Appendix A).
 *
 * <p>This is the greedy one-step, maximum-modelled-reliability policy. It is
 * explicitly <b>not</b> a globally optimal multi-task POMDP policy, and a
 * selection is not a guarantee of success.
 *
 * <p>The decision records the outcome, the selected node (if any), the threshold
 * applied, every candidate with its disposition and estimates, and the reason
 * codes explaining the outcome. A node is never selected with a fabricated
 * reliability: when no eligible candidate has a defined estimate the outcome is
 * an explicit no-selection unless an explicitly configured policy fallback
 * applies, in which case the selection is labelled as a fallback and carries no
 * reliability value.
 *
 * @param taskId             identity of the scheduled task
 * @param decisionTimeMillis the decision instant {@code t}
 * @param status             the overall outcome
 * @param selectedNodeId     the selected node id, or {@code null} when none was selected
 * @param selectedReliability the selected node's reliability in [0, 1]; non-null if and only if
 *                            {@code status == SELECTED}
 * @param policyThreshold    the threshold {@code θτ} applied, or {@code null} when none configured
 * @param policyFallback     true when the selection came from a configured fallback, not reliability
 * @param candidates         the per-candidate decision trace, ordered by node id
 * @param reasons            distinct reason codes explaining the outcome
 * @param derivation         human-readable account of the decision
 */
public record SchedulingDecision(
        String taskId,
        long decisionTimeMillis,
        SchedulingStatus status,
        String selectedNodeId,
        Double selectedReliability,
        Double policyThreshold,
        boolean policyFallback,
        List<CandidateDecision> candidates,
        List<SchedulingReason> reasons,
        String derivation) {

    public SchedulingDecision {
        Objects.requireNonNull(taskId, "taskId");
        Objects.requireNonNull(status, "status");
        candidates = candidates == null ? List.of() : List.copyOf(candidates);
        reasons = reasons == null ? List.of() : List.copyOf(reasons);
        derivation = derivation == null ? "" : derivation;
        if (selectedReliability != null && (selectedReliability < 0.0 || selectedReliability > 1.0)) {
            throw new IllegalArgumentException(
                    "selectedReliability must be within [0, 1] (was " + selectedReliability + ")");
        }
        if (policyThreshold != null && (policyThreshold < 0.0 || policyThreshold > 1.0)) {
            throw new IllegalArgumentException(
                    "policyThreshold must be within [0, 1] (was " + policyThreshold + ")");
        }
        if (status.hasSelection() != (selectedNodeId != null)) {
            throw new IllegalArgumentException(
                    "selectedNodeId must be non-null exactly when a node is selected (status=" + status + ")");
        }
        if ((status == SchedulingStatus.SELECTED) != (selectedReliability != null)) {
            throw new IllegalArgumentException(
                    "selectedReliability must be non-null exactly for a probabilistic SELECTED outcome (status="
                            + status + ")");
        }
        if (policyFallback != (status == SchedulingStatus.FALLBACK_SELECTED)) {
            throw new IllegalArgumentException(
                    "policyFallback must be true exactly for a fallback selection (status=" + status + ")");
        }
    }

    /** @return true when a node was selected */
    public boolean hasSelection() {
        return status.hasSelection();
    }

    /** @return the trace entry for a node id, or {@code null} when absent */
    public CandidateDecision candidateFor(String nodeId) {
        return candidates.stream()
                .filter(c -> Objects.equals(c.nodeId(), nodeId))
                .findFirst()
                .orElse(null);
    }

    /** @return the selected candidate's trace entry, or {@code null} when no node was selected */
    public CandidateDecision selectedCandidate() {
        return selectedNodeId == null ? null : candidateFor(selectedNodeId);
    }
}
