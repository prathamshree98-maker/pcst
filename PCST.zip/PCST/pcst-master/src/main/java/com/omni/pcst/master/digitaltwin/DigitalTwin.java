package com.omni.pcst.master.digitaltwin;

import com.omni.pcst.master.belief.BayesianBeliefEngine;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Master-side state for one registered node: the Digital Twin.
 *
 * <p>The Digital Twin is the Master's state and <em>belief</em> about a node, not
 * a renamed telemetry object. It keeps four strictly separated concerns:
 *
 * <ol>
 *   <li><b>Raw observations</b> — the latest accepted {@link TelemetryObservation}
 *       and a bounded history of recent ones (newest first).</li>
 *   <li><b>Lifecycle/freshness metadata</b> — registration times and the last
 *       accepted heartbeat time (Master clock).</li>
 *   <li><b>Registration metadata</b> — node id, hostname, port, agent version.</li>
 *   <li><b>Belief state</b> — starts as {@link BeliefState#UNINITIALIZED} and is
 *       populated from the observation history by the configured Bayesian
 *       update engine after each accepted observation (no engine configured
 *       means the state stays uninitialized).</li>
 * </ol>
 *
 * <p>All mutations are serialized through an internal per-node lock, so
 * concurrent RPC handlers (registration, heartbeat, telemetry) cannot corrupt
 * state. The lock is held per node only; different nodes never contend.
 */
final class DigitalTwin {

    private final String nodeId;
    private final long registeredAtMillis;
    private final ReentrantLock lock = new ReentrantLock();

    private String hostname;
    private int port;
    private String agentVersion;
    private long lastRegistrationMillis;
    private long lastHeartbeatMillis;
    private long lastTelemetryReceivedAtMillis;
    private TelemetryObservation latestObservation;
    private final Deque<TelemetryObservation> observationHistory;
    private final int maxHistorySize;
    private final BayesianBeliefEngine beliefEngine;
    private long staleObservationsRejected;

    private BeliefState beliefState = BeliefState.UNINITIALIZED;

    DigitalTwin(String nodeId, String hostname, int port, String agentVersion,
                long registeredAtMillis, int maxHistorySize, BayesianBeliefEngine beliefEngine) {
        this.nodeId = nodeId;
        this.hostname = hostname;
        this.port = port;
        this.agentVersion = agentVersion;
        this.registeredAtMillis = registeredAtMillis;
        this.lastRegistrationMillis = registeredAtMillis;
        this.maxHistorySize = maxHistorySize;
        this.beliefEngine = beliefEngine;
        this.observationHistory = new ArrayDeque<>();
    }

    /**
     * Refreshes registration metadata after an accepted (re-)registration.
     * Observation history and freshness state are preserved: re-registration is
     * not a node replacement.
     */
    void refreshRegistration(String hostname, int port, String agentVersion, long serverTimeMillis) {
        lock.lock();
        try {
            this.hostname = hostname;
            this.port = port;
            this.agentVersion = agentVersion;
            this.lastRegistrationMillis = serverTimeMillis;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Records an accepted heartbeat. Unknown nodes never reach this method —
     * the manager rejects them before a twin is created or updated.
     */
    void recordHeartbeat(long serverTimeMillis) {
        lock.lock();
        try {
            this.lastHeartbeatMillis = serverTimeMillis;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Applies a new observation if it is not stale.
     *
     * @return {@code true} when the observation was accepted and became the latest
     *         one; {@code false} when it was rejected because its timestamp is
     *         older than (or equal to) the currently latest observation. A
     *         rejected observation never overwrites newer state.
     */
    boolean applyObservation(TelemetryObservation observation, long receivedAtMillis) {
        lock.lock();
        try {
            TelemetryObservation current = latestObservation;
            if (current != null && observation.timestamp() <= current.timestamp()) {
                staleObservationsRejected++;
                return false;
            }
            this.latestObservation = observation;
            this.lastTelemetryReceivedAtMillis = receivedAtMillis;
            observationHistory.addFirst(observation);
            while (observationHistory.size() > maxHistorySize) {
                observationHistory.removeLast();
            }
            if (beliefEngine != null) {
                this.beliefState = beliefEngine.update(new ArrayList<>(observationHistory));
            }
            return true;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Returns an immutable point-in-time view of this twin. The history list is a
     * copy; the observation instances themselves are immutable.
     */
    DigitalTwinSnapshot snapshot() {
        lock.lock();
        try {
            return new DigitalTwinSnapshot(
                    nodeId,
                    hostname,
                    port,
                    agentVersion,
                    registeredAtMillis,
                    lastRegistrationMillis,
                    lastHeartbeatMillis,
                    latestObservation,
                    List.copyOf(new ArrayList<>(observationHistory)),
                    lastTelemetryReceivedAtMillis,
                    staleObservationsRejected,
                    beliefState);
        } finally {
            lock.unlock();
        }
    }

    String getNodeId() {
        return nodeId;
    }
}
