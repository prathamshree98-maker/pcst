package com.omni.pcst.master.execution;

import com.omni.pcst.master.task.Task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * JDBC-backed {@link TaskRegistry} implementation backed by PostgreSQL.
 *
 * <p>Active when {@code pcst.persistence.jdbc.enabled=true}. Startup fails
 * closed if the datasource or Flyway migration is unavailable; there is no
 * silent fallback to in-memory persistence.
 *
 * <p>All mutations go through {@link JdbcTaskRepository} with optimistic
 * concurrency control on the {@code version} column. Duplicate taskId creation
 * is rejected deliberately; existing rows are never silently overwritten.
 */
@Component
@ConditionalOnProperty(name = "pcst.persistence.jdbc.enabled", havingValue = "true")
@Primary
public class JdbcTaskRegistry implements TaskRegistry {

    private static final Logger log = LoggerFactory.getLogger(JdbcTaskRegistry.class);

    private static final int MAX_UPDATE_RETRIES = 3;

    private final JdbcTaskRepository repository;

    public JdbcTaskRegistry(JdbcTaskRepository repository) {
        this.repository = repository;
    }

    /**
     * Creates a new task record in the ACCEPTED state.
     *
     * @param task the submitted task
     * @param now  server timestamp
     * @return the created record
     * @throws IllegalArgumentException if a task with the same taskId already exists
     */
    @Override
    public TaskRecord create(Task task, long now) {
        TaskRecord record = TaskRecord.createAccepted(task, java.util.UUID.randomUUID().toString(), now);
        repository.insert(record);
        return record;
    }

    /**
     * Atomically updates a task record using a function, with optimistic
     * concurrency control. On a version conflict the current state is re-read
     * and the updater is re-applied, up to {@link #MAX_UPDATE_RETRIES} times.
     *
     * @param taskId the task identifier
     * @param updater a function from current record to new record; may return
     *               the same record to indicate no change
     * @return the new record, or empty if taskId not found
     */
    @Override
    public Optional<TaskRecord> update(String taskId,
                                       Function<TaskRecord, TaskRecord> updater) {
        for (int attempt = 0; attempt <= MAX_UPDATE_RETRIES; attempt++) {
            Optional<JdbcTaskRepository.VersionedRecord> currentOpt = repository.findById(taskId);
            if (currentOpt.isEmpty()) {
                return Optional.empty();
            }
            JdbcTaskRepository.VersionedRecord current = currentOpt.get();
            TaskRecord updated = updater.apply(current.record());
            if (updated == current.record()) {
                return Optional.of(current.record());
            }
            int rows = repository.update(current.record(), updated, current.version());
            if (rows == 1) {
                return Optional.of(updated);
            }
            // Version conflict: retry with the latest state
            if (attempt < MAX_UPDATE_RETRIES) {
                log.warn("Update conflict on taskId={}, retrying (attempt={})",
                        taskId, attempt + 1);
            }
        }
        log.warn("Failed to update task record after {} retries: taskId={}",
                MAX_UPDATE_RETRIES + 1, taskId);
        return Optional.empty();
    }

    /**
     * @return the current snapshot for a taskId, or empty if not found
     */
    @Override
    public Optional<TaskRecord> get(String taskId) {
        return repository.findById(taskId)
                .map(JdbcTaskRepository.VersionedRecord::record);
    }

    /** @return all current task records */
    @Override
    public Collection<TaskRecord> all() {
        return repository.findAll();
    }

    /** @return count of tracked tasks */
    @Override
    public int size() {
        return all().size();
    }

    /** Removes a task record (for testing/cleanup). */
    @Override
    public void remove(String taskId) {
        repository.deleteById(taskId);
    }

    /** Returns tasks in a specific state. */
    @Override
    public List<TaskRecord> tasksInState(TaskState state) {
        return all().stream()
                .filter(t -> t.state() == state)
                .collect(Collectors.toList());
    }
}
