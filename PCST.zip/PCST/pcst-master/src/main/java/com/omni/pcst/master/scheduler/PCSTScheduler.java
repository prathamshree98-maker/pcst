package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.capability.CapabilityAssessment;
import com.omni.pcst.master.capability.CapabilityEngine;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.reliability.ReliabilityAssessment;
import com.omni.pcst.master.reliability.ReliabilityEngine;
import com.omni.pcst.master.reliability.ReliabilityInput;
import com.omni.pcst.master.task.HardConstraintFilter;
import com.omni.pcst.master.task.NodeEligibilityResult;
import com.omni.pcst.master.task.Task;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.stereotype.Component;

/**
 * Step 6D PCST scheduler: the greedy, one-decision-epoch maximum-reliability
 * policy of specification section 10.1.
 *
 * <p>{@code n* = arg max R(n, τ)} over the feasible set {@code F_t(τ)}, subject to
 * {@code R(n*, τ) ≥ θτ}. The scheduler composes the three upstream stages — the
 * Step 6A hard-constraint filter, the Step 6B capability estimator and the
 * Step 6C reliability estimator — and applies the policy to their results. It
 * recomputes none of them.
 *
 * <h2>What the policy is, and is not</h2>
 * This is a greedy belief-state policy for the current single task at the current
 * instant. It is <b>not</b> a globally optimal multi-task POMDP policy, and a
 * selection is not a guarantee of success (specification sections 6.4 and 10.2).
 *
 * <h2>Guardrails</h2>
 * <ul>
 *   <li>Hard eligibility is applied first. An ineligible candidate is never
 *       selected, even if it carries a reliability estimate.</li>
 *   <li>Only candidates with a <b>defined</b> reliability estimate are ranked. An
 *       unresolved estimate is never treated as {@code 0}, {@code 1}, or a rank.
 *   <li>Capability is never substituted for reliability as the ranking value; it
 *       appears only in the decision trace.</li>
 *   <li>No probabilities are multiplied and no weighted score is formed.</li>
 *   <li>If eligible candidates exist but none has a defined estimate, the outcome
 *       is an explicit no-selection unless an explicitly configured
 *       {@link FallbackPolicy} applies, in which case the selection is labelled a
 *       policy fallback and carries no reliability value.</li>
 * </ul>
 *
 * <h2>Determinism</h2>
 * Candidates are deduplicated and ordered by node id. A tie at the maximum
 * reliability is broken deterministically by the lowest node id. Identical inputs
 * produce identical decisions. The scheduler is stateless and mutates nothing.
 */
@Component
public final class PCSTScheduler implements Scheduler {

    private final HardConstraintFilter hardConstraintFilter;
    private final CapabilityEngine capabilityEngine;
    private final ReliabilityEngine reliabilityEngine;
    private final SchedulingPolicyConfig policy;

    /** Creates a scheduler with the default filter, engines, and a no-threshold policy. */
    public PCSTScheduler() {
        this(SchedulingPolicyConfig.none());
    }

    /** Creates a scheduler with the default filter and engines and the given policy. */
    public PCSTScheduler(SchedulingPolicyConfig policy) {
        this(new HardConstraintFilter(), new CapabilityEngine(), new ReliabilityEngine(), policy);
    }

    /**
     * @param hardConstraintFilter the Step 6A filter
     * @param capabilityEngine     the Step 6B capability engine
     * @param reliabilityEngine    the Step 6C reliability engine
     * @param policy               the Step 6D policy configuration
     */
    public PCSTScheduler(HardConstraintFilter hardConstraintFilter,
                         CapabilityEngine capabilityEngine,
                         ReliabilityEngine reliabilityEngine,
                         SchedulingPolicyConfig policy) {
        this.hardConstraintFilter = Objects.requireNonNull(hardConstraintFilter, "hardConstraintFilter");
        this.capabilityEngine = Objects.requireNonNull(capabilityEngine, "capabilityEngine");
        this.reliabilityEngine = Objects.requireNonNull(reliabilityEngine, "reliabilityEngine");
        this.policy = Objects.requireNonNull(policy, "policy");
    }

    public SchedulingPolicyConfig policy() {
        return policy;
    }

    public HardConstraintFilter hardConstraintFilter() {
        return hardConstraintFilter;
    }

    public CapabilityEngine capabilityEngine() {
        return capabilityEngine;
    }

    public ReliabilityEngine reliabilityEngine() {
        return reliabilityEngine;
    }

    /**
     * End-to-end entry point: filters hard eligibility, estimates capability and
     * reliability for every candidate, then applies the policy.
     *
     * @param task               the task to place; must not be null
     * @param decisionTimeMillis the decision instant {@code t}
     * @param snapshots          candidate node snapshots, in any order
     * @return the decision; never {@code null}
     */
    public SchedulingDecision schedule(Task task,
                                       long decisionTimeMillis,
                                       Collection<DigitalTwinSnapshot> snapshots) {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(snapshots, "snapshots");

        List<NodeEligibilityResult> eligibility =
                hardConstraintFilter.filter(task, snapshots, decisionTimeMillis);
        Map<String, DigitalTwinSnapshot> byNodeId = deduplicateSnapshots(snapshots);

        List<SchedulingCandidate> candidates = new ArrayList<>(eligibility.size());
        for (NodeEligibilityResult result : eligibility) {
            DigitalTwinSnapshot snapshot = byNodeId.get(result.nodeId());
            if (snapshot == null) {
                continue;
            }
            CapabilityAssessment capability = capabilityEngine.assess(task, snapshot, decisionTimeMillis);
            ReliabilityAssessment reliability = reliabilityEngine.assess(
                    new ReliabilityInput(task, snapshot, result, capability));
            candidates.add(new SchedulingCandidate(result, capability, reliability));
        }
        return select(task, decisionTimeMillis, candidates);
    }

    @Override
    public SchedulingDecision select(Task task,
                                     long decisionTimeMillis,
                                     Collection<SchedulingCandidate> candidates) {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(candidates, "candidates");

        List<SchedulingCandidate> ordered = deduplicateOrdered(candidates);
        if (ordered.isEmpty()) {
            return build(task, decisionTimeMillis, SchedulingStatus.NO_FEASIBLE_NODE, null, null, null,
                    false, List.of(),
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no candidate node was supplied, so the feasible set F_t(tau) is empty");
        }

        Double threshold = policy.thresholdFor(task.taskClass());

        List<SchedulingCandidate> eligible = ordered.stream()
                .filter(SchedulingCandidate::eligible)
                .toList();
        if (eligible.isEmpty()) {
            List<CandidateDecision> trace = new ArrayList<>(ordered.size());
            for (SchedulingCandidate candidate : ordered) {
                trace.add(excluded(candidate));
            }
            return build(task, decisionTimeMillis, SchedulingStatus.NO_FEASIBLE_NODE, null, null, threshold,
                    false, trace,
                    List.of(SchedulingReason.NO_CANDIDATE_PASSED_HARD_ELIGIBILITY),
                    "no candidate passed hard eligibility, so F_t(tau) is empty; no reliability was ranked");
        }

        List<SchedulingCandidate> rankable = eligible.stream()
                .filter(SchedulingCandidate::hasReliability)
                .toList();
        boolean someUnresolved = rankable.size() < eligible.size();

        if (!rankable.isEmpty()) {
            return selectRanked(task, decisionTimeMillis, threshold, ordered, rankable, someUnresolved);
        }
        return selectUnresolved(task, decisionTimeMillis, threshold, ordered);
    }

    // -------------------------------------------------------------- ranked case

    private SchedulingDecision selectRanked(Task task,
                                            long decisionTimeMillis,
                                            Double threshold,
                                            List<SchedulingCandidate> ordered,
                                            List<SchedulingCandidate> rankable,
                                            boolean someUnresolved) {
        double maxReliability = rankable.stream()
                .mapToDouble(c -> c.reliability().reliability())
                .max()
                .orElseThrow(() -> new IllegalStateException("rankable set must not be empty"));
        List<SchedulingCandidate> winners = rankable.stream()
                .filter(c -> Double.compare(c.reliability().reliability(), maxReliability) == 0)
                .toList();
        SchedulingCandidate winner = winners.get(0);
        boolean tieBroken = winners.size() > 1;

        boolean meetsThreshold = threshold == null || maxReliability >= threshold;

        if (!meetsThreshold) {
            List<CandidateDecision> trace = new ArrayList<>(ordered.size());
            for (SchedulingCandidate candidate : ordered) {
                if (!candidate.eligible()) {
                    trace.add(excluded(candidate));
                } else if (candidate.hasReliability()) {
                    trace.add(describe(candidate, CandidateDisposition.BELOW_THRESHOLD,
                            "eligible with reliability " + candidate.reliability().reliability()
                                    + ", below the policy threshold " + threshold));
                } else {
                    trace.add(unresolved(candidate));
                }
            }
            List<SchedulingReason> reasons = new ArrayList<>();
            reasons.add(SchedulingReason.ALL_RANKED_CANDIDATES_BELOW_POLICY_THRESHOLD);
            if (someUnresolved) {
                reasons.add(SchedulingReason.SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE);
            }
            return build(task, decisionTimeMillis, SchedulingStatus.DEFER_OR_REJECT, null, null, threshold,
                    false, trace, reasons,
                    "every eligible candidate with a reliability estimate (" + rankable.size()
                            + ") is below the policy threshold " + threshold
                            + "; no node was selected (defer or reject)");
        }

        List<CandidateDecision> trace = new ArrayList<>(ordered.size());
        for (SchedulingCandidate candidate : ordered) {
            if (!candidate.eligible()) {
                trace.add(excluded(candidate));
            } else if (candidate.nodeId().equals(winner.nodeId())) {
                trace.add(describe(candidate, CandidateDisposition.SELECTED,
                        "selected with the highest reliability " + maxReliability
                                + (tieBroken ? " (tie broken by lowest node id)" : "")));
            } else if (candidate.hasReliability()) {
                trace.add(describe(candidate, CandidateDisposition.LOWER_RELIABILITY,
                        "eligible with reliability " + candidate.reliability().reliability()
                                + ", below the maximum " + maxReliability));
            } else {
                trace.add(unresolved(candidate));
            }
        }

        List<SchedulingReason> reasons = new ArrayList<>();
        reasons.add(SchedulingReason.SELECTED_HIGHEST_RELIABILITY);
        reasons.add(threshold == null
                ? SchedulingReason.NO_POLICY_THRESHOLD_CONFIGURED
                : SchedulingReason.SELECTED_MEETS_POLICY_THRESHOLD);
        if (tieBroken) {
            reasons.add(SchedulingReason.TIE_BROKEN_BY_NODE_ID);
        }
        if (someUnresolved) {
            reasons.add(SchedulingReason.SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE);
        }
        String derivation = "selected node " + winner.nodeId() + " with the highest estimated reliability "
                + maxReliability + " among " + rankable.size() + " ranked eligible candidate(s)"
                + (threshold == null
                        ? "; no policy threshold was configured (specification section 19)"
                        : " at or above the policy threshold " + threshold)
                + (tieBroken ? "; the maximum was shared and was broken by the lowest node id" : "")
                + (someUnresolved ? "; some eligible candidates had no reliability estimate and were not ranked" : "")
                + "; this is a greedy one-step choice, not a global optimum";
        return build(task, decisionTimeMillis, SchedulingStatus.SELECTED, winner.nodeId(), maxReliability,
                threshold, false, trace, reasons, derivation);
    }

    // ---------------------------------------------------------- unresolved case

    private SchedulingDecision selectUnresolved(Task task,
                                                long decisionTimeMillis,
                                                Double threshold,
                                                List<SchedulingCandidate> ordered) {
        List<SchedulingCandidate> eligible = ordered.stream()
                .filter(SchedulingCandidate::eligible)
                .toList();

        if (policy.fallbackPolicy() == FallbackPolicy.LOWEST_NODE_ID) {
            SchedulingCandidate winner = eligible.get(0);
            List<CandidateDecision> trace = new ArrayList<>(ordered.size());
            for (SchedulingCandidate candidate : ordered) {
                if (!candidate.eligible()) {
                    trace.add(excluded(candidate));
                } else if (candidate.nodeId().equals(winner.nodeId())) {
                    trace.add(describe(candidate, CandidateDisposition.SELECTED_BY_FALLBACK,
                            "selected by the configured policy fallback (lowest node id); "
                                    + "no reliability estimate exists, so this is not a probabilistic conclusion"));
                } else {
                    trace.add(unresolved(candidate));
                }
            }
            return build(task, decisionTimeMillis, SchedulingStatus.FALLBACK_SELECTED, winner.nodeId(), null,
                    threshold, true, trace,
                    List.of(SchedulingReason.POLICY_FALLBACK_LOWEST_NODE_ID,
                            SchedulingReason.NO_ELIGIBLE_CANDIDATE_HAS_A_RELIABILITY_ESTIMATE),
                    "no eligible candidate has a reliability estimate; the configured policy fallback selected "
                            + winner.nodeId() + " (lowest node id). This is a deterministic policy fallback, "
                            + "not a probabilistic conclusion");
        }

        List<CandidateDecision> trace = new ArrayList<>(ordered.size());
        for (SchedulingCandidate candidate : ordered) {
            if (!candidate.eligible()) {
                trace.add(excluded(candidate));
            } else {
                trace.add(unresolved(candidate));
            }
        }
        return build(task, decisionTimeMillis, SchedulingStatus.NO_SELECTION_UNRESOLVED, null, null,
                threshold, false, trace,
                List.of(SchedulingReason.NO_ELIGIBLE_CANDIDATE_HAS_A_RELIABILITY_ESTIMATE),
                "eligible candidates exist but none has a defined reliability estimate; "
                        + "no node was selected rather than invent a probability");
    }

    // ------------------------------------------------------------------ helpers

    private CandidateDecision excluded(SchedulingCandidate candidate) {
        boolean proven = candidate.eligibility().reasons().stream()
                .anyMatch(reason -> !reason.isIndeterminate());
        boolean indeterminate = candidate.eligibility().indeterminate();
        String cause;
        if (proven && indeterminate) {
            cause = "excluded by a proven hard-constraint violation and an unproven constraint";
        } else if (proven) {
            cause = "excluded by a proven hard-constraint violation";
        } else {
            cause = "excluded by an unproven (indeterminate) hard constraint";
        }
        if (candidate.hasReliability()) {
            cause = cause + "; a reliability estimate was present but never overrides ineligibility";
        }
        return describe(candidate, CandidateDisposition.EXCLUDED_HARD_CONSTRAINT, cause);
    }

    private CandidateDecision unresolved(SchedulingCandidate candidate) {
        return describe(candidate, CandidateDisposition.UNRESOLVED_RELIABILITY,
                "eligible but its reliability status is " + candidate.reliability().status()
                        + ", so it has no defined estimate and was not ranked");
    }

    private CandidateDecision describe(SchedulingCandidate candidate,
                                       CandidateDisposition disposition,
                                       String explanation) {
        CapabilityAssessment capability = candidate.capability();
        return new CandidateDecision(
                candidate.nodeId(),
                candidate.eligible(),
                disposition,
                candidate.eligibility().reasons(),
                candidate.reliability().status(),
                candidate.reliability().reliability(),
                candidate.reliability().capabilityStatus(),
                capability == null ? null : capability.capability(),
                explanation);
    }

    private SchedulingDecision build(Task task,
                                     long decisionTimeMillis,
                                     SchedulingStatus status,
                                     String selectedNodeId,
                                     Double selectedReliability,
                                     Double threshold,
                                     boolean policyFallback,
                                     List<CandidateDecision> trace,
                                     List<SchedulingReason> reasons,
                                     String derivation) {
        return new SchedulingDecision(task.taskId(), decisionTimeMillis, status, selectedNodeId,
                selectedReliability, threshold, policyFallback, trace, reasons, derivation);
    }

    private boolean someUnresolved(List<SchedulingCandidate> ordered) {
        return ordered.stream().anyMatch(c -> c.eligible() && !c.hasReliability());
    }

    private static List<SchedulingCandidate> deduplicateOrdered(
            Collection<SchedulingCandidate> candidates) {
        Map<String, SchedulingCandidate> byNodeId = new LinkedHashMap<>();
        for (SchedulingCandidate candidate : candidates) {
            if (candidate == null) {
                continue;
            }
            byNodeId.putIfAbsent(candidate.nodeId(), candidate);
        }
        List<SchedulingCandidate> ordered = new ArrayList<>(byNodeId.values());
        ordered.sort(Comparator.comparing(SchedulingCandidate::nodeId));
        return ordered;
    }

    private static Map<String, DigitalTwinSnapshot> deduplicateSnapshots(
            Collection<DigitalTwinSnapshot> snapshots) {
        Map<String, DigitalTwinSnapshot> byNodeId = new LinkedHashMap<>();
        for (DigitalTwinSnapshot snapshot : snapshots) {
            if (snapshot == null) {
                continue;
            }
            String nodeId = snapshot.nodeId();
            if (nodeId == null || nodeId.isBlank()) {
                continue;
            }
            byNodeId.putIfAbsent(nodeId, snapshot);
        }
        return byNodeId;
    }
}
