package com.omni.pcst.master.dashboard;

import com.omni.pcst.master.digitaltwin.BeliefState;
import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.ResourceBelief;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Detailed view of a node for node detail page.
 */
public record NodeDetail(
        String nodeId,
        String hostname,
        int port,
        String agentVersion,
        long registeredAtMillis,
        long lastRegistrationMillis,
        long lastHeartbeatMillis,
        long lastTelemetryReceivedAtMillis,
        long staleObservationsRejected,
        TelemetryDetail latestTelemetry,
        List<TelemetryDetail> observationHistory,
        BeliefDetail beliefState) {

    public static NodeDetail fromSnapshot(DigitalTwinSnapshot snapshot) {
        TelemetryDetail telemetry = snapshot.latestObservation() != null
                ? TelemetryDetail.from(snapshot.latestObservation())
                : null;

        List<TelemetryDetail> history = snapshot.observationHistory().stream()
                .map(TelemetryDetail::from)
                .toList();

        BeliefDetail belief = snapshot.beliefState() != null
                ? BeliefDetail.from(snapshot.beliefState())
                : null;

        return new NodeDetail(
                snapshot.nodeId(),
                snapshot.hostname(),
                snapshot.port(),
                snapshot.agentVersion(),
                snapshot.registeredAtMillis(),
                snapshot.lastRegistrationMillis(),
                snapshot.lastHeartbeatMillis(),
                snapshot.lastTelemetryReceivedAtMillis(),
                snapshot.staleObservationsRejected(),
                telemetry,
                history,
                belief);
    }

    /**
     * Detailed telemetry observation.
     */
    public record TelemetryDetail(
            long timestamp,
            Double cpuUtilizationPercent,
            Long totalMemoryBytes,
            Long usedMemoryBytes,
            Long availableMemoryBytes,
            Boolean gpuAvailable,
            Double gpuUtilizationPercent,
            Double batteryLevelPercent,
            Boolean batteryCharging,
            Double temperatureCelsius,
            Double latencyMs,
            Double packetLossPercent,
            Long totalDiskBytes,
            Long freeDiskBytes,
            Integer processCount,
            Boolean userActive) {

        public static TelemetryDetail from(TelemetryObservation obs) {
            return new TelemetryDetail(
                    obs.timestamp(),
                    obs.cpuUtilizationPercent(),
                    obs.totalMemoryBytes(),
                    obs.usedMemoryBytes(),
                    obs.availableMemoryBytes(),
                    obs.gpuAvailable(),
                    obs.gpuUtilizationPercent(),
                    obs.batteryLevelPercent(),
                    obs.batteryCharging(),
                    obs.temperatureCelsius(),
                    obs.latencyMs(),
                    obs.packetLossPercent(),
                    obs.totalDiskBytes(),
                    obs.freeDiskBytes(),
                    obs.processCount(),
                    obs.userActive());
        }

        public Optional<Double> memoryUtilizationPercent() {
            if (totalMemoryBytes != null && usedMemoryBytes != null && totalMemoryBytes > 0) {
                return Optional.of((double) usedMemoryBytes / totalMemoryBytes * 100.0);
            }
            return Optional.empty();
        }
    }

    /**
     * Detailed belief state.
     */
    public record BeliefDetail(
            long observationCount,
            long latestObservationTimestamp,
            long computedAtMillis,
            Map<String, ResourceBeliefDetail> beliefs) {

        public static BeliefDetail from(BeliefState beliefState) {
            Map<String, ResourceBeliefDetail> beliefs = beliefState.beliefs().entrySet().stream()
                    .collect(java.util.stream.Collectors.toMap(
                            Map.Entry::getKey,
                            e -> ResourceBeliefDetail.from(e.getValue())));
            return new BeliefDetail(
                    beliefState.observationCount(),
                    beliefState.latestObservationTimestamp(),
                    beliefState.computedAtMillis(),
                    beliefs);
        }
    }

    /**
     * Detailed resource belief.
     */
    public record ResourceBeliefDetail(
            String resourceName,
            double posteriorMean,
            double posteriorVariance,
            double posteriorStdDev,
            long observationCount,
            long lastObservationTimestamp) {

        public static ResourceBeliefDetail from(ResourceBelief belief) {
            return new ResourceBeliefDetail(
                    belief.resourceName(),
                    belief.posteriorMean(),
                    belief.posteriorVariance(),
                    Math.sqrt(belief.posteriorVariance()),
                    belief.observationCount(),
                    belief.lastObservationTimestamp());
        }
    }
}