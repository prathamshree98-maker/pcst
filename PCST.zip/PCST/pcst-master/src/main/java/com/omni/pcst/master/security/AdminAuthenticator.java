package com.omni.pcst.master.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Validates administrator access to protected enrollment APIs.
 *
 * <p>The administrator API key is resolved from {@code pcst.admin.api-key} (or the
 * {@code PCST_ADMIN_API_KEY} environment variable). It is never logged and never
 * embedded in frontend JavaScript. When no key is configured, administrative
 * enrollment is disabled and protected endpoints fail closed (HTTP 503) instead
 * of being open to the public.
 */
@Component
public class AdminAuthenticator {

    private final Optional<String> configuredKey;

    public AdminAuthenticator(@Value("${pcst.admin.api-key:}") String adminApiKey) {
        String key = (adminApiKey == null) ? "" : adminApiKey.trim();
        this.configuredKey = key.isBlank() ? Optional.empty() : Optional.of(key);
    }

    /**
     * @return {@code true} when an administrator API key is configured
     */
    public boolean isAdminConfigured() {
        return configuredKey.isPresent();
    }

    /**
     * Validates a bearer token supplied in an {@code Authorization} header.
     *
     * @param authorization the raw {@code Authorization} header value
     * @return {@code true} only when a key is configured and the bearer token
     *         matches it exactly
     */
    public boolean isAdmin(String authorization) {
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            return false;
        }
        String token = authorization.substring("Bearer ".length()).trim();
        return configuredKey.map(key -> key.equals(token)).orElse(false);
    }
}
