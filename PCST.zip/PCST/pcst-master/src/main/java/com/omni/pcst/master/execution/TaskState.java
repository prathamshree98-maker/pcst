package com.omni.pcst.master.execution;

import java.util.EnumSet;
import java.util.Set;

/**
 * Lifecycle state of a task execution attempt on the Master.
 *
 * <p>Transitions are strictly forward; once a terminal state is reached the
 * task never moves back to a non-terminal state. Illegal transitions are
 * rejected by {@link TaskRecord#transitionTo}.
 */
public enum TaskState {

    /** Task has been accepted and persisted; scheduling has not started. */
    ACCEPTED("task accepted, awaiting scheduling"),

    /** Scheduling produced no feasible node; task will not be dispatched. */
    NO_FEASIBLE_NODE("no node passed hard eligibility"),

    /** Scheduling could not produce a reliability estimate for any eligible node. */
    UNRESOLVED_SCHEDULING("eligible candidates exist but none has a defined reliability estimate"),

    /** Scheduling selected a node and dispatch is being attempted. */
    DISPATCHING("dispatching task to selected node"),

    /** Dispatch was accepted by the target agent; execution has not started. */
    DISPATCH_ACCEPTED("dispatch accepted by agent"),

    /** Dispatch was rejected by the target agent; task remains on Master. */
    DISPATCH_REJECTED("dispatch rejected by agent"),

    /** Agent acknowledged the dispatch and started executing the workload. */
    RUNNING("task is executing on agent"),

    /** Task completed successfully with a result. */
    SUCCEEDED("task completed successfully"),

    /** Task failed during execution (agent-reported failure). */
    FAILED("task failed during execution"),

    /** Master lost contact with agent after dispatch; outcome is unknown. */
    OUTCOME_UNKNOWN("agent unreachable after dispatch; outcome unknown");

    private final String description;

    TaskState(String description) {
        this.description = description;
    }

    public String description() {
        return description;
    }

    /** @return true for states that are final and cannot transition further */
    public boolean isTerminal() {
        return this == NO_FEASIBLE_NODE
                || this == UNRESOLVED_SCHEDULING
                || this == DISPATCH_REJECTED
                || this == SUCCEEDED
                || this == FAILED
                || this == OUTCOME_UNKNOWN;
    }

    /**
     * @return true if a transition from this state to {@code target} is allowed
     */
    public boolean canTransitionTo(TaskState target) {
        if (isTerminal()) {
            return false; // terminal states never transition, not even to themselves,
                          // so duplicate/delayed terminal results are rejected
        }
        if (this == target) {
            return true; // self-transition allowed for non-terminal dispatch-sent updates
        }
        return VALID_TRANSITIONS.getOrDefault(this, Set.of()).contains(target);
    }

    private static final java.util.Map<TaskState, Set<TaskState>> VALID_TRANSITIONS =
            java.util.Map.ofEntries(
                    java.util.Map.entry(ACCEPTED, EnumSet.of(NO_FEASIBLE_NODE, UNRESOLVED_SCHEDULING, DISPATCHING)),
                    // A terminal result or a RUNNING update can legitimately arrive before the
                    // dispatch acknowledgement is observed: the agent reports the outcome as
                    // soon as the workload finishes, which for a fast workload can precede the
                    // dispatch response or the ACCEPTED/RUNNING lifecycle updates. Terminal
                    // states are therefore reachable directly from DISPATCHING.
                    java.util.Map.entry(DISPATCHING, EnumSet.of(DISPATCH_ACCEPTED, DISPATCH_REJECTED,
                            OUTCOME_UNKNOWN, RUNNING, SUCCEEDED, FAILED)),
                    java.util.Map.entry(DISPATCH_ACCEPTED, EnumSet.of(RUNNING, OUTCOME_UNKNOWN, SUCCEEDED, FAILED)),
                    java.util.Map.entry(RUNNING, EnumSet.of(SUCCEEDED, FAILED, OUTCOME_UNKNOWN)),
                    java.util.Map.entry(DISPATCH_REJECTED, EnumSet.of(ACCEPTED)) // allow reschedule
            );
}