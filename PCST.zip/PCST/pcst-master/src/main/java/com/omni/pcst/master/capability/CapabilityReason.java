package com.omni.pcst.master.capability;

/**
 * Stable reason codes describing how one requirement entered (or failed to enter)
 * a capability assessment.
 *
 * <p>Codes are the programmatic contract; the accompanying description is for
 * humans only. Callers branch on the enum, never on message text. A code records
 * <em>why</em> a requirement has the status it has; it never encodes a probability
 * and never carries a numeric weight.
 */
public enum CapabilityReason {

    /** A marginal capability probability was computed from a predictive distribution. */
    COMPUTED("a marginal capability probability was computed from the predictive distribution"),

    /** No predictive model exists for this resource condition on the current node model. */
    NO_PREDICTIVE_MODEL("no predictive distribution model exists for this resource condition"),

    /**
     * The requirement's unit is not commensurate with the tracked belief unit, so
     * a probability cannot be formed without inventing a conversion.
     */
    UNIT_MISMATCH("the required unit is not commensurate with the belief unit"),

    /**
     * Energy/battery is a separate reliability event ({@code Eenergy}), not a
     * resource condition of capability.
     */
    DEFERRED_ENERGY_RELIABILITY("battery/energy belongs to execution reliability, not capability"),

    /**
     * The deadline is a separate reliability event ({@code Edeadline}), not a
     * resource condition of capability.
     */
    DEFERRED_DEADLINE_RELIABILITY("the deadline belongs to execution reliability, not capability"),

    /** The requirement is a compatibility/profile restriction, not a resource condition. */
    NOT_A_RESOURCE_CONDITION("the requirement is not a resource condition"),

    /** No belief posterior exists for the required resource yet. */
    MISSING_BELIEF("no belief posterior exists for the required resource"),

    /** The belief evidence is older than the configured maximum evidence age. */
    STALE_EVIDENCE("the belief evidence is older than the configured evidence age"),

    /** The belief evidence is dated after the decision instant and cannot be trusted as history. */
    EVIDENCE_AFTER_ORIGIN("the belief evidence is dated after the decision instant"),

    /** A belief parameter is non-finite and cannot define a distribution. */
    NON_FINITE_PARAMETER("a belief parameter is not finite"),

    /** The belief variance is not strictly positive and cannot define a distribution. */
    NON_POSITIVE_VARIANCE("the belief variance is not strictly positive"),

    /** The task expresses a resource condition but no duration to define the execution interval. */
    MISSING_HORIZON("the task states no expected duration to define the execution interval"),

    /** More than one computable condition exists and no justified joint model is available. */
    JOINT_MODEL_UNRESOLVED("multiple conditions with no justified joint model; marginals are not combined"),

    /** The task expresses no resource conditions; capability over them is vacuously 1. */
    VACUOUS_NO_REQUIREMENTS("the task expresses no resource conditions"),

    /** The assessment inputs were not usable (e.g. a missing candidate snapshot). */
    INVALID_INPUT("the assessment inputs were not usable");

    private final String description;

    CapabilityReason(String description) {
        this.description = description;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
