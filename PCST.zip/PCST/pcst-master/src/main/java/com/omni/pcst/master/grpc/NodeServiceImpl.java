package com.omni.pcst.master.grpc;

import com.omni.pcst.master.digitaltwin.DigitalTwinManager;
import com.omni.pcst.master.execution.TaskExecutionCoordinator;
import com.omni.pcst.master.security.DeviceCredentialService;
import com.omni.pcst.master.security.PairingCodeService;
import com.omni.pcst.proto.HeartbeatRequest;
import com.omni.pcst.proto.HeartbeatResponse;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.RegisterNodeRequest;
import com.omni.pcst.proto.RegisterNodeResponse;
import com.omni.pcst.proto.TaskLifecycleAck;
import com.omni.pcst.proto.TaskLifecycleUpdate;
import com.omni.pcst.proto.TelemetryRequest;
import com.omni.pcst.proto.TelemetryResponse;
import io.grpc.stub.StreamObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class NodeServiceImpl extends NodeServiceGrpc.NodeServiceImplBase {

    private static final Logger log = LoggerFactory.getLogger(NodeServiceImpl.class);

    private final DigitalTwinManager digitalTwinManager;
    private final PairingCodeService pairingCodeService;
    private final DeviceCredentialService deviceCredentialService;
    private final TaskExecutionCoordinator taskExecutionCoordinator;

    public NodeServiceImpl(DigitalTwinManager digitalTwinManager,
                           PairingCodeService pairingCodeService,
                           DeviceCredentialService deviceCredentialService,
                           TaskExecutionCoordinator taskExecutionCoordinator) {
        this.digitalTwinManager = digitalTwinManager;
        this.pairingCodeService = pairingCodeService;
        this.deviceCredentialService = deviceCredentialService;
        this.taskExecutionCoordinator = taskExecutionCoordinator;
    }

    @Override
    public void registerNode(RegisterNodeRequest request, StreamObserver<RegisterNodeResponse> responseObserver) {
        String nodeId = request.getNodeId();
        long serverTime = System.currentTimeMillis();

        RegisterNodeResponse.Builder responseBuilder = RegisterNodeResponse.newBuilder()
                .setServerTime(serverTime);

        if (nodeId == null || nodeId.trim().isEmpty()) {
            log.warn("Received registration request with blank node_id");
            responseBuilder.setAccepted(false)
                    .setMessage("Registration failed: node_id cannot be blank");
            responseObserver.onNext(responseBuilder.build());
            responseObserver.onCompleted();
            return;
        }

        // Authentication: a client-provided node_id is never trusted as proof of
        // device identity. Registration must present either a device credential
        // (reconnection) or a single-use pairing code (first-time enrollment).
        if (request.hasDeviceCredential()) {
            handleDeviceCredentialRegistration(request, nodeId, serverTime, responseBuilder);
        } else if (request.hasPairingCode()) {
            handlePairingCodeRegistration(request, nodeId, serverTime, responseBuilder);
        } else {
            log.warn("Registration rejected: no enrollment credential for node_id={}", nodeId);
            responseBuilder.setAccepted(false)
                    .setMessage("Registration failed: enrollment credential required (pairing code or device credential)");
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    private void handleDeviceCredentialRegistration(RegisterNodeRequest request,
                                                    String nodeId,
                                                    long serverTime,
                                                    RegisterNodeResponse.Builder responseBuilder) {
        String deviceCredential = request.getDeviceCredential();
        if (!deviceCredentialService.validate(deviceCredential, nodeId)) {
            log.warn("Registration rejected: invalid or revoked device credential for node_id={}", nodeId);
            responseBuilder.setAccepted(false)
                    .setMessage("Registration failed: invalid or revoked device credential");
            return;
        }
        // Credential is bound to this node: re-register / reconnect the device.
        String agentSessionId = request.hasAgentSessionId() ? request.getAgentSessionId() : null;
        digitalTwinManager.onNodeRegistered(
                nodeId, request.getHostname(), request.getPort(), request.getAgentVersion(),
                serverTime, agentSessionId);
        log.info("Device credential re-registration accepted: node_id={}", nodeId);
        responseBuilder.setAccepted(true)
                .setMessage("Device re-registration accepted");
    }

    private void handlePairingCodeRegistration(RegisterNodeRequest request,
                                               String nodeId,
                                               long serverTime,
                                               RegisterNodeResponse.Builder responseBuilder) {
        String pairingCode = request.getPairingCode();
        java.util.Optional<PairingCodeService.PairingCodeRecord> consumed =
                pairingCodeService.consume(pairingCode);
        if (consumed.isEmpty()) {
            log.warn("Registration rejected: invalid, expired, used, or revoked pairing code for node_id={}", nodeId);
            responseBuilder.setAccepted(false)
                    .setMessage("Registration failed: pairing code is invalid, expired, used, or revoked");
            return;
        }

        // Issue a device credential bound to this node id and associate it with
        // the registration. This node is now the authorized owner of the code.
        String deviceCredential = deviceCredentialService.issue(nodeId);
        String agentSessionId = request.hasAgentSessionId() ? request.getAgentSessionId() : null;
        digitalTwinManager.onNodeRegistered(
                nodeId, request.getHostname(), request.getPort(), request.getAgentVersion(),
                serverTime, agentSessionId);
        log.info("Pairing code enrollment accepted: node_id={}", nodeId);
        responseBuilder.setAccepted(true)
                .setMessage("Pairing enrollment accepted; device credential issued")
                .setDeviceCredential(deviceCredential);
    }

    @Override
    public void heartbeat(HeartbeatRequest request, StreamObserver<HeartbeatResponse> responseObserver) {
        String nodeId = request.getNodeId();
        long serverTime = System.currentTimeMillis();

        HeartbeatResponse.Builder responseBuilder = HeartbeatResponse.newBuilder()
                .setServerTime(serverTime);

        if (nodeId == null || nodeId.trim().isEmpty()) {
            log.warn("Received heartbeat request with blank node_id");
            responseBuilder.setAcknowledged(false);
        } else if (digitalTwinManager.onHeartbeat(nodeId, serverTime)) {
            log.debug("Received heartbeat from node_id={}, timestamp={}", nodeId, request.getTimestamp());
            responseBuilder.setAcknowledged(true);
        } else {
            log.warn("Received heartbeat from unknown node_id={} (not registered)", nodeId);
            responseBuilder.setAcknowledged(false);
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    @Override
    public void reportTelemetry(TelemetryRequest request, StreamObserver<TelemetryResponse> responseObserver) {
        String nodeId = request.getNodeId();
        long serverTime = System.currentTimeMillis();

        TelemetryResponse response;
        if (nodeId == null || nodeId.trim().isEmpty()) {
            log.warn("ReportTelemetry received with blank node_id");
            response = TelemetryResponse.newBuilder()
                    .setAccepted(false)
                    .setMessage("blank node_id")
                    .setServerTime(serverTime)
                    .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        DigitalTwinManager.TelemetryIngestion ingestion =
                digitalTwinManager.onTelemetry(nodeId, request, serverTime);
        switch (ingestion) {
            case ACCEPTED -> response = TelemetryResponse.newBuilder()
                    .setAccepted(true)
                    .setMessage("Telemetry accepted by Master")
                    .setServerTime(serverTime)
                    .build();
            case UNKNOWN_NODE -> response = TelemetryResponse.newBuilder()
                    .setAccepted(false)
                    .setMessage("unknown node_id: node is not registered")
                    .setServerTime(serverTime)
                    .build();
            case STALE_OR_OUT_OF_ORDER -> response = TelemetryResponse.newBuilder()
                    .setAccepted(false)
                    .setMessage("stale or out-of-order telemetry timestamp")
                    .setServerTime(serverTime)
                    .build();
            case DUPLICATE_SEQUENCE -> response = TelemetryResponse.newBuilder()
                    .setAccepted(false)
                    .setMessage("duplicate telemetry sequence; already recorded")
                    .setServerTime(serverTime)
                    .build();
            case OBSOLETE_SESSION -> response = TelemetryResponse.newBuilder()
                    .setAccepted(false)
                    .setMessage("telemetry from a superseded agent session")
                    .setServerTime(serverTime)
                    .build();
            default -> throw new IllegalStateException("Unexpected ingestion result: " + ingestion);
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void reportTaskLifecycle(TaskLifecycleUpdate update, StreamObserver<TaskLifecycleAck> responseObserver) {
        String taskId = update.getTaskId();
        String attemptId = update.getAttemptId();
        com.omni.pcst.proto.TaskState state = update.getState();
        long serverTime = System.currentTimeMillis();

        TaskLifecycleAck.Builder ackBuilder = TaskLifecycleAck.newBuilder()
                .setServerTime(serverTime);

        if (taskId == null || taskId.trim().isEmpty()) {
            log.warn("ReportTaskLifecycle received with blank task_id");
            ackBuilder.setAccepted(false).setMessage("task_id cannot be blank");
            responseObserver.onNext(ackBuilder.build());
            responseObserver.onCompleted();
            return;
        }
        if (attemptId == null || attemptId.trim().isEmpty()) {
            log.warn("ReportTaskLifecycle received with blank attempt_id for taskId={}", taskId);
            ackBuilder.setAccepted(false).setMessage("attempt_id cannot be blank");
            responseObserver.onNext(ackBuilder.build());
            responseObserver.onCompleted();
            return;
        }

        boolean applied = taskExecutionCoordinator.handleLifecycleUpdate(update);
        if (applied) {
            log.info("Lifecycle update applied: taskId={}, attemptId={}, state={}", taskId, attemptId, state);
            ackBuilder.setAccepted(true).setMessage("Lifecycle update accepted");
        } else {
            log.warn("Lifecycle update not applied: taskId={}, attemptId={}, state={} (task not found or attempt mismatch)",
                    taskId, attemptId, state);
            ackBuilder.setAccepted(false).setMessage("Lifecycle update not applied (task not found or attempt mismatch)");
        }
        responseObserver.onNext(ackBuilder.build());
        responseObserver.onCompleted();
    }
}
