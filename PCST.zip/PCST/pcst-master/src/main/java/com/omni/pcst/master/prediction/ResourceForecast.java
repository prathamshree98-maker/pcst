package com.omni.pcst.master.prediction;

import java.util.Objects;
import java.util.Optional;

/**
 * Immutable result of one resource forecast.
 *
 * <p>Every outcome carries an explicit {@link Status}. A status other than
 * {@link Status#OK} never carries a numeric point estimate: there is no
 * fabricated zero, no default value and no confidence or calibration claim.
 * When {@link Status#OK} is returned, the estimate is the persistence value
 * described in {@link PersistenceResourcePredictor}.
 *
 * <p>Uncertainty is reported explicitly and separately from posterior belief
 * variance. {@link #uncertainty()} is only populated when a finite value can
 * be stated under the documented persistence model; it is derived from the
 * spread of the in-window measurement history, never by re-labelling a
 * {@code ResourceBelief.posteriorVariance} as predictive uncertainty.
 *
 * @param status outcome classification
 * @param resourceIdentifier the resource that was requested
 * @param pointEstimate persistence point estimate; present only when
 *        {@code status == OK}
 * @param uncertainty forecast uncertainty; present only when it could be stated
 * @param observationTimestamp timestamp of the observation the estimate came from
 * @param observationCount number of in-window measurements that contributed
 * @param newestObservationTimestamp newest in-window observation timestamp seen
 * @param ageMillis how old the estimate's observation was at request time
 */
public record ResourceForecast(
        Status status,
        String resourceIdentifier,
        Double pointEstimate,
        Double uncertainty,
        long observationTimestamp,
        int observationCount,
        long newestObservationTimestamp,
        long ageMillis) {

    /**
     * Coherent outcome classification for a forecast.
     *
     * <p>Statuses are exhaustive and mutually exclusive so callers never have to
     * infer a cause from a silent default.
     */
    public enum Status {
        /** A point estimate was produced from actual observation data. */
        OK,
    /** Request was structurally or semantically invalid (bad window, bad minimum). */
    INVALID_REQUEST,
        /** The requested resource identifier is not a supported resource. */
        UNSUPPORTED_RESOURCE,
        /** The snapshot has no observation history at all. */
        MISSING_OBSERVATIONS,
        /** The resource had no valid in-window measurement to forecast from. */
        MISSING_MEASUREMENT,
        /** In-window valid measurements existed but fewer than the required minimum. */
        INSUFFICIENT_HISTORY,
        /** Every in-window measurement was non-finite, so none was usable. */
        NON_FINITE_MEASUREMENT,
        /** All candidate observations were too old relative to the request time. */
        STALE_OBSERVATIONS
    }

    public ResourceForecast {
        Objects.requireNonNull(status, "status must not be null");
        Objects.requireNonNull(resourceIdentifier, "resourceIdentifier must not be null");
        pointEstimate = Optional.ofNullable(pointEstimate).orElse(null);
        uncertainty = Optional.ofNullable(uncertainty).orElse(null);
    }

    /**
     * Builds a non-OK result. Non-OK results never carry a point estimate or
     * an uncertainty value, so they are constructed through this factory and
     * cannot accidentally expose a fabricated number.
     */
    static ResourceForecast withoutEstimate(Status status, String resourceIdentifier) {
        return new ResourceForecast(status, resourceIdentifier, null, null,
                0L, 0, 0L, 0L);
    }

    /** @return {@code true} when this result carries a numeric point estimate */
    public boolean hasPointEstimate() {
        return pointEstimate != null;
    }

    /** @return {@code true} when this result carries a stated uncertainty value */
    public boolean hasUncertainty() {
        return uncertainty != null;
    }
}
