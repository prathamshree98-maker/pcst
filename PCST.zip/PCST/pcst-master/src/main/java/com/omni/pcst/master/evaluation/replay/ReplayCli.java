package com.omni.pcst.master.evaluation.replay;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Thin command-line entry point for the offline replay evaluation.
 *
 * <p>Usage:
 * <pre>
 *   java com.omni.pcst.master.evaluation.replay.ReplayCli \
 *        --input &lt;path-to.jsonl&gt; \
 *        [--output &lt;dir&gt;] \
 *        [--horizons 30000,60000,300000] \
 *        [--tolerance &lt;ms&gt;] [--window &lt;ms&gt;] [--min-observations &lt;n&gt;]
 * </pre>
 *
 * <p>The CLI holds no evaluation logic of its own; it parses arguments and
 * delegates to {@link ReplayHarness} and {@link ReplayReportWriter}. The input
 * file is only ever read.
 */
public final class ReplayCli {

    private ReplayCli() {
        throw new AssertionError("entry point only");
    }

    public static void main(String[] args) {
        System.exit(run(args));
    }

    /** @return process exit code: 0 success, 1 usage/input error */
    public static int run(String[] args) {
        if (args == null || args.length == 0 || hasFlag(args, "--help") || hasFlag(args, "-h")) {
            System.out.println(usage());
            return args == null || args.length == 0 ? 1 : 0;
        }
        try {
            String input = valueOf(args, "--input");
            if (input == null) {
                System.err.println("error: --input is required\n");
                System.err.println(usage());
                return 1;
            }
            Path inputPath = Paths.get(input).toAbsolutePath().normalize();
            if (!Files.isRegularFile(inputPath)) {
                System.err.println("error: input file not found: " + inputPath);
                return 1;
            }

            long[] horizons = parseHorizons(valueOf(args, "--horizons"));
            long tolerance = parseLong(valueOf(args, "--tolerance"),
                    ReplayConfig.DEFAULT_TARGET_TOLERANCE_MILLIS);
            long window = parseLong(valueOf(args, "--window"),
                    ReplayConfig.DEFAULT_OBSERVATION_WINDOW_MILLIS);
            int minObs = (int) parseLong(valueOf(args, "--min-observations"),
                    ReplayConfig.DEFAULT_MINIMUM_OBSERVATIONS);

            Path outputDir = Paths.get(
                    valueOf(args, "--output") != null ? valueOf(args, "--output") : "replay-output")
                    .toAbsolutePath().normalize();
            if (outputDir.equals(inputPath)) {
                System.err.println("error: output must differ from the evaluated input file");
                return 1;
            }

            ReplayConfig config = new ReplayConfig(horizons, tolerance, window, minObs);
            ReplayHarness harness = new ReplayHarness(config);
            ReplayHarness.EvaluationReport report = harness.evaluate(inputPath);

            Path jsonPath = ReplayReportWriter.write(report, outputDir);
            System.out.println(ReplayReportWriter.toMarkdown(report));
            System.out.println("JSON report:   " + jsonPath);
            System.out.println("Markdown report: " + outputDir.resolve("replay-evaluation.md"));
            return 0;
        } catch (IllegalArgumentException e) {
            System.err.println("error: " + e.getMessage() + "\n");
            System.err.println(usage());
            return 1;
        } catch (IOException e) {
            System.err.println("error: could not read input: " + e.getMessage());
            return 1;
        }
    }

    private static long[] parseHorizons(String raw) {
        if (raw == null || raw.isBlank()) {
            return ReplayConfig.DEFAULT_HORIZONS_MILLIS.clone();
        }
        String[] parts = raw.split(",");
        long[] horizons = new long[parts.length];
        for (int i = 0; i < parts.length; i++) {
            horizons[i] = Long.parseLong(parts[i].trim());
        }
        return horizons;
    }

    private static long parseLong(String raw, long fallback) {
        return (raw == null || raw.isBlank()) ? fallback : Long.parseLong(raw.trim());
    }

    private static boolean hasFlag(String[] args, String flag) {
        for (String arg : args) {
            if (arg.equals(flag)) {
                return true;
            }
        }
        return false;
    }

    /** Accepts both {@code --name value} and {@code --name=value}. */
    private static String valueOf(String[] args, String name) {
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (arg.startsWith(name + "=")) {
                return arg.substring(name.length() + 1);
            }
            if (arg.equals(name) && i + 1 < args.length) {
                return args[i + 1];
            }
        }
        return null;
    }

    static String usage() {
        return """
                PCST offline replay evaluation harness

                Usage:
                  --input <path>            JSON Lines telemetry evaluation file (required, read-only)
                  --output <dir>            output directory (default: replay-output)
                  --horizons <ms,ms,..>     forecast horizons (default: 30000,60000,300000)
                  --tolerance <ms>          target matching tolerance (default: 10000)
                  --window <ms>             predictor observation window (default: 600000)
                  --min-observations <n>    minimum in-window observations (default: 2)
                  --help                    show this message

                Writes replay-evaluation.json and replay-evaluation.md to the output directory.
                The input file is only ever read and is never modified.
                """;
    }
}