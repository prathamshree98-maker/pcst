package com.omni.pcst.master.execution;

import java.util.Objects;

/**
 * Request DTO for task submission via REST API.
 */
public record TaskSubmissionRequest(
        String taskId,
        String taskClass,
        String workloadReference,
        String inputCharacteristics,
        Long expectedDurationMillis,
        ResourcesRequest resources,
        ConstraintsRequest constraints) {

    public TaskSubmissionRequest {
        Objects.requireNonNull(taskId, "taskId");
        Objects.requireNonNull(taskClass, "taskClass");
        Objects.requireNonNull(workloadReference, "workloadReference");
        inputCharacteristics = inputCharacteristics == null ? "" : inputCharacteristics;
    }
}