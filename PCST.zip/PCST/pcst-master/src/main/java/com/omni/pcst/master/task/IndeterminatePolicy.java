package com.omni.pcst.master.task;

/**
 * What the filter does when a hard constraint cannot be decided because evidence
 * is missing, stale, or not exposed by the current node model.
 *
 * <p>The specification requires that such a constraint be reported rather than
 * guessed, but does not itself decide whether an unproven node may still be
 * scheduled. That decision is therefore made explicit here rather than buried in
 * a branch, and is configurable per deployment.
 */
public enum IndeterminatePolicy {

    /**
     * A node with any unproven constraint is excluded from the feasible set.
     *
     * <p>This is the default because it is the conservative choice: the Master
     * never places work on a node whose ability to do so it cannot establish.
     * The cost is reduced availability, and with it a possible bias against nodes
     * whose telemetry is sparse.
     */
    REJECT,

    /**
     * A node is admitted only if every <em>proven</em> constraint passes;
     * unproven constraints do not exclude it.
     *
     * <p>This maximises availability but places work on nodes whose capability
     * was never established, which is unsafe for hard constraints such as memory
     * residency. Use only when the task is understood to be resilient to an
     * unverifiable constraint.
     */
    ADMIT_UNPROVEN
}