package com.omni.pcst.master.prediction;

import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Persistence resource forecast (Step 5C): the first functional prediction
 * baseline of the PCST Master.
 *
 * <h2>Model</h2>
 * The forecast at horizon {@code H} for resource {@code r} holds the resource's
 * latest valid in-window observation constant into the future:
 *
 * <pre>
 *   forecast(r, H) = y_r(t*)   where t* = newest timestamp t in window with y_r(t) valid
 * </pre>
 *
 * <p>The estimate does not depend on {@code H}. That is the defining property
 * of a persistence baseline. The authoritative specification (Mathematical
 * Specification V1.1 §7) requires a <i>task-conditioned predictive law</i>
 * {@code P&#8339;,&#964; = p(X&#8339;,t:t+H&#964; | I&#8338;, A&#8338; assigns &#964; to n)}. No task,
 * reservation, transition or duration model exists in the repository yet, so
 * this baseline is deliberately limited to:
 *
 * <ul>
 *   <li><b>No trend.</b> No drift, oscillation or seasonal term is fitted. A
 *       linear extrapolation baseline belongs to a later stage.</li>
 *   <li><b>Endpoint only.</b> A single value at the horizon, not a trajectory
 *       over {@code [t, t+H]}. §7.1 permits a documented endpoint approximation
 *       only when paths cannot yet be modelled, which is the case here.</li>
 *   <li><b>No task conditioning.</b> There is no planned load, reservation,
 *       dispatch delay or expected task duration to condition on (the G4 /
 *       §14.2 {@code PredictionEngine.predict(belief, task, reservations,
 *       horizon)} contract).</li>
 *   <li><b>No capability, reliability, confidence or calibration claim.</b>
 *       Nothing has been measured against real future outcomes, so no
 *       probability of success, score or confidence value is produced.</li>
 * </ul>
 *
 * <h2>Uncertainty policy</h2>
 * Forecast uncertainty is reported separately from posterior belief variance
 * and is never obtained by relabelling a {@code ResourceBelief} variance. A
 * posterior variance describes uncertainty about a <i>current latent value</i>;
 * a forecast at horizon {@code H} additionally requires the <i>evolution</i> of
 * that value, which no transition model here provides. The only honest
 * uncertainty statement available is the observed spread of the in-window
 * measurements, so that is what is reported — and only when at least two valid
 * measurements exist, so a single observation yields {@code null} rather than
 * a fabricated zero spread.
 *
 * <h2>Semantics preserved from the Digital Twin</h2>
 * <ul>
 *   <li>History is read exactly as
 *       {@link DigitalTwinSnapshot#observationHistory()} documents it:
 *       <b>newest first</b>. The newest valid in-window observation wins.</li>
 *   <li>Missing measurements ({@code null}) mean "absent", never zero. A null
 *       resource value carries no information: it is skipped, never replaced by
 *       a fabricated zero, and never makes the estimate zero.</li>
 *   <li>Non-finite values (NaN, &plusmn;Infinity) are not usable measurements
 *       and are treated like missing values rather than smoothed over.</li>
 *   <li>Memory utilization is derived from
 *       {@code usedMemoryBytes / totalMemoryBytes * 100} only when both are
 *       present and total is strictly positive. {@link TelemetryObservation}
 *       has no {@code memoryUtilizationPercent} component, so this derivation
 *       is the only path to a memory utilization figure.</li>
 *   <li>Staleness is measured against {@code requestedAtMillis}, never
 *       against wall-clock time, so the predictor is fully deterministic and
 *       independently unit-testable.</li>
 *   <li>The predictor never mutates the snapshot and never other state; it
 *       reads only the immutable list the snapshot exposes.</li>
 * </ul>
 *
 * <h2>Thread safety</h2>
 * Stateless: all state is method-local. Safe for concurrent use.
 */
public final class PersistenceResourcePredictor {

    /**
     * Creates a predictor. Intentionally takes no dependencies: the request
     * carries the immutable snapshot explicitly, so there is no injected
     * service, no registry and no global mutable state to reach into.
     */
    public PersistenceResourcePredictor() {
    }

    /**
     * Forecasts one resource from an immutable twin snapshot.
     *
     * @param request forecast request; must not be null
     * @return an immutable result whose status classifies the outcome; never
     *         null, and never an estimate that was not backed by real data
     */
    public ResourceForecast forecast(ForecastRequest request) {
        Objects.requireNonNull(request, "request must not be null");

        // --- Semantic validation ---------------------------------------------
        // Structural invariants (non-null snapshot, non-negative window and
        // horizon) are enforced by the record itself. Policy-level validation
        // is done here so it is reported as a result, not as an exception.
        if (request.minimumObservations() < 1) {
            return withoutEstimate(ResourceForecast.Status.INVALID_REQUEST,
                    request.resourceIdentifier());
        }

        Optional<ForecastableResource> resource =
                ForecastableResource.fromIdentifier(request.resourceIdentifier());
        if (resource.isEmpty()) {
            return withoutEstimate(ResourceForecast.Status.UNSUPPORTED_RESOURCE,
                    request.resourceIdentifier());
        }
        ForecastableResource target = resource.get();
        DigitalTwinSnapshot snapshot = request.snapshot();

        // --- 1. Resolve the candidate history ---------------------------------
        // A registered node that has never sent telemetry has an empty history
        // and no latest observation: that is MISSING_OBSERVATIONS, never a
        // fabricated zero. A null history list is treated as absent state.
        List<TelemetryObservation> history = new ArrayList<>();
        List<TelemetryObservation> stored = snapshot.observationHistory();
        if (stored != null && !stored.isEmpty()) {
            history.addAll(stored);
        } else if (snapshot.latestObservation() != null) {
            history.add(snapshot.latestObservation());
        }
        if (history.isEmpty()) {
            return withoutEstimate(ResourceForecast.Status.MISSING_OBSERVATIONS,
                    target.identifier());
        }

        long requestedAt = request.requestedAtMillis();
        long window = request.observationWindowMillis();

        // --- 2. Filter by the requested window and timestamp -----------------
        // An observation is a candidate only if its timestamp is at or before
        // the requested time (a future-dated observation cannot be evidence
        // about the requested instant) and, when a window is given, not older
        // than the window start. Memory utilization is derived per observation,
        // so an observation with unusable byte counts contributes no candidate.
        long windowStart = window <= 0L ? Long.MIN_VALUE : requestedAt - window;
        List<Measurement> candidates = new ArrayList<>();
        int discardedAsNotUsableYet = 0;
        int discardedAsTooOld = 0;
        for (TelemetryObservation observation : history) {
            if (observation == null) {
                continue;
            }
            long timestamp = observation.timestamp();
            if (timestamp > requestedAt) {
                discardedAsNotUsableYet++;
                continue;
            }
            if (timestamp < windowStart) {
                discardedAsTooOld++;
                continue;
            }
            candidates.add(new Measurement(timestamp, target.measureFrom(observation)));
        }

        if (candidates.isEmpty()) {
            // History exists but nothing in it is usable as evidence for the
            // requested instant: it is either in the future relative to the
            // request or outside the requested observation window. Both are
            // stale input, so both are reported as one coherent status.
            if (discardedAsNotUsableYet > 0 || discardedAsTooOld > 0) {
                return withoutEstimate(ResourceForecast.Status.STALE_OBSERVATIONS,
                        target.identifier());
            }
            return withoutEstimate(ResourceForecast.Status.MISSING_MEASUREMENT,
                    target.identifier());
        }

        // --- 3. Classify the in-window measurements --------------------------
        int validCount = 0;
        int nullCount = 0;
        int nonFiniteCount = 0;
        Measurement newestValid = null;
        for (Measurement measurement : candidates) {
            Double value = measurement.value();
            if (value == null) {
                nullCount++;
                continue;
            }
            if (!Double.isFinite(value)) {
                nonFiniteCount++;
                continue;
            }
            validCount++;
            // History is newest-first, so the first valid entry encountered is
            // the newest valid observation. The timestamp comparison makes the
            // selection independent of the list's ordering.
            if (newestValid == null || measurement.timestamp() > newestValid.timestamp()) {
                newestValid = measurement;
            }
        }

        if (validCount == 0) {
            ResourceForecast.Status status = nonFiniteCount > 0
                    ? ResourceForecast.Status.NON_FINITE_MEASUREMENT
                    : ResourceForecast.Status.MISSING_MEASUREMENT;
            return withoutEstimate(status, target.identifier());
        }

        if (validCount < request.minimumObservations()) {
            return withoutEstimate(ResourceForecast.Status.INSUFFICIENT_HISTORY,
                    target.identifier());
        }

        // --- 4. Build the result ---------------------------------------------
        // Uncertainty is stated only when at least two valid in-window
        // measurements exist. It is the observed half-range of those
        // measurements and is described by uncertaintyInterpretation().
        Double uncertainty = null;
        if (validCount >= 2) {
            uncertainty = observedHalfRange(candidates);
        }

        long newestObservationTimestamp = candidates.get(0).timestamp();
        return new ResourceForecast(
                ResourceForecast.Status.OK,
                target.identifier(),
                newestValid.value(),
                uncertainty,
                newestValid.timestamp(),
                validCount,
                newestObservationTimestamp,
                requestedAt - newestValid.timestamp());
    }

    /**
     * Describes what a reported uncertainty value means, so a caller cannot
     * mistake it for posterior belief variance or for a calibration claim.
     */
    public String uncertaintyInterpretation() {
        return "empirical half-range (max-min)/2 of the valid in-window "
                + "measurements; a data-spread diagnostic, NOT predictive "
                + "uncertainty and NOT a posterior belief variance";
    }

    /**
     * Half-range of the valid in-window measurements. Uses only actual
     * measurements; returns {@code null} when none are usable.
     */
    private static Double observedHalfRange(List<Measurement> candidates) {
        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        for (Measurement candidate : candidates) {
            Double value = candidate.value();
            if (value == null || !Double.isFinite(value)) {
                continue;
            }
            min = Math.min(min, value);
            max = Math.max(max, value);
        }
        if (min > max) {
            return null;
        }
        return (max - min) / 2.0;
    }

    private static ResourceForecast withoutEstimate(ResourceForecast.Status status,
                                                    String resourceIdentifier) {
        return ResourceForecast.withoutEstimate(status, resourceIdentifier);
    }

    /** One candidate measurement: its timestamp and its (possibly absent) value. */
    private record Measurement(long timestamp, Double value) {
    }
}
