package com.omni.pcst.master.task;

import com.omni.pcst.master.digitaltwin.DigitalTwinSnapshot;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Deterministic hard-constraint filter: decides which registered nodes pass the
 * specification's feasible-set predicate
 * {@code F*(τ) = { n ∈ N : n passes every hard eligibility predicate for τ at time t }}.
 *
 * <h2>What this class deliberately does not do</h2>
 * <ul>
 *   <li>It does not estimate capability probabilities. Specification section 9
 *       places capability ({@code C(n,τ) = P(E_res | I_t, τ→n)}) after this
 *       filter, and a hard-constraint check can never stand in for it.</li>
 *   <li>It does not estimate completion reliability, rank, or dispatch.</li>
 *   <li>It does not mutate any Digital Twin state. It reads immutable
 *       {@link DigitalTwinSnapshot} values only.</li>
 * </ul>
 *
 * <h2>Evaluation rules</h2>
 * <ul>
 *   <li>A requirement that is absent (null) imposes <b>no</b> constraint and is
 *       not evaluated at all. An explicit zero is a real requirement and is
 *       evaluated normally.</li>
 *   <li>Comparisons use {@code >=} for "at least this much available", so an
 *       exact boundary is a satisfaction.</li>
 *   <li>Utilization is never read as capacity. Specification section 3.2 warns
 *       that a node at 30% utilization is not necessarily more capable than one
 *       at 70%; only genuinely available quantities (free memory, free disk,
 *       accelerator presence) are compared.</li>
 *   <li>Missing telemetry is never read as zero. It yields
 *       {@link ConstraintOutcome#INDETERMINATE}.</li>
 *   <li>Every applicable constraint is evaluated, so a rejected node reports all
 *       of its disqualifications rather than only the first.</li>
 * </ul>
 *
 * <h2>Determinism</h2>
 * Results are ordered by node id. Evaluation depends only on the task, the
 * snapshot and the decision instant, so identical inputs always yield identical
 * results. Duplicate node ids collapse deterministically to the first occurrence
 * in iteration order.
 */
public final class HardConstraintFilter {

    private final HardConstraintConfig config;

    public HardConstraintFilter() {
        this(HardConstraintConfig.defaults());
    }

    public HardConstraintFilter(HardConstraintConfig config) {
        this.config = Objects.requireNonNull(config, "config");
    }

    public HardConstraintConfig config() {
        return config;
    }

    /**
     * Evaluates a task against a collection of node snapshots.
     *
     * @param task               the task to place
     * @param snapshots          candidate node snapshots, in any order
     * @param decisionTimeMillis decision instant t used for staleness arithmetic
     * @return one result per distinct node, ordered by node id
     */
    public List<NodeEligibilityResult> filter(Task task,
                                              Collection<DigitalTwinSnapshot> snapshots,
                                              long decisionTimeMillis) {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(snapshots, "snapshots");

        Map<String, DigitalTwinSnapshot> deduplicated = deduplicateByNodeId(snapshots);
        List<NodeEligibilityResult> results = new ArrayList<>(deduplicated.size());
        for (Map.Entry<String, DigitalTwinSnapshot> entry : deduplicated.entrySet()) {
            results.add(evaluateCandidate(task, entry.getKey(), entry.getValue(), decisionTimeMillis));
        }
        results.sort(Comparator.comparing(NodeEligibilityResult::nodeId));
        return List.copyOf(results);
    }

    /**
     * Evaluates a task against explicit node ids, resolving each through the
     * supplied resolver. An id that resolves to nothing is reported as
     * {@link RejectionReason#NODE_UNKNOWN} rather than being silently dropped.
     *
     * @param resolver maps a node id to its snapshot, or {@code null} when unknown;
     *                in production this is
     *                {@code DigitalTwinManager::getSnapshot}
     */
    public List<NodeEligibilityResult> filterByNodeIds(Task task,
                                                       Collection<String> candidateNodeIds,
                                                       java.util.function.Function<String, DigitalTwinSnapshot> resolver,
                                                       long decisionTimeMillis) {
        Objects.requireNonNull(task, "task");
        Objects.requireNonNull(candidateNodeIds, "candidateNodeIds");
        Objects.requireNonNull(resolver, "resolver");

        Map<String, DigitalTwinSnapshot> resolved = new LinkedHashMap<>();
        for (String nodeId : candidateNodeIds) {
            if (nodeId == null || nodeId.isBlank() || resolved.containsKey(nodeId)) {
                continue;   // first occurrence wins; duplicates collapse deterministically
            }
            resolved.put(nodeId, resolver.apply(nodeId));
        }

        List<NodeEligibilityResult> results = new ArrayList<>(resolved.size());
        for (Map.Entry<String, DigitalTwinSnapshot> entry : resolved.entrySet()) {
            DigitalTwinSnapshot snapshot = entry.getValue();
            if (snapshot == null) {
                results.add(unknownNode(task.taskId(), entry.getKey(), decisionTimeMillis));
            } else {
                results.add(evaluateCandidate(task, entry.getKey(), snapshot, decisionTimeMillis));
            }
        }
        results.sort(Comparator.comparing(NodeEligibilityResult::nodeId));
        return List.copyOf(results);
    }

    /** Evaluates exactly one candidate; never throws for a malformed snapshot. */
    public NodeEligibilityResult evaluateCandidate(Task task, String nodeId,
                                                   DigitalTwinSnapshot snapshot,
                                                   long decisionTimeMillis) {
        try {
            List<ConstraintEvaluation> evaluations =
                    evaluateConstraints(task, nodeId, snapshot, decisionTimeMillis);
            return assemble(task.taskId(), nodeId, evaluations, decisionTimeMillis);
        } catch (RuntimeException e) {
            // One malformed candidate must not invalidate the rest of the batch.
            return new NodeEligibilityResult(task.taskId(), nodeId, false, true,
                    List.of(ConstraintEvaluation.indeterminate(
                            HardConstraint.COMPUTE_CAPACITY,
                            RejectionReason.EVALUATION_ERROR, null, null, null)),
                    List.of(RejectionReason.EVALUATION_ERROR),
                    decisionTimeMillis);
        }
    }

    private List<ConstraintEvaluation> evaluateConstraints(Task task, String nodeId,
                                                           DigitalTwinSnapshot snapshot,
                                                           long decisionTimeMillis) {
        List<ConstraintEvaluation> results = new ArrayList<>();

        // Deadline feasibility is a property of the task's own duration model and
        // the decision instant; it needs no node evidence.
        results.add(evaluateDeadline(task, decisionTimeMillis));

        TelemetryObservation observation = snapshot.latestObservation();
        long lastReceived = snapshot.lastTelemetryReceivedAtMillis();
        EvidenceState evidence = classifyEvidence(observation, lastReceived, decisionTimeMillis);

        TaskResources resources = task.resources();
        TaskConstraints constraints = task.constraints();

        results.add(evaluateMemory(resources, observation, evidence));
        results.add(evaluateStorage(resources, observation, evidence));
        results.add(evaluateAcceleratorPresence(resources, observation, evidence));
        results.add(evaluateAcceleratorMemory(resources, observation, evidence));
        results.add(evaluateComputeCapacity(resources, observation, evidence));
        results.add(evaluateBattery(constraints, observation, evidence));
        results.add(evaluateNetworkLatency(constraints, observation, evidence));
        results.add(evaluatePacketLoss(constraints, observation, evidence));
        results.add(evaluateExecutionProfile(constraints, observation, evidence));

        return results;
    }

    // ---------------------------------------------------------------- constraints

    private ConstraintEvaluation evaluateDeadline(Task task, long decisionTimeMillis) {
        TaskConstraints constraints = task.constraints();
        Long horizon = task.expectedDurationMillis() != null
                ? task.expectedDurationMillis()
                : constraints.expectedDurationMillis();
        Long deadline = constraints.deadlineEpochMillis();

        if (deadline == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.DEADLINE_FEASIBILITY,
                    "no deadline", null, "epoch millis");
        }
        if (horizon == null) {
            return ConstraintEvaluation.indeterminate(HardConstraint.DEADLINE_FEASIBILITY,
                    RejectionReason.DEADLINE_UNVERIFIABLE,
                    "deadline=" + deadline, null, "epoch millis");
        }
        long latestStart = deadline - horizon;
        if (latestStart < decisionTimeMillis) {
            return ConstraintEvaluation.violated(HardConstraint.DEADLINE_FEASIBILITY,
                    RejectionReason.DEADLINE_INFEASIBLE,
                    "latestStart=" + latestStart + " (deadline " + deadline
                            + " minus duration " + horizon + ")",
                    "decisionTime=" + decisionTimeMillis, "epoch millis");
        }
        return ConstraintEvaluation.satisfied(HardConstraint.DEADLINE_FEASIBILITY,
                "latestStart=" + latestStart, "decisionTime=" + decisionTimeMillis, "epoch millis");
    }

    private ConstraintEvaluation evaluateMemory(TaskResources resources,
                                                TelemetryObservation observation,
                                                EvidenceState evidence) {
        Long required = resources.requiredMemoryBytes();
        if (required == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.MEMORY_AVAILABILITY,
                    "not required", null, "bytes");
        }
        if (evidence != EvidenceState.FRESH) {
            return indeterminate(HardConstraint.MEMORY_AVAILABILITY, evidenceReason(evidence),
                    "available>=" + required, "bytes");
        }
        Long available = observation.availableMemoryBytes();
        if (available == null) {
            return indeterminate(HardConstraint.MEMORY_AVAILABILITY, RejectionReason.NO_OBSERVATION,
                    "available>=" + required, "availableMemoryBytes=<absent>", "bytes");
        }
        if (available < required) {
            return ConstraintEvaluation.violated(HardConstraint.MEMORY_AVAILABILITY,
                    RejectionReason.MEMORY_INSUFFICIENT, "available>=" + required,
                    "available=" + available, "bytes");
        }
        return ConstraintEvaluation.satisfied(HardConstraint.MEMORY_AVAILABILITY,
                "available>=" + required, "available=" + available, "bytes");
    }

    private ConstraintEvaluation evaluateStorage(TaskResources resources,
                                                 TelemetryObservation observation,
                                                 EvidenceState evidence) {
        Long required = resources.requiredStorageBytes();
        if (required == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.STORAGE_AVAILABILITY,
                    "not required", null, "bytes");
        }
        if (evidence != EvidenceState.FRESH) {
            return indeterminate(HardConstraint.STORAGE_AVAILABILITY, evidenceReason(evidence),
                    "free>=" + required, "bytes");
        }
        Long free = observation.freeDiskBytes();
        if (free == null) {
            return indeterminate(HardConstraint.STORAGE_AVAILABILITY, RejectionReason.NO_OBSERVATION,
                    "free>=" + required, "freeDiskBytes=<absent>", "bytes");
        }
        if (free < required) {
            return ConstraintEvaluation.violated(HardConstraint.STORAGE_AVAILABILITY,
                    RejectionReason.STORAGE_INSUFFICIENT, "free>=" + required,
                    "free=" + free, "bytes");
        }
        return ConstraintEvaluation.satisfied(HardConstraint.STORAGE_AVAILABILITY,
                "free>=" + required, "free=" + free, "bytes");
    }

    private ConstraintEvaluation evaluateAcceleratorPresence(TaskResources resources,
                                                             TelemetryObservation observation,
                                                             EvidenceState evidence) {
        if (!resources.acceleratorRequired()) {
            return ConstraintEvaluation.satisfied(HardConstraint.ACCELERATOR_PRESENCE,
                    "not required", null, "boolean");
        }
        if (evidence != EvidenceState.FRESH) {
            return indeterminate(HardConstraint.ACCELERATOR_PRESENCE, evidenceReason(evidence),
                    "acceleratorPresent=true", "boolean");
        }
        Boolean present = observation.gpuAvailable();
        if (present == null) {
            return indeterminate(HardConstraint.ACCELERATOR_PRESENCE, RejectionReason.NO_OBSERVATION,
                    "acceleratorPresent=true", "gpuAvailable=<absent>", "boolean");
        }
        if (!present) {
            return ConstraintEvaluation.violated(HardConstraint.ACCELERATOR_PRESENCE,
                    RejectionReason.ACCELERATOR_ABSENT, "acceleratorPresent=true",
                    "acceleratorPresent=" + present, "boolean");
        }
        return ConstraintEvaluation.satisfied(HardConstraint.ACCELERATOR_PRESENCE,
                "acceleratorPresent=true", "acceleratorPresent=" + present, "boolean");
    }

    private ConstraintEvaluation evaluateAcceleratorMemory(TaskResources resources,
                                                          TelemetryObservation observation,
                                                          EvidenceState evidence) {
        Long required = resources.requiredAcceleratorMemoryBytes();
        if (required == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.ACCELERATOR_MEMORY,
                    "not required", null, "bytes");
        }
        // Deliberately indeterminate: the node model exposes accelerator
        // presence and utilization, never device-memory capacity. Deriving it
        // from utilization would be exactly the load/capacity confusion that
        // specification section 3.2 warns against.
        return indeterminate(HardConstraint.ACCELERATOR_MEMORY,
                RejectionReason.ACCELERATOR_MEMORY_UNVERIFIABLE,
                "acceleratorMemory>=" + required, null, "bytes");
    }

    private ConstraintEvaluation evaluateComputeCapacity(TaskResources resources,
                                                         TelemetryObservation observation,
                                                         EvidenceState evidence) {
        Double required = resources.requiredComputeUnits();
        if (required == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.COMPUTE_CAPACITY,
                    "not required", null, "compute units");
        }
        // Deliberately indeterminate: cpuUtilizationPercent is a load
        // observation and is never used as a capacity proxy.
        return indeterminate(HardConstraint.COMPUTE_CAPACITY,
                RejectionReason.COMPUTE_CAPACITY_UNVERIFIABLE,
                "computeUnits>=" + required, null, "compute units");
    }

    private ConstraintEvaluation evaluateBattery(TaskConstraints constraints,
                                                 TelemetryObservation observation,
                                                 EvidenceState evidence) {
        Double required = constraints.minimumBatteryPercent();
        if (required == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.BATTERY_LEVEL,
                    "not required", null, "percent");
        }
        if (evidence != EvidenceState.FRESH) {
            return indeterminate(HardConstraint.BATTERY_LEVEL, evidenceReason(evidence),
                    "battery>=" + required, "percent");
        }
        Double observed = observation.batteryLevelPercent();
        if (observed == null) {
            return indeterminate(HardConstraint.BATTERY_LEVEL, RejectionReason.BATTERY_UNKNOWN,
                    "battery>=" + required, "batteryLevelPercent=<absent>", "percent");
        }
        if (observed < required) {
            return ConstraintEvaluation.violated(HardConstraint.BATTERY_LEVEL,
                    RejectionReason.BATTERY_BELOW_MINIMUM, "battery>=" + required,
                    "battery=" + observed, "percent");
        }
        return ConstraintEvaluation.satisfied(HardConstraint.BATTERY_LEVEL,
                "battery>=" + required, "battery=" + observed, "percent");
    }

    private ConstraintEvaluation evaluateNetworkLatency(TaskConstraints constraints,
                                                       TelemetryObservation observation,
                                                       EvidenceState evidence) {
        Double required = constraints.maximumNetworkLatencyMillis();
        if (required == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.NETWORK_LATENCY,
                    "not required", null, "milliseconds");
        }
        if (evidence != EvidenceState.FRESH) {
            return indeterminate(HardConstraint.NETWORK_LATENCY, evidenceReason(evidence),
                    "latency<=" + required, "milliseconds");
        }
        Double observed = observation.latencyMs();
        if (observed == null) {
            return indeterminate(HardConstraint.NETWORK_LATENCY, RejectionReason.NETWORK_LATENCY_UNKNOWN,
                    "latency<=" + required, "latencyMs=<absent>", "milliseconds");
        }
        if (observed > required) {
            return ConstraintEvaluation.violated(HardConstraint.NETWORK_LATENCY,
                    RejectionReason.NETWORK_LATENCY_EXCEEDED, "latency<=" + required,
                    "latency=" + observed, "milliseconds");
        }
        return ConstraintEvaluation.satisfied(HardConstraint.NETWORK_LATENCY,
                "latency<=" + required, "latency=" + observed, "milliseconds");
    }

    private ConstraintEvaluation evaluatePacketLoss(TaskConstraints constraints,
                                                   TelemetryObservation observation,
                                                   EvidenceState evidence) {
        Double required = constraints.maximumPacketLossPercent();
        if (required == null) {
            return ConstraintEvaluation.satisfied(HardConstraint.PACKET_LOSS,
                    "not required", null, "percent");
        }
        if (evidence != EvidenceState.FRESH) {
            return indeterminate(HardConstraint.PACKET_LOSS, evidenceReason(evidence),
                    "packetLoss<=" + required, "percent");
        }
        Double observed = observation.packetLossPercent();
        if (observed == null) {
            return indeterminate(HardConstraint.PACKET_LOSS, RejectionReason.PACKET_LOSS_UNKNOWN,
                    "packetLoss<=" + required, "packetLossPercent=<absent>", "percent");
        }
        if (observed > required) {
            return ConstraintEvaluation.violated(HardConstraint.PACKET_LOSS,
                    RejectionReason.PACKET_LOSS_EXCEEDED, "packetLoss<=" + required,
                    "packetLoss=" + observed, "percent");
        }
        return ConstraintEvaluation.satisfied(HardConstraint.PACKET_LOSS,
                "packetLoss<=" + required, "packetLoss=" + observed, "percent");
    }

    private ConstraintEvaluation evaluateExecutionProfile(TaskConstraints constraints,
                                                         TelemetryObservation observation,
                                                         EvidenceState evidence) {
        String required = constraints.requiredExecutionProfile();
        if (required == null || required.isBlank()) {
            return ConstraintEvaluation.satisfied(HardConstraint.EXECUTION_PROFILE,
                    "not required", null, "profile");
        }
        // The node model exposes no execution profile, architecture or security
        // label, so compatibility can be neither proven nor disproven.
        return indeterminate(HardConstraint.EXECUTION_PROFILE,
                RejectionReason.EXECUTION_PROFILE_UNVERIFIABLE,
                "profile=" + required, null, "profile");
    }

    // ---------------------------------------------------------------- helpers

    private static RejectionReason evidenceReason(EvidenceState evidence) {
        return evidence == EvidenceState.STALE
                ? RejectionReason.STALE_EVIDENCE
                : RejectionReason.NO_OBSERVATION;
    }

    private static RejectionReason batteryUnknownReason(EvidenceState evidence) {
        return evidence == EvidenceState.STALE
                ? RejectionReason.STALE_EVIDENCE
                : RejectionReason.BATTERY_UNKNOWN;
    }

    private ConstraintEvaluation indeterminate(HardConstraint constraint, RejectionReason reason,
                                              String required, String unit) {
        return ConstraintEvaluation.indeterminate(constraint, reason, required, null, unit);
    }

    private ConstraintEvaluation indeterminate(HardConstraint constraint, RejectionReason reason,
                                              String required, String observed, String unit) {
        return ConstraintEvaluation.indeterminate(constraint, reason, required, observed, unit);
    }

    /** Evidence freshness classification of a candidate's latest observation. */
    private enum EvidenceState {
        /** A recent, usable observation exists. */
        FRESH,
        /** An observation exists but is older than the configured age. */
        STALE,
        /** No observation has ever been received. */
        ABSENT
    }

    private EvidenceState classifyEvidence(TelemetryObservation observation, long lastReceived,
                                           long decisionTimeMillis) {
        if (observation == null || lastReceived <= 0L) {
            return EvidenceState.ABSENT;
        }
        long age = decisionTimeMillis - lastReceived;
        if (age > config.maxEvidenceAgeMillis()) {
            return EvidenceState.STALE;
        }
        if (age < 0L) {
            // Evidence from the future relative to the decision instant cannot be
            // trusted as history; treat it as unusable rather than as fresh.
            return EvidenceState.STALE;
        }
        return EvidenceState.FRESH;
    }

    private NodeEligibilityResult assemble(String taskId, String nodeId,
                                           List<ConstraintEvaluation> evaluations,
                                           long decisionTimeMillis) {
        List<RejectionReason> blocking = new ArrayList<>();
        boolean indeterminate = false;
        for (ConstraintEvaluation evaluation : evaluations) {
            if (evaluation.isBlocking()) {
                blocking.add(evaluation.reason());
                indeterminate = indeterminate || evaluation.reason().isIndeterminate();
            }
        }

        boolean eligible;
        if (blocking.isEmpty()) {
            eligible = true;
        } else if (config.indeterminatePolicy() == IndeterminatePolicy.REJECT) {
            eligible = false;
        } else {
            // ADMIT_UNPROVEN: only proven violations exclude the node.
            eligible = blocking.stream().noneMatch(r -> !r.isIndeterminate());
        }

        return new NodeEligibilityResult(taskId, nodeId, eligible, indeterminate,
                List.copyOf(evaluations), List.copyOf(blocking), decisionTimeMillis);
    }

    private NodeEligibilityResult unknownNode(String taskId, String nodeId, long decisionTimeMillis) {
        return new NodeEligibilityResult(taskId, nodeId, false, false,
                List.of(ConstraintEvaluation.violated(HardConstraint.COMPUTE_CAPACITY,
                        RejectionReason.NODE_UNKNOWN, "node registered", "node unknown", "n/a")),
                List.of(RejectionReason.NODE_UNKNOWN),
                decisionTimeMillis);
    }

    /** Collapses duplicate node ids to the first occurrence, preserving order. */
    private static Map<String, DigitalTwinSnapshot> deduplicateByNodeId(
            Collection<DigitalTwinSnapshot> snapshots) {
        Map<String, DigitalTwinSnapshot> byId = new LinkedHashMap<>();
        for (DigitalTwinSnapshot snapshot : snapshots) {
            if (snapshot == null) {
                continue;
            }
            String nodeId = snapshot.nodeId();
            if (nodeId == null || nodeId.isBlank()) {
                continue;
            }
            byId.putIfAbsent(nodeId, snapshot);
        }
        return byId;
    }
}