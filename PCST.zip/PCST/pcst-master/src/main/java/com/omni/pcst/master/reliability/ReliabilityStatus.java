package com.omni.pcst.master.reliability;

/**
 * Outcome of a completion-reliability assessment for one task / one candidate
 * node.
 *
 * <p>The status states exactly how far the assessment got. A {@code null}
 * reliability with a non-computable status is more honest than a fabricated
 * number, and callers can branch on the enum. A status other than
 * {@link #COMPUTABLE} never carries a numeric probability.
 */
public enum ReliabilityStatus {

    /**
     * The completion reliability {@code R(n, τ) = P(Esucc | I_t, τ → n)} is defined.
     * This happens only when the task's entire success contract reduces to the one
     * event the current model can evaluate.
     */
    COMPUTABLE("the completion reliability probability is defined"),

    /**
     * At least one required success event has a model, but the overall joint
     * reliability is not defined: another required event has no model, or a joint
     * dependency model is unavailable. {@code reliability()} is {@code null}.
     */
    UNRESOLVED_MODEL("some success events are modelled but the overall reliability is not defined"),

    /**
     * No required success event of the task has a model, so no reliability is
     * defined at all. {@code reliability()} is {@code null}.
     */
    UNSUPPORTED_MODEL("no required success event has a model for this task and node"),

    /**
     * Modelled success events exist but the evidence behind them is missing, stale,
     * or dated after the decision instant. {@code reliability()} is {@code null}.
     */
    INSUFFICIENT_EVIDENCE("success events are modelled but the evidence is missing or unusable"),

    /**
     * The inputs were malformed for a reliability assessment: a missing or
     * mismatched capability assessment, or unusable arguments.
     * {@code reliability()} is {@code null}.
     */
    INVALID_INPUT("the inputs were malformed for a reliability assessment"),

    /**
     * The candidate is excluded by a hard constraint, so reliability is not
     * estimated. Whether the exclusion is a proven violation or an unproven
     * (indeterminate) condition is distinguished by the reason codes.
     * {@code reliability()} is {@code null}.
     */
    REJECTED_HARD_CONSTRAINT("the candidate is excluded by a hard constraint");

    private final String description;

    ReliabilityStatus(String description) {
        this.description = description;
    }

    /** @return true only for {@link #COMPUTABLE} */
    public boolean hasProbability() {
        return this == COMPUTABLE;
    }

    /** @return human-readable description; not part of the programmatic contract */
    public String description() {
        return description;
    }
}
