package com.omni.pcst.master.evaluation;

import com.omni.pcst.master.digitaltwin.TelemetryObservation;

import java.util.Objects;

/**
 * Immutable evaluation-observation record for chronological replay
 * (schema {@code pcst-eval-v4}).
 *
 * <p>Reuses {@link TelemetryObservation} directly to avoid duplicating the
 * telemetry model (same measurements, same null-vs-zero semantics, same
 * timestamp basis).
 *
 * <p><b>Sequence evidence.</b> {@code agentSessionId}, {@code telemetrySequence},
 * {@code sequenceClassification}, {@code sequenceGapFrom} and
 * {@code sequenceGapTo} describe the transport-layer sequence position of the
 * message this record came from. All are nullable and are never invented: a
 * record whose source reported no metadata carries {@code null}.
 *
 * <p><b>Acceptance evidence.</b> {@code acceptedByDigitalTwin} states whether the
 * Digital Twin applied this observation, and {@code validForReplay} states
 * whether it may be used as a forecast-scoring sample. An audit-only record
 * (for example a proven duplicate) is persisted with
 * {@code acceptedByDigitalTwin=false} and {@code validForReplay=false}, so it
 * cannot be mistaken for an accepted observation.
 *
 * <p>No belief, forecast, probability, or calibration label is attached.
 *
 * @param nodeId                 stable node identifier
 * @param observationTimestamp   event time of the observation
 * @param observation            raw observation (all 16 components)
 * @param ingestionTimestamp     Master clock time of ingestion
 * @param collectionConfigVersion provenance of the collection configuration
 * @param validForReplay         whether this record may be scored as a valid sample
 * @param agentSessionId         agent process session id, or null when not reported
 * @param telemetrySequence      one-based sequence within the session, or null
 * @param sequenceClassification transport classification name, or null
 * @param sequenceGapFrom        first missing sequence for a forward gap, else null
 * @param sequenceGapTo          last missing sequence for a forward gap, else null
 * @param acceptedByDigitalTwin  whether the Digital Twin applied the observation
 */
public record TelemetryEvaluationRecord(
        String nodeId,
        long observationTimestamp,
        TelemetryObservation observation,
        long ingestionTimestamp,
        String collectionConfigVersion,
        boolean validForReplay,
        String agentSessionId,
        Long telemetrySequence,
        String sequenceClassification,
        Long sequenceGapFrom,
        Long sequenceGapTo,
        boolean acceptedByDigitalTwin) {

    public TelemetryEvaluationRecord {
        Objects.requireNonNull(nodeId, "nodeId");
        Objects.requireNonNull(observation, "observation");
        Objects.requireNonNull(collectionConfigVersion, "collectionConfigVersion");
        if (nodeId.isBlank()) {
            throw new IllegalArgumentException("nodeId must not be blank");
        }
        if (telemetrySequence != null && telemetrySequence <= 0L) {
            throw new IllegalArgumentException(
                    "telemetrySequence must be positive when present (was " + telemetrySequence + ")");
        }
        if (sequenceGapFrom != null && sequenceGapFrom <= 0L) {
            throw new IllegalArgumentException("sequenceGapFrom must be positive when present");
        }
        if (sequenceGapTo != null && sequenceGapTo <= 0L) {
            throw new IllegalArgumentException("sequenceGapTo must be positive when present");
        }
        // An observation that was not applied can never be a valid scoring sample.
        if (!acceptedByDigitalTwin) {
            validForReplay = false;
        }
    }

    /** @return true when this record may be used as a forecast-scoring sample */
    public boolean isScorableSample() {
        return validForReplay && acceptedByDigitalTwin;
    }

    public TelemetryEvaluationRecord(String nodeId,
                                     long observationTimestamp,
                                     TelemetryObservation observation,
                                     long ingestionTimestamp,
                                     String collectionConfigVersion,
                                     boolean validForReplay,
                                     String agentSessionId,
                                     Long telemetrySequence) {
        this(nodeId, observationTimestamp, observation, ingestionTimestamp,
                collectionConfigVersion, validForReplay, agentSessionId, telemetrySequence,
                null, null, null, true);
    }

    public TelemetryEvaluationRecord(String nodeId,
                                     long observationTimestamp,
                                     TelemetryObservation observation,
                                     long ingestionTimestamp,
                                     String collectionConfigVersion,
                                     boolean validForReplay) {
        this(nodeId, observationTimestamp, observation, ingestionTimestamp,
                collectionConfigVersion, validForReplay, null, null,
                null, null, null, true);
    }

    /** Convenience factory for accepted observations with no sequence metadata. */
    public static TelemetryEvaluationRecord of(String nodeId,
                                                TelemetryObservation observation,
                                                long ingestionTimestamp,
                                                String configVersion) {
        return of(nodeId, observation, ingestionTimestamp, configVersion,
                null, null, null, null, null);
    }

    /**
     * Convenience factory for accepted observations carrying full sequence
     * evidence.
     *
     * @param agentSessionId    agent session id; null when not reported
     * @param telemetrySequence one-based sequence; null when not reported
     * @param classification    transport classification name; null when not reported
     * @param gapFrom           first missing sequence; null unless a forward gap
     * @param gapTo             last missing sequence; null unless a forward gap
     */
    public static TelemetryEvaluationRecord of(String nodeId,
                                                TelemetryObservation observation,
                                                long ingestionTimestamp,
                                                String configVersion,
                                                String agentSessionId,
                                                Long telemetrySequence,
                                                String classification,
                                                Long gapFrom,
                                                Long gapTo) {
        boolean observationUsable = observation != null
                && observation.timestamp() >= 0
                && (observation.cpuUtilizationPercent() == null || Double.isFinite(observation.cpuUtilizationPercent()))
                && (observation.totalMemoryBytes() == null || observation.totalMemoryBytes() >= 0);
        return new TelemetryEvaluationRecord(
                nodeId,
                observation != null ? observation.timestamp() : -1L,
                observation,
                ingestionTimestamp,
                configVersion,
                observationUsable,
                blankToNull(agentSessionId),
                (telemetrySequence != null && telemetrySequence <= 0L) ? null : telemetrySequence,
                blankToNull(classification),
                (gapFrom != null && gapFrom <= 0L) ? null : gapFrom,
                (gapTo != null && gapTo <= 0L) ? null : gapTo,
                true);
    }

    /**
     * Builds an audit-only record for telemetry that was deliberately NOT
     * applied to the Digital Twin (a proven duplicate, or telemetry from a
     * superseded session).
     *
     * <p>The record always carries {@code acceptedByDigitalTwin=false} and
     * {@code validForReplay=false}, so it can never enter the accepted-observation
     * replay path.
     */
    public static TelemetryEvaluationRecord auditOnly(String nodeId,
                                                      TelemetryObservation observation,
                                                      long ingestionTimestamp,
                                                      String configVersion,
                                                      String agentSessionId,
                                                      Long telemetrySequence,
                                                      String classification) {
        return new TelemetryEvaluationRecord(
                nodeId,
                observation != null ? observation.timestamp() : -1L,
                observation,
                ingestionTimestamp,
                configVersion,
                false,
                blankToNull(agentSessionId),
                (telemetrySequence != null && telemetrySequence <= 0L) ? null : telemetrySequence,
                blankToNull(classification),
                null,
                null,
                false);
    }

    private static String blankToNull(String value) {
        return (value == null || value.isBlank()) ? null : value;
    }
}