package com.omni.pcst.master.execution;

/**
 * Execution constraints for a task submission.
 */
public record ConstraintsRequest(
        Long deadlineEpochMillis,
        Long expectedDurationMillis,
        Double minimumBatteryPercent,
        Double maximumNetworkLatencyMillis,
        Double maximumPacketLossPercent,
        String interruptionTolerance,
        String requiredExecutionProfile) {}