package com.omni.pcst.master.evaluation.replay;

/**
 * Accumulates forecast error statistics for one (predictor, resource, horizon)
 * combination.
 *
 * <p><b>Metrics and why they are chosen.</b> Only scale-appropriate metrics are
 * used. Mean absolute error, root mean squared error and mean signed error are
 * reported in each resource's native unit. MAPE is deliberately
 * <em>not</em> implemented: several supported resources legitimately take the
 * value zero (idle CPU, zero packet loss), and a percentage error against a zero
 * actual is undefined and explodes. No combined cross-resource score is
 * produced, because utilisation percentage points and milliseconds do not share
 * a unit.
 *
 * <p><b>No-samples handling.</b> With zero scored pairs the metrics are reported
 * as {@code null} rather than {@code 0.0} or NaN, and {@link #hasSamples()} is
 * false, so "no evidence" is never rendered as "perfect prediction".
 *
 * <p><b>Numerical stability.</b> Errors are accumulated in double precision with
 * Kahan compensated summation for the squared and signed sums, which matters
 * when many large-magnitude errors are combined.
 *
 * <p>This class is not thread-safe; each (predictor, resource, horizon) cell owns
 * its own accumulator.
 */
final class ErrorAccumulator {

    private final String unit;

    private long samples;
    private double sumAbsolute;
    private double sumSquared;
    private double sumSigned;
    private final double[] squareCompensation = new double[1];
    private final double[] signedCompensation = new double[1];
    private double maxAbsolute;

    ErrorAccumulator(String unit) {
        this.unit = unit;
    }

    /**
     * Adds one scored pair.
     *
     * @param forecast predicted value
     * @param actual   observed value
     * @throws IllegalArgumentException if either value is not finite; such a pair
     *                                  must never enter the statistics
     */
    void add(double forecast, double actual) {
        if (!Double.isFinite(forecast) || !Double.isFinite(actual)) {
            throw new IllegalArgumentException(
                    "non-finite value cannot be scored: forecast=" + forecast + " actual=" + actual);
        }
        double error = forecast - actual;

        samples++;
        sumAbsolute += Math.abs(error);
        maxAbsolute = Math.max(maxAbsolute, Math.abs(error));

        // Kahan compensated summation for the squared and signed sums.
        sumSquared = kahanAdd(sumSquared, error * error, squareCompensation);
        sumSigned = kahanAdd(sumSigned, error, signedCompensation);
    }

    private static double kahanAdd(double sum, double value, double[] compensation) {
        double adjusted = value - compensation[0];
        double next = sum + adjusted;
        compensation[0] = (next - sum) - adjusted;
        return next;
    }

    long sampleCount() {
        return samples;
    }

    boolean hasSamples() {
        return samples > 0L;
    }

    String unit() {
        return unit;
    }

    /** @return mean absolute error, or null when there are no samples */
    Double meanAbsoluteError() {
        return samples == 0L ? null : sumAbsolute / samples;
    }

    /** @return root mean squared error, or null when there are no samples */
    Double rootMeanSquaredError() {
        if (samples == 0L) {
            return null;
        }
        double value = sumSquared / samples;
        return value <= 0.0 ? 0.0 : Math.sqrt(value);
    }

    /** @return mean signed error (bias); positive means over-prediction */
    Double meanSignedError() {
        return samples == 0L ? null : sumSigned / samples;
    }

    /** @return largest absolute error, or null when there are no samples */
    Double maxAbsoluteError() {
        return samples == 0L ? null : maxAbsolute;
    }
}