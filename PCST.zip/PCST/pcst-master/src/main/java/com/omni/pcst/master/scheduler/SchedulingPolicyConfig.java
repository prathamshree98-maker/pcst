package com.omni.pcst.master.scheduler;

import com.omni.pcst.master.task.TaskClass;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Configuration of the Step 6D scheduling policy.
 *
 * <p>Specification section 10.1 defines the decision rule
 * {@code n* = arg max R(n, τ)} subject to {@code R(n*, τ) ≥ θτ}, where {@code θτ}
 * is "a policy threshold, possibly task-class-specific". Specification section 19
 * records that when no threshold is configured the rule degrades to "use highest
 * estimated reliability among eligible nodes, with limitations exposed". This type
 * carries exactly those operational parameters; it holds no model and introduces
 * no probability.
 *
 * @param defaultReliabilityThreshold the policy threshold in [0, 1] applied when no
 *                                   task-class-specific threshold matches, or
 *                                   {@code null} when no threshold is configured
 * @param taskClassThresholds        task-class-specific thresholds in [0, 1],
 *                                   overriding the default; empty when none
 * @param fallbackPolicy             the explicit rule for the all-unresolved case
 */
public record SchedulingPolicyConfig(
        Double defaultReliabilityThreshold,
        Map<TaskClass, Double> taskClassThresholds,
        FallbackPolicy fallbackPolicy) {

    public SchedulingPolicyConfig {
        validateThreshold("defaultReliabilityThreshold", defaultReliabilityThreshold);
        taskClassThresholds = taskClassThresholds == null
                ? Map.of()
                : Map.copyOf(taskClassThresholds);
        for (Map.Entry<TaskClass, Double> entry : taskClassThresholds.entrySet()) {
            if (entry.getKey() == null) {
                throw new IllegalArgumentException("taskClassThresholds must not contain a null key");
            }
            validateThreshold("taskClassThresholds[" + entry.getKey() + "]", entry.getValue());
        }
        Objects.requireNonNull(fallbackPolicy, "fallbackPolicy");
    }

    private static void validateThreshold(String field, Double threshold) {
        if (threshold != null && (threshold < 0.0 || threshold > 1.0)) {
            throw new IllegalArgumentException(
                    field + " must be within [0, 1] when present (was " + threshold + ")");
        }
    }

    /**
     * The policy threshold that applies to a task class.
     *
     * <p>A task-class-specific threshold wins over the default. A {@code null}
     * result means no threshold is configured for this task, so the decision uses
     * the highest estimated reliability among eligible nodes (specification
     * section 19).
     *
     * @param taskClass the task's class; a {@code null} value uses the default
     * @return the applicable threshold, or {@code null} when none is configured
     */
    public Double thresholdFor(TaskClass taskClass) {
        if (taskClass != null && taskClassThresholds.containsKey(taskClass)) {
            return taskClassThresholds.get(taskClass);
        }
        return defaultReliabilityThreshold;
    }

    /**
     * @return the default policy: no threshold, no task-class overrides, and no
     * fallback (a no-selection outcome when no reliability estimate exists)
     */
    public static SchedulingPolicyConfig none() {
        return new SchedulingPolicyConfig(null, Map.of(), FallbackPolicy.NONE);
    }

    /** @return a policy with a default threshold and no fallback */
    public static SchedulingPolicyConfig of(double defaultReliabilityThreshold) {
        return new SchedulingPolicyConfig(defaultReliabilityThreshold, Map.of(), FallbackPolicy.NONE);
    }

    /** @return a copy with the given task-class-specific thresholds added/overridden */
    public SchedulingPolicyConfig withTaskClassThresholds(Map<TaskClass, Double> thresholds) {
        Map<TaskClass, Double> merged = new LinkedHashMap<>(taskClassThresholds);
        if (thresholds != null) {
            merged.putAll(thresholds);
        }
        return new SchedulingPolicyConfig(defaultReliabilityThreshold, merged, fallbackPolicy);
    }

    /** @return a copy with the given fallback policy */
    public SchedulingPolicyConfig withFallbackPolicy(FallbackPolicy policy) {
        return new SchedulingPolicyConfig(defaultReliabilityThreshold, taskClassThresholds, policy);
    }
}
