package com.omni.pcst.master.digitaltwin;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Probabilistic belief state for a Digital Twin.
 *
 * <p>Populated by the Bayesian update engine ({@code com.omni.pcst.master.belief})
 * from accepted {@link TelemetryObservation} history. Each tracked resource holds
 * a {@link ResourceBelief} (posterior mean + variance); resources with no
 * non-missing measurements yet simply have no entry.
 *
 * <p>Until the first accepted observation is processed, the only valid instance
 * is {@link #UNINITIALIZED}. No probability distributions, priors, or fabricated
 * values exist before the engine runs.
 */
public final class BeliefState {

    /** The single valid belief state before any observation has been processed. */
    public static final BeliefState UNINITIALIZED = new BeliefState(Map.of(), 0L, 0L, 0L);

    private final Map<String, ResourceBelief> beliefs;
    private final long observationCount;
    private final long latestObservationTimestamp;
    private final long computedAtMillis;

    private BeliefState(Map<String, ResourceBelief> beliefs, long observationCount,
                        long latestObservationTimestamp, long computedAtMillis) {
        this.beliefs = beliefs;
        this.observationCount = observationCount;
        this.latestObservationTimestamp = latestObservationTimestamp;
        this.computedAtMillis = computedAtMillis;
    }

    /**
     * Creates a populated belief state.
     *
     * @param beliefs per-resource posterior beliefs; must not be null
     * @param observationCount number of observations consumed (including ones with
     *        missing measurements)
     * @param latestObservationTimestamp timestamp of the newest observation consumed
     * @param computedAtMillis Master clock time the state was computed
     */
    public static BeliefState of(Map<String, ResourceBelief> beliefs, long observationCount,
                                 long latestObservationTimestamp, long computedAtMillis) {
        return new BeliefState(Map.copyOf(Objects.requireNonNull(beliefs, "beliefs")),
                observationCount, latestObservationTimestamp, computedAtMillis);
    }

    /**
     * @return the posterior belief for one resource, or empty when no
     *         non-missing measurement for that resource has been incorporated
     */
    public Optional<ResourceBelief> beliefFor(String resourceName) {
        return Optional.ofNullable(beliefs.get(resourceName));
    }

    /**
     * @return an unmodifiable view of all per-resource posterior beliefs
     */
    public Map<String, ResourceBelief> beliefs() {
        return beliefs;
    }

    /** @return number of observations consumed to produce this state */
    public long observationCount() {
        return observationCount;
    }

    /** @return timestamp of the newest observation consumed */
    public long latestObservationTimestamp() {
        return latestObservationTimestamp;
    }

    /** @return Master clock time this state was computed */
    public long computedAtMillis() {
        return computedAtMillis;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BeliefState other)) {
            return false;
        }
        return observationCount == other.observationCount
                && latestObservationTimestamp == other.latestObservationTimestamp
                && computedAtMillis == other.computedAtMillis
                && beliefs.equals(other.beliefs);
    }

    @Override
    public int hashCode() {
        return Objects.hash(beliefs, observationCount, latestObservationTimestamp, computedAtMillis);
    }

    @Override
    public String toString() {
        return "BeliefState{observations=" + observationCount
                + ", latestObservationTimestamp=" + latestObservationTimestamp
                + ", beliefs=" + beliefs + "}";
    }
}
