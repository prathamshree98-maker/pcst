package com.omni.pcst.master.task;

import java.util.Objects;

/**
 * The resolved outcome of one hard constraint for one candidate node.
 *
 * <p>Carries the evidence behind the decision so a later scheduling layer, or a
 * human reviewing an evaluation, can see <em>why</em> a node was excluded rather
 * than only that it was.
 *
 * @param constraint which hard constraint this result belongs to
 * @param outcome    satisfied / violated / indeterminate
 * @param reason     stable reason code; null only when {@code outcome == SATISFIED}
 * @param required   the requirement, rendered in the constraint's unit
 * @param observed   the observed value that was compared, or null when none exists
 * @param unit       unit of {@code required} and {@code observed}
 */
public record ConstraintEvaluation(
        HardConstraint constraint,
        ConstraintOutcome outcome,
        RejectionReason reason,
        String required,
        String observed,
        String unit) {

    public ConstraintEvaluation {
        Objects.requireNonNull(constraint, "constraint");
        Objects.requireNonNull(outcome, "outcome");
        if (outcome == ConstraintOutcome.SATISFIED && reason != null) {
            throw new IllegalArgumentException(
                    "a SATISFIED constraint must not carry a rejection reason");
        }
        if (outcome != ConstraintOutcome.SATISFIED && reason == null) {
            throw new IllegalArgumentException(
                    "a " + outcome + " constraint must carry a reason code");
        }
    }

    static ConstraintEvaluation satisfied(HardConstraint constraint, String required,
                                          String observed, String unit) {
        return new ConstraintEvaluation(constraint, ConstraintOutcome.SATISFIED, null,
                required, observed, unit);
    }

    static ConstraintEvaluation violated(HardConstraint constraint, RejectionReason reason,
                                        String required, String observed, String unit) {
        return new ConstraintEvaluation(constraint, ConstraintOutcome.VIOLATED, reason,
                required, observed, unit);
    }

    static ConstraintEvaluation indeterminate(HardConstraint constraint, RejectionReason reason,
                                             String required, String observed, String unit) {
        return new ConstraintEvaluation(constraint, ConstraintOutcome.INDETERMINATE, reason,
                required, observed, unit);
    }

    /** @return true when this constraint did not yield a proven success */
    public boolean isBlocking() {
        return outcome.isNotSatisfied();
    }
}