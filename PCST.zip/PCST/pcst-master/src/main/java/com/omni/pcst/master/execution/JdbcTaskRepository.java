package com.omni.pcst.master.execution;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.proto.TaskResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/**
 * JDBC-backed repository for {@link TaskRecord} rows in the {@code task_records}
 * table.
 *
 * <p>Frequently queried fields (task ID, state, timestamps, selected node) live
 * in typed columns. Structured payloads (Task, SchedulingDecision, result,
 * history) are stored as JSONB. All writes use optimistic concurrency control
 * via the {@code version} column.
 *
 * <p>Duplicate taskId creation is rejected deliberately (primary key violation
 * surfaced as {@link IllegalArgumentException}); existing rows are never
 * silently overwritten.
 */
@Repository
@ConditionalOnProperty(name = "pcst.persistence.jdbc.enabled", havingValue = "true")
public class JdbcTaskRepository {

    private static final Logger log = LoggerFactory.getLogger(JdbcTaskRepository.class);

    private static final String INSERT_SQL = """
            INSERT INTO task_records
                (task_id, attempt_id, state, created_at, updated_at,
                 selected_node_id, dispatch_time, error_message,
                 task, scheduling_decision, result, history, version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?::jsonb, ?::jsonb, ?::jsonb, ?::jsonb, 1)
            """;

    private static final String UPDATE_SQL = """
            UPDATE task_records
            SET attempt_id = ?, state = ?, updated_at = ?,
                selected_node_id = ?, dispatch_time = ?, error_message = ?,
                task = ?::jsonb, scheduling_decision = ?::jsonb, result = ?::jsonb, history = ?::jsonb,
                version = version + 1
            WHERE task_id = ? AND version = ?
            """;

    private static final String SELECT_BY_ID_SQL = """
            SELECT task_id, attempt_id, state, created_at, updated_at,
                   selected_node_id, dispatch_time, error_message,
                   task, scheduling_decision, result, history, version
            FROM task_records
            WHERE task_id = ?
            """;

    private static final String SELECT_ALL_SQL = """
            SELECT task_id, attempt_id, state, created_at, updated_at,
                   selected_node_id, dispatch_time, error_message,
                   task, scheduling_decision, result, history, version
            FROM task_records
            ORDER BY updated_at DESC
            """;

    private static final String DELETE_BY_ID_SQL = """
            DELETE FROM task_records WHERE task_id = ?
            """;

    private static final String PROBE_SQL = "SELECT version()";

    private final JdbcTemplate jdbc;
    private final ObjectMapper objectMapper;
    private final TaskRecordRowMapper rowMapper;

    public JdbcTaskRepository(JdbcTemplate jdbc, ObjectMapper objectMapper) {
        this.jdbc = jdbc;
        this.objectMapper = objectMapper;
        this.rowMapper = new TaskRecordRowMapper(objectMapper);
    }

    /**
     * Inserts a new task record. Fails if the taskId already exists.
     */
    @Transactional
    public int insert(TaskRecord record) {
        try {
            return jdbc.update(INSERT_SQL,
                    record.taskId(),
                    record.attemptId(),
                    record.state().name(),
                    record.createdAt(),
                    record.updatedAt(),
                    record.selectedNodeId(),
                    record.dispatchTime(),
                    record.errorMessage(),
                    toJson(record.task()),
                    toJsonNullable(record.schedulingDecision()),
                    toJsonNullable(toResultPayload(record.result())),
                    toJson(record.history()));
        } catch (DuplicateKeyException e) {
            throw new IllegalArgumentException(
                    "Task with taskId " + record.taskId() + " already exists", e);
        }
    }

    /**
     * Atomically updates a task record with optimistic locking on {@code version}.
     * @param expectedVersion the version read from the database for this record
     * @return the number of rows updated (0 means the version changed or the row
     *         does not exist — caller treats this as a conflict)
     */
    @Transactional
    public int update(TaskRecord current, TaskRecord updated, long expectedVersion) {
        int rows = jdbc.update(UPDATE_SQL,
                updated.attemptId(),
                updated.state().name(),
                updated.updatedAt(),
                updated.selectedNodeId(),
                updated.dispatchTime(),
                updated.errorMessage(),
                toJson(updated.task()),
                toJsonNullable(updated.schedulingDecision()),
                toJsonNullable(toResultPayload(updated.result())),
                toJson(updated.history()),
                current.taskId(),
                expectedVersion);
        if (rows == 0) {
            log.warn("Optimistic lock conflict on taskId={} (expected version={})",
                    current.taskId(), expectedVersion);
        }
        return rows;
    }

    /**
     * @return the record for a taskId, with its DB version captured for locking
     */
    @Transactional(readOnly = true)
    public Optional<VersionedRecord> findById(String taskId) {
        List<VersionedRecord> rows = jdbc.query(SELECT_BY_ID_SQL, (rs, rowNum) -> {
            TaskRecord record = rowMapper.mapRow(rs, rowNum);
            long version = rs.getLong("version");
            return new VersionedRecord(record, version);
        }, taskId);
        return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
    }

    /**
     * @return all task records, ordered by updated_at descending
     */
    @Transactional(readOnly = true)
    public List<TaskRecord> findAll() {
        return jdbc.query(SELECT_ALL_SQL, rowMapper);
    }

    /**
     * Removes a task record (for testing/cleanup).
     */
    @Transactional
    public void deleteById(String taskId) {
        jdbc.update(DELETE_BY_ID_SQL, taskId);
    }

    /**
     * Read-only connectivity probe against the configured datasource.
     * @return the database server version string
     */
    @Transactional(readOnly = true)
    public String probeVersion() {
        return jdbc.queryForObject(PROBE_SQL, String.class);
    }

    // ------------------------------------------------------------------ helpers

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to serialize task record payload", e);
        }
    }

    private String toJsonNullable(Object value) {
        if (value == null) {
            return null;
        }
        return toJson(value);
    }

    private static TaskResultPayload toResultPayload(TaskResult result) {
        if (result == null) {
            return null;
        }
        return new TaskResultPayload(
                result.getSuccess(),
                result.getOutput(),
                result.getError(),
                result.getDurationMillis());
    }

    /** A TaskRecord paired with its database version for optimistic locking. */
    public record VersionedRecord(TaskRecord record, long version) {}

    /** Jackson-friendly projection of protobuf TaskResult. */
    public record TaskResultPayload(boolean success, String output, String error, Long durationMillis) {}
}

/**
 * Maps a task_records row to a TaskRecord.
 */
class TaskRecordRowMapper implements RowMapper<TaskRecord> {

    private final ObjectMapper objectMapper;

    TaskRecordRowMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public TaskRecord mapRow(ResultSet rs, int rowNum) throws SQLException {
        String taskId = rs.getString("task_id");
        String attemptId = rs.getString("attempt_id");
        com.omni.pcst.master.execution.TaskState state =
                com.omni.pcst.master.execution.TaskState.valueOf(rs.getString("state"));
        long createdAt = rs.getLong("created_at");
        long updatedAt = rs.getLong("updated_at");
        String selectedNodeId = rs.getString("selected_node_id");
        Long dispatchTime = rs.getLong("dispatch_time");
        if (rs.wasNull()) {
            dispatchTime = null;
        }
        String errorMessage = rs.getString("error_message");

        com.omni.pcst.master.task.Task task = fromJson(rs.getString("task"),
                com.omni.pcst.master.task.Task.class);
        com.omni.pcst.master.scheduler.SchedulingDecision decision = fromJsonNullable(
                rs.getString("scheduling_decision"),
                com.omni.pcst.master.scheduler.SchedulingDecision.class);
        JdbcTaskRepository.TaskResultPayload resultPayload = fromJsonNullable(
                rs.getString("result"), JdbcTaskRepository.TaskResultPayload.class);
        com.omni.pcst.proto.TaskResult result = resultPayload == null
                ? null
                : toProtoResult(resultPayload);
        List<com.omni.pcst.master.execution.TaskRecord.StateTransition> history = fromJsonCollection(
                rs.getString("history"),
                objectMapper.getTypeFactory().constructCollectionType(
                        java.util.List.class,
                        com.omni.pcst.master.execution.TaskRecord.StateTransition.class));

        return new com.omni.pcst.master.execution.TaskRecord(
                taskId, attemptId, task, state, createdAt, updatedAt,
                decision, selectedNodeId, dispatchTime, result, errorMessage, history);
    }

    private <T> T fromJson(String json, Class<T> type) {
        try {
            if (json == null) {
                return null;
            }
            return objectMapper.readValue(json, type);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to deserialize task record payload", e);
        }
    }

    private <T> T fromJsonNullable(String json, Class<T> type) {
        if (json == null) {
            return null;
        }
        return fromJson(json, type);
    }

    private <T> T fromJsonCollection(String json, com.fasterxml.jackson.databind.JavaType type) {
        try {
            if (json == null) {
                return null;
            }
            return objectMapper.readValue(json, type);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to deserialize task record payload", e);
        }
    }

    private static com.omni.pcst.proto.TaskResult toProtoResult(
            JdbcTaskRepository.TaskResultPayload payload) {
        return com.omni.pcst.proto.TaskResult.newBuilder()
                .setSuccess(payload.success())
                .setOutput(payload.output() == null ? "" : payload.output())
                .setError(payload.error() == null ? "" : payload.error())
                .setDurationMillis(payload.durationMillis() == null ? 0 : payload.durationMillis())
                .build();
    }
}
