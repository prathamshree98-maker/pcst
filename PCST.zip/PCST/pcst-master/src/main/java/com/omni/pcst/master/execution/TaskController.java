package com.omni.pcst.master.execution;

import com.omni.pcst.master.scheduler.SchedulingDecision;
import com.omni.pcst.master.task.Task;
import com.omni.pcst.master.task.TaskClass;
import com.omni.pcst.master.task.TaskConstraints;
import com.omni.pcst.master.task.TaskResources;
import com.omni.pcst.master.task.TaskValidationException;
import com.omni.pcst.master.task.InterruptionTolerance;
import com.omni.pcst.master.task.ValidationViolation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * REST API for task submission and querying.
 */
@RestController
@RequestMapping("/api/v1/tasks")
public class TaskController {

    private static final Logger log = LoggerFactory.getLogger(TaskController.class);

    private final TaskExecutionCoordinator coordinator;

    public TaskController(TaskExecutionCoordinator coordinator) {
        this.coordinator = coordinator;
    }

    /**
     * Submits a task for execution.
     *
     * Request body:
     * {
     *   "taskId": "task-123",
     *   "taskClass": "NETWORK_BOUND",
     *   "workloadReference": "NO_OP",
     *   "inputCharacteristics": "optional input",
     *   "expectedDurationMillis": 60000,
     *   "resources": {
     *     "requiredMemoryBytes": 1073741824,
     *     "requiredStorageBytes": 10737418240,
     *     "acceleratorRequired": false,
     *     "requiredAcceleratorMemoryBytes": null,
     *     "requiredComputeUnits": null
     *   },
     *   "constraints": {
     *     "deadlineEpochMillis": 1700000000000,
     *     "expectedDurationMillis": 60000,
     *     "minimumBatteryPercent": 20.0,
     *     "maximumNetworkLatencyMillis": 100.0,
     *     "maximumPacketLossPercent": 1.0,
     *     "interruptionTolerance": "PREEMPTIBLE",
     *     "requiredExecutionProfile": "gpu-profile"
     *   }
     * }
     *
     * All fields except taskId, taskClass, workloadReference are optional.
     * resources and constraints default to empty if omitted.
     */
    @PostMapping
    public ResponseEntity<?> submitTask(@RequestBody TaskSubmissionRequest request) {
        try {
            Task task = buildTask(request);
            if (task == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Invalid task data"));
            }
            TaskRecord record = coordinator.submitTask(task);
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(toTaskResponse(record));
        } catch (TaskValidationException e) {
            log.warn("Task validation failed: {}", e.violations());
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "Validation failed",
                    "violations", e.violations().stream()
                            .map(v -> Map.of("field", v.field(), "message", v.reason()))
                            .collect(Collectors.toList())));
        } catch (IllegalArgumentException e) {
            log.warn("Task submission rejected: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            log.error("Task submission failed: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", "Internal server error: " + e.getMessage()));
        }
    }

    /**
     * Gets the current state of a task.
     */
    @GetMapping("/{taskId}")
    public ResponseEntity<?> getTask(@PathVariable String taskId) {
        return coordinator.getTask(taskId)
                .map(record -> ResponseEntity.ok(toTaskResponse(record)))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Lists all tasks.
     */
    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> listTasks() {
        List<Map<String, Object>> tasks = coordinator.listTasks().stream()
                .map(this::toTaskResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(tasks);
    }

    /**
     * Gets the scheduling decision for a task (if available).
     */
    @GetMapping("/{taskId}/decision")
    public ResponseEntity<?> getSchedulingDecision(@PathVariable String taskId) {
        Optional<TaskRecord> recordOpt = coordinator.getTask(taskId);
        if (recordOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        TaskRecord record = recordOpt.get();
        if (record.schedulingDecision() == null) {
            return ResponseEntity.notFound().build();
        }
        SchedulingDecision decision = record.schedulingDecision();
        Map<String, Object> body = new java.util.LinkedHashMap<>();
        body.put("taskId", record.taskId());
        body.put("attemptId", record.attemptId());
        body.put("status", decision.status().name());
        body.put("selectedNodeId", decision.selectedNodeId());
        body.put("selectedReliability", decision.selectedReliability());
        body.put("policyThreshold", decision.policyThreshold());
        body.put("policyFallback", decision.policyFallback());
        body.put("derivation", decision.derivation());
        body.put("candidates", decision.candidates().stream()
                .map(c -> {
                    Map<String, Object> entry = new java.util.LinkedHashMap<>();
                    entry.put("nodeId", c.nodeId());
                    entry.put("eligible", c.eligible());
                    entry.put("disposition", c.disposition().name());
                    entry.put("reliability", c.reliability());
                    entry.put("capability", c.capability());
                    entry.put("reliabilityStatus", c.reliabilityStatus().name());
                    entry.put("rejectionReasons", c.rejectionReasons().stream()
                            .map(Enum::name)
                            .collect(Collectors.toList()));
                    entry.put("explanation", c.explanation());
                    return entry;
                })
                .collect(Collectors.toList()));
        body.put("reasons", decision.reasons().stream()
                .map(Enum::name)
                .collect(Collectors.toList()));
        return ResponseEntity.ok(body);
    }

    // ------------------------------------------------------------------ helpers

    private Task buildTask(TaskSubmissionRequest request) {
        try {
            TaskClass taskClass = TaskClass.valueOf(request.taskClass());
            return Task.builder(request.taskId())
                    .taskClass(taskClass)
                    .workloadReference(request.workloadReference())
                    .inputCharacteristics(request.inputCharacteristics())
                    .expectedDurationMillis(request.expectedDurationMillis())
                    .resources(request.resources() != null ? buildResources(request.resources()) : TaskResources.NONE)
                    .constraints(request.constraints() != null ? buildConstraints(request.constraints()) : TaskConstraints.NONE)
                    .build();
        } catch (IllegalArgumentException e) {
            log.warn("Invalid task class value: {}", e.getMessage());
            throw new IllegalArgumentException("Invalid value for: " + e.getMessage());
        }
    }

    private TaskResources buildResources(ResourcesRequest r) {
        Double computeUnits = r.requiredComputeUnits();
        if (computeUnits != null && (Double.isNaN(computeUnits) || Double.isInfinite(computeUnits))) {
            log.warn("Invalid compute units value: {}, treating as absent", computeUnits);
            computeUnits = null;
        }
        return new TaskResources(
                normalizeBytes("requiredMemoryBytes", r.requiredMemoryBytes()),
                normalizeBytes("requiredStorageBytes", r.requiredStorageBytes()),
                r.acceleratorRequired() != null ? r.acceleratorRequired() : false,
                normalizeBytes("requiredAcceleratorMemoryBytes", r.requiredAcceleratorMemoryBytes()),
                computeUnits);
    }

    /**
     * Preserves an absent (null) byte requirement as absent. Absent must never be
     * converted to zero: an unspecified requirement imposes no hard constraint,
     * while an explicit zero is a real demand. A negative value is an invalid
     * explicit requirement and is clamped to zero; a finite non-negative value is
     * preserved exactly.
     */
    private static Long normalizeBytes(String field, Long value) {
        if (value == null) {
            return null;
        }
        if (value < 0L) {
            log.warn("Invalid {} value: {}, forcing to 0", field, value);
            return 0L;
        }
        return value;
    }

    private TaskConstraints buildConstraints(ConstraintsRequest r) {
        return new TaskConstraints(
                r.deadlineEpochMillis(),
                r.expectedDurationMillis(),
                r.minimumBatteryPercent(),
                r.maximumNetworkLatencyMillis(),
                r.maximumPacketLossPercent(),
                r.interruptionTolerance() != null ? InterruptionTolerance.valueOf(r.interruptionTolerance()) : null,
                r.requiredExecutionProfile());
    }

    private Map<String, Object> toTaskResponse(TaskRecord record) {
        Map<String, Object> resp = new java.util.LinkedHashMap<>();
        resp.put("taskId", record.taskId());
        resp.put("attemptId", record.attemptId());
        resp.put("state", record.state().name());
        resp.put("stateDescription", record.state().description());
        resp.put("createdAt", record.createdAt());
        resp.put("updatedAt", record.updatedAt());
        resp.put("workloadReference", record.task().workloadReference());
        resp.put("taskClass", record.task().taskClass().name());

        if (record.schedulingDecision() != null) {
            resp.put("selectedNodeId", record.schedulingDecision().selectedNodeId());
            resp.put("schedulingStatus", record.schedulingDecision().status().name());
        }
        if (record.result() != null) {
            resp.put("result", Map.of(
                    "success", record.result().getSuccess(),
                    "output", record.result().getOutput(),
                    "error", record.result().getError(),
                    "durationMillis", record.result().getDurationMillis()));
        }
        if (record.errorMessage() != null) {
            resp.put("errorMessage", record.errorMessage());
        }
        resp.put("history", record.history().stream()
                .map(h -> Map.of(
                        "from", h.from().name(),
                        "to", h.to().name(),
                        "timestamp", h.timestamp(),
                        "detail", h.detail()))
                .collect(Collectors.toList()));
        return resp;
    }
}