package com.omni.pcst.master.capability;

import com.omni.pcst.master.digitaltwin.ResourceBelief;

import java.util.Objects;
import java.util.Optional;

/**
 * Default {@link PredictiveDistributionSource}: uses the Bayesian belief posterior
 * itself as the predictive distribution.
 *
 * <h2>Why this is valid only under a stated assumption</h2>
 * The Step 4B Bayesian engine models each resource as i.i.d. Gaussian measurements
 * around an unknown but <b>constant</b> true value, with no drift, trend or
 * process noise. Under that model, the posterior {@code N(m, s²)} is the
 * distribution of the future <em>latent value</em> itself, because the value does
 * not change over time. So the posterior <b>is</b> the predictive distribution for
 * the execution interval, with no additional extrapolation.
 *
 * <p>This is precisely and only the persistence assumption. The posterior variance
 * is the remaining epistemic uncertainty about a static value; it is <b>not</b>
 * relabelled as a forecast uncertainty and no process-noise term is added. If a
 * future prediction stage introduces temporal dynamics, it must supply a different
 * {@link PredictiveDistributionSource}; this default then no longer applies.
 *
 * <p>Note also what is deliberately not done: the empirical half-range or spread of
 * a point forecast is never used as a variance, because a heuristic forecast
 * interval is not a distribution and reusing it as one would silently misstate
 * probability.
 */
public final class BeliefPosteriorDistributionSource implements PredictiveDistributionSource {

    /** Stable source identifier recorded on every distribution it produces. */
    public static final String SOURCE = "belief-posterior-persistence";

    /** The single modeling assumption this source relies on. */
    public static final String ASSUMPTION =
            "static latent resource value with i.i.d. Gaussian observation noise: the belief "
                    + "posterior N(posteriorMean, posteriorVariance) is the predictive distribution "
                    + "for the execution interval; no drift or process noise is modelled";

    @Override
    public Optional<PredictiveDistribution> distributionFor(ResourceBelief belief) {
        if (Objects.isNull(belief)) {
            return Optional.empty();
        }
        return Optional.of(new PredictiveDistribution(
                belief.posteriorMean(), belief.posteriorVariance(), SOURCE, ASSUMPTION));
    }
}
