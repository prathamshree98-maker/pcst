﻿// PCST Observatory — Sprint 5 Premium Frontend
// Connects to the PCST Master REST API on port 8080 (HTTP)

// ==========================================================================
// Configuration & State
// ==========================================================================
const API_BASE = '/api/v1';
const DEFAULT_REFRESH_INTERVAL = 30000;

let dashboardState = {
    connected: false,
    refreshInterval: null,
    lastRefresh: 0,
    pollingInFlight: new Set(),
};

// ==========================================================================
// Initialization
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
    initBackground();
    initConnectionStatus();
    initRouting();
    initRefresh();
    initOnboarding();
    initTaskForm();
});

// ==========================================================================
// Toast Notifications
// ==========================================================================
function showToast(message, type = 'info', duration = 4000) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<div class="toast-body">${message}</div>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 200ms';
        setTimeout(() => toast.remove(), 220);
    }, duration);
}

// ==========================================================================
// Ambient Background — left-weighted particle network (Canvas 2D)
// Reproduces the reference visual: dense Delaunay-triangulated geometry
// along the left edge that fades into sparse particles over open white
// space on the right. No external dependencies or CDN scripts; falls back
// to a static CSS gradient if canvas rendering is unavailable.
// ==========================================================================
const BG_POINT_RGB = {
    cyan: '14,165,233',
    blue: '65,140,215',
    violet: '124,58,237',
    magenta: '217,70,239',
    pink: '214,80,160',
};
const BG_FACET_PALETTE = [
    { rgb: '246,243,253', steps: [0.14, 0.20, 0.26], weight: 0.42 },
    { rgb: '234,228,250', steps: [0.16, 0.22, 0.28], weight: 0.26 },
    { rgb: '229,242,252', steps: [0.16, 0.21, 0.26], weight: 0.20 },
    { rgb: '249,234,243', steps: [0.12, 0.15, 0.18], weight: 0.12 },
];
const BG_EDGE_STYLES = {
    'gray|f': 'rgba(214,221,240,0.20)',
    'gray|n': 'rgba(214,221,240,0.38)',
    'violet|n': 'rgba(167,139,250,0.46)',
    'magenta|n': 'rgba(217,70,239,0.40)',
};

const bg = {
    canvas: null, ctx: null,
    animId: null, running: false, staticMode: false, bound: false,
    w: 0, h: 0, dpr: 1, t: 0, last: 0,
    points: [], facetGroups: {}, edgeGroups: {}, pointGroups: {},
    edgePool: [], glowSprites: null, glowNodes: [], travelers: [],
};

function initBackground() {
    const canvas = document.getElementById('bg-canvas');
    const fallback = document.querySelector('.bg-fallback');
    if (!canvas || !fallback) return;

    let ctx = null;
    try { ctx = canvas.getContext('2d'); } catch (e) { ctx = null; }
    if (!ctx) {
        canvas.style.display = 'none';
        fallback.style.display = 'block';
        return;
    }

    bg.canvas = canvas;
    bg.ctx = ctx;
    bg.staticMode = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    if (!bg.glowSprites) bg.glowSprites = makeGlowSprites();

    bindBackgroundEvents();
    layoutBackground();

    if (bg.staticMode) {
        bg.running = false;
        drawBackground();
    } else {
        bg.running = true;
        bg.last = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
        bg.animId = requestAnimationFrame(frameBackground);
    }
}

function bindBackgroundEvents() {
    if (bg.bound) return;
    bg.bound = true;

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            if (bg.animId) cancelAnimationFrame(bg.animId);
            bg.animId = null;
            bg.running = false;
        } else if (bg.canvas && !bg.staticMode && !bg.running) {
            bg.running = true;
            bg.last = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
            bg.animId = requestAnimationFrame(frameBackground);
        }
    });

    let resizeTimer = null;
    window.addEventListener('resize', () => {
        if (!bg.ctx) return;
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            if (!bg.ctx) return;
            layoutBackground();
            if (bg.staticMode || !bg.running) drawBackground();
        }, 200);
    });

    window.addEventListener('beforeunload', () => {
        if (bg.animId) cancelAnimationFrame(bg.animId);
        bg.animId = null;
        bg.running = false;
    });
}

function gaussRandom() {
    let u = 0;
    let v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function pickFacetPalette() {
    let roll = Math.random();
    for (let i = 0; i < BG_FACET_PALETTE.length; i++) {
        const p = BG_FACET_PALETTE[i];
        if (roll < p.weight) return p;
        roll -= p.weight;
    }
    return BG_FACET_PALETTE[0];
}

function makeGlowSprites() {
    const sprites = {};
    const size = 256;
    const keys = Object.keys(BG_POINT_RGB);
    for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        const rgb = BG_POINT_RGB[key];
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const g = canvas.getContext('2d');
        if (!g) continue;
        const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
        grad.addColorStop(0, 'rgba(' + rgb + ',0.16)');
        grad.addColorStop(0.4, 'rgba(' + rgb + ',0.05)');
        grad.addColorStop(1, 'rgba(' + rgb + ',0)');
        g.fillStyle = grad;
        g.fillRect(0, 0, size, size);
        sprites[key] = canvas;
    }
    return sprites;
}

function makeBackgroundPoint(hx, hy, w, h) {
    const x = hx < 0 ? 0 : (hx > w ? w : hx);
    const y = hy < 0 ? 0 : (hy > h ? h : hy);
    const roll = Math.random();
    let color = 'cyan';
    if (roll > 0.94) color = 'pink';
    else if (roll > 0.84) color = 'magenta';
    else if (roll > 0.72) color = 'violet';
    else if (roll > 0.58) color = 'blue';
    const r = Math.random() < 0.08 ? 2.7 + Math.random() * 0.9 : 1.2 + Math.random() * 1.4;
    const scale = Math.min(1.5, Math.max(0.6, w / 1200));
    return {
        hx: x, hy: y, x: x, y: y, color: color, r: r,
        ampX: (5 + Math.random() * 9) * scale,
        ampY: (4 + Math.random() * 7) * scale,
        phX: Math.random() * Math.PI * 2,
        phY: Math.random() * Math.PI * 2,
        spX: 0.10 + Math.random() * 0.16,
        spY: 0.08 + Math.random() * 0.14,
    };
}

function delaunayTriangles(pts) {
    const n = pts.length;
    if (n < 3) return [];
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (let i = 0; i < n; i++) {
        const p = pts[i];
        if (p.hx < minX) minX = p.hx;
        if (p.hy < minY) minY = p.hy;
        if (p.hx > maxX) maxX = p.hx;
        if (p.hy > maxY) maxY = p.hy;
    }
    const dmax = Math.max(maxX - minX, maxY - minY) || 1;
    const mx = (minX + maxX) / 2;
    const my = (minY + maxY) / 2;

    const vx = new Array(n + 3);
    const vy = new Array(n + 3);
    for (let i = 0; i < n; i++) {
        vx[i] = pts[i].hx;
        vy[i] = pts[i].hy;
    }
    vx[n] = mx - 20 * dmax;
    vy[n] = my - dmax;
    vx[n + 1] = mx;
    vy[n + 1] = my + 20 * dmax;
    vx[n + 2] = mx + 20 * dmax;
    vy[n + 2] = my - dmax;

    let tris = [[n, n + 1, n + 2]];
    for (let i = 0; i < n; i++) {
        const px = vx[i];
        const py = vy[i];
        const survivors = [];
        const boundary = new Map();
        for (let t = 0; t < tris.length; t++) {
            const tr = tris[t];
            const a = tr[0];
            const b = tr[1];
            const c = tr[2];
            if (inCircum(vx[a], vy[a], vx[b], vy[b], vx[c], vy[c], px, py)) {
                bumpEdge(boundary, a, b);
                bumpEdge(boundary, b, c);
                bumpEdge(boundary, c, a);
            } else {
                survivors.push(tr);
            }
        }
        boundary.forEach((count, key) => {
            if (count === 1) {
                survivors.push([Math.floor(key / 65536), key % 65536, i]);
            }
        });
        tris = survivors;
    }

    const out = [];
    for (let t = 0; t < tris.length; t++) {
        const tr = tris[t];
        if (tr[0] < n && tr[1] < n && tr[2] < n) out.push(tr);
    }
    return out;
}

function bumpEdge(map, a, b) {
    const lo = a < b ? a : b;
    const hi = a < b ? b : a;
    const key = lo * 65536 + hi;
    map.set(key, (map.get(key) || 0) + 1);
}

function inCircum(ax, ay, bx, by, cx, cy, px, py) {
    const d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
    if (d === 0) return false;
    const a2 = ax * ax + ay * ay;
    const b2 = bx * bx + by * by;
    const c2 = cx * cx + cy * cy;
    const ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d;
    const uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d;
    const dx = px - ux;
    const dy = py - uy;
    const rx = ax - ux;
    const ry = ay - uy;
    return dx * dx + dy * dy <= rx * rx + ry * ry;
}

function layoutBackground() {
    const w = Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1);
    const h = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 1);
    bg.w = w;
    bg.h = h;
    bg.dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    bg.canvas.width = Math.round(w * bg.dpr);
    bg.canvas.height = Math.round(h * bg.dpr);
    bg.canvas.style.width = w + 'px';
    bg.canvas.style.height = h + 'px';
    bg.ctx.setTransform(bg.dpr, 0, 0, bg.dpr, 0, 0);

    const narrow = w < 760;
    const cores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) || 4;
    let count = narrow ? 72 : Math.round(108 + Math.min(24, (w - 760) / 60));
    if (cores <= 2) count = Math.round(count * 0.65);

    const clusterCount = narrow ? 4 : 6;
    const clusters = [];
    for (let i = 0; i < clusterCount; i++) {
        clusters.push({
            x: (0.03 + Math.random() * 0.40) * w,
            y: (0.08 + Math.random() * 0.84) * h,
            r: (0.05 + Math.random() * 0.07) * w,
        });
    }
    const nCluster = Math.round(count * 0.30);
    const nPower = Math.round(count * 0.50);
    const nUniform = Math.max(0, count - nCluster - nPower);

    const pts = [];
    for (let i = 0; i < nCluster; i++) {
        const c = clusters[i % clusterCount];
        pts.push(makeBackgroundPoint(c.x + gaussRandom() * c.r, c.y + gaussRandom() * c.r, w, h));
    }
    for (let i = 0; i < nPower; i++) {
        pts.push(makeBackgroundPoint(Math.pow(Math.random(), 2.6) * w * 0.78, Math.random() * h, w, h));
    }
    for (let i = 0; i < nUniform; i++) {
        pts.push(makeBackgroundPoint(Math.random() * w, Math.random() * h, w, h));
    }

    const tris = delaunayTriangles(pts);
    const facetMap = {};
    const edgeMap = {};
    const pointMap = {};
    const seen = new Set();
    const edgePool = [];
    const maxArea = w * h * 0.016;

    for (let t = 0; t < tris.length; t++) {
        const tri = tris[t];
        const a = pts[tri[0]];
        const b = pts[tri[1]];
        const c = pts[tri[2]];
        const centroidX = (a.hx + b.hx + c.hx) / 3;
        const area = Math.abs(
            a.hx * (b.hy - c.hy) + b.hx * (c.hy - a.hy) + c.hx * (a.hy - b.hy)
        ) / 2;
        if (centroidX < w * 0.5 && area > 1 && area < maxArea) {
            const pal = pickFacetPalette();
            const step = pal.steps[Math.floor(Math.random() * pal.steps.length)];
            const fill = 'rgba(' + pal.rgb + ',' + step.toFixed(2) + ')';
            if (!facetMap[fill]) facetMap[fill] = [];
            facetMap[fill].push(tri[0], tri[1], tri[2]);
        }

        for (let e = 0; e < 3; e++) {
            const i1 = tri[e];
            const i2 = tri[(e + 1) % 3];
            const lo = i1 < i2 ? i1 : i2;
            const hi = i1 < i2 ? i2 : i1;
            const key = lo * 65536 + hi;
            if (seen.has(key)) continue;
            seen.add(key);
            const p1 = pts[lo];
            const p2 = pts[hi];
            const dx = p2.hx - p1.hx;
            const dy = p2.hy - p1.hy;
            const len = Math.sqrt(dx * dx + dy * dy);
            if (len > w * 0.34) continue;
            const midX = (p1.hx + p2.hx) / 2;
            let style;
            if (midX > w * 0.17 || len > w * 0.2) {
                style = 'gray|f';
            } else {
                const r = Math.random();
                style = r < 0.70 ? 'gray|n' : (r < 0.92 ? 'violet|n' : 'magenta|n');
            }
            if (!edgeMap[style]) edgeMap[style] = [];
            edgeMap[style].push(lo, hi);
            if (len < w * 0.2) edgePool.push(lo, hi);
        }
    }

    for (let i = 0; i < pts.length; i++) {
        const color = pts[i].color;
        if (!pointMap[color]) pointMap[color] = [];
        pointMap[color].push(i);
    }

    bg.points = pts;
    bg.facetGroups = [];
    for (const key in facetMap) bg.facetGroups.push({ style: key, data: facetMap[key] });
    bg.edgeGroups = [];
    for (const key in edgeMap) bg.edgeGroups.push({ style: BG_EDGE_STYLES[key], data: edgeMap[key] });
    bg.pointGroups = [];
    for (const key in pointMap) {
        bg.pointGroups.push({ style: 'rgba(' + BG_POINT_RGB[key] + ',0.95)', data: pointMap[key] });
    }
    bg.edgePool = edgePool;

    const glowCount = narrow ? 2 : 2 + Math.floor(Math.random() * 2);
    const glowKeys = ['cyan', 'violet', 'magenta'];
    const glowNodes = [];
    for (let i = 0; i < glowCount; i++) {
        glowNodes.push({
            x: (0.04 + Math.random() * 0.48) * w,
            y: (0.10 + Math.random() * 0.80) * h,
            r: 12 + Math.random() * 16,
            sprite: glowKeys[Math.floor(Math.random() * glowKeys.length)],
            alpha: 0.35 + Math.random() * 0.25,
            phase: Math.random() * Math.PI * 2,
            speed: 0.35 + Math.random() * 0.4,
        });
    }
    bg.glowNodes = glowNodes;

    const travelers = [];
    const poolPairs = Math.floor(edgePool.length / 2);
    if (poolPairs > 0) {
        const travelerCount = Math.min(poolPairs, narrow ? 4 : 4 + Math.floor(Math.random() * 3));
        const travelerColors = ['cyan', 'violet', 'magenta'];
        for (let i = 0; i < travelerCount; i++) {
            const e = Math.floor(Math.random() * poolPairs) * 2;
            const color = travelerColors[i % travelerColors.length];
            travelers.push({
                e0: edgePool[e],
                e1: edgePool[e + 1],
                u: Math.random(),
                speed: 0.18 + Math.random() * 0.25,
                color: color,
                r: 2.4 + Math.random() * 1.2,
                fill: 'rgba(' + BG_POINT_RGB[color] + ',1)',
            });
        }
    }
    bg.travelers = travelers;
}

function frameBackground(now) {
    if (!bg.running) return;
    bg.animId = requestAnimationFrame(frameBackground);
    let dt = (now - bg.last) / 1000;
    bg.last = now;
    if (!(dt > 0)) dt = 1 / 60;
    if (dt > 0.1) dt = 0.1;
    bg.t += dt;
    updateBackground(dt);
    drawBackground();
}

function updateBackground(dt) {
    const pts = bg.points;
    const t = bg.t;
    for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        p.x = p.hx + Math.sin(t * p.spX + p.phX) * p.ampX;
        p.y = p.hy + Math.cos(t * p.spY + p.phY) * p.ampY;
    }
    const poolPairs = Math.floor(bg.edgePool.length / 2);
    for (let i = 0; i < bg.travelers.length; i++) {
        const tr = bg.travelers[i];
        tr.u += tr.speed * dt;
        while (tr.u >= 1) {
            tr.u -= 1;
            if (poolPairs > 0) {
                const e = Math.floor(Math.random() * poolPairs) * 2;
                tr.e0 = bg.edgePool[e];
                tr.e1 = bg.edgePool[e + 1];
            }
        }
    }
}

function drawBackground() {
    const ctx = bg.ctx;
    if (!ctx) return;
    const w = bg.w;
    const h = bg.h;
    const pts = bg.points;
    if (!pts) return;
    ctx.setTransform(bg.dpr, 0, 0, bg.dpr, 0, 0);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    const facetGroups = bg.facetGroups;
    for (let gi = 0; gi < facetGroups.length; gi++) {
        const g = facetGroups[gi];
        const tri = g.data;
        if (!tri.length) continue;
        ctx.beginPath();
        for (let k = 0; k < tri.length; k += 3) {
            const p1 = pts[tri[k]];
            const p2 = pts[tri[k + 1]];
            const p3 = pts[tri[k + 2]];
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.lineTo(p3.x, p3.y);
            ctx.closePath();
        }
        ctx.fillStyle = g.style;
        ctx.fill();
    }

    const edgeGroups = bg.edgeGroups;
    ctx.lineWidth = 1;
    for (let gi = 0; gi < edgeGroups.length; gi++) {
        const g = edgeGroups[gi];
        const seg = g.data;
        if (!seg.length) continue;
        ctx.beginPath();
        for (let k = 0; k < seg.length; k += 2) {
            const a = pts[seg[k]];
            const b = pts[seg[k + 1]];
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
        }
        ctx.strokeStyle = g.style;
        ctx.stroke();
    }

    const pointGroups = bg.pointGroups;
    for (let gi = 0; gi < pointGroups.length; gi++) {
        const g = pointGroups[gi];
        const idx = g.data;
        if (!idx.length) continue;
        ctx.beginPath();
        for (let k = 0; k < idx.length; k++) {
            const p = pts[idx[k]];
            ctx.moveTo(p.x + p.r, p.y);
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        }
        ctx.fillStyle = g.style;
        ctx.fill();
    }

    const sprites = bg.glowSprites;
    if (sprites) {
        for (let i = 0; i < bg.glowNodes.length; i++) {
            const n = bg.glowNodes[i];
            const pulse = 0.78 + 0.22 * Math.sin(bg.t * n.speed + n.phase);
            const rr = n.r * (0.94 + 0.06 * pulse);
            const sprite = sprites[n.sprite];
            if (!sprite) continue;
            ctx.globalAlpha = Math.max(0, Math.min(1, n.alpha * pulse));
            ctx.drawImage(sprite, n.x - rr, n.y - rr, rr * 2, rr * 2);
        }
        ctx.globalAlpha = 1;
    }

    for (let i = 0; i < bg.travelers.length; i++) {
        const tr = bg.travelers[i];
        const a = pts[tr.e0];
        const b = pts[tr.e1];
        if (!a || !b) continue;
        const x = a.x + (b.x - a.x) * tr.u;
        const y = a.y + (b.y - a.y) * tr.u;
        const sprite = sprites ? sprites[tr.color] : null;
        if (sprite) {
            const gr = tr.r * 3.5;
            ctx.globalAlpha = 0.5;
            ctx.drawImage(sprite, x - gr, y - gr, gr * 2, gr * 2);
            ctx.globalAlpha = 1;
        }
        ctx.beginPath();
        ctx.arc(x, y, tr.r, 0, Math.PI * 2);
        ctx.fillStyle = tr.fill;
        ctx.fill();
    }
}

// ==========================================================================
// Connection Status
// ==========================================================================
function initConnectionStatus() {
    checkServerConnectivity()
        .then(connected => {
            dashboardState.connected = connected;
            updateConnectionStatus(connected);
            if (connected) {
                startPolling();
                loadOverview();
                loadNodes();
                loadTasks();
            }
        })
        .catch(() => {
            dashboardState.connected = false;
            updateConnectionStatus(false);
        });
}

function checkServerConnectivity() {
    return fetch(`${API_BASE}/nodes`)
        .then(response => {
            if (response.ok) return true;
            if (response.status >= 500) return false;
            return null;
        })
        .then(result => {
            if (result === true) return true;
            if (result === false) return Promise.reject(new Error('Server error'));
            return Promise.reject(new Error('Server unreachable'));
        });
}

function updateConnectionStatus(connected) {
    const indicator = document.getElementById('connection-status');
    const statusText = document.getElementById('status-text');
    if (connected) {
        indicator.className = 'status-indicator connected';
        statusText.textContent = 'Connected';
    } else {
        indicator.className = 'status-indicator disconnected';
        statusText.textContent = 'Disconnected';
    }
}

// ==========================================================================
// Routing
// ==========================================================================
function initRouting() {
    const navBtns = document.querySelectorAll('.nav-btn');
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            navBtns.forEach(b => {
                b.classList.remove('active');
                b.setAttribute('aria-pressed', 'false');
            });
            btn.classList.add('active');
            btn.setAttribute('aria-pressed', 'true');
            switchPage(btn.dataset.page);
        });
    });
}

function switchPage(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById(`page-${page}`);
    if (target) target.classList.add('active');
    if (page === 'tasks') loadTasks();
    if (page === 'nodes') loadNodes();
    if (page === 'overview') { loadOverview(); loadTasks(); }
}

// ==========================================================================
// Refresh Control
// ==========================================================================
function startPolling() {
    if (dashboardState.refreshInterval) clearInterval(dashboardState.refreshInterval);
    dashboardState.refreshInterval = setInterval(() => {
        if (dashboardState.connected) {
            loadOverview();
            loadNodes();
            loadTasks();
        }
    }, DEFAULT_REFRESH_INTERVAL);
}

function initRefresh() {
    const intervalSelect = document.getElementById('refresh-interval');
    if (intervalSelect) {
        intervalSelect.addEventListener('change', e => {
            clearInterval(dashboardState.refreshInterval);
            const ms = parseInt(e.target.value);
            dashboardState.refreshInterval = setInterval(() => {
                if (dashboardState.connected) {
                    loadOverview();
                    loadNodes();
                    loadTasks();
                }
            }, ms);
        });
    }

    ['refresh-overview', 'refresh-nodes'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.addEventListener('click', () => {
                if (dashboardState.connected) {
                    if (id === 'refresh-overview') { loadOverview(); loadTasks(); }
                    if (id === 'refresh-nodes') loadNodes();
                } else {
                    checkServerConnectivity().then(c => {
                        dashboardState.connected = c;
                        updateConnectionStatus(c);
                        if (c) { startPolling(); loadOverview(); loadNodes(); loadTasks(); }
                    }).catch(() => updateConnectionStatus(false));
                }
            });
        }
    });
}

// ==========================================================================
// Load Data
// ==========================================================================
function loadOverview() {
    if (!dashboardState.connected) return;
    fetch(`${API_BASE}/nodes`)
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(nodes => {
            renderOverview(nodes || []);
        })
        .catch(err => {
            console.error('Error loading overview:', err);
            showToast('Failed to load overview: ' + err.message, 'error');
        });
}

function loadNodes() {
    if (!dashboardState.connected) return;
    fetch(`${API_BASE}/nodes`)
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(nodes => renderNodes(nodes || []))
        .catch(err => {
            console.error('Error loading nodes:', err);
            showToast('Failed to load nodes: ' + err.message, 'error');
        });
}

function loadTasks() {
    if (!dashboardState.connected) return;
    fetch(`${API_BASE}/tasks`)
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(tasks => renderTasks(tasks || []))
        .catch(err => {
        console.error('Error loading tasks:', err);
        showToast('Failed to load tasks: ' + err.message, 'error');
    });
}

// ==========================================================================
// Node State Derivation
// ==========================================================================
function deriveNodeState(node) {
    const now = Date.now();
    const lastTelemetry = node.lastTelemetryReceivedAtMillis || 0;
    const lastHeartbeat = node.lastHeartbeatMillis || 0;
    const lastSeen = Math.max(lastTelemetry, lastHeartbeat);
    const ageMs = now - lastSeen;
    if (ageMs > 120000) return 'OFFLINE';
    if (ageMs > 30000) return 'UNHEALTHY';
    if (lastTelemetry > 0) return 'HEALTHY';
    return 'IDLE';
}

function getStateBadgeClass(state) {
    const map = { HEALTHY: 'badge-healthy', UNHEALTHY: 'badge-warning', OFFLINE: 'badge-danger', IDLE: 'badge-secondary', DISPATCHING: 'badge-primary', FAILED: 'badge-danger' };
    return map[state] || 'badge-secondary';
}

function computeCpuPercent(cpu) {
    if (cpu === undefined || cpu === null) return '—';
    return cpu.toFixed(1);
}

function computeMemoryPercent(used, total) {
    if (!total || used === undefined || total === undefined) return '—';
    return ((used / total) * 100).toFixed(1);
}

function formatLastTelemetry(ms) {
    if (!ms) return '—';
    const diff = Math.floor((Date.now() - ms) / 1000);
    if (diff < 0) return 'Just now';
    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
}

function formatTime(millis) {
    if (!millis) return '—';
    return new Date(millis).toLocaleString();
}

function escapeHtml(s) {
    if (s === null || s === undefined) return '—';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ==========================================================================
// Overview Renderer + Charts
// ==========================================================================
function renderOverview(nodes) {
    const kpiTotal = document.getElementById('kpi-total-nodes');
    const kpiHealthy = document.getElementById('kpi-healthy-nodes');
    const kpiActive = document.getElementById('kpi-active-tasks');
    const kpiCompleted = document.getElementById('kpi-completed-tasks');
    const kpiFailed = document.getElementById('kpi-failed-tasks');

    const totalNodes = nodes.length;
    const healthyNodes = nodes.filter(n => deriveNodeState(n) === 'HEALTHY').length;

    if (kpiTotal) kpiTotal.textContent = totalNodes;
    if (kpiHealthy) kpiHealthy.textContent = healthyNodes;
    if (kpiActive) kpiActive.textContent = '—';
    if (kpiCompleted) kpiCompleted.textContent = '—';
    if (kpiFailed) kpiFailed.textContent = '—';

    const content = document.getElementById('overview-content');
    if (!content) return;

    if (totalNodes === 0) {
        content.innerHTML = `<div class="empty" style="padding:32px 24px;"><div class="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><h3>No registered nodes found</h3><p>The cluster is empty. Register node agents to see cluster information.</p></div>`;
        return;
    }

    // Node status table
    let html = `<div class="table-container"><table><thead><tr><th>Node ID</th><th>State</th><th>CPU %</th><th>Mem %</th><th>Battery %</th><th>Last Telemetry</th></tr></thead><tbody>`;
    nodes.forEach(node => {
        const state = deriveNodeState(node);
        html += `<tr>
            <td><strong>${escapeHtml(node.nodeId)}</strong></td>
            <td><span class="badge ${getStateBadgeClass(state)}">${state}</span></td>
            <td>${computeCpuPercent(node.latestTelemetry?.cpuUtilizationPercent)}</td>
            <td>${computeMemoryPercent(node.latestTelemetry?.usedMemoryBytes, node.latestTelemetry?.totalMemoryBytes)}</td>
            <td>${node.latestTelemetry?.batteryLevelPercent !== undefined ? node.latestTelemetry.batteryLevelPercent.toFixed(1) : '—'}</td>
            <td>${formatLastTelemetry(node.lastTelemetryReceivedAtMillis)}</td>
        </tr>`;
    });
    html += `</tbody></table></div>`;

    // Task status distribution chart (real data from GET /tasks)
    html += `<div class="card" style="grid-column:1/-1;margin-top:4px;">
        <div class="card-header"><h3>Task Status Distribution</h3></div>
        <div class="card-body" id="task-status-chart"><p class="caption" style="padding:8px 0;">Loading task data…</p></div>
    </div>`;

    content.innerHTML = html;

    // Fetch tasks for chart
    fetch(`${API_BASE}/tasks`)
        .then(r => r.ok ? r.json() : [])
        .then(tasks => renderTaskStatusChart(tasks || []))
        .catch(() => {
            const el = document.getElementById('task-status-chart');
            if (el) el.innerHTML = '<p class="caption" style="padding:8px 0;color:var(--color-text-caption);">Task data unavailable.</p>';
        });
}

// ==========================================================================
// Task Status Distribution Chart (SVG bar chart, real data)
// ==========================================================================
const TASK_STATES = ['ACCEPTED', 'DISPATCHING', 'DISPATCH_ACCEPTED', 'RUNNING', 'SUCCEEDED', 'FAILED', 'OUTCOME_UNKNOWN', 'NO_FEASIBLE_NODE', 'UNRESOLVED_SCHEDULING', 'DISPATCH_REJECTED'];

function renderTaskStatusChart(tasks) {
    const container = document.getElementById('task-status-chart');
    if (!container) return;

    if (!tasks.length) {
        container.innerHTML = '<p class="caption" style="padding:8px 0;color:var(--color-text-caption);">No tasks submitted yet.</p>';
        return;
    }

    const counts = {};
    tasks.forEach(t => { const s = t.state || 'UNKNOWN'; counts[s] = (counts[s] || 0) + 1; });

    // Update KPI values from task list
    const active = ['ACCEPTED', 'DISPATCHING', 'DISPATCH_ACCEPTED', 'RUNNING'].reduce((s, st) => s + (counts[st] || 0), 0);
    const completed = counts['SUCCEEDED'] || 0;
    const failed = counts['FAILED'] || 0;
    const kpiA = document.getElementById('kpi-active-tasks');
    const kpiC = document.getElementById('kpi-completed-tasks');
    const kpiF = document.getElementById('kpi-failed-tasks');
    if (kpiA) kpiA.textContent = active;
    if (kpiC) kpiC.textContent = completed;
    if (kpiF) kpiF.textContent = failed;

    const activeStates = TASK_STATES.filter(s => counts[s] > 0);
    const maxCount = Math.max(...activeStates.map(s => counts[s]), 1);
    const barWidth = 160;
    const barH = 22;
    const gap = 6;
    const height = activeStates.length * (barH + gap) + 10;

    const colors = {
        SUCCEEDED: '#16A34A', FAILED: '#DC2626', RUNNING: '#7C3AED',
        ACCEPTED: '#A855F7', DISPATCHING: '#A855F7', DISPATCH_ACCEPTED: '#7C3AED',
        OUTCOME_UNKNOWN: '#D97706', NO_FEASIBLE_NODE: '#DC2626',
        UNRESOLVED_SCHEDULING: '#D97706', DISPATCH_REJECTED: '#DC2626',
    };

    let svg = `<svg width="100%" height="${height}" viewBox="0 0 ${barWidth + 260} ${height}" role="img" aria-label="Task status distribution">`;
    activeStates.forEach((s, i) => {
        const y = i * (barH + gap) + 4;
        const w = (counts[s] / maxCount) * barWidth;
        const color = colors[s] || '#7C3AED';
        svg += `<text x="0" y="${y + 15}" font-size="11" font-family="ui-monospace,monospace" fill="#71717A">${s}</text>`;
        svg += `<rect x="140" y="${y + 3}" width="${w}" height="${barH - 6}" rx="4" fill="${color}" opacity="0.85"/>`;
        svg += `<text x="${140 + w + 6}" y="${y + 15}" font-size="11" font-family="ui-monospace,monospace" fill="#18181B" font-weight="600">${counts[s]}</text>`;
    });
    svg += `</svg>`;
    container.innerHTML = svg;
}

// ==========================================================================
// Nodes Renderer
// ==========================================================================
function renderNodes(nodes) {
    const tableBody = document.getElementById('nodes-table-body');
    const emptyDiv = document.getElementById('nodes-empty');
    if (!tableBody) return;

    if (nodes.length === 0) {
        tableBody.innerHTML = '';
        if (emptyDiv) emptyDiv.style.display = 'flex';
        return;
    }
    if (emptyDiv) emptyDiv.style.display = 'none';

    tableBody.innerHTML = nodes.map(node => {
        const state = deriveNodeState(node);
        return `<tr>
            <td><strong>${escapeHtml(node.nodeId)}</strong></td>
            <td><span class="badge ${getStateBadgeClass(state)}">${state}</span></td>
            <td>${computeCpuPercent(node.latestTelemetry?.cpuUtilizationPercent)}</td>
            <td>${computeMemoryPercent(node.latestTelemetry?.usedMemoryBytes, node.latestTelemetry?.totalMemoryBytes)}</td>
            <td>${node.latestTelemetry?.batteryLevelPercent !== undefined ? node.latestTelemetry.batteryLevelPercent.toFixed(1) : '—'}</td>
            <td>${formatLastTelemetry(node.lastTelemetryReceivedAtMillis)}</td>
            <td>${escapeHtml(node.agentVersion)}</td>
            <td><button class="btn btn-sm btn-secondary" onclick="openNodeDetail('${escapeHtml(node.nodeId)}')">Detail</button></td>
        </tr>`;
    }).join('');
}

// ==========================================================================
// Tasks Renderer (Recent Tasks list)
// ==========================================================================
function renderTasks(tasks) {
    const tbody = document.getElementById('tasks-table-body');
    const emptyDiv = document.getElementById('tasks-empty');
    if (!tbody) return;

    if (!tasks.length) {
        tbody.innerHTML = '';
        if (emptyDiv) emptyDiv.style.display = 'flex';
        return;
    }
    if (emptyDiv) emptyDiv.style.display = 'none';

    const stateClass = s => {
        if (s === 'SUCCEEDED') return 'badge-healthy';
        if (s === 'FAILED' || s === 'DISPATCH_REJECTED' || s === 'NO_FEASIBLE_NODE') return 'badge-danger';
        if (s === 'OUTCOME_UNKNOWN' || s === 'UNRESOLVED_SCHEDULING') return 'badge-warning';
        if (s === 'RUNNING' || s === 'DISPATCHING') return 'badge-primary';
        return 'badge-secondary';
    };

    const sorted = tasks.slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 50);

    tbody.innerHTML = sorted.map(t => `<tr class="task-row" onclick="openTaskDetail('${escapeHtml(t.taskId)}')" style="cursor:pointer">
        <td><strong style="font-family:var(--font-mono);font-size:12px;">${escapeHtml(t.taskId)}</strong></td>
        <td><span class="badge ${stateClass(t.state)}">${escapeHtml(t.state)}</span></td>
        <td>${escapeHtml(t.workloadReference)}</td>
        <td>${t.selectedNodeId ? `<span style="font-family:var(--font-mono);font-size:11px;">${escapeHtml(t.selectedNodeId)}</span>` : '—'}</td>
        <td style="font-size:11px;color:var(--color-text-caption);">${formatLastTelemetry(t.createdAt)}</td>
    </tr>`).join('');
}

// ==========================================================================
// Node Detail
// ==========================================================================
function openNodeDetail(nodeId) {
    fetch(`${API_BASE}/nodes/${encodeURIComponent(nodeId)}`)
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(node => {
            renderNodeDetailModal(node);
        })
        .catch(err => showToast('Could not load node detail: ' + err.message, 'error'));
}

function renderNodeDetailModal(node) {
    let modal = document.getElementById('node-detail-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'node-detail-modal';
        modal.className = 'modal-overlay';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.innerHTML = `<div class="modal-content modal-large"><div class="modal-header"><h3 id="node-detail-title">Node Detail</h3><button class="close-btn" aria-label="Close">×</button></div><div class="modal-body" id="node-detail-body"></div></div>`;
        document.body.appendChild(modal);
        modal.querySelector('.close-btn').addEventListener('click', () => modal.classList.remove('open'));
        modal.addEventListener('click', e => { if (e.target === modal) modal.classList.remove('open'); });
    }

    const state = deriveNodeState(node);
    const t = node.latestTelemetry;
    let html = `<div class="kv-list">
        <div class="kv-item"><span class="kv-label">Node ID</span><span class="kv-value">${escapeHtml(node.nodeId)}</span></div>
        <div class="kv-item"><span class="kv-label">Status</span><span class="badge ${getStateBadgeClass(state)}">${state}</span></div>
        <div class="kv-item"><span class="kv-label">Hostname</span><span class="kv-value">${escapeHtml(node.hostname)}</span></div>
        <div class="kv-item"><span class="kv-label">Port</span><span class="kv-value">${node.port}</span></div>
        <div class="kv-item"><span class="kv-label">Agent Version</span><span class="kv-value">${escapeHtml(node.agentVersion)}</span></div>
        <div class="kv-item"><span class="kv-label">Registered</span><span class="kv-value">${formatTime(node.registeredAtMillis)}</span></div>
        <div class="kv-item"><span class="kv-label">Last Heartbeat</span><span class="kv-value">${formatTime(node.lastHeartbeatMillis)}</span></div>
        <div class="kv-item"><span class="kv-label">Last Telemetry</span><span class="kv-value">${formatTime(node.lastTelemetryReceivedAtMillis)}</span></div>
        <div class="kv-item"><span class="kv-label">Stale Rejected</span><span class="kv-value">${node.staleObservationsRejected}</span></div>
    </div>`;

    if (t) {
        html += `<h4 style="margin-top:16px;font-size:13px;">Latest Telemetry</h4>
        <div class="kv-list" style="margin-top:8px;">
            <div class="kv-item"><span class="kv-label">CPU</span><span class="kv-value">${t.cpuUtilizationPercent != null ? t.cpuUtilizationPercent.toFixed(1) + '%' : '—'}</span></div>
            <div class="kv-item"><span class="kv-label">Memory</span><span class="kv-value">${computeMemoryPercent(t.usedMemoryBytes, t.totalMemoryBytes)}% used</span></div>
            <div class="kv-item"><span class="kv-label">Battery</span><span class="kv-value">${t.batteryLevelPercent != null ? t.batteryLevelPercent.toFixed(1) + '%' : '—'}</span></div>
            <div class="kv-item"><span class="kv-label">Temperature</span><span class="kv-value">${t.temperatureCelsius != null ? t.temperatureCelsius.toFixed(1) + '°C' : '—'}</span></div>
            <div class="kv-item"><span class="kv-label">Latency</span><span class="kv-value">${t.latencyMs != null ? t.latencyMs.toFixed(1) + 'ms' : '—'}</span></div>
            <div class="kv-item"><span class="kv-label">Packet Loss</span><span class="kv-value">${t.packetLossPercent != null ? t.packetLossPercent.toFixed(2) + '%' : '—'}</span></div>
        </div>`;
    }

    // Observation history chart (real data)
    if (node.observationHistory && node.observationHistory.length >= 2) {
        html += `<h4 style="margin-top:16px;font-size:13px;">CPU Observation History</h4>
        <div id="node-history-chart" style="margin-top:8px;"></div>`;
    }

    // Belief state
    if (node.beliefState && node.beliefState.beliefs) {
        html += `<h4 style="margin-top:16px;font-size:13px;">Belief State</h4><div class="kv-list" style="margin-top:8px;">`;
        Object.values(node.beliefState.beliefs).forEach(b => {
            html += `<div class="kv-item"><span class="kv-label">${escapeHtml(b.resourceName)}</span><span class="kv-value">mean=${b.posteriorMean.toFixed(2)} σ=${b.posteriorStdDev.toFixed(2)} n=${b.observationCount}</span></div>`;
        });
        html += `</div>`;
    }

    document.getElementById('node-detail-title').textContent = 'Node Detail — ' + node.nodeId;
    document.getElementById('node-detail-body').innerHTML = html;
    modal.classList.add('open');

    // Render history sparkline if applicable
    if (node.observationHistory && node.observationHistory.length >= 2) {
        renderSparkline('node-history-chart', node.observationHistory);
    }
}

// ==========================================================================
// Sparkline Chart (real observation history data)
// ==========================================================================
function renderSparkline(containerId, observations) {
    const container = document.getElementById(containerId);
    if (!container || !observations || observations.length < 2) return;

    const cpuData = observations.filter(o => o.cpuUtilizationPercent != null).reverse();
    if (cpuData.length < 2) {
        container.innerHTML = '<p class="caption">Not enough CPU observations.</p>';
        return;
    }

    const values = cpuData.map(o => o.cpuUtilizationPercent);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min || 1;
    const w = 400, h = 60, pad = 4;

    const points = values.map((v, i) => {
        const x = pad + (i / (values.length - 1)) * (w - 2 * pad);
        const y = h - pad - ((v - min) / range) * (h - 2 * pad);
        return `${x},${y}`;
    }).join(' ');

    container.innerHTML = `<svg width="100%" height="${h}" viewBox="0 0 ${w} ${h}" role="img" aria-label="CPU utilization observation history">
        <polyline points="${points}" fill="none" stroke="#7C3AED" stroke-width="2" stroke-linejoin="round"/>
        <text x="${pad}" y="${h - 1}" font-size="9" fill="#A1A1AA">${min.toFixed(1)}%</text>
        <text x="${w - pad}" y="${h - 1}" font-size="9" fill="#A1A1AA" text-anchor="end">${max.toFixed(1)}%</text>
        <text x="${w / 2}" y="12" font-size="10" fill="#71717A" text-anchor="middle">CPU % (${values.length} observations)</text>
    </svg>`;
}

// ==========================================================================
// Task Submission
// ==========================================================================
function initTaskForm() {
    const cancelBtn = document.getElementById('cancel-task-submit');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            const form = document.getElementById('task-submission-form');
            if (form) form.reset();
            const err = document.getElementById('task-submission-error');
            if (err) err.style.display = 'none';
        });
    }
}

function submitTask() {
    const taskId = document.getElementById('sub-task-id').value.trim();
    if (!taskId) {
        showFormError('task-submission-error', 'Task ID is required');
        return;
    }

    const submission = {
        taskId: taskId,
        taskClass: document.getElementById('sub-task-class').value,
        workloadReference: document.getElementById('sub-workload').value,
        inputCharacteristics: document.getElementById('sub-input-chars').value.trim() || undefined,
        expectedDurationMillis: parseInt(document.getElementById('sub-duration').value) || 60000,
        resources: {
            requiredMemoryBytes: parseInt(document.getElementById('req-memory').value) || null,
            requiredStorageBytes: parseInt(document.getElementById('req-storage').value) || null,
            acceleratorRequired: document.getElementById('sub-accel-req').value === 'true',
            requiredAcceleratorMemoryBytes: parseInt(document.getElementById('req-accel-memory').value) || null,
            requiredComputeUnits: parseFloat(document.getElementById('req-compute-units').value) || null
        },
        constraints: {
            deadlineEpochMillis: parseInt(document.getElementById('sub-deadline').value) || null,
            expectedDurationMillis: parseInt(document.getElementById('sub-duration').value) || null,
            minimumBatteryPercent: parseFloat(document.getElementById('sub-min-battery').value) || null,
            maximumNetworkLatencyMillis: parseFloat(document.getElementById('sub-max-latency').value) || null,
            maximumPacketLossPercent: parseFloat(document.getElementById('sub-max-loss').value) || null,
            interruptionTolerance: document.getElementById('sub-interrupt-tol').value || null,
            requiredExecutionProfile: document.getElementById('sub-exec-profile').value.trim() || null
        }
    };

    fetch(`${API_BASE}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submission)
    })
    .then(response => {
        if (!response.ok) return response.json().then(err => { throw new Error(err.message || JSON.stringify(err) || 'Submission failed'); });
        return response.json();
    })
    .then(() => {
        showToast(`Task "${submission.taskId}" submitted successfully`, 'success');
        const errEl = document.getElementById('task-submission-error');
        if (errEl) errEl.style.display = 'none';
        const form = document.getElementById('task-submission-form');
        if (form) form.reset();
        loadTasks();
        loadOverview();
    })
    .catch(error => {
        console.error('Task submission error:', error);
        showFormError('task-submission-error', error.message || 'Submission failed.');
        showToast('Task submission failed: ' + error.message, 'error');
    });
}

function showFormError(containerId, message) {
    const container = document.getElementById(containerId);
    if (container) {
        container.style.display = 'block';
        container.textContent = message;
    }
}

function showMessage(containerId, type, message) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const color = type === 'success' ? 'var(--color-success)' : type === 'failed' ? 'var(--color-danger)' : 'var(--color-text-dim)';
    container.innerHTML = `<div style="padding:8px 12px;border-radius:var(--radius-sm);margin:8px 0;font-size:12px;color:${color};">${message}</div>`;
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('open');
}

// ==========================================================================
// Decision Inspector (Scheduler Intelligence)
// ==========================================================================
function openTaskDetail(taskId) {
    if (!dashboardState.connected) {
        showToast('Server not connected.', 'error');
        return;
    }

    fetch(`${API_BASE}/tasks/${encodeURIComponent(taskId)}`)
        .then(async r => { if (!r.ok) throw new Error(await r.text() || 'HTTP ' + r.status); return r.json(); })
        .then(task => {
            renderTaskDetailModal(task);
        })
        .catch(err => {
            console.error('Error fetching task detail:', err);
            showToast('Could not load task detail: ' + err.message, 'error');
        });
}

function renderTaskDetailModal(task) {
    let modal = document.getElementById('task-detail-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'task-detail-modal';
        modal.className = 'modal-overlay';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.innerHTML = `<div class="modal-content modal-large"><div class="modal-header"><h3 id="task-detail-title">Task Detail</h3><button class="close-btn" aria-label="Close">×</button></div><div class="modal-body" id="task-detail-body"></div></div>`;
        document.body.appendChild(modal);
        modal.querySelector('.close-btn').addEventListener('click', () => modal.classList.remove('open'));
        modal.addEventListener('click', e => { if (e.target === modal) modal.classList.remove('open'); });
    }

    document.getElementById('task-detail-title').textContent = `Task — ${task.taskId}`;

    let html = `<div class="kv-list">
        <div class="kv-item"><span class="kv-label">Task ID</span><span class="kv-value">${escapeHtml(task.taskId)}</span></div>
        <div class="kv-item"><span class="kv-label">State</span><span class="badge ${task.state === 'SUCCEEDED' ? 'badge-healthy' : task.state === 'FAILED' ? 'badge-danger' : 'badge-primary'}">${escapeHtml(task.state)}</span></div>
        <div class="kv-item"><span class="kv-label">Description</span><span class="kv-value" style="font-family:var(--font-sans);">${escapeHtml(task.stateDescription)}</span></div>
        <div class="kv-item"><span class="kv-label">Workload</span><span class="kv-value">${escapeHtml(task.workloadReference)}</span></div>
        <div class="kv-item"><span class="kv-label">Task Class</span><span class="kv-value">${escapeHtml(task.taskClass)}</span></div>
        ${task.selectedNodeId ? `<div class="kv-item"><span class="kv-label">Assigned Node</span><span class="kv-value">${escapeHtml(task.selectedNodeId)}</span></div>` : ''}
        ${task.schedulingStatus ? `<div class="kv-item"><span class="kv-label">Scheduling Status</span><span class="kv-value">${escapeHtml(task.schedulingStatus)}</span></div>` : ''}
        <div class="kv-item"><span class="kv-label">Created</span><span class="kv-value">${formatTime(task.createdAt)}</span></div>
        <div class="kv-item"><span class="kv-label">Updated</span><span class="kv-value">${formatTime(task.updatedAt)}</span></div>
    </div>`;

    if (task.result) {
        html += `<h4 style="margin-top:14px;font-size:13px;">Result</h4><div class="kv-list" style="margin-top:6px;">
            <div class="kv-item"><span class="kv-label">Success</span><span class="kv-value">${task.result.success ? 'Yes' : 'No'}</span></div>
            ${task.result.durationMillis != null ? `<div class="kv-item"><span class="kv-label">Duration</span><span class="kv-value">${task.result.durationMillis}ms</span></div>` : ''}
            ${task.result.error ? `<div class="kv-item"><span class="kv-label">Error</span><span class="kv-value" style="color:var(--color-danger);">${escapeHtml(task.result.error)}</span></div>` : ''}
        </div>`;
    }

    if (task.errorMessage) {
        html += `<div style="margin-top:10px;padding:8px 12px;background:var(--color-danger-soft);color:var(--color-danger);border-radius:var(--radius-sm);font-size:12px;">${escapeHtml(task.errorMessage)}</div>`;
    }

    // History
    if (task.history && task.history.length) {
        html += `<h4 style="margin-top:14px;font-size:13px;">Lifecycle History</h4><div class="history-list" style="margin-top:6px;">`;
        task.history.forEach(h => {
            html += `<div class="history-item">
                <span class="history-time">${formatLastTelemetry(h.timestamp)}</span>
                <span class="history-transition"><span class="history-from">${escapeHtml(h.from)}</span><span class="history-arrow">→</span><span class="history-to">${escapeHtml(h.to)}</span></span>
                <span class="history-detail">${escapeHtml(h.detail)}</span>
            </div>`;
        });
        html += `</div>`;
    }

    document.getElementById('task-detail-body').innerHTML = html;
    modal.classList.add('open');

    // Also fetch and show scheduling decision
    loadDecisionForTask(task.taskId);
}

function loadDecisionForTask(taskId) {
    fetch(`${API_BASE}/tasks/${encodeURIComponent(taskId)}/decision`)
        .then(r => r.ok ? r.json() : null)
        .then(decision => {
            if (!decision) return;
            renderDecisionDetail(decision);
        })
        .catch(() => { /* no decision available */ });
}

function renderDecisionDetail(decision) {
    const traceBody = document.getElementById('decision-trace-body');
    const comparisonBody = document.getElementById('candidate-comparison-body');
    if (!traceBody || !comparisonBody) return;

    // Trace
    let traceHtml = `<div class="kv-list">
        <div class="kv-item"><span class="kv-label">Task</span><span class="kv-value">${escapeHtml(decision.taskId)}</span></div>
        <div class="kv-item"><span class="kv-label">Status</span><span class="kv-value">${escapeHtml(decision.status)}</span></div>
        <div class="kv-item"><span class="kv-label">Selected Node</span><span class="kv-value">${decision.selectedNodeId ? escapeHtml(decision.selectedNodeId) : '—'}</span></div>
        <div class="kv-item"><span class="kv-label">Reliability</span><span class="kv-value">${decision.selectedReliability != null ? (decision.selectedReliability * 100).toFixed(1) + '%' : '—'}</span></div>
        ${decision.policyThreshold != null ? `<div class="kv-item"><span class="kv-label">Policy Threshold</span><span class="kv-value">${(decision.policyThreshold * 100).toFixed(1)}%</span></div>` : ''}
        <div class="kv-item"><span class="kv-label">Fallback</span><span class="kv-value">${decision.policyFallback ? 'Yes' : 'No'}</span></div>
    </div>`;
    if (decision.derivation) {
        traceHtml += `<div style="margin-top:10px;padding:10px;background:var(--color-bg-subtle);border-radius:var(--radius-sm);font-size:12px;line-height:1.5;color:var(--color-text-dim);">${escapeHtml(decision.derivation)}</div>`;
    }
    if (decision.reasons && decision.reasons.length) {
        traceHtml += `<div style="margin-top:8px;">${decision.reasons.map(r => `<span class="chip" style="margin-right:4px;">${escapeHtml(r)}</span>`).join('')}</div>`;
    }
    traceBody.innerHTML = traceHtml;

    // Candidates
    if (decision.candidates && decision.candidates.length) {
        let cmpHtml = `<div class="candidate-comparison">`;
        decision.candidates.forEach(c => {
            const selected = c.nodeId === decision.selectedNodeId;
            cmpHtml += `<div class="candidate-card${selected ? ' selected' : ''}">
                <div class="candidate-info">
                    <span class="candidate-node">${escapeHtml(c.nodeId)}</span>
                    <span class="candidate-reliability">${c.reliability != null ? (c.reliability * 100).toFixed(1) + '% reliability' : 'reliability —'}</span>
                </div>
                <div class="candidate-metrics">
                    <span class="metric">Capability: ${c.capability != null ? (c.capability * 100).toFixed(1) + '%' : '—'}</span>
                    <span class="metric">${escapeHtml(c.disposition)}</span>
                    <span class="metric">${c.eligible ? 'eligible' : 'ineligible'}</span>
                    ${(c.rejectionReasons && c.rejectionReasons.length) ? c.rejectionReasons.map(r => `<span class="metric">${escapeHtml(r)}</span>`).join('') : ''}
                </div>
                ${c.explanation ? `<p class="caption" style="margin-top:4px;font-size:11px;">${escapeHtml(c.explanation)}</p>` : ''}
            </div>`;
        });
        cmpHtml += `</div>`;
        comparisonBody.innerHTML = cmpHtml;
    } else {
        comparisonBody.innerHTML = '<p class="caption">No candidate data available.</p>';
    }
}

function selectCandidate(nodeId) {
    document.querySelectorAll('.candidate-card').forEach(c => c.classList.remove('selected'));
}

// ==========================================================================
// Onboarding — "Add a Node"
// ==========================================================================
const ONBOARDING_DOWNLOAD_URLS = { windows: null, linux: null, macos: null };

function detectBrowserOS() {
    const ua = navigator.userAgent;
    if (/windows/i.test(ua)) return 'windows';
    if (/macintosh|mac os x/i.test(ua)) return 'macos';
    if (/linux/i.test(ua)) return 'linux';
    return null;
}

function osLabel(os) {
    const labels = { windows: 'Windows', linux: 'Linux', macos: 'macOS' };
    return labels[os] || os;
}

function setupInstructions(os) {
    const items = {
        windows: [
            'Install Java 21 or later.',
            'Download the Node Agent launcher for Windows (pcst-agent.bat) and the shaded JAR using the download link above.',
            'Open a terminal and set the Master endpoint:',
            '  set PCST_MASTER_HOST=&lt;your-master-host&gt;',
            '  set PCST_MASTER_PORT=9090',
            '  set PCST_NODE_ID=&lt;your-node-name&gt;',
            'Run the agent:  pcst-agent.bat',
            'Alternative:  java -jar pcst-node-agent-1.0.0-SNAPSHOT.jar',
            'Configuration can also be placed in config/pcst-agent.properties (excluded from Git).'
        ],
        linux: [
            'Install Java 21 or later.',
            'Download the Node Agent launcher for Linux (pcst-agent.sh) and the shaded JAR using the download link above.',
            'Open a terminal and set the Master endpoint:',
            '  export PCST_MASTER_HOST=&lt;your-master-host&gt;',
            '  export PCST_MASTER_PORT=9090',
            '  export PCST_NODE_ID=&lt;your-node-name&gt;',
            'Make the launcher executable:  chmod +x pcst-agent.sh',
            'Run the agent:  ./pcst-agent.sh',
            'Configuration can also be placed in config/pcst-agent.properties (excluded from Git).'
        ],
        macos: [
            'Install Java 21 or later.',
            'Download the Node Agent launcher for macOS (pcst-agent.sh) and the shaded JAR using the download link above.',
            'Open a terminal and set the Master endpoint:',
            '  export PCST_MASTER_HOST=&lt;your-master-host&gt;',
            '  export PCST_MASTER_PORT=9090',
            '  export PCST_NODE_ID=&lt;your-node-name&gt;',
            'Make the launcher executable:  chmod +x pcst-agent.sh',
            'Run the agent:  ./pcst-agent.sh',
            'Configuration can also be placed in config/pcst-agent.properties (excluded from Git).'
        ]
    };
    return (items[os] || items.windows).map(i => `<li>${i}</li>`).join('');
}

function renderOnboardingDownload() {
    const select = document.getElementById('onboarding-os-select');
    const linksDiv = document.getElementById('onboarding-download-links');
    const noticeDiv = document.getElementById('onboarding-download-notice');
    if (!select || !linksDiv || !noticeDiv) return;

    const os = select.value;
    const url = ONBOARDING_DOWNLOAD_URLS[os];

    linksDiv.innerHTML = '';
    if (url) {
        const a = document.createElement('a');
        a.href = url;
        a.textContent = `Download PCST Node Agent for ${osLabel(os)}`;
        a.className = 'btn btn-primary btn-sm';
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        linksDiv.appendChild(a);
        noticeDiv.textContent = '';
        noticeDiv.style.display = 'none';
    } else {
        linksDiv.innerHTML = '<span class="caption" style="font-size:12px;">No download link configured.</span>';
        noticeDiv.textContent = 'No published release artifact is available yet. Download links are configured in app.js (ONBOARDING_DOWNLOAD_URLS) and will be wired up when a release is published. In the meantime, build the agent from source: mvn -pl pcst-node-agent package';
        noticeDiv.style.display = 'block';
    }
}

function renderOnboardingInstructions() {
    const select = document.getElementById('onboarding-os-select');
    const div = document.getElementById('onboarding-setup-instructions');
    if (!select || !div) return;
    div.innerHTML = `<h4 style="margin-top:0;">${osLabel(select.value)} setup</h4><ul style="margin-left:18px;font-size:12px;color:var(--color-text-dim);line-height:1.7;">${setupInstructions(select.value)}</ul>`;
}

function renderOnboardingNodes(nodes) {
    const div = document.getElementById('onboarding-nodes-list');
    if (!div) return;
    if (!nodes || nodes.length === 0) {
        div.innerHTML = '<p class="caption" style="font-size:12px;">No nodes are currently registered. Run and pair a Node Agent to see it appear here.</p>';
        return;
    }
    div.innerHTML = `<div class="table-container"><table style="min-width:100%"><thead><tr><th>Node ID</th><th>State</th><th>Agent Version</th><th>Last Telemetry</th></tr></thead><tbody>` +
        nodes.map(node => {
            const state = deriveNodeState(node);
            const last = node.lastTelemetryReceivedAtMillis ? formatLastTelemetry(node.lastTelemetryReceivedAtMillis) : '—';
            return `<tr><td><strong>${escapeHtml(node.nodeId)}</strong></td><td><span class="badge ${getStateBadgeClass(state)}">${state}</span></td><td>${escapeHtml(node.agentVersion)}</td><td>${last}</td></tr>`;
        }).join('') + `</tbody></table></div>`;
}

function loadOnboardingStatus() {
    const statusDiv = document.getElementById('onboarding-status');
    const errorDiv = document.getElementById('onboarding-error');
    const btn = document.getElementById('onboarding-refresh-status');
    if (statusDiv) statusDiv.textContent = 'Loading…';
    if (errorDiv) { errorDiv.style.display = 'none'; errorDiv.textContent = ''; }
    if (btn) btn.disabled = true;

    fetch(`${API_BASE}/nodes`)
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(nodes => {
            const count = Array.isArray(nodes) ? nodes.length : 0;
            if (statusDiv) statusDiv.textContent = `${count} node(s) registered on this Master`;
            renderOnboardingNodes(nodes);
            if (btn) btn.disabled = false;
        })
        .catch(err => {
            console.error('Onboarding status error:', err);
            if (statusDiv) statusDiv.textContent = 'Status unavailable';
            if (errorDiv) {
                errorDiv.textContent = `Could not reach the Master (${err.message}). Check that the Master is running and reachable, then retry.`;
                errorDiv.style.display = 'block';
            }
            if (btn) btn.disabled = false;
        });
}

function initOnboarding() {
    const select = document.getElementById('onboarding-os-select');
    const detected = detectBrowserOS();
    const detectedDiv = document.getElementById('onboarding-detected-os');
    if (detectedDiv) {
        detectedDiv.textContent = detected
            ? `Detected operating system: ${osLabel(detected)} (browser detection is a convenience only — verify below).`
            : 'Operating system could not be detected automatically. Please select it manually.';
    }
    if (select && detected) select.value = detected;
    if (select) {
        select.addEventListener('change', () => {
            renderOnboardingDownload();
            renderOnboardingInstructions();
        });
    }
    const btn = document.getElementById('onboarding-refresh-status');
    if (btn) btn.addEventListener('click', loadOnboardingStatus);

    renderOnboardingDownload();
    renderOnboardingInstructions();
    loadOnboardingStatus();
    initAdminPairing();
}

// ==========================================================================
// Admin Pairing
// ==========================================================================
function initAdminPairing() {
    const btn = document.getElementById('admin-generate-code');
    const resultDiv = document.getElementById('admin-pairing-result');
    const errorDiv = document.getElementById('admin-pairing-error');
    const activeDiv = document.getElementById('admin-active-codes');
    if (!btn || !resultDiv || !errorDiv || !activeDiv) return;

    btn.addEventListener('click', () => {
        const apiKey = document.getElementById('admin-api-key').value.trim();
        const nodeIdHint = document.getElementById('admin-node-id-hint').value.trim();
        resultDiv.style.display = 'none';
        resultDiv.textContent = '';
        errorDiv.style.display = 'none';
        errorDiv.textContent = '';
        btn.disabled = true;
        btn.textContent = 'Generating…';

        fetch(`${API_BASE}/admin/pairing-codes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
            body: JSON.stringify({ nodeIdHint: nodeIdHint || undefined })
        })
            .then(async response => {
                const body = await response.json().catch(() => ({}));
                if (!response.ok) throw new Error(body.message || body.error || 'HTTP ' + response.status);
                return body;
            })
            .then(data => {
                resultDiv.style.display = 'block';
                resultDiv.style.background = 'var(--color-success-soft)';
                resultDiv.style.color = 'var(--color-success)';
                resultDiv.innerHTML =
                    '<strong>Pairing code issued (show it once — it is single-use):</strong><br>' +
                    '<code style="font-family:var(--font-mono);font-size:14px;">' + escapeHtml(data.code || '—') + '</code><br>' +
                    'Expires: ' + formatTime(data.expiresAtMillis) + '<br>' +
                    (data.nodeIdHint ? 'Bound node id hint: ' + escapeHtml(data.nodeIdHint) + '<br>' : '') +
                    'Communicate the code to the device operator out-of-band. Run the agent with PCST_PAIRING_CODE=<code>';
                showToast('Pairing code generated', 'success');
                listActivePairingCodes(apiKey);
            })
            .catch(error => {
                errorDiv.textContent = 'Failed to issue pairing code: ' + error.message;
                errorDiv.style.display = 'block';
                showToast('Pairing code generation failed: ' + error.message, 'error');
            })
            .finally(() => {
                btn.disabled = false;
                btn.textContent = 'Generate pairing code';
            });
    });

    listActivePairingCodes(null);
}

function listActivePairingCodes(apiKey) {
    const activeDiv = document.getElementById('admin-active-codes');
    if (!activeDiv) return;
    const headers = {};
    if (apiKey) headers['Authorization'] = 'Bearer ' + apiKey;
    fetch(`${API_BASE}/admin/pairing-codes`, { headers })
        .then(async response => {
            if (!response.ok) { activeDiv.innerHTML = '<p class="caption">Could not list active pairing codes.</p>'; return; }
            return response.json();
        })
        .then(data => {
            const codes = data && data.codes ? data.codes : [];
            if (codes.length === 0) { activeDiv.innerHTML = '<p class="caption">No active pairing codes.</p>'; return; }
            activeDiv.innerHTML = '<strong>Active pairing codes:</strong><ul style="margin:4px 0;font-size:12px;">' +
                codes.map(c => `<li><code>${escapeHtml(c.code)}</code> (expires ${formatTime(c.expiresAtMillis)})${c.nodeIdHint ? ' · hint: ' + escapeHtml(c.nodeIdHint) : ''}</li>`).join('') +
                '</ul>';
        })
        .catch(() => { activeDiv.innerHTML = '<p class="caption">Could not list active pairing codes.</p>'; });
}
