-- PCST persistent task state
-- One row per task/attempt. Retries use a new taskId (existing semantics).
CREATE TABLE task_records (
    task_id            VARCHAR(255) NOT NULL PRIMARY KEY,
    attempt_id         VARCHAR(255) NOT NULL,
    state              VARCHAR(64)  NOT NULL
                           CHECK (state IN ('ACCEPTED','NO_FEASIBLE_NODE','UNRESOLVED_SCHEDULING','DISPATCHING','DISPATCH_ACCEPTED','DISPATCH_REJECTED','RUNNING','SUCCEEDED','FAILED','OUTCOME_UNKNOWN')),
    created_at         BIGINT       NOT NULL,
    updated_at         BIGINT       NOT NULL,
    selected_node_id   VARCHAR(255),
    dispatch_time      BIGINT,
    error_message      TEXT,
    task               JSONB        NOT NULL,
    scheduling_decision JSONB,
    result             JSONB,
    history            JSONB        NOT NULL DEFAULT '[]'::jsonb,
    version            BIGINT       NOT NULL DEFAULT 1
);

-- Frequently queried fields in typed columns.
CREATE INDEX idx_task_records_state ON task_records(state);
CREATE INDEX idx_task_records_updated_at ON task_records(updated_at);

-- Comments for schema documentation.
COMMENT ON TABLE task_records IS 'Persistent task execution records owned by the PCST Master.';
COMMENT ON COLUMN task_records.task_id IS 'Client-provided stable task identity.';
COMMENT ON COLUMN task_records.attempt_id IS 'Master-generated unique attempt identity (UUID).';
COMMENT ON COLUMN task_records.state IS 'Task lifecycle state (TaskState enum name).';
COMMENT ON COLUMN task_records.created_at IS 'Submission timestamp (server time, epoch millis).';
COMMENT ON COLUMN task_records.updated_at IS 'Last state change timestamp (epoch millis).';
COMMENT ON COLUMN task_records.selected_node_id IS 'Node selected by scheduler, if any.';
COMMENT ON COLUMN task_records.dispatch_time IS 'Time dispatch was sent to agent, if any.';
COMMENT ON COLUMN task_records.error_message IS 'Error detail for failed/rejected states.';
COMMENT ON COLUMN task_records.task IS 'Serialized Task record (JSONB).';
COMMENT ON COLUMN task_records.scheduling_decision IS 'Serialized SchedulingDecision, if scheduling was attempted (JSONB).';
COMMENT ON COLUMN task_records.result IS 'Serialized TaskResult, if terminal (JSONB).';
COMMENT ON COLUMN task_records.history IS 'Ordered state transition history (JSONB).';
COMMENT ON COLUMN task_records.version IS 'Optimistic lock version for concurrent state transitions.';
