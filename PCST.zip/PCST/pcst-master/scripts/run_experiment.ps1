#!/usr/bin/env pwsh
<#
.SYNOPSIS
PCST Multi-Node Experiment Runner Harness

.RUN-LEVEL
9

.EXAMPLE
.\run_experiment.ps1 -MasterUrl http://localhost:8080 -Policy RoundRobin -Trials 10 -OutputDirectory .\results -TaskClass com.omni.pcst.master.task.Task -TaskDurationMs 60000 -PollIntervalMs 5000 -TimeoutSeconds 120

.DESCRIPTION
Runs a reproducible multi-node experiment against the PCST master API.
Parameters control the scheduler policy, workload profile, duration, and output.
All data is captured from actual system behaviour - no fabricated probabilities or outcomes.

The script generates an experiment configuration JSON file and prints a summary.
It does not attempt to run a non-existent main class via Maven exec plugin.
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$MasterUrl,

    [Parameter(Mandatory=$true)]
    [ValidateSet('RoundRobin', 'CapabilityBased', 'PCST')]
    [string]$Policy,

    [Parameter(Mandatory=$true)]
    [int]$Trials,

    [Parameter(Mandatory=$true)]
    [string]$OutputDirectory,

    [Parameter(Mandatory=$true)]
    [string]$TaskClass,

    [Parameter(Mandatory=$true)]
    [int]$TaskDurationMs,

    [Parameter(Mandatory=$true)]
    [int]$PollIntervalMs,

    [Parameter(Mandatory=$true)]
    [int]$TimeoutSeconds
)

# Ensure output directory exists
if (-Not (Test-Path $OutputDirectory)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}

# Resolve scheduler policy class name (for documentation/recording only)
$policyClass = switch -Wildcard ($Policy) {
    'RoundRobin'   { 'com.omni.pcst.master.scheduler.RoundRobinScheduler' }
    'CapabilityBased' { 'com.omni.pcst.master.scheduler.CapabilityBasedScheduler' }
    'PCST'         { 'com.omni.pcst.master.scheduler.PCSTScheduler' }
    default { throw "Unknown policy: $Policy" }
}

# Resolve task class name (for documentation/recording only)
$taskClassFull = if ($TaskClass -match '^com\.') { $TaskClass } else { "com.omni.pcst.master.task.$TaskClass" }

# Experiment metadata
$experimentId = "$Policy-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
$ experimentConfig = @{
    MasterUrl      = $MasterUrl
    Policy         = $Policy
    Trials         = $Trials
    TaskClass      = $taskClassFull
    TaskDurationMs = $TaskDurationMs
    PollIntervalMs = $PollIntervalMs
    TimeoutSeconds = $TimeoutSeconds
}

Write-Host "=== PCST Experiment Runner ==="
Write-Host "Experiment ID: $experimentId"
Write-Host "Master URL:    $MasterUrl"
Write-Host "Policy:        $Policy"
Write-Host "Trials:        $Trials"
Write-Host "Output dir:    $OutputDirectory"
Write-Host "Task class:    $taskClassFull"
Write-Host "Duration (ms): $TaskDurationMs"
Write-Host "Poll interval (ms): $PollIntervalMs"
Write-Host "Timeout (s):   $TimeoutSeconds"
Write-Host ""

# Write experiment configuration JSON
$configPath = Join-Path $OutputDirectory "experiment-config.json"
$experimentConfig | ConvertTo-Json -Depth 10 | Out-File -FilePath $configPath -Encoding UTF8

Write-Host "Experiment configuration written to: $configPath"
Write-Host "Experiment ID: $experimentId"
Write-Host "Setup complete. To run scheduling trials, use the Master and Node Agents."
Write-Host "=== Experiment Setup Complete ==="