import com.omni.pcst.master.evaluation.*;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
import java.nio.file.*;

public class QuickTest {
    public static void main(String[] args) throws Exception {
        Path file = Path.of("C:\\tmp\\eval.jsonl");
        Files.createDirectories(file.getParent());
        Files.deleteIfExists(file);
        TelemetryEvaluationStore store = new TelemetryEvaluationStore(file,2);
        TelemetryObservation obs = new TelemetryObservation(100L,42.0,1024L,512L,null,null,null,null,null,null,null,null,null,null,null,null);
        TelemetryEvaluationRecord rec = TelemetryEvaluationRecord.of("node-a",obs,999L,"v1");
        store.append(rec);
        store.flush();
        System.out.println("exists "+Files.exists(file));
        System.out.println("size "+Files.size(file));
        System.out.println("persisted "+store.getPersistedRecords());
        System.out.println("read "+store.readAll().size());
    }
}
