cd C:\Users\Pratham\Desktop\PCST
mvn spring-boot:run -pl pcst-master -Dspring-boot.run.arguments=--grpc.server.port=9090 > master.log 2>&1
timeout /T 5 >nul