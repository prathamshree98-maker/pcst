package com.omni.pcst.node.telemetry;

import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic tests for {@link TelemetrySequenceSource} session identity and
 * sequence numbering.
 *
 * <p>No sleeps: numbering is a pure counter, so every assertion follows directly
 * from the calls under test.
 */
class TelemetrySequenceSourceTest {

    @Test
    void freshSessionIdIsGeneratedPerInstanceAndIsNonEmpty() {
        TelemetrySequenceSource first = new TelemetrySequenceSource();
        TelemetrySequenceSource second = new TelemetrySequenceSource();

        String id1 = first.getAgentSessionId();
        String id2 = second.getAgentSessionId();

        assertNotNull(id1);
        assertFalse(id1.isBlank(), "session id must be non-empty");
        assertNotEquals(id1, id2, "two process instances must not share a session id");
        assertEquals(36, id1.length(), "a UUID string is 36 characters");
    }

    @Test
    void sessionIdIsStableWithinTheInstance() {
        TelemetrySequenceSource source = new TelemetrySequenceSource();
        String before = source.getAgentSessionId();

        for (int i = 0; i < 10; i++) {
            source.nextSequence();
            assertEquals(before, source.getAgentSessionId(),
                    "session id must not change while the process is alive");
        }
    }

    @Test
    void sessionIdsAreUniqueAcrossManyInstances() {
        Set<String> ids = new HashSet<>();
        for (int i = 0; i < 500; i++) {
            ids.add(new TelemetrySequenceSource().getAgentSessionId());
        }
        assertEquals(500, ids.size(), "every process instance gets a distinct session id");
    }

    @Test
    void sessionIdIsDistinctFromNodeIdConcept() {
        // The session id is an opaque per-process identity; it is not derived
        // from, and need not equal, the stable node id.
        TelemetrySequenceSource source = new TelemetrySequenceSource();
        String nodeId = "node-agent-1";
        assertNotEquals(nodeId, source.getAgentSessionId(),
                "session identity must be separate from the stable node id");
    }

    @Test
    void blankOrNullSessionIdIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new TelemetrySequenceSource(null));
        assertThrows(IllegalArgumentException.class, () -> new TelemetrySequenceSource(""));
        assertThrows(IllegalArgumentException.class, () -> new TelemetrySequenceSource("   "));
    }

    @Test
    void sequenceNumbersStartAtOneAndIncreaseMonotonically() {
        TelemetrySequenceSource source = new TelemetrySequenceSource();

        assertEquals(0L, source.lastIssuedSequence(), "no sequence is issued before the first snapshot");

        long previous = 0L;
        for (int expected = 1; expected <= 100; expected++) {
            long issued = source.nextSequence();
            assertEquals(expected, issued, "sequences are one-based and strictly increasing");
            assertTrue(issued > previous, "each sequence is greater than the previous");
            previous = issued;
            assertEquals(issued, source.lastIssuedSequence());
        }
    }

    @Test
    void sequenceResetsOnlyForANewSession() {
        TelemetrySequenceSource first = new TelemetrySequenceSource();
        first.nextSequence();
        first.nextSequence();
        assertEquals(2L, first.lastIssuedSequence());

        TelemetrySequenceSource restarted = new TelemetrySequenceSource();
        assertNotEquals(first.getAgentSessionId(), restarted.getAgentSessionId());
        assertEquals(1L, restarted.nextSequence(), "a new process restarts at one");
    }

    @Test
    void failedSendDoesNotReleaseOrReuseItsSequenceNumber() {
        // The number is consumed by nextSequence() before any send is attempted,
        // so a failed send (here simply not calling send) leaves it used.
        TelemetrySequenceSource source = new TelemetrySequenceSource();

        long failed = source.nextSequence();   // snapshot 1 produced, send fails
        long afterFailure = source.nextSequence(); // snapshot 2 produced

        assertEquals(1L, failed);
        assertEquals(2L, afterFailure);
        assertNotEquals(failed, afterFailure, "a failed send must not renumber or reuse its sequence");
        assertEquals(2L, source.lastIssuedSequence());
    }

    @Test
    void concurrentIssuanceIsUniqueAndGapless() throws Exception {
        int threads = 8;
        int perThread = 500;
        TelemetrySequenceSource source = new TelemetrySequenceSource();
        ConcurrentSkipListSet<Long> issued = new ConcurrentSkipListSet<>();
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        AtomicInteger duplicates = new AtomicInteger();

        ExecutorService pool = Executors.newFixedThreadPool(threads);
        try {
            for (int t = 0; t < threads; t++) {
                pool.submit(() -> {
                    try {
                        start.await();
                        for (int i = 0; i < perThread; i++) {
                            if (!issued.add(source.nextSequence())) {
                                duplicates.incrementAndGet();
                            }
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } finally {
                        done.countDown();
                    }
                });
            }
            start.countDown();
            assertTrue(done.await(30, TimeUnit.SECONDS), "all issuers finished");
        } finally {
            pool.shutdown();
            assertTrue(pool.awaitTermination(30, TimeUnit.SECONDS));
        }

        assertEquals(0, duplicates.get(), "a sequence number must never be issued twice");
        assertEquals(threads * perThread, issued.size());
        assertEquals((long) threads * perThread, source.lastIssuedSequence());

        // The issued set is exactly 1..N with nothing missing.
        List<Long> sorted = List.copyOf(issued);
        for (int i = 0; i < sorted.size(); i++) {
            assertEquals(i + 1L, sorted.get(i), "issued sequences form a gapless 1..N range");
        }
    }

    @Test
    void issuedSequenceRangeMatchesTheCounter() {
        TelemetrySequenceSource source = new TelemetrySequenceSource();
        Set<Long> seen = IntStream.rangeClosed(1, 50).mapToObj(i -> source.nextSequence())
                .collect(java.util.stream.Collectors.toSet());
        assertEquals(50, seen.size());
        assertEquals(50L, source.lastIssuedSequence());
    }
}