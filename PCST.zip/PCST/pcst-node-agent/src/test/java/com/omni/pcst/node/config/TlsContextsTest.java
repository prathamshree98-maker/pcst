package com.omni.pcst.node.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for {@link TlsContexts} TLS context creation.
 */
class TlsContextsTest {

    @Test
    void isTlsEnabledReturnsTrueForNonDisabledModes() {
        assertTrue(TlsContexts.isTlsEnabled("development"));
        assertTrue(TlsContexts.isTlsEnabled("production"));
        assertTrue(TlsContexts.isTlsEnabled("Production"));
        assertFalse(TlsContexts.isTlsEnabled("disabled"));
        assertFalse(TlsContexts.isTlsEnabled("DISABLED"));
        assertFalse(TlsContexts.isTlsEnabled(null));
    }

    @Test
    void clientContextWithMissingTrustStoreThrows(@TempDir Path dir) {
        Path missing = dir.resolve("nonexistent.pem");
        assertThrows(IOException.class, () ->
                TlsContexts.clientContext(missing.toString()));
    }

    @Test
    void clientContextWithEmptyFileThrows(@TempDir Path dir) throws Exception {
        Path empty = dir.resolve("empty.pem");
        Files.createFile(empty);
        assertThrows(IllegalArgumentException.class, () ->
                TlsContexts.clientContext(empty.toString()));
    }
}
