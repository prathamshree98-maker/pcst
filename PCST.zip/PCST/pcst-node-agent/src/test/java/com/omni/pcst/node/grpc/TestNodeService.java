package com.omni.pcst.node.grpc;

import com.omni.pcst.proto.HeartbeatRequest;
import com.omni.pcst.proto.HeartbeatResponse;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.RegisterNodeRequest;
import com.omni.pcst.proto.RegisterNodeResponse;
import com.omni.pcst.proto.TelemetryRequest;
import com.omni.pcst.proto.TelemetryResponse;
import io.grpc.stub.StreamObserver;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * In-process test double for the Master {@link NodeServiceGrpc.NodeServiceImplBase}.
 *
 * <p>Every response can be forced to be unsuccessful, call counters and registration
 * timestamps are recorded, and registrations can be held open on a latch so that
 * concurrent recovery attempts become observable. Counters are read directly by tests,
 * which makes the outcomes deterministic instead of timing dependent.
 */
public class TestNodeService extends NodeServiceGrpc.NodeServiceImplBase {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TestNodeService.class);

    private final AtomicBoolean acceptRegistration = new AtomicBoolean(true);
    private final AtomicBoolean acknowledgeHeartbeat = new AtomicBoolean(true);
    private final AtomicBoolean acceptTelemetry = new AtomicBoolean(true);

    private final AtomicInteger registrationCalls = new AtomicInteger();
    private final AtomicInteger acceptedRegistrations = new AtomicInteger();
    private final AtomicInteger heartbeatCalls = new AtomicInteger();
    private final AtomicInteger telemetryCalls = new AtomicInteger();
    private final AtomicInteger inFlightRegistrations = new AtomicInteger();
    private final AtomicInteger maxConcurrentRegistrations = new AtomicInteger();
    private final List<Long> registrationStartTimestamps = new CopyOnWriteArrayList<>();

    private volatile CountDownLatch registrationGate;

    public void setAcceptRegistration(boolean accept) {
        this.acceptRegistration.set(accept);
    }

    public void setAcknowledgeHeartbeat(boolean acknowledge) {
        this.acknowledgeHeartbeat.set(acknowledge);
    }

    public void setAcceptTelemetry(boolean accept) {
        this.acceptTelemetry.set(accept);
    }

    /** Holds every RegisterNode call until {@link #releaseRegistrations()} is invoked. */
    public void holdRegistrations() {
        this.registrationGate = new CountDownLatch(1);
    }

    public void releaseRegistrations() {
        CountDownLatch gate = this.registrationGate;
        this.registrationGate = null;
        if (gate != null) {
            gate.countDown();
        }
    }

    public int registrationCalls() {
        return registrationCalls.get();
    }

    public int acceptedRegistrations() {
        return acceptedRegistrations.get();
    }

    public int heartbeatCalls() {
        return heartbeatCalls.get();
    }

    public int telemetryCalls() {
        return telemetryCalls.get();
    }

    public int inFlightRegistrations() {
        return inFlightRegistrations.get();
    }

    public int maxConcurrentRegistrations() {
        return maxConcurrentRegistrations.get();
    }

    public List<Long> registrationStartTimestamps() {
        return registrationStartTimestamps;
    }

    @Override
    public void registerNode(RegisterNodeRequest request, StreamObserver<RegisterNodeResponse> responseObserver) {
        registrationCalls.incrementAndGet();
        registrationStartTimestamps.add(System.currentTimeMillis());
        int inFlight = inFlightRegistrations.incrementAndGet();
        maxConcurrentRegistrations.accumulateAndGet(inFlight, Math::max);
        try {
            awaitRegistrationGate();

            boolean accepted = acceptRegistration.get();
            if (accepted) {
                acceptedRegistrations.incrementAndGet();
            }
            responseObserver.onNext(RegisterNodeResponse.newBuilder()
                    .setAccepted(accepted)
                    .setMessage(accepted ? "Node registration successful" : "Registration denied by test master")
                    .setServerTime(System.currentTimeMillis())
                    .build());
            responseObserver.onCompleted();
        } finally {
            inFlightRegistrations.decrementAndGet();
        }
    }

    @Override
    public void heartbeat(HeartbeatRequest request, StreamObserver<HeartbeatResponse> responseObserver) {
        heartbeatCalls.incrementAndGet();
        responseObserver.onNext(HeartbeatResponse.newBuilder()
                .setAcknowledged(acknowledgeHeartbeat.get())
                .setServerTime(System.currentTimeMillis())
                .build());
        responseObserver.onCompleted();
    }

    @Override
    public void reportTelemetry(TelemetryRequest request, StreamObserver<TelemetryResponse> responseObserver) {
        telemetryCalls.incrementAndGet();
        boolean accepted = acceptTelemetry.get();
        responseObserver.onNext(TelemetryResponse.newBuilder()
                .setAccepted(accepted)
                .setMessage(accepted ? "Telemetry accepted by test master" : "Telemetry denied by test master")
                .setServerTime(System.currentTimeMillis())
                .build());
        responseObserver.onCompleted();
    }

    private void awaitRegistrationGate() {
        CountDownLatch gate = registrationGate;
        if (gate == null) {
            return;
        }
        log.debug("Holding RegisterNode until the gate is released");
        try {
            // Bounded wait so a broken test can never hang forever.
            if (!gate.await(10, TimeUnit.SECONDS)) {
                log.warn("Registration gate timed out; responding without being released");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
