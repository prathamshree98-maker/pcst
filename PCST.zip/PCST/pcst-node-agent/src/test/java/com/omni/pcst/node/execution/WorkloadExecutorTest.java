package com.omni.pcst.node.execution;

import com.omni.pcst.proto.TaskResult;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the Node Agent workload executor: supported workload types complete
 * with their real result, unsupported types are rejected, and duplicate attempts
 * are not executed twice.
 */
class WorkloadExecutorTest {

    private WorkloadExecutor executor;

    @BeforeEach
    void setUp() {
        executor = new WorkloadExecutor();
    }

    @AfterEach
    void tearDown() {
        executor.shutdown();
    }

    @Test
    void noOpWorkloadCompletesWithSuccess() throws Exception {
        CompletableFuture<TaskResult> future = new CompletableFuture<>();
        TaskResult immediate = executor.execute("noop-1", "NO_OP", null, future::complete);

        assertTrue(immediate.getSuccess(), "dispatch must be accepted immediately");

        TaskResult result = future.get(5, TimeUnit.SECONDS);
        assertTrue(result.getSuccess());
        assertEquals("NO_OP completed", result.getOutput());
    }

    @Test
    void computeWorkloadCompletesWithDeterministicResult() throws Exception {
        CompletableFuture<TaskResult> future = new CompletableFuture<>();
        TaskResult immediate = executor.execute("compute-1", "COMPUTE", "1000", future::complete);

        assertTrue(immediate.getSuccess());

        TaskResult result = future.get(5, TimeUnit.SECONDS);
        assertTrue(result.getSuccess());
        assertTrue(result.getOutput().contains("iterations=1000"),
                "output must report the requested iteration count, was " + result.getOutput());
    }

    @Test
    void sleepWorkloadCompletesOnlyAfterTheRequestedDuration() throws Exception {
        CompletableFuture<TaskResult> future = new CompletableFuture<>();
        long startNanos = System.nanoTime();
        TaskResult immediate = executor.execute("sleep-1", "SLEEP", "150", future::complete);
        assertTrue(immediate.getSuccess());

        TaskResult result = future.get(5, TimeUnit.SECONDS);
        long elapsedMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNanos);

        assertTrue(result.getSuccess());
        assertEquals("slept 150 ms", result.getOutput());
        assertTrue(elapsedMillis >= 140,
                "SLEEP must not report completion before the requested duration, elapsed=" + elapsedMillis + "ms");
    }

    @Test
    void unsupportedWorkloadTypeIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> executor.execute("bad-1", "EXPLODE", null));
    }

    @Test
    void duplicateAttemptIsNotExecutedTwice() throws Exception {
        CompletableFuture<TaskResult> first = new CompletableFuture<>();
        TaskResult immediate = executor.execute("dup-1", "SLEEP", "300", first::complete);
        assertTrue(immediate.getSuccess());

        TaskResult duplicate = executor.execute("dup-1", "SLEEP", "300", r -> { });
        assertFalse(duplicate.getSuccess());
        assertEquals("attempt already executing", duplicate.getError());

        // The original attempt still runs to completion.
        TaskResult result = first.get(5, TimeUnit.SECONDS);
        assertTrue(result.getSuccess());
    }
}
