package com.omni.pcst.node.telemetry;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import com.omni.pcst.node.grpc.MasterGrpcClient;
import io.grpc.ManagedChannel;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Verifies that telemetry collection survives repeated delivery failures, and that a failed
 * delivery is never reported as a successful one.
 */
class TelemetrySchedulerFailureTest {

    private static final long WAIT_TIMEOUT_MS = Duration.ofSeconds(20).toMillis();
    private static final int REQUIRED_CYCLES = 4;

    private TelemetryScheduler scheduler;
    private CaptureAppender logCapture;
    private Logger schedulerLogger;
    private Level previousLogLevel;

    @BeforeEach
    void setUp() {
        logCapture = new CaptureAppender();
        logCapture.start();
        schedulerLogger = (Logger) LoggerFactory.getLogger(TelemetryScheduler.class);
        previousLogLevel = schedulerLogger.getLevel();
        schedulerLogger.setLevel(Level.DEBUG);
        schedulerLogger.addAppender(logCapture);
    }

    @AfterEach
    void tearDown() {
        if (scheduler != null) {
            scheduler.stop();
        }
        schedulerLogger.detachAppender(logCapture);
        schedulerLogger.setLevel(previousLogLevel);
        logCapture.stop();
    }

    @Test
    void deliveryFailureDoesNotStopSubsequentTelemetryCycles() {
        RecordingCollector collector = new RecordingCollector();
        FailingClient client = new FailingClient(false);

        scheduler = new TelemetryScheduler(collector, 20L, client);
        scheduler.start();

        try {
            assertEventually("telemetry cycles continue after failed deliveries",
                    () -> collector.collections() >= REQUIRED_CYCLES && client.telemetryAttempts() >= REQUIRED_CYCLES);
        } finally {
            scheduler.stop();
        }

        assertTrue(collector.collections() >= REQUIRED_CYCLES,
                "collection must keep running after delivery failures");
        assertTrue(client.telemetryAttempts() >= REQUIRED_CYCLES,
                "every collected snapshot should be offered for delivery");
        assertEquals(client.telemetryAttempts(), client.connectionFailures(),
                "every failed delivery must be reported as a connection failure");
        assertEquals(0, client.successfulDeliveries(),
                "no failed delivery may be counted as successful");
    }

    @Test
    void deliverySuccessKeepsCyclesRunning() {
        RecordingCollector collector = new RecordingCollector();
        FailingClient client = new FailingClient(true);

        scheduler = new TelemetryScheduler(collector, 20L, client);
        scheduler.start();

        try {
            assertEventually("telemetry cycles continue after successful deliveries",
                    () -> collector.collections() >= REQUIRED_CYCLES
                            && client.successfulDeliveries() >= REQUIRED_CYCLES);
        } finally {
            scheduler.stop();
        }

        assertEquals(client.successfulDeliveries(), client.telemetryAttempts(),
                "successful deliveries must match delivery attempts");
        assertEquals(0, client.connectionFailures());
    }

    @Test
    void failedDeliveryIsNeverLoggedAsSuccessfulDelivery() {
        RecordingCollector collector = new RecordingCollector();
        FailingClient client = new FailingClient(false);

        scheduler = new TelemetryScheduler(collector, 20L, client);
        scheduler.start();

        try {
            assertEventually("multiple failed cycles recorded", () -> collector.collections() >= REQUIRED_CYCLES);
        } finally {
            scheduler.stop();
        }

        List<String> messages = logCapture.messages();

        assertTrue(messages.stream().anyMatch(m -> m.contains("Telemetry snapshot collected")),
                "collection should be logged: " + messages);
        assertTrue(messages.stream().anyMatch(m -> m.contains("delivery failed")),
                "the failed delivery should be visible in the log: " + messages);
        assertTrue(messages.stream().noneMatch(m -> m.contains("delivered to Master")),
                "a failed delivery must never be logged as delivered: " + messages);
    }

    @Test
    void heartbeatFlowDoesNotConsumeTelemetrySequenceNumbers() throws Exception {
        RecordingCollector collector = new RecordingCollector();
        FailingClient client = new FailingClient(false);
        TelemetrySequenceSource source = new TelemetrySequenceSource();

        scheduler = new TelemetryScheduler(collector, 20L, client, source);
        long sequenceBefore = source.lastIssuedSequence();
        scheduler.start();

        try {
            assertEventually("telemetry cycles ran",
                    () -> collector.collections() >= REQUIRED_CYCLES);
        } finally {
            scheduler.stop();
        }

        // The heartbeat path lives in MasterGrpcClient on its own schedule and is
        // exercised separately; the telemetry sequence source is only reachable
        // from the telemetry cycle. Waiting through many cycles (during which the
        // heartbeat schedule runs independently) must still show a contiguous,
        // strictly increasing sequence with no heartbeat interference.
        List<Long> sequences = client.telemetrySequences();
        assertFalse(sequences.isEmpty(), "telemetry attempts must have been recorded");
        for (int i = 0; i < sequences.size(); i++) {
            assertEquals(i + 1L, sequences.get(i),
                    "sequence numbers are contiguous and one-based despite concurrent heartbeats");
        }
        assertEquals(sequenceBefore + sequences.size(), source.lastIssuedSequence(),
                "exactly one sequence is consumed per telemetry snapshot and none by heartbeats");
    }

    @Test
    void failedSendStillConsumesItsSequenceNumber() throws Exception {
        RecordingCollector collector = new RecordingCollector();
        FailingClient client = new FailingClient(false);
        TelemetrySequenceSource source = new TelemetrySequenceSource();

        scheduler = new TelemetryScheduler(collector, 20L, client, source);
        scheduler.start();

        try {
            assertEventually("telemetry cycles ran",
                    () -> collector.collections() >= REQUIRED_CYCLES);
        } finally {
            scheduler.stop();
        }

        assertTrue(client.telemetryAttempts() >= REQUIRED_CYCLES);
        assertEquals(0, client.successfulDeliveries(), "every send in this test failed");
        // Because every send failed, every consumed sequence must still be
        // accounted for: no renumbering, no reuse.
        assertEquals(client.telemetryAttempts(), source.lastIssuedSequence(),
                "a failed send consumes its sequence number and never reuses it");
    }

    @Test
    void schedulerStampsItsOwnSessionIdOnEverySend() throws Exception {
        RecordingCollector collector = new RecordingCollector();
        FailingClient client = new FailingClient(true);
        TelemetrySequenceSource source = new TelemetrySequenceSource();

        scheduler = new TelemetryScheduler(collector, 20L, client, source);
        scheduler.start();

        try {
            assertEventually("telemetry cycles ran",
                    () -> collector.collections() >= REQUIRED_CYCLES);
        } finally {
            scheduler.stop();
        }

        assertTrue(client.successfulDeliveries() >= REQUIRED_CYCLES);
        assertEquals(source.getAgentSessionId(), scheduler.getAgentSessionId(),
                "the scheduler exposes the session id it stamps on every message");
        for (String observed : client.sessionsSeen()) {
            assertEquals(source.getAgentSessionId(), observed,
                    "every send carries the one session id for this process lifetime");
        }
    }

    /* ------------------------------------------------------------------ helpers */

    /**
     * Counts collections and returns a fixed snapshot, so no real hardware access happens.
     */
    private static final class RecordingCollector extends TelemetryCollector {

        private final AtomicInteger collections = new AtomicInteger();

        int collections() {
            return collections.get();
        }

        @Override
        public TelemetrySnapshot collect() {
            collections.incrementAndGet();
            return new TelemetrySnapshot(
                    System.currentTimeMillis(),
                    1.0,
                    1L,
                    0L,
                    1L,
                    1L,
                    1L,
                    1,
                    null,
                    null,
                    null,
                    false,
                    null,
                    null,
                    null);
        }
    }

    /**
     * Test double for the gRPC client: never opens a connection, and either always succeeds
     * or always fails to deliver.
     */
    private static final class FailingClient extends MasterGrpcClient {

        private final boolean succeed;
        private final AtomicInteger telemetryAttempts = new AtomicInteger();
        private final AtomicInteger successfulDeliveries = new AtomicInteger();
        private final AtomicInteger connectionFailures = new AtomicInteger();
        private final List<Long> telemetrySequences = new CopyOnWriteArrayList<>();
        private final List<String> sessionsSeen = new CopyOnWriteArrayList<>();

        FailingClient(boolean succeed) {
            super(newUnusedChannel(), "unused", 0, "test-node", 0, "0.1.0", 1000L);
            this.succeed = succeed;
        }

        private static ManagedChannel newUnusedChannel() {
            return InProcessChannelBuilder.forName(InProcessServerBuilder.generateName())
                    .directExecutor()
                    .build();
        }

        @Override
        public boolean sendTelemetry(TelemetrySnapshot snapshot) {
            telemetryAttempts.incrementAndGet();
            if (succeed) {
                successfulDeliveries.incrementAndGet();
                return true;
            }
            onConnectionFailure("test-delivery-failure");
            return false;
        }

        @Override
        public boolean sendTelemetry(TelemetrySnapshot snapshot, String agentSessionId, long telemetrySequence) {
            telemetrySequences.add(telemetrySequence);
            sessionsSeen.add(agentSessionId);
            return sendTelemetry(snapshot);
        }

        @Override
        public void onConnectionFailure(String operation) {
            connectionFailures.incrementAndGet();
        }

        List<Long> telemetrySequences() {
            return List.copyOf(telemetrySequences);
        }

        List<String> sessionsSeen() {
            return List.copyOf(sessionsSeen);
        }

        int telemetryAttempts() {
            return telemetryAttempts.get();
        }

        int successfulDeliveries() {
            return successfulDeliveries.get();
        }

        int connectionFailures() {
            return connectionFailures.get();
        }
    }

    /** Thread safe appender used to assert on what the scheduler logs. */
    private static final class CaptureAppender extends AppenderBase<ILoggingEvent> {

        private final CopyOnWriteArrayList<String> messages = new CopyOnWriteArrayList<>();

        @Override
        protected void append(ILoggingEvent eventObject) {
            messages.add(eventObject.getFormattedMessage());
        }

        List<String> messages() {
            return messages;
        }
    }

    private static void assertEventually(String description, BooleanSupplier condition) {
        long deadline = System.currentTimeMillis() + WAIT_TIMEOUT_MS;
        while (System.currentTimeMillis() < deadline) {
            if (condition.getAsBoolean()) {
                return;
            }
            try {
                Thread.sleep(5L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new AssertionError("Interrupted while waiting for: " + description, e);
            }
        }
        throw new AssertionError("Timed out after " + WAIT_TIMEOUT_MS + " ms waiting for: " + description);
    }
}
