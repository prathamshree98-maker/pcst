package com.omni.pcst.node.grpc;

import com.omni.pcst.node.telemetry.TelemetrySnapshot;
import io.grpc.ManagedChannel;
import io.grpc.Server;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Failure handling and recovery behaviour of {@link MasterGrpcClient}, driven by a local
 * in-process gRPC server ({@link TestNodeService}) so that no sockets and no real network
 * are involved. The recovery backoff is shortened through the
 * {@code grpc.recovery.backoff-ms} system property, which keeps the tests fast while still
 * exercising the real state machine.
 */
class MasterGrpcClientRecoveryTest {

    private static final long WAIT_TIMEOUT_MS = Duration.ofSeconds(20).toMillis();
    private static final long HEARTBEAT_INTERVAL_MS = 50L;

    private String masterName;
    private TestNodeService master;
    private Server masterServer;
    private MasterGrpcClient client;

    @BeforeEach
    void setUp() {
        System.setProperty("grpc.recovery.backoff-ms", "50");
        masterName = InProcessServerBuilder.generateName();
        master = new TestNodeService();
    }

    @AfterEach
    void tearDown() throws InterruptedException {
        if (client != null) {
            client.stop();
        }
        stopMaster();
        System.clearProperty("grpc.recovery.backoff-ms");
    }

    @Test
    void startIsNonBlockingWhenMasterIsUnavailable() {
        client = newClient();

        long startedAt = System.currentTimeMillis();
        client.start();
        long elapsed = System.currentTimeMillis() - startedAt;

        assertTrue(elapsed < 1000L,
                "start() must not block on registration, took " + elapsed + " ms");
        assertNotEquals(MasterGrpcClient.RegistrationState.REGISTERED, client.getRegistrationState());

        // The background loop keeps retrying on its own.
        assertEventually("registration attempts continue while the Master is unavailable",
                () -> client.getRegistrationAttemptCount() >= 2);
    }

    @Test
    void registrationRetriesUntilMasterBecomesAvailable() throws Exception {
        client = newClient();
        client.start();

        assertEventually("registration is retried at least once before the Master appears",
                () -> client.getRegistrationAttemptCount() >= 2);
        // Capture the attempt count before the Master appears: failed attempts never
        // reach the server (client-side UNAVAILABLE), and a successful registration
        // resets the counter, so neither is observable after startMaster() returns.
        int attemptsBeforeMasterAppeared = client.getRegistrationAttemptCount();

        startMaster();

        assertEventually("registration succeeds once the Master is reachable",
                () -> client.getRegistrationState() == MasterGrpcClient.RegistrationState.REGISTERED);
        assertEquals(1, master.acceptedRegistrations(), "exactly one registration should be accepted");
        assertTrue(attemptsBeforeMasterAppeared >= 2,
                "registration should have been retried before the Master appeared");

        assertEventually("heartbeats are delivered after registration",
                () -> master.heartbeatCalls() >= 2);
    }

    @Test
    void registrationRecoversAfterMasterRestart() throws Exception {
        startMaster();
        client = newClient();
        client.start();

        assertEventually("registered before the restart",
                () -> client.getRegistrationState() == MasterGrpcClient.RegistrationState.REGISTERED);

        stopMaster();
        client.onConnectionFailure("test-master-stopped");

        assertEventually("falling back to RECOVERING when the Master disappears",
                () -> client.getRegistrationState() == MasterGrpcClient.RegistrationState.RECOVERING);

        startMaster();

        assertEventually("registration recovered after the restart",
                () -> client.getRegistrationState() == MasterGrpcClient.RegistrationState.REGISTERED);
        assertEquals(2, master.acceptedRegistrations(), "one registration per master start");
        assertTrue(master.maxConcurrentRegistrations() <= 1,
                "only one registration RPC may ever be in flight");

        assertEventually("heartbeats resume after the restart",
                () -> master.heartbeatCalls() >= 2);
        assertTrue(client.sendTelemetry(snapshot()), "telemetry must work again after recovery");
        assertTrue(master.telemetryCalls() >= 1);
    }

    @Test
    void rejectedRegistrationKeepsRetryingWithBoundedBackoff() throws IOException {
        startMaster();
        master.setAcceptRegistration(false);

        client = newClient();
        client.start();

        assertEventually("registration keeps being retried after rejection",
                () -> client.getRegistrationAttemptCount() >= 3);
        assertNotEquals(MasterGrpcClient.RegistrationState.REGISTERED, client.getRegistrationState());

        // The configured backoff is 50 ms and doubles on each failure, so gaps between
        // consecutive attempts must grow and must never be a tight loop.
        List<Long> timestamps = master.registrationStartTimestamps();
        assertTrue(timestamps.size() >= 2);
        for (int i = 1; i < timestamps.size(); i++) {
            long gap = timestamps.get(i) - timestamps.get(i - 1);
            assertTrue(gap >= 25L,
                    "retry interval is too small (gap=" + gap + " ms); the retry loop is not bounded");
        }
    }

    @Test
    void concurrentConnectionFailuresCreateOnlyOneRecoveryAttempt() throws IOException, InterruptedException {
        startMaster();
        // Hold registrations open so exactly one attempt can be in flight at a time.
        master.holdRegistrations();

        client = newClient();
        client.start();

        assertEventually("the first registration attempt is in flight",
                () -> master.inFlightRegistrations() >= 1);

        int signallers = 16;
        CountDownLatch ready = new CountDownLatch(signallers);
        CountDownLatch done = new CountDownLatch(signallers);
        for (int i = 0; i < signallers; i++) {
            Thread thread = new Thread(() -> {
                ready.countDown();
                try {
                    ready.await();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
                client.onConnectionFailure("test-concurrent-signal");
                done.countDown();
            }, "failure-signaller-" + i);
            thread.start();
        }
        assertTrue(done.await(10, TimeUnit.SECONDS), "concurrent failure signals should return promptly");

        // Observe for a short window: a second recovery loop would show up as a second
        // in-flight registration almost immediately.
        long observationEnd = System.currentTimeMillis() + 750L;
        while (System.currentTimeMillis() < observationEnd) {
            assertEquals(1, master.registrationCalls(),
                    "concurrent failure signals must not start duplicate recovery attempts");
            assertEquals(1, master.maxConcurrentRegistrations(),
                    "no concurrent duplicate registration RPC is allowed");
            Thread.sleep(10L);
        }

        master.releaseRegistrations();

        assertEventually("registration completes once the gate is released",
                () -> client.getRegistrationState() == MasterGrpcClient.RegistrationState.REGISTERED);
        assertEquals(1, master.acceptedRegistrations());
        assertEquals(1, master.maxConcurrentRegistrations(),
                "only one registration RPC ran in total");
        assertTrue(master.registrationCalls() <= 2,
                "a burst of connection failures must not cause a burst of registrations");
    }

    @Test
    void telemetryRejectionIsNotReportedAsSuccessfulDelivery() throws IOException {
        startMaster();
        master.setAcceptTelemetry(false);

        client = newClient();
        client.start();

        assertEventually("registration is established on a healthy connection",
                () -> client.getRegistrationState() == MasterGrpcClient.RegistrationState.REGISTERED);
        int registrationsBeforeRejections = master.registrationCalls();

        for (int i = 0; i < 3; i++) {
            assertFalse(client.sendTelemetry(snapshot()),
                    "a rejected telemetry RPC must never be reported as delivered");
        }

        assertEquals(registrationsBeforeRejections, master.registrationCalls(),
                "a rejected telemetry RPC on a healthy connection must not trigger re-registration");
        assertEquals(MasterGrpcClient.RegistrationState.REGISTERED, client.getRegistrationState());

        master.setAcceptTelemetry(true);
        assertTrue(client.sendTelemetry(snapshot()), "accepted telemetry must be reported as delivered");
    }

    @Test
    void telemetryFailsWhileMasterIsUnavailable() {
        client = newClient();
        client.start();

        for (int i = 0; i < 3; i++) {
            assertFalse(client.sendTelemetry(snapshot()),
                    "telemetry delivery must fail clearly without a Master");
        }
        assertNotEquals(MasterGrpcClient.RegistrationState.REGISTERED, client.getRegistrationState());
        // Losing the Master must not stop the retry machinery.
        assertEventually("recovery keeps retrying", () -> client.getRegistrationAttemptCount() >= 2);
    }

    @Test
    void shutdownStopsRecoveryAttemptsAndIsIdempotent() throws InterruptedException {
        client = newClient();
        client.start();

        assertEventually("recovery loop is running", () -> client.getRegistrationAttemptCount() >= 1);

        client.stop();

        int attemptsAfterShutdown = client.getRegistrationAttemptCount();
        Thread.sleep(400L);
        assertEquals(attemptsAfterShutdown, client.getRegistrationAttemptCount(),
                "no registration attempt may be started after shutdown");
        assertDoesNotThrow(client::stop, "stop() must be idempotent");
    }

    /* ------------------------------------------------------------------ helpers */

    private MasterGrpcClient newClient() {
        ManagedChannel channel = InProcessChannelBuilder.forName(masterName)
                .directExecutor()
                .build();
        return new MasterGrpcClient(channel, masterName, 0, "test-node", 9091, "0.1.0", HEARTBEAT_INTERVAL_MS);
    }

    private void startMaster() throws IOException {
        masterServer = InProcessServerBuilder.forName(masterName)
                .directExecutor()
                .addService(master)
                .build()
                .start();
    }

    private void stopMaster() throws InterruptedException {
        Server server = masterServer;
        masterServer = null;
        if (server != null) {
            server.shutdownNow();
            assertTrue(server.awaitTermination(5, TimeUnit.SECONDS), "test master should terminate promptly");
        }
    }

    private static TelemetrySnapshot snapshot() {
        return new TelemetrySnapshot(
                System.currentTimeMillis(),
                12.5,
                1024L * 1024L * 1024L,
                512L * 1024L * 1024L,
                512L * 1024L * 1024L,
                100L * 1024L * 1024L * 1024L,
                40L * 1024L * 1024L * 1024L,
                4,
                null,
                null,
                null,
                false,
                null,
                null,
                null);
    }

    private static void assertEventually(String description, BooleanSupplier condition) {
        long deadline = System.currentTimeMillis() + WAIT_TIMEOUT_MS;
        AssertionError lastFailure = null;
        while (System.currentTimeMillis() < deadline) {
            try {
                if (condition.getAsBoolean()) {
                    return;
                }
            } catch (AssertionError e) {
                lastFailure = e;
            }
            try {
                Thread.sleep(5L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new AssertionError("Interrupted while waiting for: " + description, e);
            }
        }
        throw new AssertionError("Timed out after " + WAIT_TIMEOUT_MS + " ms waiting for: " + description,
                lastFailure);
    }
}
