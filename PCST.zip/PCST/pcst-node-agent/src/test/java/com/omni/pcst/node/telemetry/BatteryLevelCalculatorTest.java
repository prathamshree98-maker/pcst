package com.omni.pcst.node.telemetry;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Test;

import oshi.hardware.PowerSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Deterministic unit tests for {@link BatteryLevelCalculator}. No hardware:
 * every {@link PowerSource} is a configurable fake. Covers genuine 0%, genuine
 * 100%, intermediate percentages, unavailable data, failed-query sentinels and
 * multiple power sources.
 */
class BatteryLevelCalculatorTest {

    @Test
    void genuineZeroPercentIsPreservedAndDistinctFromUnavailable() {
        Double level = BatteryLevelCalculator.toPercent(fake(0.0, 0, 50_000, false));

        assertNotNull(level, "a genuine 0% reading must not become unavailable");
        assertEquals(0.0, level, 1e-9);
    }

    @Test
    void genuineHundredPercentIsAcceptedWhenCorroborated() {
        Double level = BatteryLevelCalculator.toPercent(fake(1.0, 50_000, 50_000, false));

        assertNotNull(level, "a corroborated full battery is a real 100%");
        assertEquals(100.0, level, 1e-9);
    }

    @Test
    void intermediatePercentageConverts() {
        Double level = BatteryLevelCalculator.toPercent(fake(0.12, 6_000, 50_000, false));

        assertNotNull(level);
        assertEquals(12.0, level, 1e-9);
    }

    @Test
    void failedQuerySentinelIsUnavailableInsteadOfHundred() {
        // OSHI 6.6.1 WindowsPowerSource defaults when the SystemBatteryState
        // query fails: fraction 1.0, current 0, max 1. This is the observed
        // fabricated-100% signature and must never become 100%.
        Double level = BatteryLevelCalculator.toPercent(fake(1.0, 0, 1, false));

        assertNull(level, "unavailable battery data must stay unavailable, not 100%");
    }

    @Test
    void staleDefaultFractionFallsBackToRawDeviceRatio() {
        // SystemBatteryState query failed (fraction left at the 1.0 default)
        // while the per-device query returned real capacities: the measured
        // raw ratio is used instead of the stale default.
        Double level = BatteryLevelCalculator.toPercent(fake(1.0, 6_000, 50_000, false));

        assertNotNull(level);
        assertEquals(12.0, level, 1e-9);
    }

    @Test
    void livePartialFailureShapeYieldsDeviceRatio() {
        // Shape observed live on the laptop: stale 1.0 fraction with valid
        // device capacities while charging.
        Double level = BatteryLevelCalculator.toPercent(fake(1.0, 24_772, 26_299, true));

        assertNotNull(level);
        assertEquals(24_772.0 / 26_299.0 * 100.0, level, 1e-9);
        assertTrue(level > 93.0 && level < 95.0);
    }

    @Test
    void zeroCurrentWithRealMaxAndStaleFractionIsUnavailable() {
        // Ambiguous: failed status query vs. genuinely empty battery with a
        // stale fraction. Never fabricate 0% here; a genuine 0% arrives with a
        // consistent 0.0 fraction instead.
        assertNull(BatteryLevelCalculator.toPercent(fake(1.0, 0, 50_000, false)));
    }

    @Test
    void zeroMaxCapacityIsUnavailable() {
        assertNull(BatteryLevelCalculator.toPercent(fake(0.5, 0, 0, false)));
        assertNull(BatteryLevelCalculator.toPercent(fake(0.5, 100, -1, false)));
    }

    @Test
    void nonFiniteAndOutOfRangeFractionsWithoutRawDataAreUnavailable() {
        assertNull(BatteryLevelCalculator.toPercent(fake(Double.NaN, 0, 1, false)));
        assertNull(BatteryLevelCalculator.toPercent(fake(Double.POSITIVE_INFINITY, 0, 1, false)));
        assertNull(BatteryLevelCalculator.toPercent(fake(1.5, 0, 1, false)));
        assertNull(BatteryLevelCalculator.toPercent(fake(-0.1, 0, 1, false)));
    }

    @Test
    void unusableFractionWithValidRawDataFallsBackToRawRatio() {
        // OSHI clamps its fraction, so these shapes should not occur on
        // Windows; if they ever do, valid device capacities still win over
        // the broken fraction rather than producing unavailable.
        assertEquals(12.0, BatteryLevelCalculator.toPercent(fake(Double.NaN, 6_000, 50_000, false)), 1e-9);
        assertEquals(12.0, BatteryLevelCalculator.toPercent(fake(1.5, 6_000, 50_000, false)), 1e-9);
    }

    @Test
    void smallTimingDriftBetweenQueriesIsTolerated() {
        // OSHI's fraction and the raw capacities come from two Windows queries
        // taken moments apart; a sub-tolerance drift is still the same reading.
        Double level = BatteryLevelCalculator.toPercent(fake(0.12, 6_100, 50_000, false));

        assertNotNull(level);
        assertEquals(12.0, level, 1e-9, "the reported value is OSHI's fraction, not the drifted ratio");
    }

    @Test
    void selectPrimarySkipsFailedSources() {
        PowerSource sentinel = fake(1.0, 0, 1, false);
        PowerSource genuine = fake(0.6, 30_000, 50_000, false);

        PowerSource selected = BatteryLevelCalculator.selectPrimary(Arrays.asList(sentinel, genuine));

        assertSame(genuine, selected);
        assertEquals(60.0, BatteryLevelCalculator.toPercent(selected), 1e-9);
    }

    @Test
    void selectPrimaryFallsBackToFirstSourceWhenNoneIsValid() {
        PowerSource first = fake(1.0, 0, 1, true);
        PowerSource second = fake(1.0, 0, 1, false);

        PowerSource selected = BatteryLevelCalculator.selectPrimary(Arrays.asList(first, second));

        assertSame(first, selected, "charging state of the primary source stays observable");
        assertNull(BatteryLevelCalculator.toPercent(selected));
        assertTrue(selected.isCharging(), "charging availability is independent of level availability");
    }

    @Test
    void selectPrimaryHandlesNullAndEmptyLists() {
        assertNull(BatteryLevelCalculator.selectPrimary(null));
        assertNull(BatteryLevelCalculator.selectPrimary(Collections.emptyList()));
    }

    @Test
    void nullPowerSourceIsRejected() {
        assertThrows(NullPointerException.class, () -> BatteryLevelCalculator.toPercent(null));
    }

    /* ------------------------------------------------------------------ helpers */

    private static PowerSource fake(double fraction, int current, int max, boolean charging) {
        FakePowerSource ps = new FakePowerSource();
        ps.remainingCapacityPercent = fraction;
        ps.currentCapacity = current;
        ps.maxCapacity = max;
        ps.designCapacity = 52_000;
        ps.charging = charging;
        return ps;
    }

    /** Configurable test double for OSHI's {@link PowerSource}; no hardware. */
    private static final class FakePowerSource implements PowerSource {

        double remainingCapacityPercent = 1.0;
        int currentCapacity = 0;
        int maxCapacity = 1;
        int designCapacity = 1;
        boolean charging = false;

        @Override
        public String getName() {
            return "fake-battery";
        }

        @Override
        public String getDeviceName() {
            return "fake-device";
        }

        @Override
        public double getRemainingCapacityPercent() {
            return remainingCapacityPercent;
        }

        @Override
        public double getTimeRemainingEstimated() {
            return -1.0;
        }

        @Override
        public double getTimeRemainingInstant() {
            return 0.0;
        }

        @Override
        public double getPowerUsageRate() {
            return 0.0;
        }

        @Override
        public double getVoltage() {
            return 0.0;
        }

        @Override
        public double getAmperage() {
            return 0.0;
        }

        @Override
        public boolean isPowerOnLine() {
            return false;
        }

        @Override
        public boolean isCharging() {
            return charging;
        }

        @Override
        public boolean isDischarging() {
            return !charging;
        }

        @Override
        public PowerSource.CapacityUnits getCapacityUnits() {
            return PowerSource.CapacityUnits.RELATIVE;
        }

        @Override
        public int getCurrentCapacity() {
            return currentCapacity;
        }

        @Override
        public int getMaxCapacity() {
            return maxCapacity;
        }

        @Override
        public int getDesignCapacity() {
            return designCapacity;
        }

        @Override
        public int getCycleCount() {
            return -1;
        }

        @Override
        public String getChemistry() {
            return "unknown";
        }

        @Override
        public LocalDate getManufactureDate() {
            return null;
        }

        @Override
        public String getManufacturer() {
            return "unknown";
        }

        @Override
        public String getSerialNumber() {
            return "unknown";
        }

        @Override
        public double getTemperature() {
            return 0.0;
        }

        @Override
        public boolean updateAttributes() {
            return false;
        }
    }

}
