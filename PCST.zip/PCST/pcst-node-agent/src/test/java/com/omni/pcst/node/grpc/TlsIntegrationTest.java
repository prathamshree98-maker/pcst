package com.omni.pcst.node.grpc;

import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.RegisterNodeRequest;
import com.omni.pcst.proto.RegisterNodeResponse;
import io.grpc.ManagedChannel;
import io.grpc.Server;
import io.grpc.netty.shaded.io.grpc.netty.NettyServerBuilder;
import io.grpc.netty.shaded.io.netty.handler.ssl.util.SelfSignedCertificate;
import io.grpc.stub.StreamObserver;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for TLS-secured gRPC communication between Node Agent and Master.
 *
 * <p>These tests use Netty's {@link SelfSignedCertificate} to generate temporary
 * certificates, start a TLS gRPC server, and verify that a TLS client with the
 * correct trust store can connect and register, while a client with an incorrect
 * trust store cannot.
 */
class TlsIntegrationTest {

    @TempDir
    Path tempDir;

    private static class TestNodeService extends NodeServiceGrpc.NodeServiceImplBase {
        @Override
        public void registerNode(RegisterNodeRequest request,
                                 StreamObserver<RegisterNodeResponse> responseObserver) {
            RegisterNodeResponse response = RegisterNodeResponse.newBuilder()
                    .setAccepted(true)
                    .setMessage("TLS registration accepted")
                    .setServerTime(System.currentTimeMillis())
                    .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }
    }

    @Test
    void tlsClientWithCorrectTrustStoreCanRegister() throws Exception {
        SelfSignedCertificate serverCert = new SelfSignedCertificate("localhost");

        Server server = NettyServerBuilder.forPort(0)
                .addService(new TestNodeService())
                .useTransportSecurity(serverCert.certificate(), serverCert.privateKey())
                .build()
                .start();
        int port = server.getPort();

        try {
            // Write the server cert to a temp file to use as the client trust store
            Path trustStore = tempDir.resolve("trust.pem");
            Files.copy(serverCert.certificate().toPath(), trustStore);

            // Client with correct trust store
            ManagedChannel channel = io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder
                    .forAddress("localhost", port)
                    .useTransportSecurity()
                    .sslContext(com.omni.pcst.node.config.TlsContexts.clientContext(trustStore.toString()))
                    .build();

            try {
                NodeServiceGrpc.NodeServiceBlockingStub stub =
                        NodeServiceGrpc.newBlockingStub(channel);

                RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                        .setNodeId("tls-test-node")
                        .setHostname("test-host")
                        .setPort(9091)
                        .setAgentVersion("1.0.0")
                        .build();

                RegisterNodeResponse response = stub.registerNode(request);
                assertTrue(response.getAccepted(),
                        "TLS client with correct trust store must register");
            } finally {
                channel.shutdown();
            }
        } finally {
            server.shutdown();
        }
    }

    @Test
    void tlsClientWithWrongTrustStoreCannotConnect() throws Exception {
        // Server cert A
        SelfSignedCertificate serverCertA = new SelfSignedCertificate("localhost");
        // Client trusts cert B (different cert)
        SelfSignedCertificate clientTrustCertB = new SelfSignedCertificate("other");

        Server server = NettyServerBuilder.forPort(0)
                .addService(new TestNodeService())
                .useTransportSecurity(serverCertA.certificate(), serverCertA.privateKey())
                .build()
                .start();
        int port = server.getPort();

        try {
            // Client trusts cert B but server presents cert A
            Path wrongTrustStore = tempDir.resolve("wrong-trust.pem");
            Files.copy(clientTrustCertB.certificate().toPath(), wrongTrustStore);

            ManagedChannel channel = io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder
                    .forAddress("localhost", port)
                    .useTransportSecurity()
                    .sslContext(com.omni.pcst.node.config.TlsContexts.clientContext(wrongTrustStore.toString()))
                    .build();

            try {
                NodeServiceGrpc.NodeServiceBlockingStub stub =
                        NodeServiceGrpc.newBlockingStub(channel);

                RegisterNodeRequest request = RegisterNodeRequest.newBuilder()
                        .setNodeId("tls-test-node")
                        .setHostname("test-host")
                        .setPort(9091)
                        .setAgentVersion("1.0.0")
                        .build();

                // Expect the TLS handshake to fail due to untrusted certificate
                assertThrows(Exception.class, () -> stub.registerNode(request),
                        "TLS client with wrong trust store must fail to connect");
            } finally {
                channel.shutdown();
            }
        } finally {
            server.shutdown();
        }
    }
}
