package com.omni.pcst.node.config;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Optional;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Persists the Node Agent's device credential to the local machine.
 *
 * <p>The credential is the device's proof of identity after a successful pairing
 * enrollment. It must be stored with restrictive filesystem permissions and must
 * never be logged. On POSIX systems the file is created mode {@code 600}
 * (owner read/write only). On Windows the file is written normally (Windows ACL
 * handling is outside this component's scope).
 *
 * <p>Storage locations (first existing/writable used):
 * <ol>
 *   <li>{@code PCST_AGENT_CREDENTIAL_FILE} environment variable (absolute path)</li>
 *   <li>{@code ~/.pcst/device-credential}</li>
 * </ol>
 */
public final class DeviceCredentialStore {

    private static final Logger log = LoggerFactory.getLogger(DeviceCredentialStore.class);

    private static final String CREDENTIAL_ENV = "PCST_AGENT_CREDENTIAL_FILE";
    private static final String HOME_CREDENTIAL =
            System.getProperty("user.home") + java.io.File.separator + ".pcst" + java.io.File.separator + "device-credential";

    private DeviceCredentialStore() {
    }

    /**
     * @return the configured credential file path, or the default location
     */
    public static Path credentialFile() {
        String env = System.getenv(CREDENTIAL_ENV);
        if (env != null && !env.isBlank()) {
            return Paths.get(env.trim());
        }
        return Paths.get(HOME_CREDENTIAL);
    }

    /**
     * Reads the stored device credential, if any.
     *
     * @return the credential, or empty when no file exists or it is blank
     */
    public static Optional<String> read() {
        Path file = credentialFile();
        if (!Files.isRegularFile(file)) {
            return Optional.empty();
        }
        try {
            String content = Files.readString(file).trim();
            return content.isBlank() ? Optional.empty() : Optional.of(content);
        } catch (IOException e) {
            log.warn("Could not read device credential from {}: {}", file, e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * Deletes the stored device credential file, if it exists.
     * Safe to call when no file exists (for example after the Master rejects
     * the credential as invalid or revoked).
     *
     * @throws IOException when the file cannot be deleted
     */
    public static void delete() throws IOException {
        Path file = credentialFile();
        if (Files.isRegularFile(file)) {
            Files.delete(file);
            log.info("Device credential deleted from {} (value not logged)", file);
        }
    }

    /**
     * Writes the device credential to the local machine with restrictive
     * permissions.
     *
     * @param credential the device credential to persist (never logged)
     * @throws IOException when the file cannot be written
     */
    public static void write(String credential) throws IOException {
        if (credential == null || credential.isBlank()) {
            throw new IllegalArgumentException("Refusing to write a blank device credential");
        }
        Path file = credentialFile();
        Path parent = file.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
        // Write to a temp file then atomically move, to avoid partial writes.
        Path temp = Files.createTempFile(parent == null ? null : parent, "pcst-cred-", ".tmp");
        try (OutputStream out = Files.newOutputStream(temp)) {
            out.write(credential.getBytes(StandardCharsets.UTF_8));
        }
        setRestrictivePermissions(temp);
        Files.move(temp, file, java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        setRestrictivePermissions(file);
        log.info("Device credential stored at {} (restrictive permissions applied where supported)", file);
    }

    private static void setRestrictivePermissions(Path file) {
        try {
            Set<PosixFilePermission> perms = Files.getPosixFilePermissions(file);
            perms.remove(PosixFilePermission.GROUP_READ);
            perms.remove(PosixFilePermission.GROUP_WRITE);
            perms.remove(PosixFilePermission.GROUP_EXECUTE);
            perms.remove(PosixFilePermission.OTHERS_READ);
            perms.remove(PosixFilePermission.OTHERS_WRITE);
            perms.remove(PosixFilePermission.OTHERS_EXECUTE);
            Files.setPosixFilePermissions(file, perms);
        } catch (UnsupportedOperationException e) {
            // Windows or filesystem without POSIX permissions: best effort.
            log.debug("POSIX permissions not supported for {}: {}", file, e.getMessage());
        } catch (IOException e) {
            log.warn("Could not set restrictive permissions on {}: {}", file, e.getMessage());
        }
    }
}
