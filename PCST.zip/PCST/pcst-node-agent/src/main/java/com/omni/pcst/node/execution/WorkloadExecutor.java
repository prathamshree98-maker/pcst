package com.omni.pcst.node.execution;

import com.omni.pcst.proto.TaskResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * Executes supported workload types on the Node Agent.
 *
 * <p>Supported workload types:
 * <ul>
 *   <li>{@code NO_OP} - completes immediately with success</li>
 *   <li>{@code COMPUTE} - performs a bounded deterministic computation</li>
 *   <li>{@code SLEEP} - sleeps for a specified duration (for testing timeouts)</li>
 * </ul>
 *
 * <p>Execution is offloaded to a bounded thread pool to avoid blocking the
 * gRPC request handling threads. The executor has a fixed queue capacity;
 * tasks submitted when the queue is full are rejected with a structured error.
 */
public class WorkloadExecutor {

    private static final Logger log = LoggerFactory.getLogger(WorkloadExecutor.class);

    private static final int MAX_WORKERS = 4;
    private static final int MAX_QUEUE_CAPACITY = 16;
    private static final long MAX_COMPUTE_ITERATIONS = 10_000_000L;
    private static final long MAX_SLEEP_MILLIS = 300_000L; // 5 minutes

    private final ExecutorService executor;
    private final ConcurrentMap<String, ExecutionHandle> runningTasks = new ConcurrentHashMap<>();

    public WorkloadExecutor() {
        this.executor = Executors.newFixedThreadPool(MAX_WORKERS, daemonThreadFactory("pcst-workload"));
    }

    /**
     * Executes a workload asynchronously.
     *
     * @param attemptId    unique attempt identifier (used for deduplication)
     * @param workloadType the workload type (NO_OP, COMPUTE, SLEEP)
     * @param payload      JSON payload with workload-specific parameters
     * @return the execution result
     * @throws WorkloadRejectedException if the executor queue is full
     * @throws IllegalArgumentException   if workload type or payload is invalid
     */
    public TaskResult execute(String attemptId, String workloadType, String payload) {
        return execute(attemptId, workloadType, payload, null);
    }

    /**
     * Executes a workload asynchronously and notifies {@code onComplete} with the
     * final result once execution finishes.
     *
     * @param attemptId    unique attempt identifier (used for deduplication)
     * @param workloadType the workload type (NO_OP, COMPUTE, SLEEP)
     * @param payload      JSON payload with workload-specific parameters
     * @param onComplete   callback invoked with the final result when execution
     *                     completes, or {@code null} when no callback is wanted
     * @return the execution result
     * @throws WorkloadRejectedException if the executor queue is full
     * @throws IllegalArgumentException   if workload type or payload is invalid
     */
    public TaskResult execute(String attemptId, String workloadType, String payload,
                              Consumer<TaskResult> onComplete) {
        // Deduplication: if same attemptId is already running, return existing handle's result
        // or reject if we want strict single-execution semantics
        ExecutionHandle existing = runningTasks.get(attemptId);
        if (existing != null) {
            log.info("Attempt {} already running; rejecting duplicate", attemptId);
            return TaskResult.newBuilder()
                    .setSuccess(false)
                    .setError("attempt already executing")
                    .setDurationMillis(0)
                    .build();
        }

        Workload workload = parseWorkload(workloadType, payload);
        ExecutionHandle handle = new ExecutionHandle(attemptId, workloadType, onComplete);
        ExecutionHandle previous = runningTasks.putIfAbsent(attemptId, handle);
        if (previous == null) {
            // Successfully registered, submit to executor
            executor.submit(() -> {
                try {
                    TaskResult result = workload.run();
                    handle.complete(result);
                } catch (Exception e) {
                    log.error("Workload {} failed: {}", workloadType, e.getMessage(), e);
                    handle.complete(TaskResult.newBuilder()
                            .setSuccess(false)
                            .setError(e.getMessage())
                            .setDurationMillis(0)
                            .build());
                } finally {
                    runningTasks.remove(attemptId, handle);
                }
            });
        } else {
            // Race condition - another thread got there first
            return TaskResult.newBuilder()
                    .setSuccess(false)
                    .setError("attempt already executing")
                    .setDurationMillis(0)
                    .build();
        }

        // Return immediately with ACCEPTED status; actual result comes via lifecycle updates
        return TaskResult.newBuilder()
                .setSuccess(true)
                .setOutput("accepted")
                .setDurationMillis(0)
                .build();
    }

    private Workload parseWorkload(String workloadType, String payload) {
        return switch (workloadType.toUpperCase()) {
            case "NO_OP" -> new NoOpWorkload();
            case "COMPUTE" -> new ComputeWorkload(payload);
            case "SLEEP" -> new SleepWorkload(payload);
            default -> throw new IllegalArgumentException("Unsupported workload type: " + workloadType);
        };
    }

    /** Shuts down the executor, waiting for running tasks to complete. */
    public void shutdown() {
        log.info("Shutting down workload executor...");
        executor.shutdown();
        try {
            if (!executor.awaitTermination(30, TimeUnit.SECONDS)) {
                log.warn("Workload executor did not terminate in time; forcing shutdown.");
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private static ThreadFactory daemonThreadFactory(String name) {
        return r -> {
            Thread t = new Thread(r, name);
            t.setDaemon(true);
            return t;
        };
    }

    // ------------------------------------------------------------------ workload implementations

    private interface Workload {
        TaskResult run() throws Exception;
    }

    private static class NoOpWorkload implements Workload {
        @Override
        public TaskResult run() {
            return TaskResult.newBuilder()
                    .setSuccess(true)
                    .setOutput("NO_OP completed")
                    .setDurationMillis(0)
                    .build();
        }
    }

    private static class ComputeWorkload implements Workload {
        private final long iterations;

        ComputeWorkload(String payload) {
            this.iterations = parseIterations(payload);
        }

        private long parseIterations(String payload) {
            if (payload == null || payload.isBlank()) {
                return 1_000_000L; // default
            }
            try {
                long parsed = Long.parseLong(payload.trim());
                if (parsed <= 0 || parsed > MAX_COMPUTE_ITERATIONS) {
                    throw new IllegalArgumentException("iterations must be in [1, " + MAX_COMPUTE_ITERATIONS + "]");
                }
                return parsed;
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("COMPUTE payload must be an integer iteration count");
            }
        }

        @Override
        public TaskResult run() {
            long start = System.currentTimeMillis();
            // Deterministic computation: sum of first N integers
            long sum = 0;
            for (long i = 1; i <= iterations; i++) {
                sum += i;
            }
            long duration = System.currentTimeMillis() - start;
            return TaskResult.newBuilder()
                    .setSuccess(true)
                    .setOutput("sum= " + sum + " (iterations=" + iterations + ")")
                    .setDurationMillis(duration)
                    .build();
        }
    }

    private static class SleepWorkload implements Workload {
        private final long millis;

        SleepWorkload(String payload) {
            if (payload == null || payload.isBlank()) {
                this.millis = 1000L; // default 1 second
            } else {
                try {
                    long parsed = Long.parseLong(payload.trim());
                    if (parsed <= 0 || parsed > MAX_SLEEP_MILLIS) {
                        throw new IllegalArgumentException("sleep duration must be in [1, " + MAX_SLEEP_MILLIS + "] ms");
                    }
                    this.millis = parsed;
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("SLEEP payload must be an integer millisecond duration");
                }
            }
        }

        @Override
        public TaskResult run() throws InterruptedException {
            long start = System.currentTimeMillis();
            Thread.sleep(millis);
            long duration = System.currentTimeMillis() - start;
            return TaskResult.newBuilder()
                    .setSuccess(true)
                    .setOutput("slept " + millis + " ms")
                    .setDurationMillis(duration)
                    .build();
        }
    }

    // ------------------------------------------------------------------ execution handle

    /**
     * Tracks a single execution for deduplication and result retrieval.
     */
    private static class ExecutionHandle {
        private final String attemptId;
        private final String workloadType;
        private final Consumer<TaskResult> onComplete;
        private final java.util.concurrent.atomic.AtomicReference<TaskResult> resultRef =
                new java.util.concurrent.atomic.AtomicReference<>();

        ExecutionHandle(String attemptId, String workloadType, Consumer<TaskResult> onComplete) {
            this.attemptId = attemptId;
            this.workloadType = workloadType;
            this.onComplete = onComplete;
        }

        void complete(TaskResult result) {
            resultRef.set(result);
            if (onComplete != null) {
                try {
                    onComplete.accept(result);
                } catch (Exception e) {
                    log.error("Completion callback failed for attempt {}: {}", attemptId, e.getMessage(), e);
                }
            }
        }

        Optional<TaskResult> getResult() {
            return Optional.ofNullable(resultRef.get());
        }
    }

    // ------------------------------------------------------------------ exceptions

    public static class WorkloadRejectedException extends RuntimeException {
        public WorkloadRejectedException(String message) {
            super(message);
        }
    }
}