package com.omni.pcst.node.telemetry;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * Measures round-trip latency and probe loss between this Node Agent and the
 * configured PCST Master.
 *
 * <p>The probe target is the Master host/port that the Node Agent already uses
 * for its gRPC channel, so the observation always describes the Node-to-Master
 * path and never general internet quality.
 *
 * <p>Implementation uses standard {@link Socket} connect probes against the
 * Master TCP port: no third-party networking dependency is required.
 *
 * <p>This component is intentionally independent of the gRPC heartbeat. A
 * heartbeat acknowledgement is never used as a packet-loss signal.
 */
public class NetworkTelemetryProbe {

    private final String masterHost;
    private final int masterPort;
    private final int probeCount;
    private final long probeIntervalMs;
    private final int probeTimeoutMs;

    public NetworkTelemetryProbe(String masterHost, int masterPort,
                                 int probeCount, long probeIntervalMs, int probeTimeoutMs) {
        this.masterHost = masterHost;
        this.masterPort = masterPort;
        this.probeCount = probeCount;
        this.probeIntervalMs = probeIntervalMs;
        this.probeTimeoutMs = probeTimeoutMs;
    }

    /**
     * Runs one measurement window and returns the observed values.
     *
     * @return latency and packet loss, or {@link NetworkObservation#unavailable()}
     *         if the Master address could not be resolved.
     */
    public NetworkObservation measure() {
        InetSocketAddress target = new InetSocketAddress(masterHost, masterPort);
        if (target.isUnresolved()) {
            return NetworkObservation.unavailable();
        }

        int failed = 0;
        double totalLatencyMs = 0.0;
        int successful = 0;

        for (int i = 0; i < probeCount; i++) {
            if (i > 0 && probeIntervalMs > 0) {
                try {
                    Thread.sleep(probeIntervalMs);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            long startNanos = System.nanoTime();
            if (probe(target)) {
                totalLatencyMs += (System.nanoTime() - startNanos) / 1_000_000.0;
                successful++;
            } else {
                failed++;
            }
        }

        int attempted = successful + failed;
        if (attempted == 0) {
            return NetworkObservation.unavailable();
        }

        Double latency = successful > 0 ? (totalLatencyMs / successful) : null;
        double lossPercent = (failed * 100.0) / attempted;

        return new NetworkObservation(latency, lossPercent);
    }

    private boolean probe(InetSocketAddress target) {
        try (Socket socket = new Socket()) {
            socket.connect(target, probeTimeoutMs);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}