package com.omni.pcst.node;

import com.omni.pcst.node.config.AgentConfiguration;
import com.omni.pcst.node.config.DeviceCredentialStore;
import com.omni.pcst.node.execution.WorkloadExecutor;
import com.omni.pcst.node.grpc.MasterGrpcClient;
import com.omni.pcst.node.grpc.TaskDispatchService;
import com.omni.pcst.node.telemetry.TelemetryCollector;
import com.omni.pcst.node.telemetry.TelemetryScheduler;
import com.omni.pcst.node.telemetry.TelemetrySequenceSource;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

/**
 * PCST Node Agent with task execution capability.
 *
 * <p>Starts the following components:
 * <ul>
 *   <li>gRPC server for task dispatch (port 9091 by default)</li>
 *   <li>gRPC client for Master communication (registration, heartbeat, telemetry, task lifecycle)</li>
 *   <li>Telemetry collection and delivery</li>
 *   <li>Workload execution engine</li>
 * </ul>
 *
 * <p>Configuration is supplied by {@link AgentConfiguration} with precedence:
 * defaults &lt; local configuration file &lt; environment variables &lt; system
 * properties. No secret is hard-coded. See the project documentation for the
 * full list of configuration keys.
 *
 * <p>Enrollment flow:
 * <ul>
 *   <li>First time: the operator provides a pairing code ({@code PCST_PAIRING_CODE}
 *       or {@code pcst.pairing.code}). The agent sends it to the Master; on
 *       success the Master issues a device credential which the agent stores
 *       locally with restrictive permissions.</li>
 *   <li>Reconnection: the agent loads the stored device credential and presents
 *       it on every registration, so no new pairing code is needed.</li>
 * </ul>
 * Credentials are never logged.
 */
public class PcstNodeAgent {

    private static final Logger log = LoggerFactory.getLogger(PcstNodeAgent.class);

    private static final long DEFAULT_TELEMETRY_INTERVAL_MS = 5000L;
    private static final int DEFAULT_GRPC_PORT = 9091;
    private static final String AGENT_VERSION_PROPERTY = "pcst.agent.version";
    private static final String MANIFEST_VERSION_ATTRIBUTE = "Implementation-Version";

    public static void main(String[] args) {
        // Handle version request before any heavy initialization.
        for (String arg : args) {
            if ("--version".equals(arg) || "-v".equals(arg)) {
                System.out.println("PCST Node Agent " + resolveAgentVersion(null));
                return;
            }
        }

        AgentConfiguration config = AgentConfiguration.load();
        String agentVersion = resolveAgentVersion(config.getAgentVersion());

        log.info("Starting PCST Node Agent (version={})...", agentVersion);
        log.info("Master target       : {}:{}", config.getMasterHost(), config.getMasterPort());
        log.info("Node id             : {}", config.getNodeId());
        log.info("Node dispatch port  : {}", config.getNodePort());
        log.info("Heartbeat interval  : {} ms", config.getHeartbeatIntervalMs());
        log.info("Telemetry interval  : {} ms", config.getTelemetryIntervalMs());
        if (config.hasNodeToken()) {
            log.info("Enrollment credential: configured (value not logged)");
        } else {
            log.info("Enrollment credential: not configured");
        }
        log.warn("NOTE: The Master now requires an enrollment credential (pairing code or "
                + "device credential). Remote exposure additionally requires TLS (not yet enabled).");

        // Resolve the device identity to present to the Master:
        //   1. A previously stored device credential (reconnection), or
        //   2. A configured pairing code (first-time enrollment).
        // The agent refuses to start without one, so an uncredentialed node can
        // never be trusted by the Master merely by supplying a node_id.
        Optional<String> storedCredential = DeviceCredentialStore.read();
        String deviceCredential = null;
        String pairingCode = null;

        if (storedCredential.isPresent()) {
            deviceCredential = storedCredential.get();
            log.info("Using stored device credential for reconnection (value not logged)");
        } else if (config.getDeviceCredential().isPresent()) {
            deviceCredential = config.getDeviceCredential().get();
            log.info("Using device credential from configuration (value not logged)");
        } else if (config.getPairingCode().isPresent()) {
            pairingCode = config.getPairingCode().get();
            log.info("Pairing code configured for first-time enrollment (value not logged)");
        } else {
            log.error("No enrollment credential available: provide a pairing code (PCST_PAIRING_CODE) "
                    + "or a previously stored device credential before starting the agent.");
            System.exit(1);
            return;
        }

        // One fresh session id per process lifetime, shared by registration and the
        // telemetry path so both always agree. It is distinct from the stable
        // nodeId: a change of session id is what makes a restart explicit.
        TelemetrySequenceSource sequenceSource = new TelemetrySequenceSource();
        log.info("Node Agent session id={} (node_id={})", sequenceSource.getAgentSessionId(), config.getNodeId());

        MasterGrpcClient client = new MasterGrpcClient(
                config.getMasterHost(),
                config.getMasterPort(),
                config.getNodeId(),
                config.getNodePort(),
                agentVersion,
                config.getHeartbeatIntervalMs(),
                config.getTlsMode(),
                config.getTrustCertCollectionFile().orElse(null));
        client.setRegistrationSessionId(sequenceSource.getAgentSessionId());
        client.setPairingCode(pairingCode);
        client.setDeviceCredential(deviceCredential);

        // Report successful connection only after the Master has accepted
        // registration. The recovery loop drives registration in the background
        // so an unavailable Master never blocks telemetry collection.
        client.setRegistrationListener(() -> {
            log.info("PCST Node Agent ONLINE - registration accepted by Master (node_id={})", config.getNodeId());
            // Persist any newly issued device credential so future runs reconnect
            // without a pairing code. Never log the credential.
            client.getDeviceCredential().ifPresent(issued -> {
                try {
                    DeviceCredentialStore.write(issued);
                    log.info("Device credential persisted to local machine (value not logged)");
                } catch (Exception e) {
                    log.warn("Could not persist device credential: {}", e.getMessage());
                }
            });
        });

        // Workload executor for task execution
        WorkloadExecutor workloadExecutor = new WorkloadExecutor();

        // gRPC service for task dispatch
        TaskDispatchService taskDispatchService = new TaskDispatchService(workloadExecutor, client, config.getNodeId());

        // gRPC server for incoming task dispatch requests
        Server grpcServer = ServerBuilder.forPort(config.getNodePort())
                .addService(taskDispatchService)
                .build();

        // Telemetry is collected and delivered on its own schedule. It is started before the
        // gRPC client so collection is never blocked by registration: snapshots collected
        // while the Master is unavailable simply fail to deliver and are dropped, leaving a
        // detectable sequence gap on the Master.
        TelemetryCollector telemetryCollector = new TelemetryCollector();
        TelemetryScheduler telemetryScheduler =
                new TelemetryScheduler(telemetryCollector, config.getTelemetryIntervalMs(), client, sequenceSource);
        telemetryScheduler.start();

        // Start gRPC server for task dispatch
        try {
            grpcServer.start();
            log.info("Task dispatch gRPC server started on port {}", config.getNodePort());
        } catch (Exception e) {
            log.error("Failed to start gRPC server: {}", e.getMessage(), e);
            System.exit(1);
        }

        client.start();

        // Log the registration outcome once it settles (best effort, non-blocking).
        log.info("PCST Node Agent registration state={} (node_id={})",
                client.getRegistrationState(), config.getNodeId());

        CountDownLatch latch = new CountDownLatch(1);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Shutdown signal received for Node Agent...");
            telemetryScheduler.stop();
            workloadExecutor.shutdown();
            try {
                grpcServer.shutdown().awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            client.stop();
            latch.countDown();
        }));

        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.info("Node Agent main thread interrupted.");
            telemetryScheduler.stop();
            workloadExecutor.shutdown();
            grpcServer.shutdown();
            client.stop();
        }
    }

    private static String resolveAgentVersion(String configured) {
        if (configured != null && !configured.isBlank()) {
            return configured;
        }
        String manifestVersion = readManifestVersion();
        return (manifestVersion != null && !manifestVersion.isBlank()) ? manifestVersion : "1.0.0";
    }

    private static String readManifestVersion() {
        try (InputStream in = PcstNodeAgent.class.getClassLoader()
                .getResourceAsStream("META-INF/MANIFEST.MF")) {
            if (in == null) {
                return null;
            }
            Properties manifest = new Properties();
            manifest.load(in);
            return manifest.getProperty(MANIFEST_VERSION_ATTRIBUTE);
        } catch (Exception e) {
            log.debug("Could not read manifest version: {}", e.getMessage());
            return null;
        }
    }
}
