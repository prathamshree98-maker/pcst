package com.omni.pcst.node.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Loads Node Agent configuration with the following precedence (lowest to highest):
 * <ol>
 *   <li>built-in defaults</li>
 *   <li>local configuration file</li>
 *   <li>environment variables</li>
 *   <li>Java system properties</li>
 * </ol>
 *
 * <p>No secret is ever hard-coded. The local configuration file is excluded from Git
 * (see {@code .gitignore}) and is the recommended place for operator-specific values
 * such as the Master endpoint and any enrollment credential.
 *
 * <h2>Configuration keys</h2>
 * <table>
 *   <tr><th>Property key</th><th>Environment variable</th><th>Default</th><th>Description</th></tr>
 *   <tr><td>{@code pcst.master.host}</td><td>{@code PCST_MASTER_HOST}</td><td>{@code localhost}</td><td>Master gRPC host</td></tr>
 *   <tr><td>{@code pcst.master.port}</td><td>{@code PCST_MASTER_PORT}</td><td>{@code 9090}</td><td>Master gRPC port</td></tr>
 *   <tr><td>{@code pcst.node.id}</td><td>{@code PCST_NODE_ID}</td><td>local hostname</td><td>Stable node identifier</td></tr>
 *   <tr><td>{@code pcst.node.port}</td><td>{@code PCST_NODE_PORT}</td><td>{@code 9091}</td><td>Agent task-dispatch gRPC port</td></tr>
 *   <tr><td>{@code pcst.agent.version}</td><td>{@code PCST_AGENT_VERSION}</td><td>{@code 1.0.0}</td><td>Agent version reported to Master</td></tr>
 *   <tr><td>{@code pcst.heartbeat.interval-ms}</td><td>{@code PCST_HEARTBEAT_INTERVAL_MS}</td><td>{@code 5000}</td><td>Heartbeat interval</td></tr>
 *   <tr><td>{@code pcst.telemetry.interval-ms}</td><td>{@code PCST_TELEMETRY_INTERVAL_MS}</td><td>{@code 5000}</td><td>Telemetry interval</td></tr>
 *   <tr><td>{@code pcst.recovery.backoff-ms}</td><td>{@code PCST_RECOVERY_BACKOFF_MS}</td><td>{@code 2000}</td><td>Initial registration recovery backoff (ms)</td></tr>
 *   <tr><td>{@code pcst.node.token}</td><td>{@code PCST_NODE_TOKEN}</td><td>(none)</td><td>Enrollment credential (not yet validated by Master; pairing deferred)</td></tr>
 * </table>
 *
 * <h2>Configuration file</h2>
 * The file location is resolved in order:
 * <ol>
 *   <li>{@code PCST_AGENT_CONFIG} environment variable (absolute path)</li>
 *   <li>{@code config/pcst-agent.properties} in the current working directory</li>
 *   <li>{@code ~/.pcst/agent.properties}</li>
 * </ol>
 * The first existing file is used.
 */
public final class AgentConfiguration {

    private static final Logger log = LoggerFactory.getLogger(AgentConfiguration.class);

    private static final String CONFIG_ENV = "PCST_AGENT_CONFIG";
    private static final String CWD_CONFIG = "config/pcst-agent.properties";
    private static final String HOME_CONFIG = System.getProperty("user.home") + File.separator + ".pcst" + File.separator + "agent.properties";

    private static final Map<String, String> DEFAULTS = new LinkedHashMap<>();
    static {
        DEFAULTS.put("pcst.master.host", "localhost");
        DEFAULTS.put("pcst.master.port", "9090");
        DEFAULTS.put("pcst.node.id", resolveDefaultNodeId());
        DEFAULTS.put("pcst.node.port", "9091");
        DEFAULTS.put("pcst.agent.version", "1.0.0");
        DEFAULTS.put("pcst.heartbeat.interval-ms", "5000");
        DEFAULTS.put("pcst.telemetry.interval-ms", "5000");
        DEFAULTS.put("pcst.recovery.backoff-ms", "2000");
        DEFAULTS.put("pcst.node.token", "");
        DEFAULTS.put("pcst.pairing.code", "");
        DEFAULTS.put("pcst.device.credential", "");
        DEFAULTS.put("pcst.grpc.tls.mode", "disabled");
        DEFAULTS.put("pcst.grpc.tls.trust-cert-collection-file", "");
    }

    private static final Map<String, String> ENV_MAP = new LinkedHashMap<>();
    static {
        ENV_MAP.put("pcst.master.host", "PCST_MASTER_HOST");
        ENV_MAP.put("pcst.master.port", "PCST_MASTER_PORT");
        ENV_MAP.put("pcst.node.id", "PCST_NODE_ID");
        ENV_MAP.put("pcst.node.port", "PCST_NODE_PORT");
        ENV_MAP.put("pcst.agent.version", "PCST_AGENT_VERSION");
        ENV_MAP.put("pcst.heartbeat.interval-ms", "PCST_HEARTBEAT_INTERVAL_MS");
        ENV_MAP.put("pcst.telemetry.interval-ms", "PCST_TELEMETRY_INTERVAL_MS");
        ENV_MAP.put("pcst.recovery.backoff-ms", "PCST_RECOVERY_BACKOFF_MS");
        ENV_MAP.put("pcst.node.token", "PCST_NODE_TOKEN");
        ENV_MAP.put("pcst.pairing.code", "PCST_PAIRING_CODE");
        ENV_MAP.put("pcst.device.credential", "PCST_DEVICE_CREDENTIAL");
        ENV_MAP.put("pcst.grpc.tls.mode", "PCST_GRPC_TLS_MODE");
        ENV_MAP.put("pcst.grpc.tls.trust-cert-collection-file", "PCST_GRPC_TLS_TRUST_CERT_COLLECTION_FILE");
    }

    private final Properties properties = new Properties();

    private AgentConfiguration() {
        // 1. defaults
        DEFAULTS.forEach(properties::setProperty);

        // 2. local configuration file
        File configFile = resolveConfigFile();
        if (configFile != null && configFile.isFile()) {
            try (InputStream in = new FileInputStream(configFile)) {
                properties.load(in);
                log.info("Loaded Node Agent configuration from {}", configFile.getAbsolutePath());
            } catch (IOException e) {
                log.warn("Could not read configuration file {}: {}", configFile.getAbsolutePath(), e.getMessage());
            }
        } else {
            log.debug("No Node Agent configuration file found (checked PCST_AGENT_CONFIG, config/pcst-agent.properties, ~/.pcst/agent.properties)");
        }

        // 3. environment variables (override file)
        ENV_MAP.forEach((key, env) -> {
            String value = System.getenv(env);
            if (value != null && !value.isBlank()) {
                properties.setProperty(key, value.trim());
                if ("pcst.node.token".equals(key)) {
                    log.debug("Enrollment credential configured via environment variable {}", env);
                } else {
                    log.debug("Configuration override from environment {} = {}", env, value);
                }
            }
        });

        // 4. system properties (highest precedence)
        ENV_MAP.keySet().forEach(key -> {
            String value = System.getProperty(key);
            if (value != null && !value.isBlank()) {
                properties.setProperty(key, value.trim());
            }
        });
    }

    public static AgentConfiguration load() {
        return new AgentConfiguration();
    }

    public String getMasterHost() {
        return required("pcst.master.host");
    }

    public int getMasterPort() {
        return parseInt("pcst.master.port", 9090);
    }

    public String getNodeId() {
        return required("pcst.node.id");
    }

    public int getNodePort() {
        return parseInt("pcst.node.port", 9091);
    }

    public String getAgentVersion() {
        return required("pcst.agent.version");
    }

    public long getHeartbeatIntervalMs() {
        return parseLong("pcst.heartbeat.interval-ms", 5000L);
    }

    public long getTelemetryIntervalMs() {
        return parseLong("pcst.telemetry.interval-ms", 5000L);
    }

    public long getRecoveryBackoffMs() {
        return parseLong("pcst.recovery.backoff-ms", 2000L);
    }

    /**
     * @return the TLS mode: {@code disabled}, {@code development}, or {@code production}
     */
    public String getTlsMode() {
        return required("pcst.grpc.tls.mode");
    }

    /**
     * @return the path to the trusted certificate collection (PEM) for verifying the Master,
     *         or empty when none is configured
     */
    public Optional<String> getTrustCertCollectionFile() {
        String value = properties.getProperty("pcst.grpc.tls.trust-cert-collection-file");
        return (value == null || value.isBlank()) ? Optional.empty() : Optional.of(value);
    }

    /**
     * @return {@code true} when TLS is enabled for the agent-to-Master connection
     */
    public boolean isTlsEnabled() {
        return !"disabled".equalsIgnoreCase(getTlsMode());
    }

    /**
     * @return the configured enrollment credential, or empty when none is set.
     *         The value must never be logged.
     */
    public Optional<String> getNodeToken() {
        String value = properties.getProperty("pcst.node.token");
        return (value == null || value.isBlank()) ? Optional.empty() : Optional.of(value);
    }

    public boolean hasNodeToken() {
        return getNodeToken().isPresent();
    }

    /**
     * @return the one-time pairing code configured for first-time enrollment, or
     *         empty when none is set. The value must never be logged.
     */
    public Optional<String> getPairingCode() {
        String value = properties.getProperty("pcst.pairing.code");
        return (value == null || value.isBlank()) ? Optional.empty() : Optional.of(value);
    }

    /**
     * @return a device credential supplied as a bootstrap override, or empty when
     *         none is set. The value must never be logged.
     */
    public Optional<String> getDeviceCredential() {
        String value = properties.getProperty("pcst.device.credential");
        return (value == null || value.isBlank()) ? Optional.empty() : Optional.of(value);
    }

    /* ---------------------------------------------------------------- internals */

    private static String resolveDefaultNodeId() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            return "node-agent-1";
        }
    }

    private static File resolveConfigFile() {
        String envPath = System.getenv(CONFIG_ENV);
        if (envPath != null && !envPath.isBlank()) {
            File f = new File(envPath.trim());
            if (f.isFile()) {
                return f;
            }
            log.warn("PCST_AGENT_CONFIG points to a non-existent file: {}", envPath);
        }
        File cwd = new File(CWD_CONFIG);
        if (cwd.isFile()) {
            return cwd;
        }
        File home = new File(HOME_CONFIG);
        if (home.isFile()) {
            return home;
        }
        return null;
    }

    private String required(String key) {
        String value = properties.getProperty(key);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Required configuration missing: " + key);
        }
        return value;
    }

    private int parseInt(String key, int fallback) {
        try {
            return Integer.parseInt(properties.getProperty(key));
        } catch (Exception e) {
            return fallback;
        }
    }

    private long parseLong(String key, long fallback) {
        try {
            return Long.parseLong(properties.getProperty(key));
        } catch (Exception e) {
            return fallback;
        }
    }
}
