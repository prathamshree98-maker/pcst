package com.omni.pcst.node.telemetry;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Per-process telemetry identity and sequence source for one Node Agent.
 *
 * <h2>Session identity</h2>
 * A fresh {@link UUID} is generated when the instance is created, i.e. once per
 * Node Agent process lifetime. It is stable for that lifetime and is never
 * reused after a restart. It is deliberately distinct from the stable
 * {@code nodeId}: {@code nodeId} survives restarts, the session id does not, so
 * a change of session id is what makes a restart explicit to the Master and what
 * authorises it to reset sequence tracking.
 *
 * <h2>Sequence semantics</h2>
 * <ul>
 *   <li><b>One-based.</b> The first snapshot in a process is sequence 1.</li>
 *   <li><b>Strictly increasing</b> within a session, assigned exactly once per
 *       produced snapshot.</li>
 *   <li><b>Assigned before transmission.</b> The number is drawn when the
 *       snapshot is produced, before any send is attempted, so a failed send
 *       leaves the number consumed. A later successful message therefore
 *       reveals the earlier failure instead of hiding it.</li>
 *   <li><b>Never renumbered.</b> A failed or rejected send does not release or
 *       reuse its sequence number.</li>
 *   <li><b>Telemetry only.</b> Heartbeats are produced by a completely separate
 *       schedule and never consume a telemetry sequence number.</li>
 *   <li><b>Reset scope.</b> The counter restarts at 1 only for a new session
 *       (a new instance of this class, normally a new process).</li>
 * </ul>
 *
 * <p>Thread-safe: {@link AtomicLong#incrementAndGet()} guarantees uniqueness
 * and monotonicity even if snapshots were produced from several threads.
 */
public final class TelemetrySequenceSource {

    private final String agentSessionId;
    private final AtomicLong sequence = new AtomicLong(0L);

    /** Creates a source with a freshly generated session id. */
    public TelemetrySequenceSource() {
        this(UUID.randomUUID().toString());
    }

    /**
     * Test seam: uses a caller-supplied session id. Production code uses
     * {@link #TelemetrySequenceSource()} so a session id is always a fresh UUID.
     */
    public TelemetrySequenceSource(String agentSessionId) {
        if (agentSessionId == null || agentSessionId.isBlank()) {
            throw new IllegalArgumentException("agentSessionId must be non-blank");
        }
        this.agentSessionId = agentSessionId;
    }

    /** @return this process lifetime's session id; never null or blank */
    public String getAgentSessionId() {
        return agentSessionId;
    }

    /**
     * Consumes and returns the next sequence number.
     *
     * <p>Called once per produced snapshot, before the send attempt. A failed
     * send does not roll the counter back.
     *
     * @return a one-based, strictly increasing sequence number
     */
    public long nextSequence() {
        return sequence.incrementAndGet();
    }

    /**
     * @return the highest sequence number handed out so far, without consuming
     * one. Zero before the first snapshot.
     */
    public long lastIssuedSequence() {
        return sequence.get();
    }
}