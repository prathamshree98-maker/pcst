package com.omni.pcst.node.telemetry;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.hardware.GraphicsCard;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.hardware.PowerSource;
import oshi.software.os.FileSystem;
import oshi.software.os.OSFileStore;
import oshi.software.os.OperatingSystem;

public class TelemetryCollector {

    private static final Logger log = LoggerFactory.getLogger(TelemetryCollector.class);

    private final HardwareAbstractionLayer hardware;
    private final CentralProcessor processor;
    private final GlobalMemory memory;
    private final OperatingSystem operatingSystem;
    private final NetworkTelemetryProbe networkProbe;

    public TelemetryCollector() {
        SystemInfo si = new SystemInfo();
        this.hardware = si.getHardware();
        this.processor = hardware.getProcessor();
        this.memory = hardware.getMemory();
        this.operatingSystem = si.getOperatingSystem();

        String masterHost = System.getProperty("grpc.master.host", "localhost");
        int masterPort = Integer.parseInt(System.getProperty("grpc.master.port", "9090"));
        int probeCount = Integer.parseInt(System.getProperty("net.probe.count", "4"));
        long probeIntervalMs = Long.parseLong(System.getProperty("net.probe.interval-ms", "100"));
        int probeTimeoutMs = Integer.parseInt(System.getProperty("net.probe.timeout-ms", "1000"));

        this.networkProbe = new NetworkTelemetryProbe(
                masterHost, masterPort, probeCount, probeIntervalMs, probeTimeoutMs);
    }

    /**
     * Temporary diagnostic logging for the battery accuracy investigation.
     * Logs the raw OSHI values of every returned power source so a reported
     * percentage can be traced back to its inputs. Enable debug logging to see
     * it; the {@code BATTERY_DIAG} prefix makes it greppable.
     */
    private static void logBatteryDiagnostics(List<PowerSource> powerSources) {
        if (!log.isDebugEnabled()) {
            return;
        }
        for (int i = 0; i < powerSources.size(); i++) {
            PowerSource ps = powerSources.get(i);
            if (ps == null) {
                log.debug("BATTERY_DIAG raw[{}]: null entry", i);
                continue;
            }
            log.debug("BATTERY_DIAG raw[{}]: name='{}' deviceName='{}' fraction={} current={} max={} design={} "
                            + "units={} estimatedTime={} powerOnLine={} charging={} discharging={}",
                    i, ps.getName(), ps.getDeviceName(), ps.getRemainingCapacityPercent(),
                    ps.getCurrentCapacity(), ps.getMaxCapacity(), ps.getDesignCapacity(),
                    ps.getCapacityUnits(), ps.getTimeRemainingEstimated(),
                    ps.isPowerOnLine(), ps.isCharging(), ps.isDischarging());
        }
    }

    public TelemetrySnapshot collect() {
        double cpuLoad = processor.getSystemCpuLoad(500) * 100.0;

        long totalMemory = memory.getTotal();
        long usedMemory = totalMemory - memory.getAvailable();
        long availableMemory = memory.getAvailable();

        FileSystem fileSystem = operatingSystem.getFileSystem();
        long totalDisk = 0;
        long freeDisk = 0;

        for (OSFileStore fs : fileSystem.getFileStores()) {
            totalDisk += fs.getTotalSpace();
            freeDisk += fs.getFreeSpace();
        }

        Double batteryLevel = null;
        Boolean batteryCharging = null;
        List<PowerSource> powerSources = hardware.getPowerSources();
        if (powerSources != null && !powerSources.isEmpty()) {
            logBatteryDiagnostics(powerSources);
            PowerSource selected = BatteryLevelCalculator.selectPrimary(powerSources);
            if (selected != null) {
                batteryLevel = BatteryLevelCalculator.toPercent(selected);
                // Charging state is retained independently of whether the
                // percentage itself could be corroborated.
                batteryCharging = selected.isCharging();
                log.debug("BATTERY_DIAG final: source='{}' fraction={} current={} max={} -> level={} charging={}",
                        selected.getName(), selected.getRemainingCapacityPercent(),
                        selected.getCurrentCapacity(), selected.getMaxCapacity(),
                        batteryLevel == null ? "unavailable" : batteryLevel + "%", batteryCharging);
            }
        }

        Double temperature = null;
        double cpuTemperature = hardware.getSensors().getCpuTemperature();
        if (cpuTemperature > 0.0) {
            temperature = cpuTemperature;
        }

        Boolean gpuAvailable = Boolean.FALSE;
        Double gpuUtil = null;
        List<GraphicsCard> graphicsCards = hardware.getGraphicsCards();
        if (graphicsCards != null && !graphicsCards.isEmpty()) {
            gpuAvailable = Boolean.TRUE;
        }

        NetworkObservation network = networkProbe.measure();

        return new TelemetrySnapshot(
            System.currentTimeMillis(),
            cpuLoad,
            totalMemory,
            usedMemory,
            availableMemory,
            totalDisk,
            freeDisk,
            operatingSystem.getProcessCount(),
            batteryLevel,
            batteryCharging,
            temperature,
            gpuAvailable,
            gpuUtil,
            network.latencyMs(),
            network.packetLossPercent()
        );
    }
}