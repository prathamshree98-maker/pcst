package com.omni.pcst.node.telemetry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.omni.pcst.node.grpc.MasterGrpcClient;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Periodically collects telemetry on its own thread, independent of the
 * heartbeat scheduler owned by the gRPC client.
 *
 * <p>Collection is dispatched to a single-threaded executor using
 * {@code scheduleWithFixedDelay}, which gives two properties this class depends
 * on:
 *
 * <ul>
 *   <li>Tasks never run concurrently with themselves, so
 *       {@link TelemetryCollector#collect()} can never be re-entered even if a
 *       slow collection outlasts the configured interval.</li>
 *   <li>The next run is scheduled relative to the <em>end</em> of the previous
 *       run, so a slow collection cannot cause a backlog of catch-up runs.</li>
 * </ul>
 */
public class TelemetryScheduler {

    private static final Logger log = LoggerFactory.getLogger(TelemetryScheduler.class);

    private final TelemetryCollector collector;
    private final long intervalMs;
    private final MasterGrpcClient client;
    private final TelemetrySequenceSource sequenceSource;

    private ScheduledExecutorService executor;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public TelemetryScheduler(TelemetryCollector collector, long intervalMs, MasterGrpcClient client) {
        this(collector, intervalMs, client, new TelemetrySequenceSource());
    }

    /**
     * Full constructor. The sequence source is injected so the production
     * telemetry path can be exercised with a known session identity; production
     * code uses the three-argument constructor, which creates a fresh session.
     */
    public TelemetryScheduler(TelemetryCollector collector, long intervalMs, MasterGrpcClient client,
                              TelemetrySequenceSource sequenceSource) {
        this.collector = collector;
        this.intervalMs = intervalMs;
        this.client = client;
        this.sequenceSource = sequenceSource;
    }

    /**
     * @return this agent process lifetime's session id: stable for the lifetime
     * of the owning {@link TelemetrySequenceSource}, new on every restart.
     */
    public String getAgentSessionId() {
        return sequenceSource.getAgentSessionId();
    }

    /** @return the highest telemetry sequence number issued so far */
    public long lastIssuedSequence() {
        return sequenceSource.lastIssuedSequence();
    }

    public void start() {
        if (!running.compareAndSet(false, true)) {
            log.warn("Telemetry scheduler already started; ignoring duplicate start().");
            return;
        }

        ThreadFactory threadFactory = runnable -> {
            Thread thread = new Thread(runnable, "pcst-telemetry");
            thread.setDaemon(true);
            return thread;
        };

        executor = Executors.newSingleThreadScheduledExecutor(threadFactory);
        log.info("Starting telemetry scheduler: interval={} ms", intervalMs);
        executor.scheduleWithFixedDelay(this::collectOnce, intervalMs, intervalMs, TimeUnit.MILLISECONDS);
    }

    private void collectOnce() {
        try {
            TelemetrySnapshot snapshot = collector.collect();

            // The sequence number is consumed BEFORE any send is attempted. A
            // failed send therefore leaves the number used: it is never released
            // and never reused, so the next successful message exposes the gap on
            // the Master instead of silently renumbering over it.
            long telemetrySequence = sequenceSource.nextSequence();

            // Collection and delivery are separate outcomes and are logged as such: a
            // failure to deliver must never be reported as a successful send.
            log.info("Telemetry snapshot collected: timestamp={}, cpu={}%, session={}, sequence={}",
                    snapshot.timestamp(), snapshot.cpuUtilization(),
                    sequenceSource.getAgentSessionId(), telemetrySequence);
            log.debug("Telemetry snapshot detail: {}", snapshot);

            if (client.sendTelemetry(snapshot, sequenceSource.getAgentSessionId(), telemetrySequence)) {
                log.debug("Telemetry snapshot delivered to Master: timestamp={}, sequence={}",
                        snapshot.timestamp(), telemetrySequence);
            } else {
                log.debug("Telemetry snapshot collected but delivery failed (timestamp={}, sequence={}); "
                        + "sequence consumed, snapshot dropped, no local buffering",
                        snapshot.timestamp(), telemetrySequence);
            }
        } catch (Exception e) {
            // The schedule must survive a failed cycle, so the exception is logged and
            // swallowed here; the next run is already scheduled by the executor.
            log.warn("Telemetry collection cycle failed: {}", e.getMessage());
        }
    }

    public void stop() {
        if (!running.compareAndSet(true, false)) {
            return;
        }

        log.info("Stopping telemetry scheduler...");
        if (executor != null) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    log.warn("Telemetry collection did not finish in time; forcing shutdown.");
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
            executor = null;
        }
        log.info("Telemetry scheduler stopped.");
    }

    /**
     * Reads the telemetry interval from {@code grpc.telemetry.interval-ms},
     * falling back to {@code defaultIntervalMs} when the property is missing,
     * non-numeric, or non-positive.
     */
    public static long resolveIntervalMs(String propertyValue, long defaultIntervalMs) {
        if (propertyValue == null || propertyValue.isBlank()) {
            return defaultIntervalMs;
        }
        long parsed;
        try {
            parsed = Long.parseLong(propertyValue.trim());
        } catch (NumberFormatException e) {
            log.warn("Invalid grpc.telemetry.interval-ms='{}'; using default {} ms",
                    propertyValue, defaultIntervalMs);
            return defaultIntervalMs;
        }
        if (parsed <= 0) {
            log.warn("Non-positive grpc.telemetry.interval-ms={}; using default {} ms",
                    parsed, defaultIntervalMs);
            return defaultIntervalMs;
        }
        return parsed;
    }
}