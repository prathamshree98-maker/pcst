package com.omni.pcst.node.telemetry;

public record TelemetrySnapshot(
    long timestamp,
    double cpuUtilization,
    long totalMemory,
    long usedMemory,
    long availableMemory,
    long totalDisk,
    long freeDisk,
    int processCount,
    Double batteryLevelPercent,
    Boolean batteryCharging,
    Double temperatureCelsius,
    Boolean gpuAvailable,
    Double gpuUtilizationPercent,
    Double latencyMs,
    Double packetLossPercent
) {}