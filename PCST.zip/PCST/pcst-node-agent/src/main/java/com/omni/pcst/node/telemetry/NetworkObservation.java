package com.omni.pcst.node.telemetry;

/**
 * Immutable holder for a single network observation taken between this Node
 * Agent and the configured PCST Master.
 *
 * <p>A {@code null} value means the observation could not be measured. It never
 * means "zero".
 */
public record NetworkObservation(Double latencyMs, Double packetLossPercent) {

    /** No measurement could be taken at all, e.g. the Master address is unresolvable. */
    public static NetworkObservation unavailable() {
        return new NetworkObservation(null, null);
    }
}