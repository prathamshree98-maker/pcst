package com.omni.pcst.node.grpc;

import com.omni.pcst.node.execution.WorkloadExecutor;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.TaskDispatchRequest;
import com.omni.pcst.proto.TaskDispatchResponse;
import com.omni.pcst.proto.TaskLifecycleUpdate;
import com.omni.pcst.proto.TaskResult;
import com.omni.pcst.proto.TaskState;
import io.grpc.stub.StreamObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * gRPC service implementation for task dispatch on the Node Agent.
 *
 * <p>Handles {@code DispatchTask} RPCs from the Master, validates the request,
 * delegates execution to the {@link WorkloadExecutor}, and reports lifecycle
 * updates back to the Master via {@code ReportTaskLifecycle}.
 */
public class TaskDispatchService extends NodeServiceGrpc.NodeServiceImplBase {

    private static final Logger log = LoggerFactory.getLogger(TaskDispatchService.class);

    private final WorkloadExecutor workloadExecutor;
    private final MasterGrpcClient grpcClient;
    private final String nodeId;

    public TaskDispatchService(WorkloadExecutor workloadExecutor,
                               MasterGrpcClient grpcClient,
                               String nodeId) {
        this.workloadExecutor = workloadExecutor;
        this.grpcClient = grpcClient;
        this.nodeId = nodeId;
    }

    @Override
    public void dispatchTask(TaskDispatchRequest request, StreamObserver<TaskDispatchResponse> responseObserver) {
        String taskId = request.getTaskId();
        String attemptId = request.getAttemptId();
        String workloadType = request.getWorkloadType();
        String payload = request.getPayload();
        long deadlineEpochMillis = request.getDeadlineEpochMillis();

        log.info("Received task dispatch: taskId={}, attemptId={}, workloadType={}, deadline={}",
                taskId, attemptId, workloadType, deadlineEpochMillis > 0 ? deadlineEpochMillis : "none");

        TaskDispatchResponse.Builder responseBuilder = TaskDispatchResponse.newBuilder()
                .setServerTime(System.currentTimeMillis());

        // Validate request
        if (taskId == null || taskId.isBlank()) {
            log.warn("Dispatch rejected: blank task_id");
            sendResponse(responseBuilder.setAccepted(false).setMessage("task_id cannot be blank").build(), responseObserver);
            return;
        }
        if (attemptId == null || attemptId.isBlank()) {
            log.warn("Dispatch rejected: blank attempt_id");
            sendResponse(responseBuilder.setAccepted(false).setMessage("attempt_id cannot be blank").build(), responseObserver);
            return;
        }
        if (workloadType == null || workloadType.isBlank()) {
            log.warn("Dispatch rejected: blank workload_type");
            sendResponse(responseBuilder.setAccepted(false).setMessage("workload_type cannot be blank").build(), responseObserver);
            return;
        }

        // Check deadline if provided
        if (deadlineEpochMillis > 0 && System.currentTimeMillis() > deadlineEpochMillis) {
            log.warn("Dispatch rejected: deadline already passed for taskId={}", taskId);
            sendResponse(responseBuilder.setAccepted(false).setMessage("deadline already passed").build(), responseObserver);
            return;
        }

        // Execute workload asynchronously. The immediate result indicates whether the
        // dispatch was accepted; the final SUCCEEDED/FAILED outcome is reported through
        // the completion callback only after the workload has actually finished, so the
        // Master never marks a task successful merely because dispatch succeeded.
        try {
            TaskResult immediate = workloadExecutor.execute(attemptId, workloadType, payload,
                    result -> {
                        TaskState terminal = result.getSuccess() ? TaskState.SUCCEEDED : TaskState.FAILED;
                        sendLifecycleUpdate(taskId, attemptId, terminal,
                                result.getSuccess() ? "execution completed"
                                        : ("execution failed: " + result.getError()),
                                result);
                    });
            if (!immediate.getSuccess()) {
                // Execution was rejected (e.g., duplicate attempt)
                sendLifecycleUpdate(taskId, attemptId, TaskState.REJECTED, immediate.getError(), immediate);
                sendResponse(responseBuilder.setAccepted(false).setMessage(immediate.getError()).build(), responseObserver);
                return;
            }
            // Report the lifecycle synchronously: dispatch accepted, then execution
            // started. The terminal SUCCEEDED/FAILED update is sent later from the
            // completion callback, so a fast workload can never report a terminal
            // result before the Master has observed that execution started. Sending
            // these two updates before the response also removes the need for an
            // arbitrary delay to order RUNNING ahead of completion.
            sendLifecycleUpdate(taskId, attemptId, TaskState.ACCEPTED, "dispatch accepted", null);
            sendLifecycleUpdate(taskId, attemptId, TaskState.RUNNING, "execution started", null);
            sendResponse(responseBuilder.setAccepted(true).setMessage("dispatch accepted").build(), responseObserver);
        } catch (IllegalArgumentException e) {
            log.warn("Dispatch rejected: invalid request for taskId={}: {}", taskId, e.getMessage());
            sendResponse(responseBuilder.setAccepted(false).setMessage(e.getMessage()).build(), responseObserver);
        } catch (WorkloadExecutor.WorkloadRejectedException e) {
            log.warn("Dispatch rejected: executor queue full for taskId={}: {}", taskId, e.getMessage());
            sendResponse(responseBuilder.setAccepted(false).setMessage("execution queue full").build(), responseObserver);
        } catch (Exception e) {
            log.error("Unexpected error dispatching taskId={}: {}", taskId, e.getMessage(), e);
            sendResponse(responseBuilder.setAccepted(false).setMessage("internal error: " + e.getMessage()).build(), responseObserver);
        }
    }

    private void sendLifecycleUpdate(String taskId, String attemptId, TaskState state,
                                     String message, TaskResult result) {
        TaskLifecycleUpdate update = TaskLifecycleUpdate.newBuilder()
                .setTaskId(taskId)
                .setAttemptId(attemptId)
                .setNodeId(nodeId)
                .setState(state)
                .setTimestamp(System.currentTimeMillis())
                .setMessage(message != null ? message : "")
                .setResult(result != null ? result : TaskResult.getDefaultInstance())
                .build();

        grpcClient.sendTaskLifecycle(update);
    }

    private void sendResponse(TaskDispatchResponse response, StreamObserver<TaskDispatchResponse> observer) {
        observer.onNext(response);
        observer.onCompleted();
    }
}