package com.omni.pcst.node.config;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Builds gRPC TLS contexts for the Node Agent.
 *
 * <p>When TLS is enabled, the agent verifies the Master certificate and hostname
 * using a trusted certificate collection (PEM). Certificate verification is never
 * disabled and no trust-all fallback is provided.
 */
public final class TlsContexts {

    private static final Logger log = LoggerFactory.getLogger(TlsContexts.class);

    private TlsContexts() {
    }

    /**
     * Builds a client-side SSL context configured to trust the Master's certificate
     * authority.
     *
     * @param trustCertCollectionFile path to the trusted certificate collection (PEM)
     * @return the built SSL context
     * @throws IOException when the trust collection cannot be read
     */
    public static io.grpc.netty.shaded.io.netty.handler.ssl.SslContext clientContext(
            String trustCertCollectionFile) throws IOException {
        File trustCert = Paths.get(trustCertCollectionFile).toFile();
        if (!trustCert.isFile()) {
            throw new IOException("Trust certificate collection not found: " + trustCert);
        }
        log.info("Configuring TLS client trust store: {}", trustCert.getAbsolutePath());
        return io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts.forClient()
                .trustManager(trustCert)
                .build();
    }

    /**
     * @param mode the TLS mode from configuration
     * @return {@code true} when a TLS context should be used (mode is not disabled)
     */
    public static boolean isTlsEnabled(String mode) {
        return mode != null && !"disabled".equalsIgnoreCase(mode);
    }
}
