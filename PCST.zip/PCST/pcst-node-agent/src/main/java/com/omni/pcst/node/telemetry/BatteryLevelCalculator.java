package com.omni.pcst.node.telemetry;

import java.util.List;
import java.util.Objects;

import oshi.hardware.PowerSource;

/**
 * Interprets OSHI {@link PowerSource} battery readings without fabricating data.
 *
 * <h2>Why this exists</h2>
 * <p>OSHI 6.6.1 {@code WindowsPowerSource.getPowerSource()} initializes the
 * remaining-capacity fraction to {@code 1.0} and only overwrites it with
 * {@code Math.min(1.0, remainingCapacity / maxCapacity)} when the Windows
 * {@code SystemBatteryState} query succeeds and a battery is present
 * (verified against the 6.6.1 bytecode in our dependency). When the query
 * fails, the fraction stays at the {@code 1.0} default while the raw current
 * capacity stays at its {@code 0} default — so a blind
 * {@code fraction * 100.0} conversion reports a fabricated {@code 100%}.
 *
 * <h2>Detection mechanism</h2>
 * <p>A fraction is accepted only when corroborated by the raw capacities
 * exposed by the same {@link PowerSource} API:
 * <ul>
 *   <li>non-finite or out-of-range fractions are rejected;</li>
 *   <li>{@code maxCapacity <= 1} means no usable capacity data (OSHI's default
 *       is {@code 1}), so nothing can be corroborated — rejected;</li>
 *   <li>otherwise the fraction must agree with {@code current / max} within
 *       {@link #CONSISTENCY_TOLERANCE}. The tolerance covers only timing and
 *       rounding drift between OSHI's two Windows queries
 *       ({@code SystemBatteryState} vs. per-device {@code BATTERY_STATUS} /
 *       {@code BATTERY_INFORMATION}); a failed query leaves a gross mismatch
 *       (e.g. {@code 1.0} vs {@code 0.0}).</li>
 * </ul>
 * <p>When the fraction disagrees but the raw device capacities themselves are
 * valid ({@code max > 1}, {@code 0 < current <= max}), the raw
 * {@code current / max} ratio is used instead: both come from the same
 * per-device Windows IOCTLs in the same units, so the ratio is a measurement,
 * not a guess. This covers the observed partial-failure mode where the
 * {@code SystemBatteryState} query fails (fraction left at the {@code 1.0}
 * default) while the device query succeeds.
 * <p>Anything else yields {@code null} (unavailable) — never a guessed value.
 * In particular a {@code 1.0} fraction with no usable capacities
 * ({@code max <= 1}) is the failure sentinel, not 100%, and a zero current
 * with real capacity but an inconsistent fraction is ambiguous (failed status
 * query vs. empty battery), so it also yields {@code null}. A genuine
 * {@code 0%} (fraction {@code 0.0} with matching raw capacities) is preserved
 * as {@code 0.0} and stays distinct from {@code null}.
 *
 * <h2>Limitations</h2>
 * <ul>
 *   <li>Relies on OSHI 6.6.1 {@code WindowsPowerSource} default values
 *       (fraction {@code 1.0}, current {@code 0}, max {@code 1} — observed in
 *       the dependency bytecode). Re-verify against the bytecode if the OSHI
 *       version changes.</li>
 *   <li>Prefers the per-device capacity ratio over a stale fraction; if both
 *       Windows queries disagree and neither is corroborated, reports
 *       unavailable.</li>
 *   <li>Charging state is passed through from OSHI independently and is not
 *       validated here.</li>
 * </ul>
 */
public final class BatteryLevelCalculator {

    /**
     * Maximum allowed drift between OSHI's normalized fraction and the raw
     * {@code current / max} ratio before the reading is deemed inconsistent.
     */
    public static final double CONSISTENCY_TOLERANCE = 0.05;

    private BatteryLevelCalculator() {
    }

    /**
     * Converts one {@link PowerSource} to a battery level percentage.
     *
     * @return the level in percent, or {@code null} when the reading cannot be
     *         corroborated and must be reported as unavailable
     */
    public static Double toPercent(PowerSource powerSource) {
        Objects.requireNonNull(powerSource, "powerSource");
        double fraction = powerSource.getRemainingCapacityPercent();
        int currentCapacity = powerSource.getCurrentCapacity();
        int maxCapacity = powerSource.getMaxCapacity();

        boolean fractionUsable =
                Double.isFinite(fraction) && fraction >= 0.0 && fraction <= 1.0;
        boolean rawUsable =
                maxCapacity > 1 && currentCapacity > 0 && currentCapacity <= maxCapacity;

        if (fractionUsable && maxCapacity > 1 && currentCapacity >= 0) {
            double rawRatio = (double) currentCapacity / (double) maxCapacity;
            if (Math.abs(rawRatio - fraction) <= CONSISTENCY_TOLERANCE) {
                return fraction * 100.0;
            }
            // Falls through to the raw-ratio fallback below when the two
            // Windows queries disagree.
        }
        if (rawUsable) {
            // The normalized fraction is stale or missing (e.g. the 1.0
            // default left by a failed SystemBatteryState query), but the
            // per-device capacities are valid measurements in the same units,
            // so their ratio is used. This is never reached for the total
            // failure sentinel (current 0 / max 1), which stays unavailable.
            return ((double) currentCapacity / (double) maxCapacity) * 100.0;
        }
        // No corroborated measurement: OSHI's 1.0 failure default must never
        // become 100%, and an ambiguous zero current must never become 0%.
        return null;
    }

    /**
     * Selects the primary power source: the first source whose level can be
     * corroborated, falling back to the first source when none can (so the
     * charging state of the primary source is still observable). Returns
     * {@code null} for a null or empty list.
     */
    public static PowerSource selectPrimary(List<PowerSource> powerSources) {
        if (powerSources == null || powerSources.isEmpty()) {
            return null;
        }
        for (PowerSource powerSource : powerSources) {
            if (powerSource != null && toPercent(powerSource) != null) {
                return powerSource;
            }
        }
        return powerSources.get(0);
    }
}
