package com.omni.pcst.node.grpc;

import com.omni.pcst.node.config.DeviceCredentialStore;
import com.omni.pcst.node.config.TlsContexts;
import com.omni.pcst.node.telemetry.TelemetrySnapshot;import com.omni.pcst.proto.BatteryTelemetry;
import com.omni.pcst.proto.CpuTelemetry;
import com.omni.pcst.proto.DiskTelemetry;
import com.omni.pcst.proto.GpuTelemetry;
import com.omni.pcst.proto.HeartbeatRequest;
import com.omni.pcst.proto.HeartbeatResponse;
import com.omni.pcst.proto.MemoryTelemetry;
import com.omni.pcst.proto.NetworkTelemetry;
import com.omni.pcst.proto.NodeServiceGrpc;
import com.omni.pcst.proto.ProcessTelemetry;
import com.omni.pcst.proto.RegisterNodeRequest;
import com.omni.pcst.proto.RegisterNodeResponse;
import com.omni.pcst.proto.TaskLifecycleUpdate;
import com.omni.pcst.proto.TaskLifecycleAck;
import com.omni.pcst.proto.TelemetryRequest;
import com.omni.pcst.proto.TelemetryResponse;
import com.omni.pcst.proto.TemperatureTelemetry;
import io.grpc.ManagedChannel;
import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.InetAddress;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * gRPC client used by the Node Agent to talk to the PCST Master.
 *
 * <p>Three independent schedules are involved in the agent, and this class owns two of them:
 * heartbeats and registration recovery. Telemetry is scheduled separately by
 * {@link com.omni.pcst.node.telemetry.TelemetryScheduler} so that telemetry collection is
 * never blocked by registration or heartbeat behaviour.
 *
 * <h2>Registration state machine</h2>
 * <pre>
 *   UNREGISTERED --(start / recovery)--&gt; RECOVERING --(RegisterNode accepted)--&gt; REGISTERED
 *        ^                                    |                                     |
 *        |                                    | (backoff, retry)                     | (connection failure)
 *        +------------------------------------+-------------------------------------+
 * </pre>
 *
 * <ul>
 *   <li>{@link #start()} never blocks on registration: the first attempt runs on a
 *       dedicated background thread, so an unavailable Master cannot stall telemetry
 *       collection.</li>
 *   <li>All retries run on a single-threaded recovery executor and at most one recovery
 *       loop is active at a time, so a burst of failures cannot create duplicate
 *       registrations or extra threads.</li>
 *   <li>The retry interval is exponential and bounded (see {@link #MAX_RECOVERY_BACKOFF_MS});
 *       the number of attempts is unbounded, because recovery has to continue until the
 *       Master returns.</li>
 *   <li>A successful registration resets the backoff, so a long outage followed by a
 *       success leaves the context ready for the next one.</li>
 * </ul>
 *
 * <h2>Known limitation</h2>
 * Telemetry is not buffered. A snapshot that cannot be delivered is discarded; only the
 * next collected snapshot is sent. Guaranteed delivery is out of scope for this step.
 */
public class MasterGrpcClient {

    public enum RegistrationState {
        /** The agent has not (yet) successfully registered with the Master. */
        UNREGISTERED,
        /** The Master accepted the most recent registration. */
        REGISTERED,
        /** Registration is (re)established in the background after a connection failure. */
        RECOVERING
    }

    private static final Logger log = LoggerFactory.getLogger(MasterGrpcClient.class);

    private static final String RECOVERY_BACKOFF_PROPERTY = "pcst.recovery.backoff-ms";
    private static final String RECOVERY_BACKOFF_ENV = "PCST_RECOVERY_BACKOFF_MS";
    private static final long DEFAULT_RECOVERY_BACKOFF_MS = 2000L;
    private static final long MAX_RECOVERY_BACKOFF_MS = 30000L;

    private final String masterHost;
    private final int masterPort;
    private final String nodeId;
    private final int nodePort;
    private final String agentVersion;
    private final long heartbeatIntervalMs;
    private final long initialRecoveryBackoffMs;
    private final ManagedChannel channel;

    /**
     * Session id sent on registration, so the Master can make an agent restart
     * explicit. Set from the telemetry session source; null means "not reported".
     */
    private volatile String registrationSessionId;

    private final ReentrantLock stateLock = new ReentrantLock();
    private final Condition wakeup = stateLock.newCondition();
    private final AtomicBoolean recoveryRunning = new AtomicBoolean(false);
    private final AtomicBoolean started = new AtomicBoolean(false);
    private volatile Runnable registrationListener;
    private volatile String pairingCode;
    private volatile String deviceCredential;

    private RegistrationState state = RegistrationState.UNREGISTERED;
    private long recoveryBackoffMs;
    private int registrationAttempts;
    private boolean shutdown;

    private volatile NodeServiceGrpc.NodeServiceBlockingStub blockingStub;
    private ScheduledExecutorService heartbeatScheduler;
    private ScheduledExecutorService recoveryScheduler;

    public MasterGrpcClient(String masterHost, int masterPort, String nodeId, int nodePort,
                            String agentVersion, long heartbeatIntervalMs) {
        this(masterHost, masterPort, nodeId, nodePort, agentVersion, heartbeatIntervalMs,
                "disabled", null);
    }

    /**
     * Creates a client with optional TLS. When {@code tlsMode} is not {@code disabled},
     * the channel uses transport security with the provided trust certificate collection.
     * In {@code production} mode a trust store is required; the constructor fails closed
     * when it is missing.
     */
    public MasterGrpcClient(String masterHost, int masterPort, String nodeId, int nodePort,
                            String agentVersion, long heartbeatIntervalMs,
                            String tlsMode, String trustCertCollectionFile) {
        this(buildChannel(masterHost, masterPort, tlsMode, trustCertCollectionFile),
                masterHost, masterPort, nodeId, nodePort, agentVersion, heartbeatIntervalMs);
    }

    /**
     * Test seam: allows injecting a pre-built channel (for example an in-process gRPC
     * channel) so that failure and recovery paths can be exercised without sockets.
     */
    public MasterGrpcClient(ManagedChannel channel, String masterHost, int masterPort, String nodeId, int nodePort,
                            String agentVersion, long heartbeatIntervalMs) {
        this.channel = channel;
        this.masterHost = masterHost;
        this.masterPort = masterPort;
        this.nodeId = nodeId;
        this.nodePort = nodePort;
        this.agentVersion = agentVersion;
        this.heartbeatIntervalMs = heartbeatIntervalMs;
        this.initialRecoveryBackoffMs = resolveInitialBackoffMs();
        this.recoveryBackoffMs = this.initialRecoveryBackoffMs;
    }

    /**
     * Builds the gRPC channel. When TLS mode is not {@code disabled}, the channel uses
     * transport security with certificate verification. Production mode fails closed
     * when the trust store is missing.
     */
    private static ManagedChannel buildChannel(String masterHost, int masterPort,
                                               String tlsMode, String trustCertCollectionFile) {
        NettyChannelBuilder builder = NettyChannelBuilder.forAddress(masterHost, masterPort);
        if (TlsContexts.isTlsEnabled(tlsMode)) {
            try {
                builder.useTransportSecurity()
                        .sslContext(TlsContexts.clientContext(trustCertCollectionFile));
                log.info("TLS enabled for gRPC channel to {}:{} (mode={})",
                        masterHost, masterPort, tlsMode);
            } catch (IOException e) {
                throw new IllegalStateException("TLS is enabled but trust store could not be loaded: "
                        + e.getMessage(), e);
            }
        } else {
            builder.usePlaintext();
            log.info("Plaintext gRPC channel to {}:{} (TLS disabled)", masterHost, masterPort);
        }
        return builder.build();
    }

    /**
     * Sets the agent session id included in registration. Called once by the agent
     * at startup with the same session id the telemetry path stamps on snapshots,
     * so registration and telemetry always agree on session identity.
     */
    public void setRegistrationSessionId(String agentSessionId) {
        this.registrationSessionId = agentSessionId;
    }

    /**
     * Sets the one-time pairing code used for first-time enrollment. After a
     * successful enrollment the agent should switch to {@link #setDeviceCredential}.
     * The value is never logged.
     */
    public void setPairingCode(String pairingCode) {
        this.pairingCode = pairingCode;
    }

    /**
     * Sets the device credential presented on reconnection. The value is never
     * logged.
     */
    public void setDeviceCredential(String deviceCredential) {
        this.deviceCredential = deviceCredential;
    }

    /** @return the session id sent on registration, or null when not reported */
    public String getRegistrationSessionId() {
        return registrationSessionId;
    }

    /**
     * @return the device credential issued by the Master after a successful
     *         enrollment, or empty when none has been issued yet.
     */
    public java.util.Optional<String> getDeviceCredential() {
        return (deviceCredential == null || deviceCredential.isBlank())
                ? java.util.Optional.empty()
                : java.util.Optional.of(deviceCredential);
    }

    /**
     * Builds the gRPC stub, starts the recurring heartbeat schedule and kicks off
     * registration on a background thread. This method returns immediately even when the
     * Master is unreachable.
     */
    public void start() {
        if (!started.compareAndSet(false, true)) {
            log.warn("Master gRPC client already started; ignoring duplicate start().");
            return;
        }

        log.info("Node Agent starting up...");
        log.info("Connecting to Master gRPC target {}:{}", masterHost, masterPort);

        blockingStub = NodeServiceGrpc.newBlockingStub(channel);

        heartbeatScheduler = Executors.newSingleThreadScheduledExecutor(
                daemonThreadFactory("pcst-node-heartbeat"));
        heartbeatScheduler.scheduleAtFixedRate(this::sendHeartbeat,
                heartbeatIntervalMs, heartbeatIntervalMs, TimeUnit.MILLISECONDS);

        recoveryScheduler = Executors.newSingleThreadScheduledExecutor(
                daemonThreadFactory("pcst-node-recovery"));

        // Registration is intentionally asynchronous: an unavailable Master must never
        // block telemetry collection on the agent.
        triggerRecovery("agent-startup");
        log.info("Node Agent started; registration recovery running in background (initial backoff={} ms)",
                initialRecoveryBackoffMs);
    }

    /**
     * Reports a failed or unsuccessful RPC. Safe to call from any thread and any number of
     * concurrent callers: the transition to {@link RegistrationState#RECOVERING} happens at
     * most once, and only a single recovery loop is ever started.
     */
    public void onConnectionFailure(String operation) {
        boolean registrationLost = false;
        stateLock.lock();
        try {
            if (shutdown) {
                return;
            }
            if (state == RegistrationState.REGISTERED) {
                state = RegistrationState.RECOVERING;
                registrationLost = true;
            }
        } finally {
            stateLock.unlock();
        }

        if (registrationLost) {
            log.warn("Master connection lost during {}; scheduling registration recovery", operation);
            triggerRecovery(operation);
        }
    }

    public RegistrationState getRegistrationState() {
        stateLock.lock();
        try {
            return state;
        } finally {
            stateLock.unlock();
        }
    }

    /**
     * Registers a callback invoked (best-effort, outside the state lock) when the
     * Master accepts registration and the node becomes registered. Safe to call at
     * any time; only the most recent listener is kept.
     */
    public void setRegistrationListener(Runnable listener) {
        this.registrationListener = listener;
    }

    /**
     * @return number of RegisterNode attempts recorded since the last successful registration
     */
    public int getRegistrationAttemptCount() {
        stateLock.lock();
        try {
            return registrationAttempts;
        } finally {
            stateLock.unlock();
        }
    }

    /**
     * Sends one telemetry snapshot to the Master via the {@code ReportTelemetry} RPC.
     *
     * @return {@code true} only when the RPC succeeded and the Master answered with
     *         {@code accepted=true}; {@code false} for any unsuccessful response, RPC
     *         failure or shutdown. A {@code false} result means the snapshot was dropped
     *         (there is no local buffering).
     */
    public boolean sendTelemetry(TelemetrySnapshot snapshot) {
        return sendTelemetry(snapshot, null, 0L);
    }

    /**
     * Sends one telemetry snapshot to the Master via the {@code ReportTelemetry} RPC,
     * carrying the agent session id and the telemetry sequence number assigned by
     * the caller <em>before</em> transmission.
     *
     * <p>The sequence number is supplied by the caller rather than drawn here, so
     * that it is consumed once per produced snapshot even when the send below
     * fails. A failed send never releases or reuses the number.
     *
     * @return {@code true} only when the RPC succeeded and the Master answered with
     *         {@code accepted=true}; {@code false} for any unsuccessful response, RPC
     *         failure or shutdown. A {@code false} result means the snapshot was dropped
     *         (there is no local buffering).
     */
    public boolean sendTelemetry(TelemetrySnapshot snapshot, String agentSessionId, long telemetrySequence) {
        if (isShutdown() || blockingStub == null) {
            log.warn("Dropping telemetry snapshot: client is not connected (timestamp={}, sequence={})",
                    snapshot.timestamp(), telemetrySequence);
            return false;
        }

        try {
            TelemetryRequest request = buildTelemetryRequest(snapshot, agentSessionId, telemetrySequence);

            TelemetryResponse response = blockingStub.reportTelemetry(request);
            if (response.getAccepted()) {
                return true;
            }
            // An explicit rejection is an unsuccessful RPC on a healthy connection (for
            // example a rejected node_id): it must not be reported as delivered, but it is
            // not a connection failure either, so no re-registration is triggered here.
            log.warn("Telemetry rejected by Master: message='{}', sequence={} (snapshot discarded, no local buffering)",
                    response.getMessage(), telemetrySequence);
            return false;

        } catch (StatusRuntimeException e) {
            log.warn("gRPC failure sending telemetry: sequence={}, status={}, description={}",
                    telemetrySequence, e.getStatus().getCode(), e.getStatus().getDescription());
            onConnectionFailure("telemetry-grpc-failure");
            return false;
        } catch (Exception e) {
            log.warn("Unexpected error sending telemetry: sequence={}, error={} (snapshot discarded, no local buffering)",
                    telemetrySequence, e.getMessage());
            onConnectionFailure("telemetry-unexpected-error");
            return false;
        }
    }

    /**
     * Sends a task lifecycle update to the Master via the {@code ReportTaskLifecycle} RPC.
     *
     * @param update the lifecycle update to send
     * @return {@code true} only when the RPC succeeded and the Master answered with
     *         {@code accepted=true}; {@code false} for any unsuccessful response, RPC
     *         failure or shutdown.
     */
    public boolean sendTaskLifecycle(TaskLifecycleUpdate update) {
        if (isShutdown() || blockingStub == null) {
            log.warn("Dropping task lifecycle update: client is not connected (taskId={}, attemptId={})",
                    update.getTaskId(), update.getAttemptId());
            return false;
        }

        try {
            TaskLifecycleAck response = blockingStub.reportTaskLifecycle(update);
            if (response.getAccepted()) {
                return true;
            }
            log.warn("Task lifecycle update rejected by Master: message='{}', taskId={}, attemptId={}",
                    response.getMessage(), update.getTaskId(), update.getAttemptId());
            return false;

        } catch (StatusRuntimeException e) {
            log.warn("gRPC failure sending task lifecycle: taskId={}, attemptId={}, status={}, description={}",
                    update.getTaskId(), update.getAttemptId(), e.getStatus().getCode(), e.getStatus().getDescription());
            onConnectionFailure("task-lifecycle-grpc-failure");
            return false;
        } catch (Exception e) {
            log.warn("Unexpected error sending task lifecycle: taskId={}, attemptId={}, error={}",
                    update.getTaskId(), update.getAttemptId(), e.getMessage());
            onConnectionFailure("task-lifecycle-unexpected-error");
            return false;
        }
    }

    /**
     * Stops both schedules, wakes the recovery loop so it exits immediately, and shuts the
     * channel down. Calling this more than once is a no-op.
     */
    public void stop() {
        stateLock.lock();
        try {
            if (shutdown) {
                log.debug("Node Agent gRPC client already stopped; ignoring duplicate stop().");
                return;
            }
            shutdown = true;
            // Wake the recovery loop if it is waiting in a backoff interval.
            wakeup.signalAll();
        } finally {
            stateLock.unlock();
        }

        log.info("Shutting down Node Agent gRPC client...");
        // Cancel in-flight RPCs first so a blocked call cannot delay the shutdown.
        channel.shutdownNow();
        stopExecutor(heartbeatScheduler, "heartbeat");
        stopExecutor(recoveryScheduler, "recovery");
        heartbeatScheduler = null;
        recoveryScheduler = null;
        blockingStub = null;

        try {
            if (!channel.awaitTermination(3, TimeUnit.SECONDS)) {
                log.warn("gRPC channel did not terminate in time; forcing shutdown.");
                channel.shutdownNow();
            }
        } catch (InterruptedException e) {
            channel.shutdownNow();
            Thread.currentThread().interrupt();
        }
        log.info("Node Agent gRPC client shut down successfully.");
    }

    /* ------------------------------------------------------------------ internals */

    private void triggerRecovery(String reason) {
        if (isShutdown()) {
            return;
        }
        if (!recoveryRunning.compareAndSet(false, true)) {
            log.debug("Registration recovery already in progress; ignoring trigger from {}", reason);
            return;
        }

        stateLock.lock();
        try {
            if (state == RegistrationState.UNREGISTERED) {
                state = RegistrationState.RECOVERING;
            }
        } finally {
            stateLock.unlock();
        }

        log.info("Starting registration recovery (trigger={})", reason);
        try {
            recoveryScheduler.execute(this::runRecoveryLoop);
        } catch (RejectedExecutionException | NullPointerException e) {
            recoveryRunning.set(false);
            log.warn("Could not schedule registration recovery: {}", e.getMessage());
        }
    }

    private void runRecoveryLoop() {
        boolean unexpectedError = false;
        try {
            while (!isShutdown()) {
                if (getRegistrationState() == RegistrationState.REGISTERED) {
                    log.info("Registration established; recovery loop finished (attempts={})",
                            getRegistrationAttemptCount());
                    return;
                }
                register();
                if (getRegistrationState() == RegistrationState.REGISTERED || isShutdown()) {
                    log.info("Registration established; recovery loop finished (attempts={})",
                            getRegistrationAttemptCount());
                    return;
                }
                long backoffMs = currentRecoveryBackoff();
                log.info("Registration not yet established; retrying in {} ms", backoffMs);
                if (!awaitRecoveryBackoff(backoffMs)) {
                    return;
                }
            }
        } catch (RuntimeException e) {
            // Never let the loop die silently: it is the only thing that can restore the
            // connection, so it is always rescheduled (see finally block).
            log.warn("Unexpected error in registration recovery loop: {} ({}); rescheduling",
                    e.getClass().getSimpleName(), e.getMessage());
            unexpectedError = true;
            if (!awaitRecoveryBackoff(currentRecoveryBackoff())) {
                return;
            }
        } finally {
            // Clear the guard first so that a trigger racing with this exit can claim the
            // next loop. If the state flipped back to RECOVERING while this loop was
            // finishing, or the loop aborted on an error, keep recovery alive; an agent
            // must never give up on the Master.
            recoveryRunning.set(false);
            if (!isShutdown() && getRegistrationState() != RegistrationState.REGISTERED) {
                triggerRecovery(unexpectedError ? "recovery-loop-error" : "state-changed-during-loop");
            }
        }
    }

    /**
     * Performs exactly one RegisterNode attempt. Any unsuccessful outcome is logged with
     * status information only (no stack trace) and recorded so the caller can back off.
     */
    private void register() {
        RegisterNodeRequest.Builder requestBuilder = RegisterNodeRequest.newBuilder()
                .setNodeId(nodeId)
                .setHostname(resolveHostname())
                .setPort(nodePort)
                .setAgentVersion(agentVersion);
        if (registrationSessionId != null && !registrationSessionId.isBlank()) {
            requestBuilder.setAgentSessionId(registrationSessionId);
        }
        // Present either a device credential (reconnection) or a pairing code
        // (first-time enrollment). Never both, never neither.
        if (deviceCredential != null && !deviceCredential.isBlank()) {
            requestBuilder.setDeviceCredential(deviceCredential);
        } else if (pairingCode != null && !pairingCode.isBlank()) {
            requestBuilder.setPairingCode(pairingCode);
        }
        RegisterNodeRequest request = requestBuilder.build();

        log.info("Sending RegisterNode request for node_id={} to {}:{}", nodeId, masterHost, masterPort);
        try {
            RegisterNodeResponse response = blockingStub.registerNode(request);
            if (response.getAccepted()) {
                // Capture any device credential issued by the Master before marking
                // registered, so the registration listener can persist it. Never log it.
                if (response.hasDeviceCredential() && !response.getDeviceCredential().isBlank()) {
                    this.deviceCredential = response.getDeviceCredential();
                    log.info("Device credential issued by Master (value not stored here; agent persists it)");
                }
                markRegistered();
                log.info("Registration accepted by Master: message='{}', server_time={}",
                        response.getMessage(), response.getServerTime());
            } else {
                recordRegistrationFailure();
                String message = response.getMessage();
                log.warn("Registration rejected by Master: message='{}', server_time={}; will retry",
                        message, response.getServerTime());
                // If we presented a device credential and the Master rejected it as invalid
                // or revoked, stop presenting it. The next recovery iteration will fall back
                // to the pairing code (if configured) or surface a clear re-pairing requirement.
                if (deviceCredential != null && !deviceCredential.isBlank()
                        && message != null && message.contains("invalid or revoked device credential")) {
                    log.warn("Device credential rejected as invalid or revoked; clearing it so the next "
                            + "recovery attempt can use the pairing code (if configured).");
                    deviceCredential = null;
                    try {
                        DeviceCredentialStore.delete();
                    } catch (IOException e) {
                        log.warn("Could not delete invalid device credential from local store: {}",
                                e.getMessage());
                    }
                }
            }
        } catch (StatusRuntimeException e) {
            recordRegistrationFailure();
            log.warn("gRPC failure during node registration: status={}, description={}; will retry",
                    e.getStatus().getCode(), e.getStatus().getDescription());
        } catch (Exception e) {
            recordRegistrationFailure();
            log.warn("Unexpected error during node registration: {}; will retry", e.getMessage());
        }
    }

    private void sendHeartbeat() {
        if (isShutdown() || blockingStub == null) {
            return;
        }

        HeartbeatRequest request = HeartbeatRequest.newBuilder()
                .setNodeId(nodeId)
                .setTimestamp(System.currentTimeMillis())
                .build();

        try {
            log.debug("Sending Heartbeat for node_id={}", nodeId);
            HeartbeatResponse response = blockingStub.heartbeat(request);
            if (response.getAcknowledged()) {
                if (getRegistrationState() == RegistrationState.REGISTERED) {
                    log.info("Heartbeat acknowledged by Master: server_time={}", response.getServerTime());
                } else {
                    log.info("Heartbeat acknowledged by Master while registration is still recovering: server_time={}",
                            response.getServerTime());
                }
            } else {
                log.warn("Heartbeat not acknowledged by Master: server_time={}", response.getServerTime());
                onConnectionFailure("heartbeat-not-acknowledged");
            }
        } catch (StatusRuntimeException e) {
            log.warn("gRPC failure during heartbeat (retrying next interval): status={}, description={}",
                    e.getStatus().getCode(), e.getStatus().getDescription());
            onConnectionFailure("heartbeat-grpc-failure");
        } catch (Exception e) {
            log.warn("Unexpected error during heartbeat (retrying next interval): {}", e.getMessage());
            onConnectionFailure("heartbeat-unexpected-error");
        }
    }

    private void markRegistered() {
        stateLock.lock();
        try {
            state = RegistrationState.REGISTERED;
            registrationAttempts = 0;
            recoveryBackoffMs = initialRecoveryBackoffMs;
        } finally {
            stateLock.unlock();
        }
        Runnable listener = registrationListener;
        if (listener != null) {
            try {
                listener.run();
            } catch (Exception e) {
                log.warn("Registration listener threw an exception: {}", e.getMessage());
            }
        }
    }

    private void recordRegistrationFailure() {
        stateLock.lock();
        try {
            state = RegistrationState.RECOVERING;
            registrationAttempts++;
            recoveryBackoffMs = Math.min(recoveryBackoffMs * 2, MAX_RECOVERY_BACKOFF_MS);
        } finally {
            stateLock.unlock();
        }
    }

    private long currentRecoveryBackoff() {
        stateLock.lock();
        try {
            return recoveryBackoffMs;
        } finally {
            stateLock.unlock();
        }
    }

    /**
     * Waits for the recovery backoff to elapse. Returns early when shutdown is signalled.
     *
     * @return {@code true} when the full backoff elapsed, {@code false} when interrupted or shut down
     */
    private boolean awaitRecoveryBackoff(long backoffMs) {
        long deadlineNanos = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(backoffMs);
        stateLock.lock();
        try {
            while (!shutdown) {
                long remainingNanos = deadlineNanos - System.nanoTime();
                if (remainingNanos <= 0) {
                    return true; // backoff fully elapsed
                }
                // Condition.await returns true when signalled, false on timeout.
                boolean signalled = wakeup.await(remainingNanos, TimeUnit.NANOSECONDS);
                if (signalled) {
                    return false; // woken by shutdown
                }
                // Spurious wakeup: recompute remaining and wait again.
            }
            return false; // shutdown
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } finally {
            stateLock.unlock();
        }
    }

    private boolean isShutdown() {
        stateLock.lock();
        try {
            return shutdown;
        } finally {
            stateLock.unlock();
        }
    }

    private void stopExecutor(ScheduledExecutorService executor, String label) {
        if (executor == null) {
            return;
        }
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                log.warn("{} schedule did not finish in time; forcing shutdown.", label);
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private static ThreadFactory daemonThreadFactory(String name) {
        return runnable -> {
            Thread thread = new Thread(runnable, name);
            thread.setDaemon(true);
            return thread;
        };
    }

    private String resolveHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            log.warn("Could not resolve local hostname, falling back to 'localhost': {}", e.getMessage());
            return "localhost";
        }
    }

    private long resolveInitialBackoffMs() {
        String configured = System.getProperty(RECOVERY_BACKOFF_PROPERTY);
        if (configured == null || configured.isBlank()) {
            configured = System.getenv(RECOVERY_BACKOFF_ENV);
        }
        if (configured == null || configured.isBlank()) {
            return DEFAULT_RECOVERY_BACKOFF_MS;
        }
        try {
            long parsed = Long.parseLong(configured.trim());
            if (parsed <= 0) {
                log.warn("Ignoring non-positive {}={}; using {} ms",
                        RECOVERY_BACKOFF_PROPERTY, parsed, DEFAULT_RECOVERY_BACKOFF_MS);
                return DEFAULT_RECOVERY_BACKOFF_MS;
            }
            return parsed;
        } catch (NumberFormatException e) {
            log.warn("Ignoring invalid {}='{}'; using {} ms",
                    RECOVERY_BACKOFF_PROPERTY, configured, DEFAULT_RECOVERY_BACKOFF_MS);
            return DEFAULT_RECOVERY_BACKOFF_MS;
        }
    }

    private TelemetryRequest buildTelemetryRequest(TelemetrySnapshot snapshot) {
        return buildTelemetryRequest(snapshot, null, 0L);
    }

    private TelemetryRequest buildTelemetryRequest(TelemetrySnapshot snapshot, String agentSessionId,
                                                   long telemetrySequence) {
        TelemetryRequest.Builder requestBuilder = TelemetryRequest.newBuilder()
                .setNodeId(nodeId)
                .setTimestamp(snapshot.timestamp());

        // Session id and sequence number are only set when supplied. An older
        // caller that omits them produces a message with the fields absent, which
        // the Master treats as "no sequence metadata reported" rather than as a
        // blank id or sequence zero.
        if (agentSessionId != null && !agentSessionId.isBlank()) {
            requestBuilder.setAgentSessionId(agentSessionId);
        }
        if (telemetrySequence > 0L) {
            requestBuilder.setTelemetrySequence(telemetrySequence);
        }

        // CPU - always present
        requestBuilder.setCpu(CpuTelemetry.newBuilder().setUtilizationPercent(snapshot.cpuUtilization()).build());

        // Memory - always present
        requestBuilder.setMemory(MemoryTelemetry.newBuilder()
                .setTotalBytes(snapshot.totalMemory())
                .setUsedBytes(snapshot.usedMemory())
                .setAvailableBytes(snapshot.availableMemory()).build());

        // GPU - availability always set; utilization only when present
        GpuTelemetry gpu;
        if (snapshot.gpuUtilizationPercent() != null) {
            gpu = GpuTelemetry.newBuilder()
                    .setAvailable(snapshot.gpuAvailable())
                    .setUtilizationPercent(snapshot.gpuUtilizationPercent())
                    .build();
        } else {
            gpu = GpuTelemetry.newBuilder().setAvailable(snapshot.gpuAvailable()).build();
        }
        requestBuilder.setGpu(gpu);

        // Battery - only when level is present
        if (snapshot.batteryLevelPercent() != null) {
            BatteryTelemetry.Builder batBuilder = BatteryTelemetry.newBuilder()
                    .setLevelPercent(snapshot.batteryLevelPercent());
            if (snapshot.batteryCharging() != null) {
                batBuilder.setCharging(snapshot.batteryCharging());
            }
            requestBuilder.setBattery(batBuilder.build());
        }

        // Temperature - only when present
        if (snapshot.temperatureCelsius() != null) {
            requestBuilder.setTemperature(TemperatureTelemetry.newBuilder()
                    .setCelsius(snapshot.temperatureCelsius()).build());
        }

        // Network - latency and packet loss; absent values are left unset (wire will not contain them)
        NetworkTelemetry.Builder networkBuilder = NetworkTelemetry.newBuilder();
        if (snapshot.latencyMs() != null) {
            networkBuilder.setLatencyMs(snapshot.latencyMs());
        }
        if (snapshot.packetLossPercent() != null) {
            networkBuilder.setPacketLossPercent(snapshot.packetLossPercent());
        }
        requestBuilder.setNetwork(networkBuilder.build());

        // Disk - always present
        requestBuilder.setDisk(DiskTelemetry.newBuilder()
                .setTotalBytes(snapshot.totalDisk())
                .setFreeBytes(snapshot.freeDisk()).build());

        // Processes - always present
        requestBuilder.setProcesses(ProcessTelemetry.newBuilder()
                .setProcessCount(snapshot.processCount()).build());

        return requestBuilder.build();
    }
}
