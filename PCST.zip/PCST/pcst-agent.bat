@echo off
rem PCST Node Agent launcher (Windows)
rem Configures the Master endpoint and enrollment credential via environment
rem variables or a local config file (config/pcst-agent.properties). No secret
rem is hard-coded here. See AGENT_CONFIGURATION.md for details.
setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
set "JAR_DIR=%SCRIPT_DIR%pcst-node-agent\target"
set "JAR="

if not exist "%JAR_DIR%" (
    echo ERROR: Build output directory not found: %JAR_DIR%
    echo Build the agent first:  mvn -pl pcst-node-agent package
    exit /b 1
)

for %%f in ("%JAR_DIR%\pcst-node-agent-*.jar") do set "JAR=%%f"
if "%JAR%"=="" (
    echo ERROR: PCST Node Agent runnable jar not found in %JAR_DIR%
    echo Build with:  mvn -pl pcst-node-agent package
    exit /b 1
)

rem Locate a Java runtime (Java 21 or later required).
if defined JAVA_HOME (
    set "JAVA=%JAVA_HOME%\bin\java.exe"
) else (
    set "JAVA=java.exe"
)

"%JAVA%" -version >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Java runtime not found. Install Java 21 or later and set JAVA_HOME.
    exit /b 1
)

echo ==========================================
echo PCST Node Agent launcher (Windows)
echo Using jar   : %JAR%
echo Master host : %PCST_MASTER_HOST%
echo Master port : %PCST_MASTER_PORT%
echo Node id     : %PCST_NODE_ID%
echo ==========================================
echo.

rem Pass any command-line arguments (e.g. --version) through to the agent.
"%JAVA%" -jar "%JAR%" %*

endlocal
