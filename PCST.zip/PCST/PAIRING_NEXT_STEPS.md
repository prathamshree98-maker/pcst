# PCST Pairing / Credentials — Sprint 1 status: DEFERRED

Secure device pairing (website pairing code → agent pairs → admin approval →
authenticated registration → credential revocation) is NOT implemented in this
sprint. It is deliberately deferred rather than faked.

## Why it was deferred

The current protocol and Master cannot support secure pairing without a
moderate rewrite:

- `RegisterNodeRequest` (`proto/node_service.proto`) carries `node_id`,
  `hostname`, `port`, `agent_version`, `agent_session_id`. There is **no**
  pairing-code, token, or credential field.
- `NodeServiceImpl.registerNode` (`pcst-master/.../grpc/NodeServiceImpl.java:28`)
  accepts **any** non-blank `node_id` unconditionally — there is no
  authentication, no approval, no credential store, and no revocation.
- gRPC transport is plaintext (`ManagedChannelBuilder.forAddress(...).usePlaintext()`);
  there is no TLS.
- The Node Agent stores no device credentials on disk.
- There is no pairing-code generation, single-use/expiry enforcement, or
  rate-limiting endpoint on the Master or website.

Implementing all of this securely (new proto fields, pairing-code service with
expiry/rate-limit, device-credential issuance+revocation, TLS for gRPC,
agent-side credential storage with filesystem permissions, admin-approval
workflow) is beyond the "smallest safe change" scope of Sprint 1 and risks
introducing security flaws if rushed.

## Honest behavior in this build

- The Master accepts registration automatically (for trusted friends / test
  computers only).
- The Node Agent logs `pcst.node.token` as "configured (value not logged)" but
  does not yet send or validate any credential.
- The onboarding page states plainly that pairing/admin approval is not yet
  implemented.

## Smallest missing pieces (next step)

1. **Proto:** add a credential/pairing-code field to `RegisterNodeRequest` (or a
   separate pairing RPC) and version the contract.
2. **Master pairing service:** REST endpoint to generate a temporary, single-use,
   expiring pairing code with rate limiting; admin approval endpoint; persist
   codes + issued device credentials; support revocation.
3. **Master registration validation:** `NodeServiceImpl` validates the
   credential/pairing code on `RegisterNode`, marks the node as
   `pending-approval` until an admin approves, rejects unknown/unapproved nodes.
4. **Transport:** switch Node Agent ↔ Master gRPC to TLS (replace `usePlaintext`).
5. **Node Agent:** read a device credential from config/env (never log it),
   store it on disk with restrictive filesystem permissions, send it on
   registration, and handle revocation/re-pairing.
6. **Website:** pairing-code generation UI + approval status; tie into the
   existing `/api/v1/nodes` status display.

## Recommended order

Do steps 1–3 first (proto + pairing service + registration validation) behind a
feature flag so the existing automatic-accept path remains available for local
testing. Add TLS (step 4) before exposing the Master to any non-local network.
