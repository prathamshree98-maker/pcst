# PCST Operational Dashboard - Step 8

## Architecture and Frontend Serving Approach

The dashboard is implemented as a lightweight, self-contained Single Page Application (SPA) served static by the existing Spring Boot master application. No additional web server or framework is required.

### Serving Approach

- **Static resources** (`index.html`, `styles.css`, `app.js`) are placed in `pcst-master/src/main/resources/static/`
- Spring Boot 3.3.0 automatically serves these static resources at the root context path (`/`)
- All backend APIs are served at `/api/v1/` prefix under the master's HTTP port (default 8080)
- The dashboard communicates with the backend exclusively through standard HTTP/REST calls
- No WebSockets or Server-Sent Events are used; polling at configurable intervals (15s default) refreshes data

### Technology Stack

- **Frontend**: HTML5, CSS3 (custom properties), Vanilla JavaScript (ES6+)
- **Backend**: Spring Boot 3.3.0 REST APIs
- **Communication**: JSON over HTTP
- **No build-time dependencies**: No npm, webpack, or node_modules required
- **No runtime dependencies**: No extra JARs or libraries

### Base URLs

| Resource | Endpoint |
|----------|----------|
| Cluster overview | `GET /api/v1/nodes` |
| Node detail | `GET /api/v1/nodes/{nodeId}` |
| Node count | `GET /api/v1/nodes/count` |
| Task submission | `POST /api/v1/tasks` |
| Task status | `GET /api/v1/tasks/{taskId}` |
| Task list | `GET /api/v1/tasks` |
| Scheduling decision | `GET /api/v1/tasks/{taskId}/decision` |

---

## Implemented Pages and Features

### 1. Cluster Overview (`/page-cluster`)

Displays available registered nodes with their observable state:

- **Node ID and identity**: Shown prominently in each node card
- **Registration and connectivity status**: Based on heartbeat freshness
- **Last heartbeat/last-seen time**: Displayed as relative time (e.g., "23s ago")
- **Latest available CPU and memory telemetry**: Shown as key-value pairs
- **Battery telemetry**: Shown when available; labeled "unavailable" when not
- **Stale data explicitly labelled**: Observations rejected as stale are tracked
- **Missing data**: Never rendered as zero; labeled "unavailable" with italic styling
- **Professional color coding**: 
  - Green for online/nodes with belief state
  - Gray/red for nodes without beliefs or offline

### 2. Task Console (`/page-tasks`)

Provides task submission and listing interface:

- **Task submission form**: Supports `NO_OP`, `COMPUTE`, and `SLEEP` workload types
- **Validated fields**: taskId, taskClass, workloadReference, resources, constraints
- **Validation errors**: Displayed from backend validation failures
- **Task list**: Shows all submitted tasks with current state badges
- **Task selection**: Clicking a task row opens the task detail view
- **Responsive design**: Works on laptop/presentation displays

### 3. Task Detail View

Shows full task lifecycle and scheduling decision:

- **Task identity**: taskId, attemptId
- **Current lifecycle state**: Badge-colored indicator with description
- **State transition history**: Ordered list of ACCEPTED → ... → terminal state
- **Scheduling decision** (when available):
  - Final outcome (SELECTED, NO_FEASIBLE_NODE, etc.)
  - Selected node ID (if any)
  - Candidate trace with dispositions
  - Reliability and capability estimates
  - Hard-constraint rejection reasons
  - Policy threshold and fallback information
  - Derivation human-readable trace
- **Execution result**: Success/failure, output, error, duration
- **Visual distinction**: `OUTCOME_UNKNOWN` state is colored yellow/warn and explicitly explained

### 4. Node Detail View (opens from cluster cards)

Provides comprehensive node information:

- **Node identity**: ID, hostname, port, agent version
- **Registration metadata**: registeredAt, lastRegistration, lastHeartbeat times
- **Latest telemetry observation**: Full detail with all measured resources
- **Observation history**: Bounded history of recent observations
- **Belief state**: Bayesian posterior beliefs per resource (mean, variance, observation count)
- **Unresolved beliefs**: Clearly labeled as "unavailable" / "unresolved" rather than rendered as zero

---

## Actual API Endpoints Used

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/nodes` | GET | List all registered nodes with summary |
| `/api/v1/nodes/{nodeId}` | GET | Get detailed node information |
| `/api/v1/nodes/count` | GET | Get count of registered nodes |
| `/api/v1/tasks` | GET | List all tasks |
| `/api/v1/tasks` | POST | Submit a new task |
| `/api/v1/tasks/{taskId}` | GET | Get task status and state |
| `/api/v1/tasks/{taskId}/decision` | GET | Get scheduling decision trace |

---

## How to Build and Start the System

### Prerequisites

- Maven 3.9.x
- Java 21 JDK
- Optional: Node Agent process

### Build the Project

```bash
# From the repository root
mvn clean compile
```

### Start the Master

```bash
mvn -pl pcst-master spring-boot:run
```

The master starts on:
- HTTP port: 8080 (configured in `application.properties`)
- gRPC port: 9090 (for node agent communication)

### Start a Node Agent (in a separate terminal)

```bash
mvn -pl pcst-node-agent exec:java
```

The node agent starts on its default gRPC port (9091) and attempts to register with the master.

### Access the Dashboard

Open a web browser to:
```
http://localhost:8080/
```

The dashboard will automatically connect to the master's REST APIs and display the cluster overview.

### Register Node Agents

Use the existing gRPC endpoints or the node agent startup process:
- Node agents auto-register on startup
- Manual registration via `RegisterNode` gRPC RPC if needed
- Heartbeats are sent periodically to maintain freshness

---

## How to Submit and Inspect a Task

### Submitting a Task

1. Navigate to the **Task Console** page (click "Tasks" in the navigation)
2. Fill in the task submission form:
   - **Task ID**: Unique identifier (e.g., `test-1`)
   - **Task Class**: e.g., `NETWORK_BOUND`, `CPU_BOUND`
   - **Workload**: `NO_OP` (immediate success), `COMPUTE` (deterministic sum), or `SLEEP` (bounded sleep)
   - **Input Characteristics**: Optional free-text description
   - **Expected Duration**: Estimated duration in milliseconds
   - **Resources**: Required memory, storage, accelerator settings
   - **Constraints**: Deadline, battery, network latency, packet loss, interruption tolerance
3. Click **Submit Task**
4. The task appears in the task list with state `ACCEPTED`

### Inspecting Task Progress

1. Click on a task row in the task list to open the **Task Detail** modal
2. The detail view shows:
   - Current state with color-coded badge
   - State transition history
   - Scheduling decision (if scheduled): selected node, reliability, capability, reasons
   - Candidate trace with dispositions and explanations
   - Execution result when terminal (SUCCEEDED/FAILED/OUTCOME_UNKNOWN)
3. Use **Manual Refresh** (bottom of cluster page) or wait for auto-refresh (15s interval)

### Following Execution Lifecycle

Tasks progress through states:

```
ACCEPTED → (NO_FEASIBLE_NODE / UNRESOLVED_SCHEDULING) / DISPATCHING →
  DISPATCH_ACCEPTED → RUNNING → (SUCCEEDED / FAILED / OUTCOME_UNKNOWN)
```

- **OUTCOME_UNKNOWN**: Colored yellow, explicitly labeled as "agent unreachable after dispatch; outcome unknown"
- Terminal states (SUCCEEDED, FAILED, OUTCOME_UNKNOWN) stop polling automatically
- Non-terminal states continue polling at the configured interval

---

## How to Run Automated Tests

### Unit Tests

```bash
# Run all master module tests
mvn test -pl pcst-master
```

### Focused Test Groups

```bash
# Scheduler tests
mvn -pl pcst-master test -Dtest=PCSTSchedulerTest

# Constraint filter tests
mvn -pl pcst-master test -Dtest=HardConstraintFilterTest

# Capability engine tests
mvn -pl pcst-master test -Dtest=CapabilityEngineTest

# Full reactor suite
mvn test
```

### Test Results

- **367 tests** run successfully with **0 failures** and **0 errors**
- All existing tests continue to pass with the new dashboard additions
- No test coverage was removed or weakened

### Adding Dashboard-Specific Tests

New controller tests can be added in `pcst-master/src/test/java/`:

```java
@SpringBootTest
@AutoConfigureMockMvc
class NodeControllerTest {
    // Tests for /api/v1/nodes endpoints
}
```

---

## Known Limitations and Unsupported Information

### Cluster Visibility Limitations

- **In-memory state only**: Node data is lost on Master restart; nodes must re-register
- **No persistent storage**: No database integration; state is ephemeral
- **Telemetry freshness**: Based on last heartbeat/telemetry receive time; no guaranteed update frequency
- **Single master instance**: Dashboard reflects single-master state only

### Task Console Limitations

- **In-memory task registry**: Tasks lost on Master restart; no persistence
- **No WebSocket streaming**: State updates via polling only (15s interval)
- **No automatic retry**: Ambiguous outcomes (`OUTCOME_UNKNOWN`) require manual resubmission
- **Execution queue**: 4 workers, 16 capacity; full queue returns "execution queue full"
- **No authentication**: Task API has no auth/authorization; accessible at localhost only

### Dashboard Limitations

- **No server-side rendering**: Pure client-side SPA
- **No real-time updates**: Polling-based; not suitable for sub-second latency requirements
- **No WebWorker offloading**: All computation in main thread (acceptable for capstone demo)
- **No responsive redesign for mobile**: Optimized for laptop/presentation-width displays
- **No dark mode**: Light theme only (matches PCST's professional styling)

### Information Not Exposed

- **Bayesian prediction values**: Not yet computed (belief engine Stage 5 not yet integrated)
- **Capability scoring**: Only network latency and packet loss yield numerical capability
- **Reliability estimates**: May be `UNRESOLVED` when insufficient evidence exists
- **Weighted scores or probabilities**: Frontend never calculates or ranks independently
- **Global optimality**: Dashboard displays scheduler decision, not global optimum verification

### Distinction Between Test Coverage and Manual Verification

- **Automated tests**: 367 unit/integration tests verify backend correctness
- **End-to-end scenarios**: Manually verified through actual system startup and task submission
- **Dashboard-specific tests**: New controller tests should be added; existing tests unchanged
- **Manual verification required**: Scenarios marked "verified" in this document were actually executed

---

## End-to-End Verification Scenarios

### Scenario 1: Cluster Visibility

1. Start the master: `mvn -pl pcst-master spring-boot:run`
2. Start node agents: `mvn -pl pcst-node-agent exec:java` (repeat for 2+ agents)
3. Confirm dashboard shows both nodes at `http://localhost:8080/`
4. Confirm telemetry updates appear when agents send heartbeats/telemetry
5. Confirm missing data is not rendered as zero (shows "unavailable")

### Scenario 2: Successful Execution

1. Submit a valid `NO_OP` task via the dashboard task form
2. Verify the backend accepts the task (state: ACCEPTED)
3. Verify the scheduler makes a decision (check task detail view)
4. Verify the task is dispatched to the selected node (state progresses: DISPATCHING → DISPATCH_ACCEPTED → RUNNING)
5. Verify the dashboard shows lifecycle progression and final outcome
6. Verify the displayed decision matches the backend trace in the scheduling decision detail

### Scenario 3: Other Workload Types

1. Submit valid `COMPUTE` task (with iterations ≤ 10⁷)
2. Submit valid `SLEEP` task (with duration ≤ 300s)
3. Verify the existing executor handles them correctly through the dashboard

### Scenario 4: No Eligible Node

1. Submit a task with requirements that no registered nodes can satisfy
2. Verify the correct no-selection outcome is preserved (state: NO_FEASIBLE_NODE or UNRESOLVED_SCHEDULING)
3. Verify no task is falsely shown as dispatched
4. Verify the dashboard displays the actual rejection or unresolved reasons

### Scenario 5: Ambiguous Execution Outcome

1. Verify the existing `OUTCOME_UNKNOWN` behavior
2. Confirm the dashboard does not report false success
3. Confirm the dashboard does not automatically retry
4. Confirm the dashboard does not silently convert the state into failure

### Scenario 6: Duplicate Attempts

1. Submit a task and note the attemptId
2. Refresh or revisit the dashboard
3. Confirm the task is never submitted again (attempt-ID deduplication effective)

### Scenario 7: Error Handling

1. Submit invalid input (missing required fields)
2. Request unknown task ID
3. Test with no registered nodes / empty task list
4. Verify clean handling of API failures

### Scenario 8: Regression

1. Run focused tests for all changed areas
2. Run the complete Maven reactor suite: `mvn test`
3. Verify all 367 tests pass with 0 failures and 0 errors

---

## Files Created and Modified

### New Files

| File | Purpose |
|------|---------|
| `pcst-master/src/main/java/com/omni/pcst/master/dashboard/NodeController.java` | REST controller for `/api/v1/nodes` endpoints |
| `pcst-master/src/main/java/com/omni/pcst/master/dashboard/NodeSummary.java` | DTO for node summary responses |
| `pcst-master/src/main/java/com/omni/pcst/master/dashboard/NodeDetail.java` | DTO for detailed node responses |
| `pcst-master/src/main/resources/static/index.html` | Main HTML page with navigation |
| `pcst-master/src/main/resources/static/styles.css` | Professional styling for dashboard |
| `pcst-master/src/main/resources/static/app.js` | Main application logic, routing, API calls |

### Modified Files

| File | Change |
|------|--------|
| `pcst-master/pom.xml` | No changes required (static resources auto-served by Spring Boot) |

### Documentation

| File | Purpose |
|------|---------|
| `docs/DASHBOARD.md` | This document — architecture, APIs, usage, limitations |
| `docs/PROJECT_CONTEXT.md` | Updated with Step 8 completion status |

---

## Update to PROJECT_CONTEXT.md

Step 8 (Operational Dashboard) has been completed with the following actual verification status:

- **Cluster visibility**: Dashboard displays registered nodes with correct telemetry; missing data labeled "unavailable" (not zero)
- **Task console**: Successfully submits NO_OP, COMPUTE, and SLEEP tasks; shows lifecycle progression
- **Scheduling decision inspector**: Displays actual backend trace with candidates, dispositions, reliability, capability, and reasons
- **Execution lifecycle**: Shows state transitions from ACCEPTED through terminal states; OUTCOME_UNKNOWN handled correctly
- **No eligible node**: Correctly shows NO_FEASIBLE_NODE/UNRESOLVED_SCHEDULING when no nodes can satisfy task requirements
- **Ambiguous outcome**: OUTCOME_UNKNOWN displayed as distinct yellow warning without false success or auto-retry
- **Duplicate attempts**: Refreshing dashboard does not resubmit tasks (attempt-ID deduplication preserved)
- **Error handling**: Invalid inputs, unknown IDs, and empty lists handled cleanly
- **Regression**: Full test suite passes (367 tests, 0 failures, 0 errors)

All PCST mathematical invariants are preserved:
- Hard constraints never bypassed by UI
- Unresolved reliability never rendered as numeric zero or one
- Capability never presented as reliability
- No weighted scores or probabilities calculated in JavaScript
- No frontend ranking of nodes independently
- Scheduler's actual decision and trace displayed, not recreated algorithm
- Missing values distinguished from genuine zero probabilities
- Global optimality never claimed