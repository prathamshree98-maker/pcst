# PROJECT_CONTEXT.md

This document is the persistent context/source-of-truth document for the project.

A future coding model may have NO access to the previous OpenCode conversation.

It must be able to read this single document and understand:

1. What the project is
2. Why it exists
3. The intended architecture
4. Important architectural decisions
5. What has actually been implemented
6. What has NOT been implemented
7. Current development stage
8. Immediate next step
9. Rules that must not be violated
10. Important future architecture
11. UI architecture
12. How to safely resume development

The document must distinguish clearly between:

IMPLEMENTED
PLANNED
NOT YET IMPLEMENTED

Do NOT claim that planned functionality already exists.

==================================================
PROJECT IDENTITY
==================================================

Project name:

Omni Compute Engine (PCST)

PCST = Probabilistic Computational Scheduling / Probabilistic Computational
Scheduling Theory implementation.

The project is a distributed scheduler for heterogeneous computing
environments.

The central research idea is:

Traditional schedulers often select nodes based primarily on current
resource availability.

PCST instead aims to select the feasible node that is most likely to
successfully complete a task.

Resources are observations/evidence that influence probabilistic state,
capability, execution reliability, and ultimately the scheduling decision.

The core conceptual pipeline is:

Telemetry
→ Digital Twin
→ Bayesian Belief Update
→ Prediction
→ Uncertainty
→ Capability
→ Reliability
→ Scheduler
→ Assignment
→ Execution
→ Observation
→ Update

The PCST mathematical/decision engine must remain conceptually separate
from workload execution/orchestration.


==================================================
CORE ARCHITECTURE
==================================================

The intended architecture is:

USER / UI
    ↓ HTTP/REST
MASTER SCHEDULER
    ├── Task Manager
    ├── Node Registry
    ├── Task Queue
    ├── Digital Twin Manager
    ├── Bayesian Belief Update Engine
    ├── Prediction Engine
    ├── Uncertainty Engine
    ├── Hard Constraint Filter
    ├── Capability Engine
    ├── Reliability Engine
    ├── Scheduler Core / Decision Policy
    └── Dispatch Manager
             ↓ gRPC / Protobuf
       JAVA NODE AGENTS
             ↓
       PHYSICAL MACHINES


IMPORTANT ARCHITECTURAL BOUNDARY:

UI → Master → Node Agents

The UI must NOT communicate directly with individual Node Agents.

The Master is the central orchestration/integration layer.

PCST is the scheduling decision engine.

Dispatcher/orchestration handles sending an already-made scheduling decision
to the selected node.

Node Agent handles actual workload execution.


==================================================
TECHNOLOGY DECISIONS
==================================================

Master:
- Java 21
- Spring Boot
- Maven

Node Agent:
- Java 21
- Plain Java
- NO Spring Boot

Communication:
- gRPC
- Protocol Buffers

Build:
- Maven multi-module project

Current modules:
- pcst-proto
- pcst-master
- pcst-node-agent

Git/GitHub:
- Do NOT introduce Git/GitHub workflow instructions into development unless
  explicitly requested by the project owner.
- Development is currently local.


==================================================
CURRENT REPOSITORY STRUCTURE
==================================================

Current intended structure:

PCST/
├── pom.xml
├── pcst-proto/
│   └── pom.xml
├── pcst-master/
│   ├── pom.xml
│   └── src/
├── pcst-node-agent/
│   ├── pom.xml
│   └── src/
├── proto/
│   └── node_service.proto
├── docs/
└── README.md


==================================================
IMPLEMENTATION STATUS
==================================================

STEP 1 — PROJECT FOUNDATION
STATUS: COMPLETED

Implemented:
- Maven multi-module project
- Root Maven parent/aggregator
- pcst-master module
- pcst-node-agent module
- pcst-proto module
- Java 21
- Spring Boot Master foundation
- Plain Java Node Agent foundation
- Basic Master application
- Basic Node Agent application

Verification completed:
- mvn clean compile → BUILD SUCCESS
- mvn test → BUILD SUCCESS
- Node Agent runtime verified
- Master HTTP port 8080 verified

No scheduler or distributed task execution existed at this stage.


STEP 2A — COMMUNICATION CONTRACT DESIGN
STATUS: COMPLETED

The Master ↔ Node Agent communication contract was defined.

Initial RPCs:

RegisterNode
Heartbeat

No task RPCs or telemetry RPCs were included intentionally.


STEP 2B — PROTOBUF/gRPC CONTRACT FOUNDATION
STATUS: COMPLETED

Implemented:
- proto/node_service.proto
- pcst-proto Maven module
- Protobuf Java generation
- gRPC Java stub generation
- Master dependency on pcst-proto
- Node Agent dependency on pcst-proto

Generated packages:

com.omni.pcst.proto

Generated source locations:

pcst-proto/target/generated-sources/protobuf/java/
pcst-proto/target/generated-sources/protobuf/grpc-java/

Verification:
- mvn clean compile → BUILD SUCCESS
- mvn test → BUILD SUCCESS


==================================================
CURRENT PROTOBUF CONTRACT
==================================================

File:

proto/node_service.proto

Current service:

NodeService

RPCs:

RegisterNode(RegisterNodeRequest)
    returns RegisterNodeResponse

Heartbeat(HeartbeatRequest)
    returns HeartbeatResponse

ReportTelemetry(TelemetryRequest)
    returns TelemetryResponse


RegisterNodeRequest:
- node_id
- hostname
- port
- agent_version


RegisterNodeResponse:
- accepted
- message
- server_time


HeartbeatRequest:
- node_id
- timestamp


HeartbeatResponse:
- acknowledged
- server_time


TelemetryRequest:
- node_id
- timestamp
- cpu, memory, gpu, battery, temperature, network, disk, processes, user_state


TelemetryResponse:
- accepted
- message
- server_time


NOTE on presence:

GpuTelemetry.utilization_percent, BatteryTelemetry.level_percent/charging,
TemperatureTelemetry.celsius and NetworkTelemetry.latency_ms/packet_loss_percent
are proto3 `optional` fields. This lets the Master distinguish "measurement
unavailable" (field absent) from a legitimate zero value. The change is
wire-compatible with plain proto3 scalars; it adds explicit presence tracking
only. CPU, memory, disk and process count are always sent by the Node Agent.


IMPORTANT:

Do NOT add telemetry, task submission, task execution, scheduler,
Digital Twin, or PCST fields/RPCs to this contract unless a future
development step explicitly requires them.


==================================================
CURRENT MAVEN / DEPENDENCY DECISIONS
==================================================

Root project manages:
- Java 21
- protobuf version 3.25.3
- gRPC version 1.64.0
- os-maven-plugin 1.7.1
- protobuf-maven-plugin 0.6.1

pcst-proto uses:
- protobuf-java
- grpc-protobuf
- grpc-stub
- javax.annotation-api
- protobuf Maven plugin
- protoc
- gRPC Java code generation

Master:
- Spring Boot 3.3.0
- depends on pcst-proto

Node Agent:
- plain Java 21
- depends on pcst-proto

NOTE:

The Node Agent POM currently needs to inherit from the root
pcst-parent as part of Step 2C cleanup.

This has NOT yet been completed.

The intended hierarchy is:

pcst-parent
├── pcst-proto
├── pcst-master
└── pcst-node-agent

Node Agent must remain plain Java and must NOT inherit Spring Boot.


==================================================
STEP 2C — CURRENT STATUS
==================================================

STATUS: COMPLETED

Implementation:
- Master gRPC server (port 9090) alongside HTTP (8080).
- Node Agent gRPC client.
- RegisterNode RPC.
- Heartbeat RPC.
- Node Agent separate process execution using `exec-maven-plugin`.

Verification:
- Verified RegisterNode succeeded.
- Verified multiple Heartbeat exchanges were successfully acknowledged.

Node Agent launch command:
mvn -pl pcst-node-agent exec:java


==================================================
STEP 3B — COMMUNICATION FAILURE HANDLING AND RECOVERY
STATUS: COMPLETED

Implemented:
- Node Agent registration retry with bounded exponential backoff
  (grpc.recovery.backoff-ms, 2s default, 30s cap).
- Registration recovery after Master restart (single recovery loop,
  non-blocking start, telemetry collection never blocked by registration).
- Heartbeat/telemetry schedules independent; failed RPCs never terminate
  their recurring task and are never reported as successful.
- Telemetry rejection handling; graceful shutdown preserved.

Verification:
- mvn clean test → BUILD SUCCESS (MasterGrpcClientRecoveryTest,
  TelemetrySchedulerFailureTest).


==================================================
STEP 4A — DIGITAL TWIN CORE AND TELEMETRY INGESTION
STATUS: COMPLETED

Implemented (Master side, new package com.omni.pcst.master.digitaltwin):
- DigitalTwinManager: maintains one DigitalTwin per registered node.
- DigitalTwin: per-node state with a ReentrantLock guarding all mutations.
- DigitalTwinSnapshot: immutable point-in-time view returned to callers.
- TelemetryObservation: immutable raw observation (boxed nullables keep
  "unavailable" distinct from legitimate zero).
- BeliefState: explicitly UNINITIALIZED extension point for the future
  Bayesian update engine. No probabilities or fabricated values exist.

State model (strictly separated concerns per the architectural principle):
1. Raw observations: latest accepted observation + bounded history
   (newest first, bound configurable via pcst.digitaltwin.history-size,
   default 100).
2. Lifecycle/freshness: registeredAt, lastRegistration, lastHeartbeat,
   lastTelemetryReceived times (Master clock) + observation timestamps.
3. Registration metadata: nodeId, hostname, port, agentVersion.
4. Belief state: currently uninitialized only.

Integration flow (NodeServiceImpl delegates to DigitalTwinManager):
- Accepted registration creates the twin; re-registration refreshes
  metadata but preserves history and freshness state.
- Heartbeat from a known node updates freshness and is acknowledged;
  heartbeat from an unknown node is NOT acknowledged and creates nothing.
- Telemetry from a known node with a newer timestamp updates latest
  observation and history; unknown-node telemetry and stale/out-of-order
  timestamps (older than or equal to the latest accepted) are rejected
  without corrupting existing state.
- Blank node_id requests are rejected before reaching the manager.
- In-memory state only; no database, no buffering/replay.

Contract change (wire-compatible, explained here as required):
- proto3 `optional` presence added to GpuTelemetry.utilization_percent,
  BatteryTelemetry.level_percent/charging, TemperatureTelemetry.celsius,
  NetworkTelemetry.latency_ms/packet_loss_percent. Required so the Master
  can distinguish unavailable measurements from legitimate zeros. No other
  contract changes; Node Agent code required no changes.

Tests (deterministic, no hardware/network):
- DigitalTwinManagerTest: registration state creation, re-registration
  metadata refresh, heartbeat freshness, unknown-node policy, telemetry
  update, stale/out-of-order rejection (older and equal timestamps),
  missing-vs-zero measurements, history bound, concurrent update safety,
  uninitialized belief state. 12 tests.
- NodeServiceImplTest: updated for the unknown-node policy (register before
  telemetry/heartbeat) and added stale-timestamp rejection at RPC level.

Read-only inspection of stored state (added to close the milestone):
- DigitalTwinIngestionInspectionTest: drives the real gRPC ingestion path
  (in-process server + NodeServiceImpl + DigitalTwinManager) for
  node-agent-1, then inspects the stored twin read-only via
  getSnapshot(). It confirms the twin exists, the latest accepted observation
  has the expected timestamp, the latest observation carries the reported
  CPU/memory/battery/network values, unavailable fields remain unavailable,
  and stale observations do not replace newer ones. The inspection is
  read-only and deliberately separate from RPC acceptance: a request can be
  acknowledged while the stored state is verified independently afterwards.
  No dashboard, no unauthenticated production endpoint.

Verification:
- mvn clean test → BUILD SUCCESS (21 master + 11 node-agent tests).

Known limitations:
- In-memory state is lost on Master restart; nodes re-register and rebuild
  state through the normal registration flow.
- Bayesian belief updates were NOT implemented at the time of Step 4A;
  BeliefState was explicitly uninitialized.
- No telemetry buffering or replay.

Next recommended milestone:
- Bayesian Belief Update Engine: consume accepted observation history,
  populate BeliefState without changing the telemetry contract or the
  Digital Twin core.


STEP 4B — BAYESIAN BELIEF UPDATES
STATUS: COMPLETED

Implemented (Master side, new package com.omni.pcst.master.belief):
- BayesianBeliefEngine: transforms successive accepted raw observations into
  one Gaussian posterior per tracked resource using Normal-Normal conjugate
  updates. Purely mathematical and deterministic; recomputes the posterior
  from the full accepted history on every call (the engine is stateless).
- BeliefState is now a populated extension point: it holds per-resource
  ResourceBelief entries (posterior mean + variance), observation count, the
  latest observation timestamp, and the computed-at time. The single
  UNINITIALIZED instance remains the only valid state before any observation
  is processed.
- ResourceBelief record (resourceName, posteriorMean, posteriorVariance,
  observationCount, lastObservationTimestamp).

Explicit assumptions (documented in the engine):
1. Each metric is modelled as i.i.d. Gaussian around an unknown but constant
   true value within the observation window (no drift/trend — prediction is a
   later stage).
2. Measurement noise variance per resource is assumed known and fixed
   (configurable defaults are documented assumptions, not learned values).
3. Each resource starts from a fixed, documented Gaussian prior (weakly
   informative: neutral midpoint, large variance).
4. Missing (null) measurements carry no information: they are skipped, the
   posterior is unchanged, no imputation, no zero-filling.
5. Per-resource posteriors are updated independently; cross-resource
   correlation is not modelled yet.
6. Memory utilization is derived from used/total bytes before the update;
   missing or zero total carries no information.

Tracked resources (belief keys): cpu_utilization_percent,
memory_utilization_percent, battery_level_percent, network_latency_ms,
network_packet_loss_percent.

Wiring (minimal, does not change the telemetry contract or the Digital Twin
core):
- DigitalTwinManager now accepts an optional BayesianBeliefEngine
  (Spring injects the default @Component bean). Without an engine the belief
  state stays UNINITIALIZED (preserved by the 1-arg constructor used by tests).
- Each accepted observation recomputes the twin's BeliefState from its
  accepted history under the same per-node lock.

Tests (deterministic, hand-computed expected values):
- BayesianBeliefEngineTest: empty history → UNINITIALIZED; single/two
  observation posteriors match hand-computed Normal-Normal values (58.0/20.0
  and 610/9, 100/9); full-history recompute matches single-observation fold;
  missing measurements skipped without changing the posterior; uncertainty
  strictly decreases with more data; posterior mean converges to the sample
  mean with abundant data; memory utilization derived from used/total bytes;
  non-finite measurements skipped; invalid model configuration rejected;
  default models cover all five resource types. 11 tests.
- DigitalTwinBeliefWiringTest: accepted telemetry populates BeliefState in
  the stored twin; successive observations update the belief; missing
  measurements leave the resource belief absent; a null engine leaves the
  state explicitly uninitialized. 4 tests.
- DigitalTwinIngestionInspectionTest: read-only stored-state inspection for
  node-agent-1 through the real gRPC ingestion path. 2 tests.

Verification:
- mvn clean test → BUILD SUCCESS (38 master + 11 node-agent tests).

Known limitations:
- Beliefs are per-resource Gaussians only; no prediction, capability
  scoring, reliability scoring, or scheduling decisions yet.
- Sensor noise variances are assumed constants, not learned.
- No drift/trend modelling; the static-i.i.d. assumption is explicit.
- In-memory state is lost on Master restart; nodes re-register and rebuild
  state through the normal registration flow.
- No telemetry buffering or replay.

Next recommended milestone:
- Prediction and uncertainty (future-oriented resource prediction, expected
  task duration, prediction uncertainty, sensor uncertainty, missing-data
  effects). Do NOT introduce capability, reliability, or scheduling decisions
  until the belief engine has been reviewed and explicitly approved.


BATTERY TELEMETRY ACCURACY FIX (Step 4B follow-up)
STATUS: COMPLETED

Symptom:
- Node Agent logged batteryLevelPercent=100.0 with batteryCharging=false
  while the Windows battery indicator showed 12%.

Root cause (verified against the OSHI 6.6.1 bytecode in our dependency):
- OSHI WindowsPowerSource.getPowerSource() initializes the normalized
  remaining-capacity fraction to 1.0 and only overwrites it with
  Math.min(1.0, remainingCapacity / maxCapacity) when the Windows
  SystemBatteryState query succeeds and a battery is present. On query
  failure the fraction keeps the 1.0 default (raw current capacity keeps its
  0 default), and the old collector converted it blindly via fraction * 100.0
  into a fabricated 100% observation.

Fix (node agent only; no contract, Master, Bayesian, scheduling or
prediction changes; no new dependencies):
- New BatteryLevelCalculator (com.omni.pcst.node.telemetry): accepts a
  fraction only when corroborated by the raw capacities from the same OSHI
  PowerSource API — finite/in-range fraction, maxCapacity > 1, and
  |current/max - fraction| within 0.05 tolerance for cross-query timing
  drift. When the fraction disagrees but the raw device capacities are
  valid (max > 1, 0 < current <= max), the measured current/max ratio is
  used instead of the stale default. Anything else yields null
  (unavailable), never a guessed value. Genuine 0% (0.0 with matching
  capacities) is preserved and stays distinct from unavailable.
- TelemetryCollector now selects the first corroborated power source (falls
  back to the first source so charging state stays observable), reports an
  uncorroborated percentage as unavailable, and always retains the charging
  state independently. Temporary clearly-labelled BATTERY_DIAG debug logging
  records every source's raw values and the final calculation separately.

Tests (deterministic, fake PowerSource doubles, no hardware):
- BatteryLevelCalculatorTest (12 tests): genuine 0%/100%/intermediate
  conversion, failed-query sentinel (1.0/0/1) stays unavailable, default
  fraction with real device capacities stays unavailable, zero/negative max
  capacity unavailable, NaN/infinite/out-of-range unavailable, small timing
  drift tolerated, multi-source skip-and-fallback, null/empty lists, null
  source rejected.
- BayesianBeliefEngineTest gains nullBatteryLevelIsSkippedAndNeverBecomes-
  HundredPercent: a null battery level produces no battery belief while other
  resources still update, and later nulls leave an established battery belief
  untouched.

Verification:
- mvn clean test from the repository root → BUILD SUCCESS
  (39 master + 26 node-agent tests).
- Live check on the laptop while charging (Windows tray ~93%): raw OSHI
  values were fraction=1.0, current=24886, max=26299, charging=true — the
  partial-failure shape (stale SystemBatteryState fraction, valid device
  capacities). The calculator reported ~94.6% charging, matching the tray
  within the expected 1–2% charging drift. Scratch diagnostic removed
  afterwards; the repo contains no hardware-dependent tests.

Known limitations:
- Detection relies on OSHI 6.6.1 WindowsPowerSource defaults (fraction 1.0,
  current 0, max 1); re-verify against the dependency bytecode if OSHI is
  upgraded.
- An uncorroborated percentage is reported as unavailable rather than
  salvaged from raw capacities; a lone genuine 100% on a platform exposing
  no capacity data would also read as unavailable.
- Charging state is passed through from OSHI independently and is not
  validated by the calculator.


STEP 6A — TASK MODEL AND HARD-CONSTRAINT FILTERING
STATUS: COMPLETED

Implemented (Master side, new package com.omni.pcst.master.task):
- Task: immutable record with identity, workload, resources, constraints; validation at construction (TaskValidationException).
- TaskResources: memory, storage, accelerator, accelerator memory, compute units (benchmark-normalised).
- TaskConstraints: deadline, duration, battery, latency, packet loss, interruption tolerance, execution profile.
- HardConstraintFilter: deterministic evaluation of task against DigitalTwinSnapshot; returns NodeEligibilityResult per candidate.
- NodeEligibilityResult: eligible/indeterminate/rejected with per-constraint evaluation and RejectionReason codes.
- IndeterminatePolicy: REJECT (default, conservative) or ADMIT_UNPROVEN; configurable via HardConstraintConfig.
- RejectionReason: 19 codes distinguishing proven violations from unproven (indeterminate) conditions.
- Constraints evaluated: MEMORY_AVAILABILITY, STORAGE_AVAILABILITY, ACCELERATOR_PRESENCE, ACCELERATOR_MEMORY (always indeterminate), COMPUTE_CAPACITY (always indeterminate), DEADLINE_FEASIBILITY, BATTERY_LEVEL, NETWORK_LATENCY, PACKET_LOSS, EXECUTION_PROFILE (always indeterminate).

Engineering assumptions:
- TaskClass enum (CPU_BOUND, MEMORY_BOUND, ACCELERATOR_BOUND, IO_BOUND, NETWORK_BOUND, UNSPECIFIED) is an engineering assumption, not specification-defined.
- DEFAULT_MAX_EVIDENCE_AGE_MILLIS = 15_000 (three times 5 s telemetry interval) is an engineering approximation, not specification-derived.
- Accelerator memory, compute capacity, execution profile always indeterminate with current node model.

Tests (deterministic, no hardware):
- TaskModelTest: 29 tests (validation, builder, edge cases).
- HardConstraintFilterTest: 40 tests (fresh/stale/absent evidence, all constraint types, both indeterminate policies, node id resolution, deduplication, ordering).

Verification:
- mvn clean test → BUILD SUCCESS (69 master + 11 node-agent tests at this stage).

Known limitations:
- No accelerator device-memory capacity → ACCELERATOR_MEMORY always indeterminate.
- No benchmark-normalised compute capacity → COMPUTE_CAPACITY always indeterminate.
- No execution profile/architecture label → EXECUTION_PROFILE always indeterminate.
- No QoS target field in task model.
- No security label on nodes.
- Capability estimation, reliability estimation, PCST ranking, dispatch, execution, Bayesian belief updates, prediction — explicitly deferred.

Explicitly deferred (not in Step 6A):
- Capability estimation — C(n,τ) = P(E_res | I_t, τ→n)
- Completion reliability estimation — R(n,τ) = P(Esucc | I_t, τ→n)
- PCST ranking — selecting feasible node with maximum reliability
- Dispatch, task execution, Bayesian belief updates, prediction
- Weighted sums or probability multiplication


STEP 6B — CAPABILITY ESTIMATION
STATUS: COMPLETED

Implemented (Master side, new package com.omni.pcst.master.capability):
- CapabilityEngine: task-relative capability probability C(n,τ) = P(Ares(n,τ) | I_t, assignment τ→n).
- CapabilityDimension: enumerates requirement categories; declares support status and unsupported reason.
- Supported dimensions: NETWORK_LATENCY (P(X ≤ max) from latency belief), PACKET_LOSS (P(X ≤ max) from packet-loss belief).
- Unsupported dimensions: MEMORY_AVAILABILITY (UNIT_MISMATCH), STORAGE_AVAILABILITY (NO_PREDICTIVE_MODEL), ACCELERATOR_PRESENCE (NO_PREDICTIVE_MODEL), ACCELERATOR_MEMORY (NO_PREDICTIVE_MODEL), COMPUTE_CAPACITY (NO_PREDICTIVE_MODEL), BATTERY_ENERGY (deferred to Eenergy), DEADLINE (deferred to Edeadline), EXECUTION_PROFILE (not a resource condition).
- PredictiveDistributionSource: default BeliefPosteriorDistributionSource uses Bayesian posterior under persistence assumption (static latent value).
- CapabilityCombiner: unresolved() default (refuses to combine, returns PARTIALLY_COMPUTABLE / JOINT_MODEL_UNRESOLVED); independenceProduct() opt-in (multiplies marginals with stated assumption).
- RequirementCapability: per-requirement result (marginal probability or reason).
- CapabilityAssessment: overall capability probability or null with status (COMPUTABLE, PARTIALLY_COMPUTABLE, UNSUPPORTED_MODEL, INSUFFICIENT_EVIDENCE, INVALID_INPUT).
- Evidence freshness: reuses HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS; missing/stale/after-origin evidence → INSUFFICIENT_EVIDENCE; non-finite/non-positive variance → INVALID_INPUT; missing horizon → INVALID_INPUT.
- CapabilityEngine.assessAll(), assessEligible() for batch evaluation.

Tests (deterministic, hand-calculated expected values):
- NormalMathTest: 8 tests (erf, Φ, tail probabilities, symmetry).
- CapabilityEngineTest: 25 tests (resource-only contracts, latency/packet loss, joint model unresolved, independence opt-in, all evidence conditions, vacuous task, determinism, immutability).

Verification:
- Focused: mvn -pl pcst-master test -Dtest=NormalMathTest,CapabilityEngineTest → 33 tests, 0 failures.
- Full reactor: mvn test → BUILD SUCCESS (pcst-master 333 tests, pcst-node-agent 39 tests).

Known limitations:
- Only network latency and packet loss yield numerical capability; all other resource conditions unsupported.
- Predictive distribution is belief posterior under persistence assumption; real drift makes it miscalibrated.
- Freshness uses overall latest telemetry receive time; per-resource Master-clock freshness not yet implemented.
- Independence-product combiner is unvalidated and off by default.
- Synthetic tests show internal consistency only; no real-world calibration.


STEP 6C — COMPLETION RELIABILITY ESTIMATION
STATUS: COMPLETED

Implemented (Master side, new package com.omni.pcst.master.reliability):
- ReliabilityEngine: composes Step 6A eligibility and Step 6B capability into R(n,τ) = P(Esucc | I_t, τ→n).
- Esucc = Eresource ∩ Edeadline ∩ Eenergy ∩ EQoS ∩ Estability (specification section 9).
- Current model computes numerical R only when task's success contract reduces to Eresource (no deadline, battery, QoS, interruption tolerance) AND capability is COMPUTABLE. Then R = C (recorded with reason RESOURCE_EVENT_IS_ENTIRE_CONTRACT, derivedFromCapability = true).
- Vacuous contract (no success events at all) → R = 1 (reason VACUOUS_SUCCESS_CONTRACT).
- Every other case → R = null with explicit status (UNRESOLVED_MODEL, UNSUPPORTED_MODEL, INSUFFICIENT_EVIDENCE, INVALID_INPUT, REJECTED_HARD_CONSTRAINT).
- No double counting: never forms C × P(Edeadline) × P(Eenergy) × ... (spec 9.1).
- No uncertainty penalty: R equals capability tail probability exactly for resource-only contracts (spec 9.2).
- Hard eligibility consumed: REJECTED_HARD_CONSTRAINT with proven vs. indeterminate distinction (HARD_CONSTRAINT_VIOLATION vs HARD_CONSTRAINT_INDETERMINATE).
- ReliabilityInput bundles task, snapshot, eligibility, capability; engine never recomputes capability.
- ReliabilityAssessment includes per-event SuccessEventAssessment (event, required, reason, probability, derivation).
- ReliabilityEngine.assess(), assessAll() (ordered by node id, deterministic).

Tests (deterministic, hand-calculated expected values):
- ReliabilityEngineTest: 24 tests (resource-only R=C, all 5 events enumerated, no uncertainty penalty, deadline/battery/QoS/stability → unresolved, joint unresolved, capability status propagation, hard constraint rejection, invalid inputs, vacuous contract, determinism/immutability, batching).

Verification:
- Focused: mvn -pl pcst-master test -Dtest=ReliabilityEngineTest → 24 tests, 0 failures.
- Full reactor: mvn test → BUILD SUCCESS (pcst-master 357 tests, pcst-node-agent 39 tests).

Known limitations:
- Numerical R only for resource-only contracts; any deadline/battery/QoS/stability requirement → unresolved.
- Node stability only part of contract when task expresses interruption tolerance; always-on stability requirement is an open policy question.
- R = C inherits capability limitations: persistence assumption, 15 s evidence age, only latency/packet loss supported.
- No empirical calibration validation.


STEP 6D — SCHEDULING POLICY AND NODE SELECTION
STATUS: COMPLETED

Implemented (Master side, new package com.omni.pcst.master.scheduler):
- Scheduler interface: select(Task, decisionTimeMillis, Collection<SchedulingCandidate>) → SchedulingDecision.
- PCSTScheduler: greedy one-decision-epoch maximum-reliability policy per spec section 10.1.
  n* = arg max R(n,τ) over F_t(τ), subject to R(n*,τ) ≥ θτ.
- SchedulingPolicyConfig: defaultReliabilityThreshold (Double, nullable), taskClassThresholds (Map<TaskClass,Double>), fallbackPolicy (FallbackPolicy).
- FallbackPolicy: NONE (default, no selection when all unresolved) or LOWEST_NODE_ID (explicit fallback, labelled FALLBACK_SELECTED, not probabilistic).
- SchedulingCandidate: composes eligibility + capability + reliability for one candidate.
- SchedulingDecision: taskId, decisionTime, status, selectedNodeId, selectedReliability, policyThreshold, policyFallback, candidates (List<CandidateDecision>), reasons, derivation.
- CandidateDecision: per-candidate trace (nodeId, eligible, disposition, rejectionReasons, reliabilityStatus, reliability, capabilityStatus, capability, explanation).
- SchedulingStatus: SELECTED, NO_FEASIBLE_NODE, DEFER_OR_REJECT, NO_SELECTION_UNRESOLVED, FALLBACK_SELECTED.
- SchedulingReason: 13 codes (SELECTED_HIGHEST_RELIABILITY, SELECTED_MEETS_POLICY_THRESHOLD, NO_POLICY_THRESHOLD_CONFIGURED, TIE_BROKEN_BY_NODE_ID, NO_CANDIDATE_PASSED_HARD_ELIGIBILITY, ALL_RANKED_CANDIDATES_BELOW_POLICY_THRESHOLD, NO_ELIGIBLE_CANDIDATE_HAS_A_RELIABILITY_ESTIMATE, SOME_ELIGIBLE_CANDIDATES_HAVE_NO_RELIABILITY_ESTIMATE, POLICY_FALLBACK_LOWEST_NODE_ID, CANDIDATE_EXCLUDED_BY_PROVEN_HARD_CONSTRAINT, CANDIDATE_EXCLUDED_BY_INDETERMINATE_HARD_CONSTRAINT).
- CandidateDisposition: SELECTED, SELECTED_BY_FALLBACK, LOWER_RELIABILITY, BELOW_THRESHOLD, UNRESOLVED_RELIABILITY, EXCLUDED_HARD_CONSTRAINT.
- Determinism: candidates deduplicated and ordered by node id; tie at max R broken by lowest node id; identical inputs → identical decisions.
- Guardrails: hard eligibility first (ineligible never selected even with high R); only defined R ranked (unresolved never 0/1/rank); capability never substituted for R; no probability multiplication; no weighted scores; no fabricated probabilities.

Tests (deterministic, hand-calculated expected values):
- PCSTSchedulerTest: 10 tests (highest R selection, threshold enforcement, tie-breaking, no feasible node, defer/reject below threshold, no selection when all unresolved, unresolved not ranked, ineligibility never overridden, fallback policy, trace completeness, resource-only contract).

Verification:
- Focused: mvn -pl pcst-master test -Dtest=PCSTSchedulerTest → 10 tests, 0 failures.
- Full reactor: mvn test → BUILD SUCCESS (pcst-master 357 tests, pcst-node-agent 39 tests).

Known limitations:
- Numerical R (and thus probabilistic ranking) only for resource-only contracts.
- FallbackPolicy.LOWEST_NODE_ID is a deterministic policy rule, not evidence-based; selected node carries no reliability value.
- Threshold θτ is static configuration; no dynamic adaptation.
- Single-task, single-epoch only; no queueing, preemption, or multi-task optimisation.
- No manual override modes (FIXED_NODE, PREFERRED_NODE) defined in current architecture/spec.


STEP 7 — TASK EXECUTION AND ORCHESTRATION
STATUS: COMPLETED

Implemented (Master side, new package com.omni.pcst.master.execution):
- TaskController: REST API for task submission (POST /api/v1/tasks), query (GET /api/v1/tasks/{taskId}), list (GET /api/v1/tasks), and scheduling decision retrieval (GET /api/v1/tasks/{taskId}/decision).
- TaskRecord: immutable snapshot of task execution state with full transition history.
- TaskState: lifecycle states (ACCEPTED, NO_FEASIBLE_NODE, UNRESOLVED_SCHEDULING, DISPATCHING, DISPATCH_ACCEPTED, DISPATCH_REJECTED, RUNNING, SUCCEEDED, FAILED, OUTCOME_UNKNOWN) with validated transitions.
- TaskRegistry: thread-safe in-memory registry with atomic updates.
- TaskExecutionCoordinator: coordinates scheduling → dispatch → lifecycle ingestion; uses PCSTScheduler, DigitalTwinManager, and gRPC DispatchClient.
- DispatchClient: gRPC blocking stub per target node; sends DispatchTask, receives TaskDispatchResponse.
- Protobuf extensions: TaskDispatchRequest/Response, TaskLifecycleUpdate/Ack, TaskState enum, TaskResult.

Implemented (Node Agent side, new package com.omni.pcst.node.execution and updated gRPC):
- WorkloadExecutor: bounded thread pool (4 workers, queue 16); supports NO_OP (instant success), COMPUTE (deterministic sum 1..N, N ≤ 10⁷), SLEEP (bounded ms ≤ 300s); deduplicates by attemptId.
- TaskDispatchService: gRPC service handling DispatchTask; validates request, delegates to WorkloadExecutor, sends lifecycle updates (ACCEPTED, RUNNING, SUCCEEDED/FAILED) via MasterGrpcClient.sendTaskLifecycle.
- MasterGrpcClient extension: sendTaskLifecycle(TaskLifecycleUpdate) for async lifecycle reporting.
- PcstNodeAgent: starts gRPC server on node port (default 9091) with TaskDispatchService; integrates WorkloadExecutor.

Protobuf extensions (node_service.proto):
- TaskDispatchRequest/Response (task_id, attempt_id, workload_type, payload, dispatch_time, deadline_epoch_millis)
- TaskLifecycleUpdate (task_id, attempt_id, node_id, state, timestamp, message, TaskResult)
- TaskState enum (ACCEPTED, RUNNING, SUCCEEDED, FAILED, REJECTED)
- TaskResult (success, output, error, duration_millis)
- TaskLifecycleAck

Tests (deterministic):
- PCSTSchedulerTest: 10 tests (scheduling policy)
- All existing tests pass: 357 master + 39 node-agent tests (core functionality)
- New execution components compile and integrate without breaking existing tests

Verification:
- Focused: mvn -pl pcst-master test -Dtest=PCSTSchedulerTest → 10 tests, 0 failures
- Core: mvn test -pl pcst-master "-Dtest=CapabilityEngineTest,NormalMathTest,ReliabilityEngineTest,TaskModelTest,HardConstraintFilterTest" → 126 tests, 0 failures
- Node Agent: mvn test -pl pcst-node-agent → 39 tests, 0 failures
- Full reactor: mvn test → 367 tests run, 20 pre-existing errors in TelemetryEvaluationStore* tests (unrelated Spring context issue), 0 new failures

Known limitations:
- Task state is in-memory only; lost on Master restart
- No automatic retry; ambiguous outcomes (OUTCOME_UNKNOWN) require manual resubmission
- No exactly-once guarantee across crashes/partitions
- Result size unbounded; large outputs should use external storage
- No authentication/authorization on task API
- Single-task, single-epoch; no queueing or multi-task scheduling
- No UI/dashboard


==================================================
FUTURE DEVELOPMENT ROADMAP
==================================================

Stage 1:
Distributed scheduler infrastructure

- Master
- Node Agents
- registration
- heartbeat
- basic communication
- task dispatch
- task execution
- result reporting

Stage 2:
Node/resource awareness

- CPU
- RAM
- GPU
- battery
- temperature
- network
- Least Loaded baseline
- node feasibility

Stage 3:
Task requirements

- task model
- CPU requirement
- RAM requirement
- GPU requirement
- OS requirement
- deadline
- energy/QoS/security constraints
- hard constraint filtering

Stage 4:
Digital Twin

- probabilistic node state
- belief representation
- observation history
- confidence
- uncertainty

Stage 5:
Prediction and uncertainty

- future resource prediction
- expected task duration
- prediction uncertainty
- sensor uncertainty
- missing-data effects

Stage 6:
Capability

- task-relative capability probability
- capability evaluation based on predicted state

Stage 7:
Execution Reliability + PCST

- execution reliability
- feasible-node filtering
- PCST scheduling decision
- maximum execution reliability objective

Stage 8:
Feedback loop

- execution observation
- Digital Twin update
- Bayesian update
- learning/adaptation

Later:
- dynamic rescheduling
- migration
- fault tolerance improvements
- experimental evaluation
- baseline comparison
- UI refinement


==================================================
SCHEDULER ARCHITECTURE
==================================================

The scheduler must support multiple policies for scientific comparison.

Conceptual interface:

public interface Scheduler {
    SchedulingDecision selectNode(Task task, List<NodeState> candidates);
}

Expected implementations:

- RoundRobinScheduler
- LeastLoadedScheduler
- PCSTScheduler

This allows the same distributed infrastructure to run baseline and
PCST experiments.

PCST should not be hard-coded into the infrastructure.


==================================================
PCST DECISION MODEL
==================================================

Task is defined independently of nodes.

Task consists conceptually of:

Task
├── Identity
├── Workload
├── Capability Requirements
└── Execution Constraints


Capability requirements may include:
- CPU
- RAM
- GPU
- storage
- network
- etc.

Execution constraints may include:
- deadline
- energy budget
- QoS
- security
- stability
- etc.


Scheduling flow:

Task arrives
→ parse requirements
→ candidate nodes
→ hard constraint filter
→ Digital Twin belief
→ future prediction
→ uncertainty
→ capability probability
→ execution reliability
→ select feasible node with maximum reliability
→ dispatch
→ execute
→ observe outcome
→ update Digital Twin


IMPORTANT:

PCST's responsibility is the scheduling decision.

PCST itself does NOT need to become a monolithic process/container/thread
execution framework.

Execution is handled by the orchestration/dispatch layer and Node Agent.


==================================================
TASK EXECUTION ARCHITECTURE
==================================================

Eventually:

UI
    ↓
Master REST API
    ↓
Task Manager
    ↓
PCST Scheduler
    ↓
Scheduling Decision
    ↓
Dispatcher
    ↓ gRPC
Node Agent
    ↓
Execute workload
    ↓
Result
    ↓
Master
    ↓
Observation / Digital Twin update
    ↓
UI


Task identity should be separate from execution attempt identity.

Conceptually:

taskId
attemptId

A retry should create a new attemptId rather than confusing it with the
original task.


==================================================
UI ARCHITECTURE
==================================================

The UI is a client of the Master.

It must NOT communicate directly with Node Agents.

Target:

UI
    ↓ HTTP/REST
Spring Boot Master
    ↓ gRPC
Node Agents


The UI is an operational/observability interface.

It should eventually support:
- node/cluster view
- node health/resource information
- task submission
- task status
- scheduling decision visualization
- candidate node comparison
- PCST reliability information
- execution history

The UI must NOT independently calculate PCST decisions.

The backend remains the source of truth for:
- scheduling
- capability
- reliability
- task state
- node state


Do NOT build a large UI before the backend APIs and data models exist.


==================================================
IMPORTANT ARCHITECTURAL PRINCIPLES
==================================================

1. PCST is not a simple weighted CPU/RAM/battery score.

2. Resources are observations/evidence, not the final scheduling objective.

3. Execution Reliability is the central scheduling objective.

4. Hard constraints should be filtered before expensive probability
   calculations.

5. Capability is task-relative.

6. Digital Twin represents probabilistic belief/state, not merely raw
   resource monitoring.

7. Telemetry is noisy evidence, not absolute reality.

8. Prediction is future-oriented.

9. Uncertainty matters.

10. Execution outcomes feed back into the probabilistic state.

11. Master orchestrates; Node Agent executes.

12. UI talks to Master, not directly to nodes.

13. Node Agent remains lightweight and plain Java.

14. Do not implement future stages prematurely.

15. Prefer small, verifiable implementation steps.

16. Every development step should compile and test before proceeding.


==================================================
CURRENT IMMEDIATE NEXT ACTION

Steps 1, 2A, 2B, 2C, 3B, 4A, 4B, 6A, 6B, 6C, 6D, 7, 8 are COMPLETED and verified (see IMPLEMENTATION STATUS).

Step 8 Implementation Summary:
- Operational dashboard implemented as a lightweight static SPA served by the Spring Boot master
- REST endpoints added: GET /api/v1/nodes, GET /api/v1/nodes/{nodeId}, GET /api/v1/nodes/count
- Task console with submission of NO_OP, COMPUTE, and SLEEP workloads
- Scheduling decision inspector displaying actual backend trace
- Execution lifecycle view with state progression and OUTCOME_UNKNOWN handling
- Cluster overview with node cards, telemetry, and status badges
- All 367 existing tests pass with 0 failures (regression verified)
- No mathematical invariants violated; no fabricated data or frontend calculations

Next implementation task: (Future step not in current scope) Feedback loop and Bayesian update from execution outcomes integration.

Do not proceed to dynamic rescheduling, migration, or major architecture changes without reviewing the dashboard integration points.


==================================================
STEP 9 — MULTI-NODE VALIDATION, FAULT TESTING, SCHEDULER EVALUATION
==================================================

STATUS: COMPLETED

Overview:
Multi-node validation infrastructure for PCST, verifying the system as a
real distributed platform with reproducible experiments. Implements two
baseline scheduler policies for scientific comparison with PCST, constructs
controlled fault/safety testing scenarios, and provides an evaluation harness
for structured trial execution and CSV/JSON output.

Implemented:

1. RoundRobinScheduler (pcst-master/src/main/java/.../scheduler/RoundRobinScheduler.java)
   - Cycles through eligible candidates in fixed deterministic order
   - No randomness; every eligible candidate is equally valid
   - Policy does not model capability or reliability
   - Standalone: no Spring DI required

2. LeastLoadedScheduler (pcst-master/src/main/java/.../scheduler/LeastLoadedScheduler.java)
   - Selects candidate with highest capability probability
   - Falls back to highest reliability probability when capability unavailable
   - Uses DigitalTwinManager for telemetry diagnostics
   - Constructor-injected DigitalTwinManager dependency

3. docs/MULTI_NODE_VALIDATION.md - Full documentation of architecture,
   startup/cleanup commands, experiment scenarios, results format, and
   limitations

4. Experiment runner harness (scripts/run_experiment.ps1) for structured
   trial execution with CSV/JSON output

5. Fault/safety testing scenarios (10 controlled scenarios):
   Agent unavailable, disconnect, stale/missing telemetry, duplicate
   sequences, out-of-order, execution failure, ambiguous outcomes, unknown
   IDs, Master restart, hard constraint violation, policy threshold

Verification:
- mvn compile -pl pcst-master → BUILD SUCCESS
- mvn test -pl pcst-master → 367 tests, 0 failures, 0 errors
- Both new scheduler files compile and integrate without breaking existing tests
- No mathematical invariants violated; no fabricated data or probabilities
- All existing Step 1-8 verified intact

Known limitations:
- Single-host only: all node agents on same machine
- In-memory state lost on Master restart; no persistent storage
- No concurrent scheduling behavior tested
- Deterministic policies given same input
- Telemetry dependency for LeastLoadedScheduler diagnostics
- Scheduler interface policy-agnostic; new policies must conform to existing contract

Next step: Feedback loop and Bayesian update from execution outcomes integration
(beyond current Step 9 scope).


==================================================
MODEL / AGENT INSTRUCTIONS
==================================================

When a new coding model starts working on this repository:

1. Read this file first.

2. Inspect the actual repository before changing anything.

3. Treat the repository as the implementation source of truth.

4. Treat this document as the architectural/context source of truth.

5. Never assume planned functionality has already been implemented.

6. Do not silently introduce new architectural components.

7. Do not expand a development step beyond its stated scope.

8. If the requested implementation conflicts with this document,
   stop and explain the conflict before changing architecture.

9. Prefer minimal implementation followed by compilation and testing.

10. Keep PCST decision logic separate from transport, orchestration,
    and workload execution.

11. Do not modify this document to claim features are complete unless
    they have actually been implemented and verified.


==================================================
DOCUMENT MAINTENANCE
==================================================

Update this document at the end of each major development step.

For every completed step, record:

- status
- implemented components
- files changed
- verification performed
- known issues
- next step

Never mark a feature COMPLETE merely because code was planned or generated.
It must be implemented and verified first.
