# Task Model and Hard-Constraint Filtering

Step 6A of PCST: an immutable task model, explicit requirement validation, and a
deterministic hard-constraint filter that decides which registered nodes are
eligible to execute a given task.

This document distinguishes **specification-derived** decisions from
**engineering assumptions** introduced where the specification leaves a question
unresolved.

---

## 1. Task model

`com.omni.pcst.master.task.Task` — an immutable record, specified independently
of any node (specification section 3.1).

| Field | Type | Required | Meaning |
|---|---|---|---|
| `taskId` | `String` | yes | Stable task identity. Must be non-blank. |
| `taskClass` | `TaskClass` | yes | Workload type. Defaults to `UNSPECIFIED`. |
| `workloadReference` | `String` | no | Executable / container / function reference. |
| `inputCharacteristics` | `String` | no | Free-form input description. Defaults to `""`. |
| `expectedDurationMillis` | `Long` | no | Duration model. Absent ≠ zero. |
| `resources` | `TaskResources` | yes | Workload demand. `NONE` when absent. |
| `constraints` | `TaskConstraints` | yes | Execution constraints. `NONE` when absent. |

### TaskResources — workload demand

| Field | Type | Unit | Absent means |
|---|---|---|---|
| `requiredMemoryBytes` | `Long` | bytes | No memory requirement |
| `requiredStorageBytes` | `Long` | bytes | No storage requirement |
| `acceleratorRequired` | `boolean` | — | No accelerator needed |
| `requiredAcceleratorMemoryBytes` | `Long` | bytes | No accelerator memory demand |
| `requiredComputeUnits` | `Double` | benchmark-normalized (dimensionless) | No compute demand |

### TaskConstraints — execution constraints

| Field | Type | Unit | Absent means |
|---|---|---|---|
| `deadlineEpochMillis` | `Long` | epoch millis | No deadline |
| `expectedDurationMillis` | `Long` | millis | No duration (constraints-level) |
| `minimumBatteryPercent` | `Double` | percent [0, 100] | No battery floor |
| `maximumNetworkLatencyMillis` | `Double` | millis ≥ 0 | No latency ceiling |
| `maximumPacketLossPercent` | `Double` | percent [0, 100] | No packet-loss ceiling |
| `interruptionTolerance` | `InterruptionTolerance` | — | No preference asserted |
| `requiredExecutionProfile` | `String` | — | No profile restriction |

### Absent vs. explicit zero

Every optional field is a boxed type. `null` means **no requirement is
expressed**; a numeric `0` means **the task explicitly demands zero**. These are
never conflated. A `null` requirement imposes no hard constraint; an explicit
zero is a real demand that is still validated and still evaluated.

---

## 2. Validation

Validation happens at construction time via `TaskValidationException`, which
carries **all** violations found (not just the first). Each violation identifies
the offending field by dotted path.

| Rule | Violation field |
|---|---|
| Blank or missing `taskId` | `taskId` |
| Null `taskClass` | `taskClass` |
| Negative memory / storage / accelerator-memory demand | `requiredMemoryBytes` etc. |
| Negative or non-finite compute demand | `requiredComputeUnits` |
| Negative duration or deadline | `expectedDurationMillis` / `deadlineEpochMillis` |
| Percentage outside [0, 100] | `minimumBatteryPercent` / `maximumPacketLossPercent` |
| Negative latency ceiling | `maximumNetworkLatencyMillis` |
| Null `resources` or `constraints` | `resources` / `constraints` |

`TaskConstraints.validateAgainstDecisionTime(t)` separately checks deadline
feasibility: `deadline − duration ≥ t`. This is a task-level consistency check,
not a node check.

**Engineering assumption:** `TaskClass` values (`CPU_BOUND`, `MEMORY_BOUND`,
`ACCELERATOR_BOUND`, `IO_BOUND`, `NETWORK_BOUND`) are not specification-defined.
They are the smallest closed set the current telemetry model can reason about.

---

## 3. Hard-constraint filter

`HardConstraintFilter` evaluates a task against candidate node snapshots and
returns a `NodeEligibilityResult` per candidate. It is deterministic: identical
inputs always produce identical results.

### Supported constraints and units

| Constraint | Comparison | Unit | Evidence source |
|---|---|---|---|
| `MEMORY_AVAILABILITY` | `available ≥ required` | bytes | `TelemetryObservation.availableMemoryBytes` |
| `STORAGE_AVAILABILITY` | `free ≥ required` | bytes | `TelemetryObservation.freeDiskBytes` |
| `ACCELERATOR_PRESENCE` | `present == true` | boolean | `TelemetryObservation.gpuAvailable` |
| `ACCELERATOR_MEMORY` | — | bytes | **Not exposed by current model → always indeterminate** |
| `COMPUTE_CAPACITY` | — | compute units | **Not exposed; utilization is load, not capacity → always indeterminate** |
| `DEADLINE_FEASIBILITY` | `deadline − duration ≥ decisionTime` | epoch millis | Task's own duration model |
| `BATTERY_LEVEL` | `level ≥ minimum` | percent | `TelemetryObservation.batteryLevelPercent` |
| `NETWORK_LATENCY` | `latency ≤ maximum` | milliseconds | `TelemetryObservation.latencyMs` |
| `PACKET_LOSS` | `loss ≤ maximum` | percent | `TelemetryObservation.packetLossPercent` |
| `EXECUTION_PROFILE` | — | — | **Not exposed by current model → always indeterminate** |

### Satisfied / violated / indeterminate

Every constraint resolves to exactly one of:

- **SATISFIED** — valid, fresh evidence proves the constraint holds.
- **VIOLATED** — valid evidence proves the constraint does not hold.
- **INDETERMINATE** — available evidence can establish neither.

Indeterminate is never silently promoted to SATISFIED or demoted to VIOLATED.

### Missing, stale, and indeterminate evidence policy

| Evidence state | Meaning | Effect under default policy |
|---|---|---|
| **Fresh** | Observation received within `maxEvidenceAgeMillis` | Used to prove SATISFIED or VIOLATED |
| **Stale** | Observation older than `maxEvidenceAgeMillis` | Constraint becomes INDETERMINATE (`STALE_EVIDENCE`) |
| **Absent** | No observation ever received | Constraint becomes INDETERMINATE (`NO_OBSERVATION`) |
| **Field missing** | Observation exists but the specific measurement is `null` | Constraint becomes INDETERMINATE (`NO_OBSERVATION` or field-specific unknown) |

**Default policy: `IndeterminatePolicy.REJECT`** — a node with any unproven
constraint is excluded from the feasible set. This is the conservative choice:
the Master never places work on a node whose ability to do so it cannot
establish.

**Alternative: `IndeterminatePolicy.ADMIT_UNPROVEN`** — a node is admitted if
every *proven* constraint passes; unproven constraints do not exclude it. This
maximises availability but places work on nodes whose capability was never
established.

The policy is configurable per deployment via `HardConstraintConfig`.

**Engineering assumption:** `DEFAULT_MAX_EVIDENCE_AGE_MILLIS = 15_000` (three
times the Node Agent's 5 s telemetry interval). This is deliberately forgiving
and is not a specification-derived constant. Deployments with a different
sampling interval must override it.

### Rejection reason codes

All codes are in `RejectionReason`. Each code states whether it is a **proven**
violation or an **unproven** (indeterminate) condition.

| Code | Proven? | Meaning |
|---|---|---|
| `MEMORY_INSUFFICIENT` | proven | Available memory below demand |
| `STORAGE_INSUFFICIENT` | proven | Free storage below demand |
| `ACCELERATOR_ABSENT` | proven | GPU required, node reports none |
| `ACCELERATOR_MEMORY_UNVERIFIABLE` | unproven | No device-memory field exists |
| `COMPUTE_CAPACITY_UNVERIFIABLE` | unproven | Utilization is load, not capacity |
| `DEADLINE_INFEASIBLE` | proven | Duration cannot fit before deadline |
| `DEADLINE_UNVERIFIABLE` | unproven | Deadline expressed but no duration |
| `BATTERY_BELOW_MINIMUM` | proven | Battery below task minimum |
| `BATTERY_UNKNOWN` | unproven | No battery observation |
| `NETWORK_LATENCY_EXCEEDED` | proven | Latency above task maximum |
| `NETWORK_LATENCY_UNKNOWN` | unproven | No latency observation |
| `PACKET_LOSS_EXCEEDED` | proven | Packet loss above task maximum |
| `PACKET_LOSS_UNKNOWN` | unproven | No packet-loss observation |
| `EXECUTION_PROFILE_UNVERIFIABLE` | unproven | No execution profile in node model |
| `STALE_EVIDENCE` | unproven | Observation older than max age |
| `NO_OBSERVATION` | unproven | No telemetry received |
| `NODE_UNKNOWN` | proven | Node id not registered |
| `EVALUATION_ERROR` | unproven | Candidate could not be evaluated |

---

## 4. Architecture boundaries

- The filter reads **immutable** `DigitalTwinSnapshot` values only. It never
  mutates Digital Twin state.
- No second node registry is created. The filter accepts snapshots or resolves
  node ids through a caller-provided resolver (e.g.
  `DigitalTwinManager::getSnapshot`).
- One malformed candidate never invalidates unrelated candidates; each is
  evaluated independently.
- Results are ordered by node id for determinism.
- No global Master lock is held during evaluation.
- The service is unit-testable without network connections.

---

## 5. Usage

```java
// Build a task
Task task = Task.builder("train-42")
        .taskClass(TaskClass.ACCELERATOR_BOUND)
        .workloadReference("registry/training:latest")
        .expectedDurationMillis(60_000L)
        .resources(new TaskResources(2 * ONE_GIB, 10 * ONE_GIB, true, 4 * ONE_GIB, null))
        .constraints(new TaskConstraints(
                System.currentTimeMillis() + 3_600_000L,
                60_000L,
                10.0,   // minimum battery %
                50.0,   // maximum latency ms
                1.0,    // maximum packet loss %
                null,
                null))
        .build();

// Configure the filter
HardConstraintConfig config = HardConstraintConfig.defaults();
// or: HardConstraintConfig.of(15_000L, IndeterminatePolicy.REJECT);
HardConstraintFilter filter = new HardConstraintFilter(config);

// Option A: filter against already-resolved snapshots
List<NodeEligibilityResult> results = filter.filter(task, snapshots, decisionTime);

// Option B: filter by node id, resolving through the Digital Twin
List<NodeEligibilityResult> results = filter.filterByNodeIds(
        task,
        List.of("node-1", "node-2"),
        digitalTwinManager::getSnapshot,
        decisionTime);

// Derive the feasible set F*(τ)
List<NodeEligibilityResult> feasible = NodeEligibilityResult.eligibleCandidates(results);

// Inspect a rejection
for (NodeEligibilityResult r : results) {
    if (!r.eligible()) {
        System.out.println(r.nodeId() + " rejected: " + r.reasons());
        for (ConstraintEvaluation ce : r.blockingConstraints()) {
            System.out.println("  " + ce.constraint() + ": " + ce.reason()
                    + " (required=" + ce.required() + ", observed=" + ce.observed() + ")");
        }
    }
}
```

---

## 6. Current model limitations

| Gap | Impact | Deferred to |
|---|---|---|
| No accelerator device-memory capacity | `ACCELERATOR_MEMORY` always indeterminate | Future node model extension |
| No benchmark-normalized compute capacity | `COMPUTE_CAPACITY` always indeterminate | Capability engine (Step 6B+) |
| No execution profile / architecture label | `EXECUTION_PROFILE` always indeterminate | Future node model extension |
| No QoS target field in task model | QoS not yet a hard constraint | Future specification revision |
| No security label on nodes | Security restrictions not yet filterable | Future node model extension |

---

## 7. Explicitly deferred

The following are **not** implemented in Step 6A and must not be inferred from
this code:

- **Capability estimation** — `C(n,τ) = P(E_res | I_t, τ→n)` requires
  probabilistic reasoning over an execution horizon.
- **Completion reliability estimation** — the central scheduling objective.
- **PCST ranking** — selecting the feasible node with maximum reliability.
- **Dispatch** — sending a decision to a node.
- **Task execution** — running workloads.
- **Bayesian belief updates** — populating `BeliefState` from observations.
- **Prediction** — `ResourceForecast` and predictor formulas.
- **Weighted sums or probability multiplication** — no such formulas appear here.
