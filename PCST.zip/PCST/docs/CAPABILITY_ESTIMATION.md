# Capability Estimation Engine

Step 6B of PCST: a task-relative, probabilistic capability estimator built on top
of the existing task model, Digital Twin belief state, and prediction boundary.
It estimates exactly one quantity — the probability that a task's resource
requirements hold on a candidate node over its execution interval — and nothing
that lies downstream of it.

This document separates **specification-derived** decisions from
**engineering assumptions** introduced where the specification leaves a question
unresolved.

---

## 1. Definition

Specification section 8 defines capability over the resource event `Ares`:

```
C(n, τ) = P( Ares(n, τ) | Iₜ, assignment τ → n )
```

| Symbol | Meaning in this implementation |
|---|---|
| `n` | the candidate node (`DigitalTwinSnapshot.nodeId()`) |
| `τ` | the task (`com.omni.pcst.master.task.Task`) |
| `Iₜ` | the information available at decision instant `t` — the node's belief state |
| `Ares` | the event that every required resource condition holds over the execution interval |
| `C` | a probability in [0, 1], or `null` with an explicit status |

Capability is **an event probability**, not a weighted resource score. There is
no code path that multiplies resource values by coefficients; specification
sections 8.1 and 8.3 forbid treating a formula such as
`0.4·CPU + 0.3·RAM + 0.3·battery` as a probability.

### One-dimensional marginal

For a single resource condition with an upper threshold `r` and predictive law
`X ~ Normal(μ, σ²)`:

```
C = P(X ≤ r) = Φ( (r − μ) / σ )
```

where `Φ` is the standard normal CDF. `NormalMath` implements `Φ` via the error
function; the Java standard library does not expose `erf`, so the Abramowitz &
Stegun 7.1.26 rational approximation is used (maximum absolute error
`1.5×10⁻⁷`, well inside the `10⁻⁶` test tolerance). This numeric choice is
explicit and documented rather than hidden.

---

## 2. Supported dimensions and the model gap

Task requirements are enumerated in `CapabilityDimension`. Each declares whether
it is a **resource condition** (`Ares`), whether the current model can form a
**predictive distribution** for it, and why not when it cannot.

| Dimension | Resource condition? | Supported? | Treatment |
|---|---|---|---|
| `NETWORK_LATENCY` (max latency, ms) | yes | **yes** | `P(X ≤ max)` from the latency belief |
| `PACKET_LOSS` (max loss, %) | yes | **yes** | `P(X ≤ max)` from the packet-loss belief |
| `MEMORY_AVAILABILITY` (bytes) | yes | no | `UNIT_MISMATCH` — belief tracks utilization %, not free bytes |
| `STORAGE_AVAILABILITY` (bytes) | yes | no | `NO_PREDICTIVE_MODEL` — no storage belief |
| `ACCELERATOR_PRESENCE` | yes | no | `NO_PREDICTIVE_MODEL` |
| `ACCELERATOR_MEMORY` (bytes) | yes | no | `NO_PREDICTIVE_MODEL` |
| `COMPUTE_CAPACITY` (units) | yes | no | `NO_PREDICTIVE_MODEL` — utilization is load, not capacity |
| `BATTERY_ENERGY` (%) | no | no | deferred to `Eenergy` reliability |
| `DEADLINE` | no | no | deferred to `Edeadline` reliability |
| `EXECUTION_PROFILE` | no | no | not a resource condition (hard compatibility) |

Only latency and packet loss are supported, because they are the only required
quantities whose **units match a tracked belief** (milliseconds and percent). A
byte-based memory demand cannot be turned into a utilization-percent belief
without a fabricated conversion, and none is invented. These gaps are reported,
not guessed.

**Energy and deadline are deliberately excluded from capability.**
Specification section 9 defines `Esucc = Eresource ∩ Edeadline ∩ Eenergy ∩ EQoS ∩ Estability`.
Battery is `Eenergy`, the deadline is `Edeadline`; both are reliability events.
Including them in `C` and then again in `R` would double-count them
(specification section 9.1). They are recorded as deferred requirement entries so
the omission is visible, not silent.

---

## 3. Predictive distribution and its assumption

The predictive distribution comes from a `PredictiveDistributionSource`. The
default, `BeliefPosteriorDistributionSource`, uses the Bayesian belief posterior
**itself**:

```
X ~ Normal( posteriorMean, posteriorVariance )
```

This is valid **only** under the belief engine's documented persistence
assumption: each resource is i.i.d. Gaussian noise around an unknown but
**constant** true value, with no drift, trend, or process noise. Under that
model the posterior is the distribution of the future *latent value*, so it *is*
the predictive law for the execution interval. This is exactly and only the
persistence assumption, and every distribution records it in its `assumption`
field.

Two things are deliberately **not** done:

- a heuristic forecast half-range or point-forecast spread is never reused as a
  variance, because a forecast interval is not a probability distribution; and
- the posterior variance is never relabelled as a generic "forecast
  uncertainty", and no extra process-noise term is added.

If a later prediction stage introduces temporal dynamics, it must supply a
different `PredictiveDistributionSource`; the default then no longer applies.

### Execution horizon

The capability event is defined over an execution interval `[t, t+H]`. The
horizon `H` is taken from `Task.expectedDurationMillis()`, falling back to
`TaskConstraints.expectedDurationMillis()`. Under the static-value persistence
model the endpoint distribution does not vary with `H`, so `H` does not enter the
probability arithmetic; it is still required to establish that the interval
exists. A task that expresses a computable resource condition but **no duration**
therefore yields `INVALID_INPUT` / `MISSING_HORIZON` rather than an interval-free
number.

---

## 4. Joint event probability across several conditions

When more than one condition is computable, capability is the probability of the
**joint** feasible region, not a product of marginals unless justified:

```
C = P( ∩ₖ Eₖ )   ≠   ∏ₖ P(Eₖ)   unless independence or a valid factorization holds
```

The engine delegates this to a `CapabilityCombiner`:

- `CapabilityCombiner.unresolved()` — the **default**. It refuses to combine and
  returns nothing, because cross-resource dependence is not modelled (the belief
  engine's per-resource independence is a modelling assumption, not a validated
  property). The assessment then becomes `PARTIALLY_COMPUTABLE` /
  `JOINT_MODEL_UNRESOLVED`, with each marginal still reported.
- `CapabilityCombiner.independenceProduct()` — an **opt-in** that multiplies the
  marginals under a clearly stated, unvalidated independence assumption. It is
  never the default, and its `assumption()` is carried onto every result.

---

## 5. Statuses, reasons, and failure behaviour

`CapabilityStatus`:

| Status | Meaning | `capability()` |
|---|---|---|
| `COMPUTABLE` | overall probability is defined | value in [0, 1] |
| `PARTIALLY_COMPUTABLE` | some marginals computed but the joint is not defined | `null` |
| `UNSUPPORTED_MODEL` | no resource condition has a predictive model | `null` |
| `INSUFFICIENT_EVIDENCE` | modelled conditions exist but belief evidence is unusable | `null` |
| `INVALID_INPUT` | non-finite/non-positive variance, or a missing horizon | `null` |

Aggregation precedence (first match wins):

1. no resource conditions at all → `COMPUTABLE`, value `1.0`
   (`VACUOUS_NO_REQUIREMENTS`; battery/deadline-only tasks land here, with their
   deferral recorded);
2. any invalid parameter or missing horizon → `INVALID_INPUT`;
3. no supported resource condition → `UNSUPPORTED_MODEL`;
4. unsupported condition present → `PARTIALLY_COMPUTABLE` if any marginal was
   computed, otherwise `UNSUPPORTED_MODEL`;
5. supported conditions but nothing computed → `INSUFFICIENT_EVIDENCE`;
6. exactly one computable condition → `COMPUTABLE`, that probability;
7. two or more computable conditions → combiner; `COMPUTABLE` if it resolves,
   otherwise `PARTIALLY_COMPUTABLE` (`JOINT_MODEL_UNRESOLVED`).

Behaviour by evidence condition:

- **Missing belief** (`MISSING_BELIEF`) — no posterior has been produced for the
  required resource. Never treated as zero.
- **Stale evidence** (`STALE_EVIDENCE`) — the belief evidence is older than the
  configured maximum age. The threshold reuses
  `HardConstraintConfig.DEFAULT_MAX_EVIDENCE_AGE_MILLIS` (15 000 ms), the same
  engineering approximation (three times the 5 s telemetry interval) the
  hard-constraint filter uses. It is not a specification-derived constant.
- **Evidence after the decision instant** (`EVIDENCE_AFTER_ORIGIN`) — the
  candidate's telemetry was received *after* `t`; it cannot be used as history
  for a decision made at `t`, and is rejected rather than quietly accepted.
- **Non-finite parameter** (`NON_FINITE_PARAMETER`) and **non-positive variance**
  (`NON_POSITIVE_VARIANCE`) — the model requiring a finite, strictly positive
  variance is enforced; a degenerate distribution never yields a number.
- **Missing horizon** (`MISSING_HORIZON`) — see section 3.

Freshness is assessed from `DigitalTwinSnapshot.lastTelemetryReceivedAtMillis()`
(Master clock), not from the node-supplied observation timestamp, so node/Master
clock skew cannot fabricate freshness.

---

## 6. Boundaries — what this step does not do

- No **completion reliability** `R(n, τ)` is computed. `Edeadline`, `Eenergy`,
  `EQoS`, and `Estability` are out of scope and are explicitly deferred.
- No **ranking**, **thresholding**, **selection**, **dispatch**, or **execution**.
  The engine returns per-candidate diagnostics only.
- No new **belief** algorithm, **predictor**, or **weighted score**.
- No **unjustified products** of marginal probabilities — the default refuses.
- The task model / hard-constraint policy, the Bayesian belief engine, telemetry,
  sequence tracking, and the replay harness are consumed but **not modified**.

---

## 7. Files

Main (`pcst-master/src/main/java/com/omni/pcst/master/capability/`):

| File | Responsibility |
|---|---|
| `NormalMath.java` | `erf`, `Φ`, tail probabilities (A&S 7.1.26) |
| `CapabilityDimension.java` | requirement categories and their model support |
| `CapabilityStatus.java` | assessment outcome |
| `CapabilityReason.java` | stable diagnostic reason codes |
| `PredictiveDistribution.java` | Gaussian predictive law + provenance |
| `PredictiveDistributionSource.java` | predictive-law seam |
| `BeliefPosteriorDistributionSource.java` | default: belief posterior under persistence |
| `CapabilityCombiner.java` | joint-model combiner (unresolved default, independence opt-in) |
| `RequirementCapability.java` | per-requirement result |
| `CapabilityAssessment.java` | per-(task, node) result |
| `CapabilityEngine.java` | `assess`, `assessAll`, `assessEligible` |

Tests (`pcst-master/src/test/java/com/omni/pcst/master/capability/`):

| File | Tests |
|---|---|
| `NormalMathTest.java` | 8 |
| `CapabilityEngineTest.java` | 25 |

---

## 8. Hand-calculated test values

Every probability test asserts a value computed by hand from the standard normal
table (tolerance `1×10⁻⁶`):

| Quantity | Hand value |
|---|---|
| `Φ(1)` | `0.8413447` |
| `Φ(2)` | `0.9772499` |
| `Φ(0.4)` | `0.6554217` |
| `Φ(0)` | `0.5` |
| `Φ(−2)` | `0.0227501` |
| `P(M ≥ 4)`, `M~N(5, 0.5²)` (spec §8.2) | `1 − Φ(−2) ≈ 0.977` |
| `P(X ≤ 100)`, `X~N(80, 10²)` | `Φ(2) = 0.9772499` |
| independence product `Φ(2)·Φ(2)` | `0.9550173` |

Anti-weighting tests:

- **`capabilityIsEventProbabilityNotALinearScore`** — nodes with equal linear
  score `mean/threshold = 0.8` but different spreads get different probabilities
  (`Φ(4) = 0.9999683` vs `Φ(0.4) = 0.6554217`); the score is not a probability.
- **`lowerUncertaintyIsNotUniversallyHigherCapability`** — mean equal to the
  threshold gives `0.5` at every variance (spec §11), while a mean below the
  threshold loses capability as spread grows (`0.9772499 → 0.6554217`). There is
  no universal uncertainty-dominance rule.

---

## 9. Limitations

- Only network latency and packet loss can be estimated; all other resource
  conditions are reported as unsupported. This is a genuine model gap, not a
  finished capability model.
- The predictive distribution is the belief posterior under the persistence
  assumption. Any real drift or trend makes it miscalibrated, and no held-out
  calibration has been performed.
- Freshness uses the overall latest telemetry receive time, so a resource whose
  marginal stopped being reported while the node still reports other fields may
  not be flagged as stale. Per-resource Master-clock freshness does not exist yet.
- The independence-product combiner is an unvalidated approximation and is off by
  default.
- The synthetic tests demonstrate internal consistency with the stated model.
  They do **not** constitute real-world validation of prediction or capability
  calibration.

---

## 10. Verification

- Focused: `mvn -pl pcst-master test -Dtest=NormalMathTest,CapabilityEngineTest`
  → **33 tests**, 0 failures, 0 errors.
- Full reactor: `mvn test` from the repository root → **BUILD SUCCESS**.
  `pcst-master` **333 tests** (0 failures, 0 errors), `pcst-node-agent`
  **39 tests** (0 failures, 0 errors). The capability package contributes the 33
  new tests; no pre-existing test changed and no pre-existing source file was
  modified.
