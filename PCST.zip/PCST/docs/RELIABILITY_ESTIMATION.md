# Completion Reliability Engine

Step 6C of PCST: a task-relative completion-reliability estimator,
`R(n, τ) = P(Esucc | Iₜ, assignment τ→n)`, built on top of the Step 6A task model
and hard-constraint filter and the Step 6B capability estimator. It composes those
upstream results into the specification's success event and nothing downstream of
it.

This document separates **specification-derived** decisions from **engineering
assumptions** introduced where the specification leaves a question unresolved.

---

## 1. Definition

Specification section 9 defines completion reliability over the success event:

```
Esucc = Eresource ∩ Edeadline ∩ Eenergy ∩ EQoS ∩ Estability
R(n, τ) = P( Esucc | Iₜ, assignment τ → n )
```

| Symbol | Meaning in this implementation |
|---|---|
| `n` | the candidate node (`DigitalTwinSnapshot.nodeId()`) |
| `τ` | the task (`com.omni.pcst.master.task.Task`) |
| `Iₜ` | the information available at decision instant `t` |
| `Eresource` | the event the Step 6B capability estimator evaluates (`C`) |
| `Edeadline`, `Eenergy`, `EQoS`, `Estability` | the remaining success events |
| `R` | a probability in [0, 1], or `null` with an explicit status |

An event is part of the success contract **only when the task expresses the
corresponding requirement** (section 9: "Security or other requirements should be
added only when they are part of the task's success contract"). `Eresource` is
always part of the contract, possibly vacuously.

---

## 2. The one computable case, and the model gap

The current node model can evaluate exactly one event: `Eresource`, and only
through Step 6B capability, and only for network latency and packet-loss
conditions there. The engine enumerates every success event and reports how each
was resolved:

| Event | Required when | Current model |
|---|---|---|
| `Eresource` | always (vacuous when the task states no resource conditions) | via Step 6B capability |
| `Edeadline` | `TaskConstraints.deadlineEpochMillis != null` | **no completion-time model** |
| `Eenergy` | `TaskConstraints.minimumBatteryPercent != null` | **no energy/drain process model** |
| `EQoS` | `TaskConstraints.requiredExecutionProfile` present | **no QoS model** |
| `Estability` | `TaskConstraints.interruptionTolerance != null` | **no node-stability model** |

There is also no joint model across events. Consequently **a numerical `R` is
produced only when the task's entire success contract reduces to `Eresource`**,
i.e. the task expresses no deadline, battery minimum, QoS/compatibility target, or
interruption tolerance, and the capability estimate is `COMPUTABLE`. In that
single case the specification equation applies directly:

```
Esucc = Eresource        ⇒        R = C
```

This is the definition applied to a one-term intersection, **not** a relabelling
of capability: it is recorded with the distinct reason
`RESOURCE_EVENT_IS_ENTIRE_CONTRACT`, `derivedFromCapability == true`, and a
`derivation` string saying exactly why. In every other case the reliability is
`null` with an explicit status. A task that expresses no success events at all has
an empty intersection, which is vacuously true (`R = 1`, reason
`VACUOUS_SUCCESS_CONTRACT`), mirroring the capability stage's vacuous case.

### Why capability is not "copied"

`Eresource` **is** the capability event, so when the contract has no other term,
`R = C` is the equation, not an approximation. The engine refuses to reuse `C`
whenever a non-resource event is expressed or whenever capability is anything but
`COMPUTABLE` (partial, unsupported, insufficient evidence). Tests
`networkPlusDeadlineDoesNotReturnCapability`, `networkPlusBatteryDoesNotReturnCapability`,
`networkPlusQosTargetDoesNotReturnCapability`, `networkPlusInterruptionToleranceDoesNotReturnCapability`,
`partialCapabilityDoesNotProduceReliability` and `unsupportedCapabilityDoesNotProduceReliability`
pin this down.

---

## 3. No double counting, no added uncertainty penalty

Specification section 9.1 forbids

```
R = C × P(Edeadline) × P(Eenergy) × P(EQoS) × P(Estability)
```

unless a valid independence or conditional factorization on a **shared predictive
trajectory** is established. No such factorization exists here, and no code path
multiplies marginals. `Edeadline`, `Eenergy`, `EQoS`, `Estability` are reported as
unresolved rather than folded into a product.

Specification section 9.2 forbids adding a separate generic uncertainty penalty
when the uncertainty is already inside the predictive distribution. The engine
adds none: for a resource-only contract `R` equals the capability tail probability
exactly, and no entropy, variance, or "confidence" term is applied. Test
`reliabilityAppliesNoUncertaintyPenaltyBeyondTheCapabilityProbability` asserts
`R` equals `Φ((r−μ)/σ)` exactly for two spreads.

---

## 4. Relationship to the tolerance stages

The three stages stay separate and are ordered, never merged:

```
hard eligibility (6A)  →  capability C = P(Eresource) (6B)  →  reliability R (6C)
```

- A candidate with `eligible == false` is returned as
  `REJECTED_HARD_CONSTRAINT` with `reliability == null`. A favourable resource
  estimate never overturns a rejection.
- A **proven** violation (`reason.isIndeterminate() == false`) yields
  `HARD_CONSTRAINT_VIOLATION`; an **unproven** (indeterminate) exclusion yields
  `HARD_CONSTRAINT_INDETERMINATE`. They are distinguished, so "cannot do it" is
  never confused with "cannot tell yet".
- A candidate admitted despite unproven conditions (an admit-unproven policy) is
  `UNRESOLVED_MODEL` with `HARD_CONSTRAINT_INDETERMINATE`: an unproven condition is
  not evidence of success.
- The 6A `IndeterminatePolicy` is consumed, never changed.

---

## 5. Statuses, reasons, and precedence

`ReliabilityStatus`:

| Status | Meaning | `reliability()` |
|---|---|---|
| `COMPUTABLE` | the reliability is defined (resource-only contract only) | value in [0, 1] |
| `UNRESOLVED_MODEL` | some required event has a model, but not all / no joint model | `null` |
| `UNSUPPORTED_MODEL` | no required event has a model | `null` |
| `INSUFFICIENT_EVIDENCE` | modelled events but the capability evidence is unusable | `null` |
| `INVALID_INPUT` | missing/mismatched inputs, or malformed capability input | `null` |
| `REJECTED_HARD_CONSTRAINT` | excluded by a hard constraint | `null` |

Precedence (first match wins): null capability → `INVALID_INPUT`; node-identity
mismatch → `INVALID_INPUT`; hard rejection → `REJECTED_HARD_CONSTRAINT`; malformed
capability input → `INVALID_INPUT`; admitted-but-indeterminate → `UNRESOLVED_MODEL`;
capability `INSUFFICIENT_EVIDENCE` → `INSUFFICIENT_EVIDENCE`; all required events
computed → `COMPUTABLE`; some required event unmodelled → `UNRESOLVED_MODEL` (or
`UNSUPPORTED_MODEL` when none is modelled and none is partially modelled).

`ReliabilityReason` codes are the programmatic contract (e.g.
`NO_COMPLETION_TIME_MODEL`, `NO_ENERGY_PROCESS_MODEL`, `NO_QOS_MODEL`,
`NO_STABILITY_MODEL`, `RESOURCE_JOINT_MODEL_UNRESOLVED`, `MISSING_CAPABILITY_ASSESSMENT`,
`HARD_CONSTRAINT_VIOLATION`, `HARD_CONSTRAINT_INDETERMINATE`). Callers branch on
the enums, never on message text.

Invariants enforced in constructors: a non-`COMPUTABLE` status never carries a
number; a success event carries a probability exactly when its reason is
`COMPUTED`; an event is `required` exactly when it is not `EVENT_NOT_IN_CONTRACT`.

---

## 6. Inputs and integration

`ReliabilityInput` bundles the four things section 9 depends on: the task, the
candidate `DigitalTwinSnapshot`, the `NodeEligibilityResult` (or `null` when hard
filtering has not run), and the Step 6B `CapabilityAssessment`. The engine never
recomputes capability; it composes. `ReliabilityEngine.assess(ReliabilityInput)`
returns one assessment, and `assessAll(...)` returns one per distinct node ordered
by node id. The engine is stateless, reads only immutable inputs, and is
deterministic: identical inputs produce equal assessments.

---

## 7. Hand-calculated test values

Tolerance `1×10⁻⁶`:

| Quantity | Hand value |
|---|---|
| `Φ(2)` | `0.9772499` |
| `Φ(0.4)` | `0.6554217` |
| independence product `Φ(2)·Φ(2)` | `0.9550173` |

- `X ~ N(80, 10²)`, `r = 100` → `R = Φ(2) = 0.9772499` (resource-only latency).
- `X ~ N(1, 1²)`, `r = 3` → `R = Φ(2) = 0.9772499` (resource-only packet loss).
- `X ~ N(80, 50²)`, `r = 100` → `R = Φ(0.4) = 0.6554217` (no extra penalty).

---

## 8. Boundaries — what this step does not do

- No **scheduling, ranking, selection, dispatch, retries, or execution** (Step 6D).
- No new **Bayesian inference**, **predictor**, **weighted score**, or
  **threshold mapping**.
- No **product of marginals** and no **uncertainty penalty**.
- No fabricated `0`/`1`: a failed or unsupported estimate is `null`.
- The task model, hard-constraint policy, belief engine, telemetry, prediction
  stage, capability stage, and replay harness are consumed but **not modified**.

---

## 9. Files

Main (`pcst-master/src/main/java/com/omni/pcst/master/reliability/`):

| File | Responsibility |
|---|---|
| `ReliabilityEvent.java` | the five success events and their labels |
| `ReliabilityStatus.java` | assessment outcome |
| `ReliabilityReason.java` | stable diagnostic reason codes |
| `SuccessEventAssessment.java` | per-event result |
| `ReliabilityInput.java` | the four-field immutable input |
| `ReliabilityAssessment.java` | per-(task, node) result |
| `ReliabilityEngine.java` | `assess`, `assessAll` |

Tests (`pcst-master/src/test/java/com/omni/pcst/master/reliability/`):

| File | Tests |
|---|---|
| `ReliabilityEngineTest.java` | 24 |

---

## 10. Limitations

- Reliability is numerically computable only for resource-only contracts. This is
  a genuine model gap, not a finished reliability model. Any contract that
  expresses a deadline, energy, QoS, or stability requirement is reported as
  unresolved.
- Node stability is treated as part of the contract only when the task expresses
  an interruption tolerance. If the operational contract should **always** treat
  node stability (no crash/interruption) as a success condition, that is an open
  policy decision; it is not modelled today and would block every numeric `R`.
- `R = C` inherits every limitation of the capability stage: the belief-posterior
  persistence assumption, the 15 000 ms evidence-age approximation, and the fact
  that only network latency and packet loss are supported.
- The synthetic tests demonstrate internal consistency with the stated model. They
  do **not** constitute empirical validation of reliability calibration.

---

## 11. Verification

- Focused: `mvn -pl pcst-master test -Dtest=ReliabilityEngineTest` → **24 tests**,
  0 failures, 0 errors.
- Full reactor: `mvn test` from the repository root → **BUILD SUCCESS**.
  `pcst-master` **357 tests** (0 failures, 0 errors), `pcst-node-agent`
  **39 tests** (0 failures, 0 errors). The reliability package contributes the 24
  new tests; no pre-existing test changed and no pre-existing source file was
  modified.
