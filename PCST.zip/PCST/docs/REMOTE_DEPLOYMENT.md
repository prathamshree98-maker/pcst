# PCST Remote Deployment Guide

This guide covers deploying the PCST Master and Node Agents so that computers on
different networks can enroll and connect securely.

## Architecture overview

```
┌─────────────┐      HTTPS (443)      ┌──────────────────┐
│  Web browser│ ─────────────────────►│ Reverse proxy    │
│  (friend)   │                       │  (Caddy/Nginx)   │
└─────────────┘                       └────────┬─────────┘
                                              │ HTTP (8080)
                                              ▼
                                      ┌──────────────────┐
                                      │  PCST Master     │
                                      │  REST + gRPC     │
                                      │  (localhost:8080,│
                                      │   localhost:9090)│
                                      └────────┬─────────┘
                                       │ gRPC (9090)
                                       │ (TLS required for production)
                                               ▼
                                      ┌──────────────────┐
                                      │  Node Agent      │
                                      │  (friend's PC)   │
                                      └──────────────────┘
```

The Node Agent connects **outbound** to the Master's gRPC port. The Master does
not initiate connections to agents.

---

## Ports and connectivity

| Component | Port | Direction | Notes |
|-----------|------|-----------|-------|
| Master REST/dashboard | 8080 | Inbound (from reverse proxy) | Exposed via HTTPS reverse proxy on 443 |
| Master gRPC | 9090 | Inbound (from agents) | Agents connect outbound to this port |
| Agent task dispatch | 9091 | Inbound (from Master) | Master dispatches tasks to this port |

### Recommended exposure

- **Public internet**: Only port 443 (HTTPS via reverse proxy) for the dashboard
  and REST API.
- **Agent-to-Master**: Port 9090 (gRPC) must be reachable by agents. If agents
  are on different networks, either expose 9090 publicly (with TLS) or use a
  VPN/private network.
- **Master-to-agent**: Port 9091 is used by the Master to dispatch tasks to the
  agent; the agent listens locally. This does not need to be publicly exposed
  unless the Master is on a different network than the agent.

Do not expose more ports than necessary.

---

## Step 1: Provision certificates (Master TLS)

The Master gRPC server supports TLS. For production, generate a certificate and
private key:

```bash
# Example using OpenSSL (install OpenSSL first)
openssl req -x509 -newkey rsa:4096 -keyout server-key.pem \
  -out server-cert.pem -days 365 -nodes \
  -subj "/CN=pcst-master.example.com" \
  -addext "subjectAltName=DNS:pcst-master.example.com,DNS:localhost,IP:127.0.0.1"

# CA certificate (for agent trust store)
# If using a self-signed cert, the server-cert.pem itself is the trust anchor
cp server-cert.pem ca-cert.pem
```

- The certificate **hostname/SAN must match** the address agents use to connect
  (e.g. `pcst-master.example.com`, not `localhost`, if agents connect remotely).
- Never commit `server-key.pem` or production certificates to Git.

---

## Step 2: Configure the Master

Create a Master environment file (`pcst-master.env`):

```bash
# Master REST/dashboard port
server.port=8080

# Master gRPC port
grpc.server.port=9090

# TLS (production mode)
pcst.grpc.tls.mode=production
pcst.grpc.tls.cert-chain-file=/etc/pcst/tls/server-cert.pem
pcst.grpc.tls.private-key-file=/etc/pcst/tls/server-key.pem

# Administrator enrollment API key (set a strong, unique value)
pcst.admin.api-key=CHANGE-ME-STRONG-KEY

# Durable state persistence (recommended for production)
pcst.state.persistence.enabled=true
pcst.state.persistence.path=/var/lib/pcst/node-state.json
pcst.state.encryption.passphrase=CHANGE-ME-STRONG-PASSPHRASE
```

Start the Master:

```bash
java -jar pcst-master/target/pcst-master-1.0.0-SNAPSHOT.jar \
  --spring.config.additional-location=file:./pcst-master.env
```

Or set environment variables:

```bash
export PCST_ADMIN_API_KEY="CHANGE-ME-STRONG-KEY"
export PCST_STATE_ENCRYPTION_PASSPHRASE="CHANGE-ME-STRONG-PASSPHRASE"
java -jar pcst-master/target/pcst-master-1.0.0-SNAPSHOT.jar
```

---

## Step 3: Reverse proxy (HTTPS for dashboard and REST)

Place the Master behind Caddy or Nginx so browser traffic is encrypted.

### Caddy example (`Caddyfile`)

```caddy
pcst-master.example.com {
    reverse_proxy localhost:8080
}
```

Run: `caddy run` (Caddy automatically obtains a Let's Encrypt certificate).

### Nginx example

```nginx
server {
    listen 443 ssl;
    server_name pcst-master.example.com;

    ssl_certificate /etc/letsencrypt/live/pcst-master.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/pcst-master.example.com/privkey.pem;

    location / {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /api/v1/ {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
    }
}
```

The admin API (`/api/v1/admin/*`) is protected by bearer authentication even
when served over HTTPS. The admin key is **never** placed in frontend
JavaScript or proxy configuration.

---

## Step 4: Configure and run a Node Agent

On each friend's computer:

1. Install Java 21 or later.
2. Build the agent: `mvn -pl pcst-node-agent package`
3. Copy `pcst-agent.bat` (Windows) or `pcst-agent.sh` (Linux/macOS) and the
   shaded JAR to the friend's machine.
4. Create `config/pcst-agent.properties` from
   `config/pcst-agent.properties.example`.

### Windows agent (`pcst-agent.bat`)

```cmd
set PCST_MASTER_HOST=pcst-master.example.com
set PCST_MASTER_PORT=9090
set PCST_NODE_ID=friend-laptop-01
set PCST_GRPC_TLS_MODE=production
set PCST_GRPC_TLS_TRUST_CERT_COLLECTION_FILE=C:\pcst\ca-cert.pem
set PCST_PAIRING_CODE=<code-from-admin>
pcst-agent.bat
```

### Linux/macOS agent (`pcst-agent.sh`)

```bash
export PCST_MASTER_HOST=pcst-master.example.com
export PCST_MASTER_PORT=9090
export PCST_NODE_ID=friend-laptop-01
export PCST_GRPC_TLS_MODE=production
export PCST_GRPC_TLS_TRUST_CERT_COLLECTION_FILE=/home/user/pcst/ca-cert.pem
export PCST_PAIRING_CODE=<code-from-admin>
chmod +x pcst-agent.sh
./pcst-agent.sh
```

### Alternative: Java system properties

```bash
java -jar pcst-node-agent/target/pcst-node-agent-1.0.0-SNAPSHOT.jar \
  -Dpcst.master.host=pcst-master.example.com \
  -Dpcst.master.port=9090 \
  -Dpcst.node.id=friend-laptop-01 \
  -Dpcst.grpc.tls.mode=production \
  -Dpcst.grpc.tls.trust-cert-collection-file=/home/user/pcst/ca-cert.pem \
  -Dpcst.pairing.code=<code-from-admin>
```

---

## Step 5: Enroll a device

1. Administrator generates a pairing code:

```bash
curl -X POST https://pcst-master.example.com/api/v1/admin/pairing-codes \
  -H "Authorization: Bearer <admin-api-key>" \
  -H "Content-Type: application/json" \
  -d '{"nodeIdHint": "friend-laptop-01", "ttlMinutes": 10}'
```

2. Communicate the code to the device operator **out-of-band** (not over the
   same channel as the Master, e.g. a separate message).

3. Device operator runs the agent with `PCST_PAIRING_CODE=<code>`.

4. On first successful enrollment, the Master issues a device credential which
   the agent stores locally. On future runs, the agent uses
   `PCST_DEVICE_CREDENTIAL` instead of a pairing code.

---

## Step 6: Verify on the dashboard

Open `https://pcst-master.example.com/` in a browser. The "Nodes" page shows
registered nodes with real telemetry (CPU, memory, battery, network, etc.).

---

## Revoking a device

If a device should no longer be trusted, the administrator revokes its
credential:

```bash
curl -X DELETE https://pcst-master.example.com/api/v1/admin/nodes/<node-id>/device-credential \
  -H "Authorization: Bearer <admin-api-key>"
```

Revocation is persisted and survives a Master restart. The agent will be unable
to reconnect with the revoked credential.

---

## What remains unverified

- **Cross-machine testing**: This guide has not been validated against a real
  second computer on a different network. The operator should perform a local
  two-agent test first, then a cross-network test before relying on remote
  deployment.
- **Public CA certificates**: The examples use self-signed or Let's Encrypt
  certificates. Operators using an internal CA must ensure agents trust that CA.
