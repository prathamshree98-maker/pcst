# PCST Offline Replay Evaluation Harness (Step 5E.3)

An offline evaluation tool. It reads persisted `pcst-eval-v4` telemetry evaluation
records, reconstructs leakage-free prediction origins, runs the **existing**
resource predictors, and scores them against subsequently observed values.

It is **not** a new prediction algorithm, not a scheduler, and produces no
reliability, capability or calibration claim.

## What it evaluates

| Predictor | Notes |
|---|---|
| `PERSISTENCE` (`PersistenceResourcePredictor`) | Also **is** the naive reference baseline — its estimate is the newest valid in-window observation held constant. It is evaluated once and documented as the baseline rather than duplicated under a second name. |
| `TREND` (`TrendResourcePredictor`) | OLS linear-trend challenger. |

Resources are taken directly from the `ForecastableResource` enum: CPU utilization,
memory utilization, battery level, network latency, packet loss. Memory utilization
is derived only through the existing approved semantics (`used/total*100`, total
strictly positive). No value is ever fabricated.

## Running it

Build first:

```
mvn -pl pcst-master -am -DskipTests package
```

Then run the CLI:

```
java -cp "<pcst-master/target/classes>;<dependency classpath>" \
     com.omni.pcst.master.evaluation.replay.ReplayCli \
     --input  path/to/eval-telemetry.jsonl \
     --output replay-output \
     --horizons 30000,60000,300000 \
     --tolerance 10000 \
     --window 600000 \
     --min-observations 2
```

| Argument | Meaning | Default |
|---|---|---|
| `--input` | JSON Lines telemetry evaluation file (**read-only**) | required |
| `--output` | Output directory | `replay-output` |
| `--horizons` | Forecast horizons in ms, comma separated | `30000,60000,300000` |
| `--tolerance` | Target-matching tolerance in ms | `10000` |
| `--window` | Predictor observation window in ms (0 = all history) | `600000` |
| `--min-observations` | Minimum in-window observations required | `2` |
| `--help` | Usage message | |

To obtain the dependency classpath:

```
mvn -pl pcst-master dependency:build-classpath "-Dmdep.outputFile=cp.txt"
```

Outputs `replay-evaluation.json` and `replay-evaluation.md` into the output
directory. **The input file is never written, truncated or migrated.**

## Input eligibility

A record must satisfy **all** of the following to become scoring evidence:

1. Parses under the current `pcst-eval-v4` schema. v1/v2/v3 are reported as
   `UNSUPPORTED_SCHEMA_VERSION` and never reinterpreted.
2. `acceptedByDigitalTwin == true`.
3. `validForReplay == true` and `isScorableSample() == true`.
4. Has a non-null observation and a non-negative observation timestamp.
5. Is not a duplicate `(session, sequence)` or `(session, observationTimestamp)`.

Observations are grouped per `(nodeId, agentSessionId)`; two sessions of one node are
never merged. Records without a session form their own group.

Every excluded record is counted by reason — the report distinguishes **parsed**
from **eligible**, which are never conflated.

## Target matching and leakage prevention

At an origin with event time `t`:

- The predictor receives a `DigitalTwinSnapshot` whose history contains **only**
  observations with `observationTimestamp <= t` (newest-first, per the snapshot contract).
- The forecast is requested for `t + horizon`.
- The target is the first eligible observation in the **same node/session** that is
  strictly later than `t` and within `±tolerance` of `t + horizon`.

The target and all later observations are structurally unable to reach the predictor
input, so leakage is prevented by construction rather than by convention.

Where no valid target exists the opportunity is counted as unscorable with a reason
(`NO_TARGET_OBSERVATION`, `TARGET_VALUE_UNAVAILABLE`, `FORECAST_UNAVAILABLE`,
`INSUFFICIENT_HISTORY`) — predictions are never silently dropped, which would make a
weak predictor look strong.

## Metrics and units

For each (predictor, resource, horizon):

- **MAE** — mean absolute error, in the resource's native unit.
- **RMSE** — root mean squared error, same unit.
- **Bias** — mean signed error; positive means over-prediction.
- **Scored pairs**, **prediction opportunities**, **coverage**.

Units: `percent` for CPU/memory/battery/packet-loss, `milliseconds` for latency.

Deliberately **not** implemented:
- **MAPE** — undefined and explosive for resources that legitimately take the value
  zero (idle CPU, zero packet loss).
- **Any combined cross-resource score** — percentage points and milliseconds do not
  share a unit.

With zero scored pairs every metric renders as `null`, never `0.0`, so "no evidence"
is never displayed as "perfect prediction". Sums use Kahan compensated summation.

## Determinism

The report contains **no wall-clock time**. Resources, predictors, horizons, node
groups and diagnostic categories are emitted in a fixed order, and numbers use a
fixed locale and precision. The same input and configuration produce byte-identical
output. A content fingerprint over the evaluated observations is included so two
runs can be compared for equivalence.

## Interpreting results

Metrics measure **forecast error only**. They are not evidence of calibration,
reliability, capability or production readiness. A sequence gap is a discontinuity
in the *received* stream, not proof of permanent message loss.

## Synthetic example

On a synthetic CPU series rising exactly 1.0 per 1000 ms, with horizon 4000 ms:

| Predictor | MAE | Bias | Interpretation |
|---|---:|---:|---|
| PERSISTENCE | 4.000000 | -4.000000 | Hand-calculable: persistence holds the last value, so it under-predicts a rising series by exactly `horizon/step`. |
| TREND | 0.000000 | 0.000000 | OLS reproduces an exactly linear series. |

This is a property of a synthetic fixture, **not** a measurement of any real system.