# PCST Novelty Gate — Candidate A

**Subject:** Age-dependent predictive-variance inflation for reliability-based scheduling of heterogeneous compute nodes under drift.
**Verdict:** `INCONCLUSIVE` — evidence supports a plausible, defensible research contribution but novelty is **not established**. A full-text comparison against the closest prior work (below) shows the component pieces exist separately; whether their specific combination for heterogeneous compute-node scheduling is novel remains unverified until the distinguishing experiment is run and the literature gap is confirmed.
**Date:** 2026-10-27
**Constraint honoured:** No production code, scheduler behaviour, schema, or dependency was modified. No novelty claim is made.

---

## 1. Bibliographic references (full-text inspected unless noted)

### Directly inspected (full text)

| Ref | Citation | Link | How inspected |
|---|---|---|---|
| [NetKV] | M. A. Ojewale, “NetKV: Network-Aware Decode Instance Selection for Disaggregated LLM Inference,” arXiv:2606.03910v1 [cs.PF], 2 Jun 2026. | https://arxiv.org/abs/2606.03910 | Full HTML read (§I–§VII, Eq. 3–9, Prop. 1–2, Alg. 1, §VI experiments) |
| [LLMSched] | B. Zhu, C. Chen, X. Fan, Y. Zhu, “LLMSched: Uncertainty-Aware Workload Scheduling for Compound LLM Applications,” arXiv:2504.03444v2 [cs.DC], 7 Apr 2025, accepted ICDCS 2025. | https://arxiv.org/abs/2504.03444 | Full HTML read (§II–§VI, Eq. 1–6, Alg. 1, BN profiler, entropy-based quant.) |
| [TZOR25] | I. Tzortzis, E. Makridis, C. D. Charalambous, T. Charalambous, “Remote Estimation over Packet-Dropping Wireless Channels with Partial State Information,” arXiv:2505.01132v1 [eess.SY], 2 May 2025. | https://arxiv.org/abs/2505.01132 | Full HTML read (§I–§VI, Eq. 1–10, POMDP, Kalman remote estimator, Eq. 10 staleness covariance growth) |
| [CHANG23] | T. Chang, X. Cao, W. X. Zheng, “A Lightweight Sensor Scheduler Based on AoI Function for Remote State Estimation over Lossy Wireless Channels,” arXiv:2308.07127v2 [eess.SY], 30 Aug 2023. | https://arxiv.org/abs/2308.07127 | Full HTML read (§II–§III, Eq. 1–14, tight scalar upper bound, Whittle index Eq. 34, threshold policy) |
| [Kaal16] | S. Kaul, R. Yates, M. Gruteser, “Real-Time Status: How Fresh Is Your Data?,” (AoI foundational) | Identified via search, abstract only | Not full-text inspected |
| [SamplingWiener17] | “Sampling of the Wiener Process for Remote Estimation over a Channel with Random Delay,” arXiv:1707.02531v7 | Identified via search, abstract only | Not full-text inspected |
| [OUBeyond19] | “Sampling and Remote Estimation for the Ornstein-Uhlenbeck Process through Queues: Age of Information and Beyond,” arXiv:1902.03552v4 | Identified via search, abstract only | Not full-text inspected |

### Not inspected (leads from citation chaining / reference lists)

- [TZOR25] references: [11] K. You, M. Fu, L. Xie, “Mean square stability for Kalman filtering with Markovian packet losses,” Automatica 2011; [12] Y. Qi, P. Cheng, J. Chen, “Optimal sensor data scheduling for remote estimation over a time-varying channel,” IEEE Trans. Autom. Control 2016; [13] K. Huang et al., “Real-time remote estimation with hybrid ARQ,” IEEE Trans. Wireless Commun. 2020; [10] T. Soleymani, J. S. Baras, D. Gündüz, “Transmit or retransmit,” IEEE Trans. Inf. Theory 2024.
- [CHANG23] references: [19] S. Kaul et al. AoI; [20] Whittle-index policy; [5] Wang et al. AoI-function-based Whittle index; [26] AoI-function from estimation error.
- [NetKV] references: [3] Mooncake (cache+load, no network); [1] DistServe; [4] Dynamo; [5] llm-d; [18] GORGO (geo KV reuse + network).
- [LLMSched] references: [13] Decima, [20] Carbyne, [22] Argus — DAG scheduling under uncertainty.

---

## 2. What each inspected paper actually does (model, equations, assumptions, objective)

### [NetKV] arXiv:2606.03910 — decode-instance selection, stale *network-congestion* telemetry
- **System:** Disaggregated LLM inference; prefill pool → decode pool over a fat-tree. Request r completes prefill on instance p; scheduler picks decode instance d.
- **Model:** Transfer time `T_transfer(p,d,s) = s / B_eff(p,d) + L_tau(p,d)` (Eq. 3), where `B_eff = B_tau · (1 − c_tau) / (1 + n_inflight^tau(p))` (Eq. 4). Static tier bandwidth B_tau, dynamic congestion c_tau (refreshed every Δ_oracle ≥ 1 s), self-contention counter.
- **Objective:** Minimise `T_transfer + T_queue + T_decode` (Eq. 5) → minimise TTFT. Not a probability of success; a latency cost.
- **Staleness treatment:** Explicit. Prop. 2 (Eq. 9) bounds staleness error `epsilon` under which tier ranking is preserved: `epsilon < (B_tau(1−c_tau*) − B_tau’(1−c_tau’*) / (B_tau + B_tau’)`. Rankings robust to stale congestion telemetry *within a bound*.
- **Uncertainty propagation:** None into a probability. Congestion is a point estimate used in a deterministic latency cost. No Bayesian belief, no predictive variance, no reliability probability, no task-conditioned horizon.
- **Scheduling decision:** Greedy min-cost per request (Alg. 1), O(|D|). Tier rankings robust to stale telemetry — but this is *robustness of a deterministic ranking*, not *age-dependent variance inflation into a probabilistic success estimate*.
- **Basis:** 64-GPU fat-tree simulator, Mooncake traces. Baseline: round-robin, load-aware, cache-aware, cache+load-aware (CLA*), NetKV-Static.

### [LLMSched] arXiv:2504.03444 — DAG scheduling under duration/structural uncertainty
- **System:** Compound LLM applications as DAGs; jobs arrive online; schedule stages on LLM/regular executors to minimise average JCT.
- **Model:** DAG with regular / LLM / dynamic stages. Bayesian-network profiler learns conditional duration distributions; entropy-based uncertainty quantification (Eq. 3–6). `R(X) = I(Y1..YM; X | E) × sum Range(Ym)` (Eq. 6).
- **Objective:** Minimise average job completion time (JCT).
- **Staleness treatment:** None. Uncertainty is about *job duration and DAG structure*, not observation age. No telemetry staleness, no process noise, no age-to-variance mapping.
- **Uncertainty propagation:** Entropy / mutual information used for exploration-exploitation (epsilon-greedy) scheduling; not propagated into a per-node success probability.
- **Scheduling decision:** Uncertainty-aware scheduler combining uncertainty reduction with SRTF via epsilon-greedy (Alg. 1).
- **Basis:** Simulation + testbed (H800, Llama2-7B, vLLM). Baselines: SJF, Decima, Argus, Carbyne, FCFS, Fair.

### [TZOR25] arXiv:2505.01132 — remote state estimation, AoI → estimation-error covariance
- **System:** LTI plant `x_k = A x_{k-1} + w_k`, smart sensor runs local Kalman filter, transmits estimate or retransmits over packet-dropping channel with HARQ/ARQ.
- **Model:** Remote estimation error covariance grows with staleness: `P_k = A^{s^r_k} P^{s}_{k-s^r_k}(A^{s^r_k})^T + sum_{j=0}^{s^r_k-1} A^j R_w (A^j)^T` (Eq. 10), where `s^r_k` is AoI (steps since last successful reception). Cost `c_k = Tr(P_k) + energy` (Eq. 22).
- **Objective:** Minimise long-term mean-squared error + energy via finite-horizon POMDP (Eq. 23–24), solved by point-based value iteration.
- **Staleness treatment:** Central. AoI directly drives estimation-error covariance growth via process noise `R_w` accumulated over `s^r_k` steps (Eq. 10).
- **Uncertainty propagation:** Estimation-error covariance is the state; belief over channel state (π_k) is separate. Not a scheduling decision across heterogeneous compute nodes; it is a *transmit/retransmit* decision for a single sensor.
- **Basis:** Numerical experiments (2-state Markov channel, LTI A, Kalman filter). Baselines: HARQ vs ARQ.

### [CHANG23] arXiv:2308.07127 — AoI-function sensor scheduling, tight error upper bound
- **System:** N heterogeneous LTI plants, M sensors can transmit per step over lossy channels. Remote estimator covariance grows with AoI.
- **Model:** `P_i(t) = A_i^{Δ_i(t)} Pbar_i (A_i^T)^{Δ_i(t)} + sum_{k=0}^{Δ_i(t)-1} A_i^k Q_i (A_i^T)^k` (Eq. 12). Tight scalar upper bound `f_i(Δ) = β_i · α_i^Δ` where `α_i = ρ^2(A_i)` (Eq. 14–16).
- **Objective:** Minimise long-term average `sum Tr(P_i(t))` (Eq. 13a).
- **Staleness treatment:** Central. AoI is the state; estimation error upper bound grows exponentially with AoI.
- **Uncertainty propagation:** Scalar AoI function upper-bounds error; Whittle index (Eq. 34) induces a threshold policy. Not a probabilistic success estimate; not reliability-based scheduling; not heterogeneous compute nodes.
- **Scheduling decision:** Whittle-index threshold policy: schedule sensor i if `Δ_i(t) < Δ_{i,th}`.
- **Basis:** Simulation. Baselines: existing AoI-based and remote-estimation schedulers.

---

## 3. Comparison table — overlap vs genuine difference

| Dimension | PCST proposed (Candidate A) | [NetKV] | [LLMSched] | [TZOR25] | [CHANG23] | Genuine difference for PCST? |
|---|---|---|---|---|---|---|
| Domain | Heterogeneous compute-node scheduling | Disaggregated LLM decode-instance selection | Compound LLM DAG scheduling | Remote state estimation (single sensor) | Multi-sensor remote estimation | PCST target (compute-node task scheduling) is distinct from all four domains |
| Scheduling objective | Maximise `P(task success)` = reliability `R(n,τ)` | Minimise TTFT (latency cost) | Minimise average JCT | Minimise MSE + energy | Minimise avg `Tr(P_i)` | PCST optimises a *probability of success*, not latency/MSE/JCT |
| Uncertainty representation | Bayesian posterior variance + age-dependent process-noise inflation → predictive distribution | Point-estimate congestion `c_tau`; no variance | Entropy / mutual information over duration DAG | Remote estimation-error covariance `P_k` | Scalar AoI upper bound `f_i(Δ)` | PCST propagates age into a *predictive variance used in a reliability probability*; others use point costs or covariance as state |
| Staleness handling | Telemetry age grows predictive variance before computing `P(X ≤ r)` | Stale congestion bounded by Prop. 2 for tier ranking | None (duration uncertainty, not age) | AoI → covariance growth via process noise (Eq. 10) | AoI → exponential error upper bound (Eq. 12) | PCST's *variance inflation into a tail-probability reliability* is closer to [TZOR25]/[CHANG23] than to [NetKV]/[LLMSched], but applied to *scheduling heterogeneous compute nodes* rather than *remote estimation/transmit decisions* |
| Task-conditioned horizon | Predictive law over `[t, t+H]` per task | Per-request transfer; no task horizon | DAG stage scheduling; no per-task horizon | Single-step transmit decision | Per-step sensor scheduling | PCST's task-conditioned execution interval is a distinguishing element, but remote-estimation literature already conditions on time steps |
| Heterogeneous nodes | Heterogeneous compute nodes (CPU/memory/battery/latency) | Homogeneous GPU decode pool (tiers by network) | Heterogeneous executors (LLM vs regular) | Single plant/sensor | Heterogeneous plants (A_i, Q_i differ) | Heterogeneity exists in [CHANG23] (plants differ) but as remote-estimation systems, not compute nodes |
| Decision type | Select feasible node with max reliability | Greedy min-cost decode instance | Epsilon-greedy stage scheduling | Transmit/retransmit (POMDP) | Whittle-index threshold | PCST is node-selection for task placement; closest structurally to [NetKV] node selection, but [NetKV] is latency not reliability |
| Validation | (proposed) synthetic drifted telemetry, calibration/Brier | Simulator, Mooncake traces | Simulator + testbed | Numerical (Kalman, Markov channel) | Simulation | PCST has no executed validation yet |

**Key finding:** The *individual mechanisms* (age → estimation-error growth [TZOR25, CHANG23], stale-telemetry robustness [NetKV], uncertainty-aware scheduling [LLMSched]) are **already known**. What is not established is whether the *specific combination* — age-dependent predictive-variance inflation fed into a probabilistic *reliability-based node-selection* decision for *heterogeneous compute nodes* — is novel or yields a meaningfully new scheduling result. None of the four inspected papers does exactly this.

---

## 4. What is already known about age-dependent uncertainty / state-estimation error

1. **Age → estimation-error growth is canonical.** [TZOR25] Eq. 10 and [CHANG23] Eq. 12 both show that remote estimation error covariance grows deterministically with AoI under process noise (`R_w`, `Q_i`) accumulated over the staleness interval. This is standard Kalman/Bayesian filtering theory, not novel.
2. **Stale telemetry can be tolerated within bounds.** [NetKV] Prop. 2 gives a closed-form staleness-tolerance bound for tier ranking. This addresses staleness but as a *robustness property of a deterministic ranking*, not as variance inflation into a probability.
3. **Uncertainty-aware scheduling exists.** [LLMSched] uses entropy/mutual information for exploration-exploitation; [CHANG23] uses a Whittle index from an AoI error upper bound. Both schedule under uncertainty but optimise JCT/MSE, not a calibrated success probability.
4. **The mapping from age to a *predictive variance* used in a *tail-probability reliability* for *node selection* is not present in any inspected paper.** This is the narrow gap PCST Candidate A would target.

**Is it merely a Kalman/Bayesian filtering adaptation?** The age → variance growth step (predict `P_{k|k-1} = A P A^T + Q` over the staleness interval) is textbook Kalman prediction. The *operational use* — feeding that inflated variance into `P(X ≤ r)` as a reliability estimate for scheduling heterogeneous compute nodes — is not, by itself, demonstrably novel from the inspected literature. A reviewer could reasonably characterize Candidate A as "apply standard remote-estimation staleness covariance growth to a scheduling reliability estimate." The burden is on PCST to show the combination yields a *meaningful new scheduling result* (better calibrated decisions / higher success rate under drift) that the baselines do not achieve.

---

## 5. Limitations of the literature search and uninspected papers

- **Search scope:** arXiv API keyword queries only (`"age of information"`, `"remote state estimation"`, `"stale"`, `"process noise"`, `"estimation error"`, `"stale telemetry"`). Not a systematic review; no IEEE/ACM digital library, no Google Scholar, no forward/backward citation chasing beyond one hop from the four inspected papers' reference lists.
- **Full text not inspected:** [Kaal16] (AoI foundational), [SamplingWiener17], [OUBeyond19], and all papers cited within [TZOR25]/[CHANG23]/[NetKV]/[LLMSched] reference lists (e.g., You et al. 2011, Qi et al. 2016, Huang et al. 2020, Soleymani et al. 2024, Decima, Carbyne, Argus, GORGO, Mooncake). Any of these could contain a closer overlap.
- **Domain bias:** Inspected papers cluster in networked control / remote estimation (eess.SY) and LLM serving (cs.DC/cs.PF). General distributed-systems / cluster scheduling literature (e.g., Kubernetes/Nomad research, chance-constrained cluster scheduling) was not examined.
- **Recency bias:** Search returns weighted toward 2023–2026; older canonical work may be under-represented.
- **No full-text access to paywalled journal versions** where they exist (e.g., ICDCS 2025 proceedings for LLMSched).

**Papers whose full text could not be inspected and may overlap:** all items in the "Not inspected" lists above, especially [TZOR25]'s references [10]–[13] (remote estimation scheduling over lossy channels) and [CHANG23]'s references [5], [20], [26] (AoI-function scheduling from estimation error).

---

## 6. Verdict

`INCONCLUSIVE`

The component mechanisms are established; the specific combination is not confirmed novel. PCST Candidate A is **not yet defensible as a standalone paper contribution** without:
1. A deeper literature sweep (cluster scheduling, chance-constrained scheduling, distributed-systems venues) beyond the inspected set, and
2. An executed distinguishing experiment showing the combination yields a measurable scheduling result that the closest prior work does not.

---

## 7. Narrowed, defensible contribution statement (if warranted)

*Conditional on the experiment below passing and the literature gap holding:*

> "We show that propagating telemetry age as process-noise-driven predictive-variance inflation into a reliability-based node-selection policy improves calibrated task-success probability under non-stationary node conditions, compared to a persistence-assumption reliability scheduler and to stale-telemetry-robust deterministic baselines, on heterogeneous compute nodes. We isolate the variance-inflation mechanism from a simple staleness gate via ablation."

This is deliberately narrow: it claims an *empirical scheduling result under drift*, not a new estimation theory (Kalman prediction over staleness is standard) and not a new scheduling domain.

---

## 8. Minimum experiment that could distinguish PCST from closest prior work

**Closest prior work to beat:** current PCST persistence-assumption scheduler (T0), RoundRobin, LeastLoaded/CapabilityBased, plus (conceptually) [NetKV]-style staleness-robust deterministic ranking and [CHANG23]/[TZOR25]-style age→error growth. Since [NetKV]/[CHANG23]/[TZOR25] are in different domains, the direct experimental comparison is within PCST's own baseline family; the literature comparison is conceptual.

**Design:**
1. **Trace:** Synthetic heterogeneous-node telemetry with controlled drift (latency or battery trending over a decision epoch), generated by the existing `TelemetrySimulator`/`BenchmarkRunner` (`pcst-master/src/test/java/.../benchmark/`).
2. **Treatments:**
   - T0: current PCST (persistence assumption, no age term)
   - T1: PCST + age-dependent predictive-variance inflation (process noise accumulated over `decisionInstant − measurementTimestamp`), reliability from inflated variance
   - T2: RoundRobin; T3: LeastLoaded/CapabilityBased
   - T1a (ablation): age used only as a staleness gate, no variance inflation — isolates the mapping from the gate
   - T1b (oracle): true state known — upper bound
3. **Workload:** Resource-only tasks (latency ceiling / packet-loss ceiling) so `R` is computable today, with injected drift making the latest measurement a biased predictor of the execution-interval value.
4. **Metrics (spec §13.2):** Task success rate; calibration (Brier score / reliability diagram of predicted `R` vs observed success); deferral rate; fallback rate; scheduler decision latency.
5. **Falsification rule:** T1 must achieve both (a) lower Brier score / better calibration than T0 and (b) equal-or-higher success rate at equal-or-lower deferral+fallback rate. If not, the hypothesis is falsified for this trace class.
6. **Reproducibility:** deterministic traces, fixed seeds, CSV/JSON output matching the existing harness format; single JVM, modest CPU/time.

**CPU/time:** modest — synthetic traces, in-memory, no live multi-agent processes (already shown infeasible in this environment).

---

## 9. Extended literature review (Part A)

Beyond the four full-text inspections in §1, the following peer-reviewed sources were inspected or identified via reference-list chaining from NetKV, LLMSched, Tzortzis et al., and Chang et al.

### Full-text inspected (additional)

| Ref | Citation | Link | Relevance |
|---|---|---|---|
| [KRIO21] | S. Kriouile, M. Assaad, “Minimizing the Age of Incorrect Information for Real-time Tracking of Markov Remote Sources,” arXiv:2102.03245v1 [cs.IT], 5 Feb 2021. | https://arxiv.org/abs/2102.03245 | **Strongest direct prior to Candidate A.** Central scheduler tracks multiple remote Markov sources; belief = probability last received update is still correct; Mean Age of Incorrect Information (MAoII) grows with staleness while the estimate is incorrect; Whittle-index threshold policy. Belief evolves: scheduled+success → p_i (reset); else π_i(t)·p_i + r_i·(1−π_i(t)) (decays). MAoII is a penalty, not a success probability; domain is remote source tracking, not compute-node scheduling. |
| [BADER23] | J. Bader et al., “Lotaru: Locally Predicting Workflow Task Runtimes for Resource Management on Heterogeneous Infrastructures,” Future Generation Computer Systems, arXiv:2309.06918v1 [cs.DC], 13 Sep 2023. | https://arxiv.org/abs/2309.06918 | Bayesian linear regression for task runtime prediction on heterogeneous clusters; provides uncertainty bounds (lower/upper confidence). Predicts runtime, not task-success reliability; no staleness/telemetry-age model; no scheduling decision under stale telemetry. |
| [FU22] | B. Fu et al., “Robust Task Scheduling for Heterogeneous Robot Teams under Capability Uncertainty,” arXiv:2106.12111v3 [cs.RO], 13 Nov 2022. | https://arxiv.org/abs/2106.12111 | Stochastic mixed-integer program; agent capabilities as random vectors; task requirement as binary function; CVaR risk minimization to maximize P(capability ≥ requirement). Heterogeneous teaming + risk-aware scheduling, but a one-shot MIP (no online staleness, no telemetry age, no Bayesian belief over time). |

### Identified via reference lists (not full-text inspected)

From [TZOR25] references: [11] K. You, M. Fu, L. Xie, “Mean square stability for Kalman filtering with Markovian packet losses,” Automatica 2011; [12] Y. Qi, P. Cheng, J. Chen, “Optimal sensor data scheduling for remote estimation over a time-varying channel,” IEEE Trans. Autom. Control 2016; [13] K. Huang et al., “Real-time remote estimation with hybrid ARQ,” IEEE Trans. Wireless Commun. 2020; [10] T. Soleymani, J. S. Baras, D. Gündüz, “Transmit or retransmit,” IEEE Trans. Inf. Theory 2024.

From [CHANG23] references: [5] Wang et al., AoI-function-based Whittle index for multi-sensor scheduling; [20] Whittle-index policy; [26] AoI function derived from remote estimation error.

From [KRIO21] / AoII lineage: [8] original AoII introduction; [9] AoII over unreliable channel; AoII overview papers (2022–2026).

### What is already known (age → uncertainty → scheduling)

1. **Age → incorrectness/error growth is canonical and published.** [KRIO21] Lemma 1–2 and MAoII (Eq. 3, 5, 17) show the probability-that-information-is-correct decays with staleness under Markov state evolution, and the penalty grows as a function of time-since-last-correct-update. [TZOR25] Eq. 10 and [CHANG23] Eq. 12 show the same for Kalman estimation-error covariance under process noise. This is the *core mechanism* of Candidate A (staleness → growing uncertainty), and it is already published.
2. **Threshold/Whittle-index scheduling on staleness-based belief is published.** [KRIO21] Theorem 1–2 and [CHANG23] Theorem 1–2 derive indexable threshold policies (schedule when AoI/uncertainty exceeds a threshold) using Whittle's index. This is the *decision rule* shape Candidate A would use.
3. **Heterogeneous capability/risk scheduling is published.** [FU22] maximizes P(capability ≥ requirement) under stochastic agent capabilities via CVaR. [BADER23] provides Bayesian uncertainty bounds for heterogeneous-cluster runtime prediction.

### What is NOT established as prior (narrow PCST-specific gap)

None of the inspected papers combines all of:
- (a) a **Gaussian Bayesian posterior** over a continuous resource value,
- (b) **process-noise / age-dependent variance inflation** of the predictive distribution,
- (c) feeding that inflated variance into a **tail-probability reliability** `P(X ≤ r)`,
- (d) used as the **ranking value** for **heterogeneous compute-node task selection**,
- (e) evaluated as a **calibrated success probability** (Brier/reliability diagram).

So the *mechanism family* is published (AoII / remote estimation), but the *specific formulation* for compute-node scheduling reliability is not confirmed either way. The burden is on PCST to show the combination yields a measurable scheduling result not captured by the AoII/Whittle-index literature.

### Revised comparison table (added rows)

| Dimension | PCST Candidate A | [KRIO21] AoII | [BADER23] Lotaru | [FU22] CTAS |
|---|---|---|---|---|
| Core mechanism | Age → variance inflation → P(X≤r) reliability | Age → belief-decay → MAoII penalty → Whittle threshold | Bayesian regression → runtime + uncertainty bound | Stochastic capability → CVaR → P(cap≥req) |
| Staleness→uncertainty | Yes (proposed) | Yes (belief π decays with staleness) | No | No |
| Scheduling objective | Maximize P(task success) | Minimize MAoII | Minimize runtime prediction error | Minimize energy+time+CVaR risk |
| Domain | Heterogeneous compute-node scheduling | Remote source tracking (Markov) | Scientific workflow runtime on clusters | Heterogeneous robot teaming |
| Published? | Proposed, not evaluated | **Published (2021)** | Published (2023) | Published (2022) |

### Verdict (Part A)

Still `INCONCLUSIVE`, but the evidence now leans strongly toward **significant prior overlap**: [KRIO21] AoII already publishes the staleness→belief-decay→threshold-scheduling mechanism that is the heart of Candidate A. PCST's differentiating claim would have to rest on (i) the Gaussian-tail-probability reliability formulation for compute nodes and (ii) an executed experiment showing it outperforms baselines under drift. Until that experiment runs and a deeper venue search (IEEE/ACM cluster-scheduling, chance-constrained scheduling) is done, novelty is not established and a "TOO CLOSE" verdict remains possible.

## 10. Experiment-path audit (Part B)

Audited the existing test-side benchmark harness (`pcst-master/src/test/java/com/omni/pcst/master/benchmark/`) and the scheduler implementations. No code was created or modified.

### Harness capabilities (what runs locally now)

`BenchmarkRunner.run()` (in `BenchmarkRunner.java`) is a deterministic, policy-only comparator:
- Generates telemetry per node from `NodeModel` true state via `TelemetrySimulator` (Gaussian noise, configurable staleness, missing fields).
- Updates Bayesian beliefs per node from full observation history.
- Builds identical `SchedulingCandidate` sets (eligibility + capability + reliability pre-computed once, shared by all schedulers) — **fair policy-level comparison; no scheduler receives more information.**
- Runs `PCSTScheduler`, `BenchmarkRoundRobinScheduler`, `CapabilityBasedScheduler`, `CpuLeastLoadedScheduler`, `OracleScheduler` via `select()` on the same candidate set each task.
- Records `SchedulingResult` per (scheduler, task): status, selected node, predicted reliability, feasibleNodeFound, taskSucceeded/taskFailed (ground truth from true state on the selected node), true values on selected node.
- Advances node state by one tick (deterministic drift).
- Reproducible via `Builder.seed(...)`; seed reproducibility verified by `BenchmarkCorrectnessTest`.

| Treatment | Status | Evidence |
|---|---|---|
| 1. Current PCST | ✅ runs | `PCSTScheduler(SchedulingPolicyConfig.none())` via `select()` |
| 2. Age-aware PCST variant | ❌ not implemented | No age-to-variance-inflation code exists (per constraints, not added) |
| 3. Round Robin with persistent rotation | ✅ runs | `BenchmarkRoundRobinScheduler` holds `rotationOrder` + `nextIndex` across calls |
| 4. Independent Least-Loaded | ✅ runs | `CpuLeastLoadedScheduler` (observed CPU load, missing = worst load) |
| 5. Age-gate-only ablation | ❌ not implemented | No age-gate variant exists |
| 6. Oracle reference | ✅ runs | `OracleScheduler` inspects true state (reference arm only) |

### Fairness checks (verified by code inspection)

- **Same pre-generated scenario & telemetry history:** Yes — one `TelemetrySimulator`/`TaskGenerator` per seed; all schedulers act on identical snapshots each task.
- **Isolated mutable state:** Yes — each scheduler is a separate instance; RR rotation state is per-instance; PCST/capability/reliability engines are stateless per call.
- **Ground-truth success per assignment:** Yes — `taskSucceeded`/`taskFailed` derived from true state on the selected node; unfinished (no selection) not counted as success/failure (enforced by test).
- **Ground truth for non-assignment:** ❌ No — `SchedulingResult` only records true state for the *selected* node. Counterfactual outcomes for unselected nodes are not recorded → **selection bias** (spec §13.4) cannot be corrected from harness output alone.
- **Brier score:** ❌ Not computed by the harness. `SchedulingResult` carries `predictedReliability` and `taskSucceeded`, so Brier = mean((p − 1{success})²) over *selected* tasks *can* be computed post-hoc from output, but only on selected tasks (biased). No automatic aggregation.

### Gaps to fill (test-only, no production change; not yet implemented)

1. **Age-aware PCST variant** and **age-gate-only ablation** — would need to be added as test-only scheduler variants in the benchmark package (or a separate test comparator), since production code cannot be changed per constraints.
2. **Output emission** — harness returns in-memory `List<SchedulingResult>`; no CSV/JSON file writing. A test/main would be needed to emit per-task CSV/JSON.
3. **Aggregate metrics** — success rate, deferral rate, Brier score, reliability diagram bins are not computed by the harness; would be post-processing of output.
4. **Selection-bias handling** — no counterfactual recording for unselected nodes; mitigable only by reporting selected-task Brier with the bias caveat, or by a controlled-exploration arm (not present).

### Executability on Windows

- Available: JDK 21, Maven 3.9.x (per `docs/PROJECT_CONTEXT.md` and `pom.xml`).
- No new dependencies needed; benchmark uses only existing project classes + JUnit.
- Exact command to run existing benchmark correctness suite:
  ```
  mvn -pl pcst-master test -Dtest=BenchmarkCorrectnessTest
  ```
  (run from repository root `C:\Users\Pratham\Desktop\PCST`). The full reactor `mvn -pl pcst-master test` also passes (benchmark tests included in the 452-test count).
- To produce CSV/JSON + aggregate metrics, a new test class or `main` would need to be added under `pcst-master/src/test/java/com/omni/pcst/master/benchmark/` that iterates `new BenchmarkRunner.Builder()...build().run()`, writes `SchedulingResult` fields to CSV/JSON, and computes success rate / deferral rate / Brier over selected tasks with fixed seeds. That code does not exist yet and is not added by this audit.

### Bottom line for the go/no-go decision

The harness can already run a fair, deterministic, seed-reproducible comparison of current PCST vs RoundRobin vs LeastLoaded vs Oracle with ground-truth outcomes. It cannot yet run the age-aware variant or age-gate ablation (not implemented), does not emit files or aggregate metrics, and cannot remove selection bias. If the literature gap (Part A) holds, the smallest next step is a **test-only experimental prototype**: add the two PCST variants + CSV/JSON emission + aggregate metrics to the existing benchmark package, run with drifted telemetry, and apply the falsification rule from §8. No production code or new simulator is required for that step.

**No implementation is authorized by this memo.** Stop here unless the extended literature review confirms the gap and the experiment prototype is approved.
