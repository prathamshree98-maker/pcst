# PCST Scheduling Policy

Step 6D of PCST: a deterministic, explainable scheduling decision engine that selects
the feasible node with the highest modelled completion reliability. It composes the
Step 6A hard-constraint filter, Step 6B capability estimator, and Step 6C reliability
estimator, and applies the approved scheduling policy to their results.

---

## 1. Approved Scheduling Objective

Specification section 10.1 and Appendix A define the V1 decision rule:

```
n* = arg max R(n, τ)   over n ∈ Fₜ(τ)
```

subject to `R(n*, τ) ≥ θτ`, where:

- `Fₜ(τ)` = feasible set = nodes passing **every** hard eligibility predicate for task τ
  at decision time `t` (Step 6A).
- `R(n, τ)` = completion reliability = `P(Esucc | Iₜ, assignment τ → n)` (Step 6C).
- `θτ` = per-task policy threshold, possibly task-class-specific (specification section 19).

If `Fₜ(τ) = ∅`, the outcome is `NO_FEASIBLE_NODE`. If candidates exist but every
defined reliability is below `θτ`, the outcome is `DEFER_OR_REJECT`. If eligible
candidates exist but none has a defined reliability estimate, the outcome is
`NO_SELECTION_UNRESOLVED` unless an explicit `FallbackPolicy` is configured.

**This is a greedy, one-decision-epoch, maximum-modelled-reliability policy.**
It is explicitly **not** a globally optimal multi-task POMDP policy, and a selection
is not a guarantee of success (specification sections 6.4 and 10.2).

---

## 2. Candidate Eligibility Flow

The scheduler operates on a strict, ordered pipeline:

```
Task + candidate snapshots
        │
        ▼
Hard-constraint filter (Step 6A) → NodeEligibilityResult per candidate
        │
        ├─→ INELIGIBLE → excluded from ranking (disposition: EXCLUDED_HARD_CONSTRAINT)
        │                 reliability estimate never overrides ineligibility
        │
        ▼
Capability estimation (Step 6B) → CapabilityAssessment per eligible candidate
        │
        ▼
Reliability estimation (Step 6C) → ReliabilityAssessment per eligible candidate
        │
        ▼
Policy decision (Step 6D)
        │
        ├─→ candidates with defined R → ranked by R, highest wins
        │     tie → lowest node id (deterministic)
        │     threshold θτ → must meet or exceed
        │
        ├─→ candidates without defined R → not ranked, not treated as 0/1
        │
        └─→ explicit outcome: SELECTED / DEFER_OR_REJECT / NO_SELECTION_UNRESOLVED / FALLBACK_SELECTED
```

---

## 3. How Capability and Reliability Are Consumed

| Stage | Input | Output | Role in scheduling |
|-------|-------|--------|-------------------|
| **6A Hard filter** | Task, `DigitalTwinSnapshot` | `NodeEligibilityResult` (eligible/indeterminate/rejected) | **Gatekeeper** — only eligible candidates proceed |
| **6B Capability** | Task, `DigitalTwinSnapshot` | `CapabilityAssessment` (probability `C` or null with status) | Estimates `P(Eresource)`; appears in trace, **never used as ranking value** |
| **6C Reliability** | Task, snapshot, eligibility, capability | `ReliabilityAssessment` (probability `R` or null with status) | **Ranking value** — only `COMPUTABLE` reliability is ranked |

### Key invariants

- **No double counting**: `Eresource` is evaluated once in capability. The reliability engine
  reuses it (`R = C`) only when the success contract reduces to `Eresource` alone.
  It never forms `C × P(Edeadline) × …` (specification section 9.1).
- **No uncertainty penalty**: The reliability equals the capability tail probability
  exactly when the contract is resource-only; no entropy, variance, or "confidence"
  term is applied (specification section 9.2).
- **No capability-for-reliability substitution**: Capability is reported in the trace
  but is never the ranking metric. A candidate with high capability but unresolved
  reliability is not ranked.

---

## 4. Treatment of Unresolved Reliability

The current model can compute a numerical `R` **only** when the task's entire success
contract reduces to `Eresource` (network latency and/or packet loss only). In every
other case (deadline, battery, QoS, stability expressed, or capability unresolved),
`R` is `null` with an explicit status.

**Guardrails enforced:**

- An unresolved reliability is **never** treated as `0`, `1`, or a valid rank.
- Candidates without a defined `R` are excluded from ranking and appear in the trace
  with disposition `UNRESOLVED_RELIABILITY`.
- If **all** eligible candidates lack a defined `R`:
  - Default (`FallbackPolicy.NONE`): outcome `NO_SELECTION_UNRESOLVED`, no node selected.
  - Opt-in (`FallbackPolicy.LOWEST_NODE_ID`): outcome `FALLBACK_SELECTED`, lowest node id
    chosen, explicitly labelled as a **policy fallback** (not a probabilistic conclusion).

---

## 5. Tie-Breaking and Fallback Semantics

### Tie-breaking

When multiple eligible candidates share the maximum reliability value (exact
`Double` equality), the tie is broken **deterministically by lowest node id**.
This is the only tie-breaker; no randomness is used.

Reason code: `TIE_BROKEN_BY_NODE_ID`.

### Fallback policy

| Policy | Behaviour when no eligible candidate has a reliability estimate |
|--------|----------------------------------------------------------------|
| `NONE` (default) | `NO_SELECTION_UNRESOLVED` — no node selected |
| `LOWEST_NODE_ID` | `FALLBACK_SELECTED` — lowest node id selected; carries no reliability value |

The fallback is **never** applied when at least one candidate has a defined
reliability estimate. It is strictly for the all-unresolved case.

---

## 6. Manual Override Semantics

The current architecture and specification do **not** define manual override modes
(`FIXED_NODE`, `PREFERRED_NODE`). The `Scheduler` interface is policy-agnostic so
that baseline implementations (round robin, least loaded) can be plugged in for
comparison, but no operational override mechanism exists in Step 6D.

If a future step introduces manual selection, it must:
- Not be described as a PCST probabilistic decision.
- Not silently bypass hard constraints.
- Be a separate code path from the reliability-based policy.

---

## 7. Decision Trace (Per-Candidate Explanation)

Every scheduling decision includes a complete trace of **every** candidate
considered, ordered by node id. Each entry (`CandidateDecision`) records:

| Field | Meaning |
|-------|---------|
| `nodeId` | Candidate node identifier |
| `eligible` | Passed hard-constraint filter? |
| `disposition` | `SELECTED` / `SELECTED_BY_FALLBACK` / `LOWER_RELIABILITY` / `BELOW_THRESHOLD` / `UNRESOLVED_RELIABILITY` / `EXCLUDED_HARD_CONSTRAINT` |
| `rejectionReasons` | Hard-constraint reasons (proven vs. indeterminate distinguished) |
| `reliabilityStatus` | Step 6C status (`COMPUTABLE`, `UNRESOLVED_MODEL`, etc.) |
| `reliability` | Numerical `R` in [0, 1] or `null` |
| `capabilityStatus` | Step 6B status name or `"MISSING"` |
| `capability` | Numerical `C` in [0, 1] or `null` |
| `explanation` | Human-readable account |

This satisfies specification section 13.1 (required logs per scheduling decision)
and the compliance matrix (capability and reliability estimates for every evaluated
candidate, not only the selected one).

---

## 8. Examples

### Example 1: Resource-only contract, highest reliability wins

```
Task: maxLatency = 100 ms, no deadline, no battery, no QoS
Candidates:
  node-a: latency belief N(80, 10²) → C = Φ(2) = 0.977
  node-b: latency belief N(90, 10²) → C = Φ(1) = 0.841
Decision:
  status = SELECTED
  selectedNode = node-a
  reliability = 0.977
  trace: node-a SELECTED (highest), node-b LOWER_RELIABILITY (0.841)
```

### Example 2: Policy threshold enforced

```
Task: maxLatency = 100 ms
Policy: threshold = 0.99
Candidates:
  node-a: reliability = 0.977
Decision:
  status = DEFER_OR_REJECT
  selectedNode = null
  trace: node-a BELOW_THRESHOLD (0.977 < 0.99)
```

### Example 3: Hard constraint overrides reliability

```
Task: requires GPU
Candidates:
  node-a: GPU absent (VIOLATED, ACCELERATOR_ABSENT), but latency belief N(80, 10²) → C = 0.977
Decision:
  status = NO_FEASIBLE_NODE
  trace: node-a EXCLUDED_HARD_CONSTRAINT (proven violation; reliability present but never overrides)
```

### Example 4: All unresolved, no fallback

```
Task: requires GPU profile "gpu" (QoS event, no model)
Candidates:
  node-a: eligible, reliability status = UNRESOLVED_MODEL (no QoS model)
Decision:
  status = NO_SELECTION_UNRESOLVED
  selectedNode = null
  trace: node-a UNRESOLVED_RELIABILITY
```

### Example 5: All unresolved, fallback enabled

```
Task: requires GPU profile "gpu"
Policy: FallbackPolicy.LOWEST_NODE_ID
Candidates:
  node-b: eligible, reliability unresolved
  node-a: eligible, reliability unresolved
Decision:
  status = FALLBACK_SELECTED
  selectedNode = node-a
  selectedReliability = null
  policyFallback = true
  trace: node-a SELECTED_BY_FALLBACK, node-b UNRESOLVED_RELIABILITY
```

---

## 9. Current Limitations

| Limitation | Impact |
|------------|--------|
| Only network latency and packet loss yield numerical `R` | Most real tasks (with deadlines, battery, QoS) produce unresolved reliability |
| No completion-time model | `Edeadline` never computable |
| No energy/drain process model | `Eenergy` never computable |
| No QoS or node-stability models | `EQoS`, `Estability` never computable |
| No joint model across success events | Even if individual events were modelled, no joint `R` |
| `FallbackPolicy.LOWEST_NODE_ID` is a policy rule, not evidence-based | Selected node has no reliability value; use only when operationally acceptable |
| Threshold `θτ` is a static configuration | No dynamic threshold adaptation |
| Single-task, single-epoch only | No queueing, preemption, or multi-task optimisation |

These are genuine model gaps, not unfinished implementation. Any contract expressing
a deadline, energy, QoS, or stability requirement is reported as unresolved.

---

## 10. Files

Main (`pcst-master/src/main/java/com/omni/pcst/master/scheduler/`):

| File | Responsibility |
|------|----------------|
| `Scheduler.java` | Policy-agnostic interface |
| `PCSTScheduler.java` | Greedy maximum-reliability implementation |
| `SchedulingDecision.java` | Immutable decision record + trace |
| `SchedulingCandidate.java` | Composed input (eligibility, capability, reliability) |
| `CandidateDecision.java` | Per-candidate trace entry |
| `SchedulingStatus.java` | Overall outcome enum |
| `SchedulingReason.java` | Decision reason codes |
| `CandidateDisposition.java` | Per-candidate outcome |
| `SchedulingPolicyConfig.java` | Threshold, task-class overrides, fallback |
| `FallbackPolicy.java` | All-unresolved recovery rule |

Tests (`pcst-master/src/test/java/com/omni/pcst/master/scheduler/`):

| File | Tests |
|------|-------|
| `PCSTSchedulerTest.java` | 10 scenarios covering selection, threshold, tie-breaking, no-feasible, defer/reject, unresolved, ineligibility guard, fallback, trace completeness, resource-only contract |

---

## 11. Verification

- Focused: `mvn -pl pcst-master test -Dtest=PCSTSchedulerTest` → **10 tests**, 0 failures, 0 errors.
- Full reactor: `mvn test` from repository root → **BUILD SUCCESS**.
  `pcst-master` **357 tests** (0 failures, 0 errors), `pcst-node-agent` **39 tests** (0 failures, 0 errors).
  The scheduler package contributes the 10 new tests; no pre-existing test changed and no pre-existing source file was modified.

---

## 12. Boundaries — What This Step Does Not Do

- No **task dispatch**, **execution**, **retries**, or **result reporting** (out of scope for Step 6D).
- No **UI**, **dashboard**, or **REST endpoint** for scheduling.
- No new **Bayesian inference**, **predictor**, **weighted score**, or **threshold mapping**.
- No **product of marginals** and no **uncertainty penalty** (forbidden by specification sections 9.1, 9.2).
- No **fabricated `0`/`1`**: a failed or unsupported estimate is `null` with explicit status.
- The task model, hard-constraint policy, belief engine, telemetry, prediction stage,
  capability stage, reliability stage, and replay harness are consumed but **not modified**.