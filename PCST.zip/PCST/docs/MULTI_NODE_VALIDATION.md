# Multi-Node Validation

## Overview

This document describes the multi-node validation infrastructure for PCST (Probabilistic Cloud Scheduling Toolkit), Step 9. It documents the reproducible experiment framework, baseline scheduler policies, fault/safety testing scenarios, and evaluation harness.

The goal of multi-node validation is to verify PCST as a real distributed system with reproducible experiments, without fabricating data or probabilities. All outcomes derive from the existing Bayesian belief engine, capability estimation, and reliability estimation models.

## Architecture

### Processes

- **Master Process** (HTTP on port 8080, gRPC on port 9090): Coordinates scheduling decisions, maintains the digital twin manager, and serves REST APIs.
- **Node Agent Processes** (one per registered node): Connect to the Master via gRPC, report telemetry (CPU, memory, energy), send heartbeats, and receive scheduling decisions. Each node agent runs in a separate JVM process on the same host.

### Communication

- Master REST APIs: `http://localhost:8080/api/v1/...`
- gRPC communication between Master and node agents on port 9090 (configured per deployment)
- Node registration: `POST /api/v1/nodes/register`
- Telemetry ingestion: `POST /api/v1/telemetry`
- Heartbeat: `POST /api/v1/heartbeat`

### Scheduler Policies (Step 9 baseline)

Two baseline scheduler policies are implemented for scientific comparison with PCST:

1. **RoundRobinScheduler** (`pcst-master/src/main/java/.../scheduler/RoundRobinScheduler.java`)
   - Cycles through eligible candidates in fixed order
   - No randomness; deterministic rotation
   - Every eligible candidate is equally valid; policy does not model capability or reliability

2. **LeastLoadedScheduler** (`pcst-master/src/main/java/.../scheduler/LeastLoadedScheduler.java`)
   - Selects candidate with highest capability probability
   - Falls back to highest reliability probability when capability is unavailable
   - Uses `DigitalTwinManager` for telemetry diagnostics (optional)
   - Deterministic tie-breaking: first candidate encountered in input collection

Both policies implement the `Scheduler` interface (`select(Task, long, Collection<SchedulingCandidate>)`) and are standalone (no Spring DI required for Round Robin; LeastLoadedScheduler takes `DigitalTwinManager` via constructor).

### Evaluation Harness

The evaluation harness runs structured scheduling trials and produces CSV/JSON output for analysis. It is invoked via PowerShell scripts (see below).

### Key Constraints

- No database; in-memory state lost on Master restart
- Node agents must be separately started JVM processes
- Experiments are reproducible given the same initial conditions
- No fabricated outcomes or probabilities; all data derives from existing models
- Scheduler policies are policy-agnostic regarding Bayesian equations

## Startup and Cleanup

### Prerequisites

- Java 21 JDK
- Maven 3.9.x
- Project built (`mvn compile -pl pcst-master`)

### Startup Scripts

#### Start Master Node

```powershell
# From the PCST root directory
cd pcst-master
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8080" &
# Wait for master to be ready
sleep 15
# Verify master is up
curl -s http://localhost:8080/api/v1/nodes | jq .
```

#### Start Node Agents

Start one or more node agents on the same host. Each node requires a unique node ID and gRPC port.

```powershell
# Node A
cd pcst-master
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8081 --grpc.port=9091 --node.id=node-A --node.hostname=localhost" &
sleep 10

# Node B
cd pcst-master
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8082 --grpc.port=9092 --node.id=node-B --node.hostname=localhost" &
sleep 10
```

#### Cleanup (stop all processes)

```powershell
# Kill any remaining Java processes from the experiment
taskkill /IM java.exe /F 2>$null
# Or more selectively:
Get-Process java | Where-Object { $_.Path -match "pcst-master" } | Stop-Process -Force
```

### Verification

After startup, verify the system state:

```powershell
# Check master node count
curl -s http://localhost:8080/api/v1/nodes/count

# List registered nodes
curl -s http://localhost:8080/api/v1/nodes | jq .

# Check node details
curl -s http://localhost:8080/api/v1/nodes/node-A | jq .
```

## Experiment Runner

### Purpose

The experiment runner (`scripts/run_experiment.ps1`) executes structured scheduling trials with the following features:

- Configurable number of trials per scenario
- CSV/JSON output with per-trial details
- Automatic scenario warm-up and cooldown
- Reproducible randomness (seed-based, though both policies are deterministic)
- Trace collection per scheduling decision

### Usage

```powershell
# From the PCST root directory
.\scripts\run_experiment.ps1 `
    --master-url "http://localhost:8080" `
    --nodes "node-A,node-B" `
    --policy "round_robin" `
    --trials 50 `
    --output results/round_robin_50t.csv
```

```powershell
# Least-loaded policy experiment
.\scripts\run_experiment.ps1 `
    --master-url "http://localhost:8080" `
    --nodes "node-A,node-B" `
    --policy "least_loaded" `
    --trials 50 `
    --output results/least_loaded_50t.csv
```

### Configuration Options

| Option | Description | Default |
|--------|-------------|---------|
| `--master-url` | Master REST base URL | `http://localhost:8080` |
| `--nodes` | Comma-separated list of node IDs | (required) |
| `--policy` | Scheduler policy: `round_robin` or `least_loaded` | (required) |
| `--trials` | Number of scheduling trials to run | 100 |
| `--output` | Output CSV file path | `results/experiment.csv` |
| `--warmup` | Number of warm-up trials (discarded) | 10 |
| `--seed` | Random seed for reproducibility | 42 |

### Output Format (CSV)

```
trial_id,selected_node_id,selected_reliability,policy_status,reason_codes,derivation,capability_probability,telemetry_cpu,telemetry_memory
1,node-B,0.9772,SELECTED,"[SELECTED_HIGHEST_RELIABILITY,NO_POLICY_THRESHOLD_CONFIGURED]",selected node node-b via least-loaded policy (best capability probability = 0.95; selected node reliability = 0.92),0.95,45.2,78.1
2,node-A,0.8913,SELECTED,"[SELECTED_HIGHEST_RELIABILITY,NO_POLICY_THRESHOLD_CONFIGURED]",selected node node-a via least-loaded policy (best capability probability = 0.95; selected node reliability = 0.88),0.94,42.8,71.3
...
```

### Output Format (JSON, optional)

The harness can also produce a JSON summary file with aggregated statistics:
- Per-policy selection frequencies
- Per-node selection counts
- Average reliability per policy
- Capability probability distribution

## Fault / Safety Testing Scenarios

The following controlled scenarios are designed to exercise the scheduling system edge cases and fault tolerance. Each scenario is reproducible and the system state is reset between trials.

### Controlled Scenarios

| Scenario | Description | Expected Behavior |
|----------|-------------|-------------------|
| **Agent Unavailable** | Node agent is not running or disconnected mid-experiment | Master returns `NO_FEASIBLE_NODE` when all candidates are ineligible or have unresolved reliability |
| **Disconnect** | gRPC connection between Master and node agent is severed | Heartbeat rejected; telemetry rejected; scheduling decisions reflect missing telemetry |
| **Stale/Missing Telemetry** | Telemetry observations are older than the staleness threshold or never sent | Capability/reliability estimates may be `UNRESOLVED_MODEL`; scheduling falls back to available estimates |
| **Duplicate Sequences** | Node sends duplicate telemetry sequences | Rejected by sequence tracker; no state corruption; staleness gate still applies |
| **Out-of-Order Observations** | Node sends telemetry with timestamps out of order | Stale/out-of-order gate rejects older observations; only newest accepted |
| **Execution Failure** | Task execution on selected node fails (simulated) | Scheduling decision marks candidate with appropriate disposition; retry logic may select alternative |
| **Ambiguous Outcomes** | Multiple candidates have identical capability/reliability values | Deterministic tie-breaking: lowest node ID wins (for LeastLoaded); round-robin rotation order wins (for RoundRobin) |
| **Unknown IDs** | Scheduling request references a node ID not in the candidate set | Candidate filtered out; if all filtered, `NO_FEASIBLE_NODE` returned |
| **Master Restart** | Master process is restarted mid-experiment | In-memory state (digital twins, registered nodes) lost; nodes must re-register; experiments restart from clean state |
| **Hard Constraint Violation** | Task constraints make all candidates ineligible | `NO_FEASIBLE_NODE` with `NO_CANDIDATE_PASSED_HARD_ELIGIBILITY` reason |
| **Policy Threshold Enforcement** | Scheduler policy threshold is configured and candidates fall below it | `DEFER_OR_REJECT` status; reasons include `ALL_RANKED_CANDIDATES_BELOW_POLICY_THRESHOLD` |

### Scenario Execution

Each scenario is executed via the experiment runner with specific pre-conditions:

```powershell
# Example: Agent unavailable scenario
# 1. Start master only (no node agents)
# 2. Create task with constraints that require node resources
# 3. Run scheduling trial - expect NO_FEASIBLE_NODE
# 4. Start node agent, re-run - expect SELECTED

# Example: Master restart scenario
# 1. Run experiments with nodes registered
# 2. Kill master process
# 3. Restart master (loses in-memory state)
# 4. Nodes re-register
# 5. Re-run experiments from clean state
```

### Results Documentation

Results from each scenario experiment are stored in `results/` directory with filenames indicating the scenario and trial count. Each CSV includes columns for:
- Trial ID
- Selected node ID
- Selected reliability probability
- Scheduling status
- Reason codes (as JSON array)
- Derivation description
- Capability probability (when available)
- Telemetry diagnostics (CPU, memory when available)

## Limitations

- **Single-host only**: All node agents run on the same machine; network partitions, latency, and JVM isolation are not modeled.
- **In-memory state**: Digital twin state is lost on Master restart; no persistent storage is configured in the base deployment.
- **No concurrent scheduling**: The experiment runner serializes trials; true concurrent scheduling behavior is not tested.
- **Deterministic policies**: Both baseline policies are deterministic given the same input; no stochastic elements are introduced (beyond what the Bayesian engine produces).
- **Telemetry dependency**: LeastLoadedScheduler telemetry diagnostics depend on `DigitalTwinManager` having accepted observations; without observations, diagnostics are absent.
- **Scheduler interface stability**: The `Scheduler.select()` interface is policy-agnostic; new policies must conform to the existing contract without modifying model equations.

## Test Commands

### Run All Scheduler Tests

```powershell
mvn test -pl pcst-master
```

### Verify Scheduler Compilation

```powershell
mvn compile -pl pcst-master
```

### Run Specific Scheduler Test Class

```powershell
mvn test -pl pcst-master -Dtest=PCSTSchedulerTest
```

### Build Entire Project

```powershell
mvn clean install
```

## References

- `docs/DASHBOARD.md` - Step 8 dashboard architecture and API documentation
- `docs/PROJECT_CONTEXT.md` - Project context and Step completion status
- `docs/SCHEDULING_POLICY.md` - Scheduling policy specification (Step 6D)
- `docs/CAPABILITY_ESTIMATION.md` - Capability estimation specification (Step 6B)
- `docs/RELIABILITY_ESTIMATION.md` - Reliability estimation specification (Step 6C)
- `docs/REPLAY_EVALUATION.md` - Existing replay evaluation harness (Step 5E.3)
- `pcst-master/src/main/java/.../scheduler/RoundRobinScheduler.java` - Round-robin implementation
- `pcst-master/src/main/java/.../scheduler/LeastLoadedScheduler.java` - Least-loaded implementation
- `pcst-master/src/main/java/.../scheduler/Scheduler.java` - Scheduler interface
- `pcst-master/src/main/java/.../scheduling/SchedulingDecision.java` - Scheduling decision model
- `pcst-master/src/main/java/.../scheduling/CandidateDecision.java` - Per-candidate disposition model
- `pcst-master/src/main/java/.../scheduler/SchedulingReason.java` - Reason codes enum
- `pcst-master/src/main/java/.../scheduler/CandidateDisposition.java` - Disposition enum
- `pcst-master/src/main/java/.../digitaltwin/DigitalTwinManager.java` - Digital twin manager
- `pcst-master/src/main/java/.../task/Task.java` - Task model
- `pcst-master/src/main/java/.../capability/CapabilityAssessment.java` - Capability assessment record
- `pcst-master/src/main/java/.../reliability/ReliabilityAssessment.java` - Reliability assessment record
<tool_call>