# PCST Research Decision Memo

**Status:** Decision memo — no implementation performed.
**Date:** 2026-10-27
**Constraint honoured:** No production code, scheduler behaviour, schema, or dependency was modified. No new simulator or benchmark was built. No novelty claim is made without a literature-based comparison.

---

## 1. Existing evidence and source paths

All evidence was recovered from the repository; no broad new status report was created. Key documents:

| Document | Path | What it establishes |
|---|---|---|
| Project context (implementation status) | `docs/PROJECT_CONTEXT.md` | Steps 1–9 completed/verified; full pipeline telemetry → belief → capability → reliability → scheduler → execution |
| Reliability estimation (Step 6C) | `docs/RELIABILITY_ESTIMATION.md` | `R(n,τ)` only computable for resource-only contracts (latency/packet loss); deadline/energy/QoS/stability unresolved |
| Capability estimation (Step 6B) | `docs/CAPABILITY_ESTIMATION.md` | `C(n,τ)` only for network latency and packet loss; persistence assumption; independence combiner unvalidated |
| Scheduling policy (Step 6D) | `docs/SCHEDULING_POLICY.md` | Greedy max-reliability, static threshold, no dynamic adaptation, fallback = lowest node id |
| Task model & hard constraints (Step 6A) | `docs/TASK_MODEL_AND_HARD_CONSTRAINTS.md` | `DEFAULT_MAX_EVIDENCE_AGE_MILLIS=15_000` is an engineering approximation, not spec-derived; accelerator memory/compute capacity/execution profile always indeterminate |
| Replay evaluation harness | `docs/REPLAY_EVALUATION.md` | Offline scorer for PERSISTENCE vs TREND predictors; leakage-free by construction; metrics = forecast error only, not calibration |
| Multi-node validation | `docs/MULTI_NODE_VALIDATION.md` | RoundRobin + LeastLoaded baselines; 10 fault scenarios; live experiment blocked by environment (PowerShell process limits) |
| Experiment results | `docs/EXPERIMENT_RESULTS.md` | 379 tests pass; scheduler baselines implemented; live multi-agent experiment not achievable in this environment |
| Mathematical specification V1.1 | `docs/specifications/PCST_MATHEMATICAL_SPECIFICATION_V1_1_CONSOLIDATED_REVIEW.extracted.txt` | Gate register approved; §13.5 novelty gate explicitly unverified; no literature review performed |
| Compliance matrix | `docs/specifications/PCST_IMPLEMENTATION_COMPLIANCE_MATRIX_V1_REVIEW.extracted.txt` | Prediction, uncertainty, joint reliability, calibration, retries = NOT ESTABLISHED; novelty not established |

Source implementations verified against reports:

- `pcst-master/src/main/java/.../belief/BayesianBeliefEngine.java` — Normal–Normal conjugate, static latent value, known fixed sensor noise, missing skipped, per-resource independence
- `pcst-master/src/main/java/.../capability/CapabilityEngine.java` — belief posterior as predictive law under persistence; latency/packet loss only
- `pcst-master/src/main/java/.../reliability/ReliabilityEngine.java` — `R = C` only for resource-only contracts; no double counting, no uncertainty penalty
- `pcst-master/src/main/java/.../scheduler/PCSTScheduler.java` — greedy max-reliability, static threshold, deterministic tie-break
- `pcst-master/src/main/java/.../prediction/{Persistence,Trend}ResourcePredictor.java` — endpoint-only, no task conditioning, no uncertainty propagation
- `pcst-master/src/main/java/.../telemetry/TelemetrySequenceTracker.java` — sequence discontinuity diagnostic, not a staleness/uncertainty model

**Fresh build verification:** `mvn -pl pcst-master test` → 452 tests run, 0 failures, 2 errors (both pre-existing `JdbcTask*` errors, an unrelated Spring context connectivity issue). Baseline is green.

---

## 2. Implemented versus merely proposed / unvalidated

### Implemented and verified (unit-tested, deterministic)

- Telemetry ingestion with presence tracking (missing ≠ zero), stale/out-of-order rejection, unknown-node rejection
- Bayesian belief engine: per-resource Gaussian posteriors under Normal–Normal, static i.i.d. assumption, known fixed noise variance, missing skipped
- Hard-constraint filter: SATISFIED / VIOLATED / INDETERMINATE, fresh vs stale vs absent evidence, `REJECT` default
- Capability engine: `C(n,τ)` event probability for latency & packet loss only; joint unresolved by default
- Reliability engine: `R = C` only when the whole success contract reduces to `Eresource`; deadline/energy/QoS/stability → unresolved
- PCST scheduler: greedy max-reliability, static threshold, deterministic fallback
- Task execution + dispatch + lifecycle (in-memory)
- Baselines: RoundRobin, LeastLoaded/CapabilityBased
- Replay harness: PERSISTENCE vs TREND forecast-error scoring (offline, leakage-free)

### Proposed in docs/spec but NOT implemented (not validated)

- Task-conditioned predictive law over `[t, t+H]` (spec §7; G3 approved but no `PredictionEngine`)
- Structured uncertainty propagation beyond posterior variance (G4 approved; no uncertainty engine)
- Joint reliability across success events with dependency modelling (G5/G6; no joint model)
- Per-resource staleness/freshness (current freshness uses overall latest telemetry receive time)
- Node-stability / interruption model (`Estability` always unresolved)
- Energy/drain process model (`Eenergy` always unresolved)
- Completion-time / deadline distribution model (`Edeadline` always unresolved)
- Calibration / empirical validation of predicted probabilities (spec §13; not performed)
- Selection-bias handling for calibration (spec §13.4; not performed)
- Dynamic rescheduling, migration, retries (roadmap Stage 8/Later)

**Key gap:** PCST today computes a numerical reliability for only the narrow class of resource-only tasks (latency/packet loss). Every task with a deadline, battery floor, QoS profile, or interruption tolerance yields unresolved reliability and is either deferred or falls back to lowest node id — not a probabilistic decision.

---

## 3. Candidate research contributions (ranked)

### Candidate A — Age-aware reliability under stale telemetry (Direction A)

**Limitation it addresses:** The belief and capability engines treat evidence as fresh if `receivedAt` is within `15_000 ms` of the decision instant, regardless of how old the observation timestamp is relative to when it was generated, and regardless of resource dynamics. Under changing node conditions (load drift, battery drain, thermal events), a "fresh" receive can still be a stale state estimate, so `R(n,τ)` is overconfident.

**Mechanism change:** Track per-resource observation age at decision time (measurement timestamp vs decision instant), and grow predictive variance / degrade reliability as a function of telemetry age. The belief posterior variance reflects sensor noise and sample count only, not process drift over the gap between measurement and decision. Add an explicit age-to-uncertainty mapping (e.g., process-noise accumulation over the staleness interval) before capability/reliability.

**Feasibility within existing architecture:** High. The `DigitalTwinSnapshot` already exposes `observationHistory()` with per-observation timestamps and `lastTelemetryReceivedAtMillis()`. `CapabilityEngine` already classifies evidence freshness. The change is local to the predictive distribution / reliability stage: keep the Normal–Normal belief, but inflate variance by an age-dependent process-noise term before computing `P(X ≤ r)`. No schema, contract, or scheduler-pipeline change required.

**Hypothesis:** Under synthetically drifted telemetry (latency/battery trending over time), an age-aware reliability estimator produces better-calibrated success probabilities and higher task success rate than the current persistence-assumption estimator, at comparable decision latency.

**Falsifiable form:** `P(success | R_age ≥ θ) ≈ R_age` (calibration) and `success_rate(age-aware PCST) > success_rate(current PCST)` on the same drifted trace, with both compared to RoundRobin/LeastLoaded baselines.

**Baselines & ablations:**
- Baselines: current PCST (no age term), RoundRobin, LeastLoaded/CapabilityBased
- Ablations: (a) age-aware without variance inflation (age used only as a freshness gate), (b) age-aware with inflation but no threshold adaptation, (c) oracle (knows true state)

**Likely failure modes / falsifiers:**
- If drift is negligible in the trace, age-aware ≈ current → no measurable gain (hypothesis falsified for that workload).
- If the age-to-variance mapping is misspecified (too aggressive), reliability becomes over-conservative → more `DEFER_OR_REJECT`, lower throughput, no success-rate gain.
- If staleness is uncorrelated with actual failure, age adds noise, not signal.

**Research vs engineering distinction:** Merely adding a max-age gate is engineering (already exists). A research contribution requires demonstrating that the age→uncertainty mapping improves calibrated decision outcomes under non-stationary conditions, with ablations isolating the mapping from the gate.

**Literature overlap:** Stale-state estimation and "age of information" (AoI) in scheduling/control is an established area (e.g., Kaul, Yates, Gruteser on AoI; real-time scheduling under outdated state). The specific combination of age-dependent variance inflation into a Bayesian reliability scheduler for heterogeneous compute nodes needs a targeted review — not obviously novel, but the PCST specificity (belief posterior + per-resource age + task-conditioned horizon) is a narrower claim.

---

### Candidate B — Principled missing/partially observed telemetry in reliability (Direction B)

**Limitation it addresses:** Missing measurements are skipped entirely (no imputation, no zero-filling — correct), but the consequence is only `INSUFFICIENT_EVIDENCE` / `UNRESOLVED_MODEL`, which pushes candidates into deferral or fallback. There is no explicit missingness model: the scheduler cannot distinguish "sensor genuinely reporting nothing" from "node unreachable," and cannot propagate missingness into uncertainty or into a deferral-vs-act trade-off. A partially observed node (some resources missing) is treated coarsely.

**Mechanism change:** Introduce an explicit missingness/observation model (likelihood of observation given node state) so that missing fields update belief uncertainty (epistemic growth) rather than only causing unresolved status. Reliability becomes a function of which resources are observed, with a principled deferral threshold tied to epistemic uncertainty rather than a hard binary.

**Feasibility:** Medium. Requires extending `BeliefState`/`ResourceBelief` to carry an epistemic/missingness component and changing `CapabilityEngine`/`ReliabilityEngine` to consume it. The belief engine is stateless and per-resource; adding a missingness likelihood is additive but touches the core inference contract. No contract change, but tests must be extended.

**Hypothesis:** Under randomly masked telemetry (MCAR and MNAR patterns), a missingness-aware reliability estimator achieves better calibration (lower Brier score) and fewer unnecessary deferrals than the current skip-or-unresolved behavior.

**Falsifiable form:** `Brier( missingness-aware R ) < Brier( current R )` and `deferral_rate( missingness-aware ) < deferral_rate( current )` at equal success rate, on masked traces.

**Baselines & ablations:** current PCST (skip → unresolved), RoundRobin, LeastLoaded; ablation: missingness used only as a hard gate (no uncertainty inflation).

**Failure modes / falsifiers:** If missingness is purely random and uninformative about success, modelling it adds complexity without calibration gain. If MNAR missingness correlates with failure but the likelihood is misspecified, estimates worsen.

**Research vs engineering distinction:** Treating missing as "unavailable" is already implemented. A research contribution is the explicit missingness likelihood and its propagation into calibrated reliability + deferral decisions, validated against baselines.

**Literature overlap:** Missing-data mechanisms (Rubin: MCAR/MAR/MNAR), multiple imputation, and selective prediction / deferral in classification (e.g., Chow's reject option). Applied to distributed scheduling with Bayesian belief — needs review; the scheduling-specific deferral trade-off is the novel angle.

---

### Candidate C — Scheduling with explicit deferral / cost of acting on unreliable estimates (Direction C)

**Limitation it addresses:** The PCST scheduler is greedy max-reliability with a static threshold: either select the max-R node or defer/reject. It never explicitly models (a) the cost of deferring (queueing delay, missed deadline), (b) the value of waiting for fresher telemetry, or (c) the expected cost of acting on an unreliable estimate. Unresolved reliability → `NO_SELECTION_UNRESOLVED` or a non-probabilistic fallback. There is no decision-theoretic treatment of "act now vs defer."

**Mechanism change:** Extend the scheduler to a small decision-theoretic rule: compare expected cost of acting (using current R) vs expected cost of deferring (fresh telemetry + re-decision) vs a bounded fallback, parameterized by task deadline and staleness. This is a single-step look-ahead / value-of-information rule, not a full POMDP.

**Feasibility:** Medium-High architecturally (scheduler is composable and stateless), but requires defining a cost model (deferral cost, mis-selection cost) that does not exist and is deployment-specific. Without a cost model, the research is speculative.

**Hypothesis:** A deferral-aware scheduler reduces deadline misses and unnecessary fallbacks versus greedy max-reliability on time-constrained workloads.

**Falsifiable form:** `deadline_miss_rate(deferral-aware) < deadline_miss_rate(greedy PCST)` and `fallback_rate(deferral-aware) < fallback_rate(greedy)` at equal throughput, on deadline-bearing tasks with stochastic telemetry freshness.

**Baselines & ablations:** greedy PCST, RoundRobin, LeastLoaded; ablation: deferral with zero cost (always defer), deferral with infinite cost (always act).

**Failure modes / falsifiers:** If the cost model is wrong (deferral cheaper than it really is), the scheduler over-defers and misses deadlines. If tasks are mostly non-urgent, deferral adds no value.

**Research vs engineering distinction:** A static threshold fallback is engineering (exists). A research contribution is an explicit, parameterized act-vs-defer rule with value-of-information, validated with ablations on the cost parameters.

**Literature overlap:** POMDP/MDP scheduling, value of information, restless bandits, real-time scheduling with imprecise computations. Full POMDP is explicitly out of scope for PCST V1; the contribution would be a bounded single-step approximation, which is well-trodden ground — novelty claim is weak unless the specific cost structure (staleness + reliability + deadline) is validated.

---

## 4. Literature check (verified via arXiv, Oct 2026)

Web access is available; searches performed against arXiv API. Verified records:

| # | Title | Authors | Year | Venue | ID / DOI | Relevance | Overlap with PCST |
|---|---|---|---|---|---|---|---|
| 1 | LLMSched: Uncertainty-Aware Workload Scheduling for Compound LLM Applications | Zhu, Chen, Fan, Zhu | 2025 | ICDCS 2025 | arXiv:2504.03444 | Uncertainty-aware scheduling, Bayesian network profiling, entropy-based uncertainty reduction | Closest validated overlap: uncertainty-aware scheduling exists; PCST's belief+reliability chain is conceptually adjacent but targets heterogeneous compute nodes, not LLM compound apps |
| 2 | SageSched: Efficient LLM Scheduling Confronting Demand Uncertainty and Hybridity | Gan et al. | 2026 | arXiv | arXiv:2603.07917 | Uncertainty-aware scheduling, output-length distribution prediction | Demand uncertainty in LLM serving; different domain, same uncertainty-aware-scheduling theme |
| 3 | NetKV: Network-Aware Decode Instance Selection for Disaggregated LLM Inference | Ojewale | 2026 | arXiv | arXiv:2606.03910 | Rankings provably robust to stale telemetry | Directly relevant to Direction A (stale telemetry robustness), but in LLM inference routing, not compute-node scheduling |
| 4 | LEO-Aware DRL Meta-Scheduler for 5G NTN Slicing | Vilchez et al. | 2026 | GLOBECOM 2026 | arXiv:2608.01668 | Meta-scheduler using stale telemetry | Stale-telemetry scheduling exists in networking; different domain |
| 5 | Chance-Constrained Makespan Scheduling | Shi, Huang, Yan, Neumann | 2022/2025 | arXiv | arXiv:2212.11478 | Chance-constrained scheduling under stochastic processing times | Direction B/C adjacent (chance constraints), but makespan on identical machines, not node reliability |
| 6 | A Robust Chance Constrained Approach to Surgery Scheduling | Caserta et al. | 2026 | arXiv | arXiv:2608.03931 | Reliability as endogenous decision, buffer allocation | Chance-constrained reliability exists; surgery scheduling domain |
| 7 | DAGS-SLAM ... Uncertainty-Aware Scheduling | Zhang et al. | 2026 | arXiv | arXiv:2602.21644 | Uncertainty-aware scheduling in robotics | Robotics domain, not compute scheduling |

Searches with zero or weak returns: `"Bayesian belief" AND scheduling`, `"missing observations" AND distributed scheduling`, `"stale observations" AND belief update AND scheduling`, `"belief-based scheduling"`.

**Assessment:** Uncertainty-aware scheduling, chance-constrained scheduling, and stale/age-of-information telemetry are **established literatures**. PCST's specific combination — Bayesian belief over heterogeneous node resources → task-conditioned capability → joint execution reliability → greedy max-reliability scheduling — is narrower, but no verified novelty claim can be made yet. The spec itself (§13.5, §19) states novelty is unverified and requires a scholarly literature review. **No novelty claim is made in this memo.**

Verified vs unverified: the seven papers above are verified via arXiv metadata. No claim is made that PCST is distinct from them until a full-text comparison is done.

---

## 5. Smallest credible experiment (leading hypothesis)

**Leading candidate:** Direction A (age-aware reliability under stale telemetry), because it is the most feasible within the existing architecture (local change to predictive distribution / reliability, no contract change) and addresses a real, documented gap (stale telemetry under changing node conditions).

**Experiment design:**

1. **Trace source:** Use the existing `TelemetrySimulator`/`BenchmarkRunner` harness (`pcst-master/src/test/java/.../benchmark/`) to generate synthetic node telemetry with a controlled drift profile (e.g., latency or battery trending over a decision epoch), plus RoundRobin and LeastLoaded/CapabilityBased baselines already implemented.

2. **Treatments:**
   - T0: current PCST (persistence assumption, no age term)
   - T1: PCST + age-to-variance inflation (process noise accumulated over `decisionInstant − measurementTimestamp`), reliability computed from inflated variance
   - T2: RoundRobin
   - T3: LeastLoaded/CapabilityBased

3. **Workload mix:** Resource-only tasks (latency ceiling / packet-loss ceiling) so `R` is computable today, with injected drift that makes the latest measurement a biased predictor of the execution-interval value.

4. **Metrics (per spec §13.2):**
   - Task success rate
   - Calibration: reliability diagram / Brier score of predicted `R` vs observed success
   - Deferral rate (`DEFER_OR_REJECT` / `NO_SELECTION_UNRESOLVED`)
   - Fallback rate
   - Scheduler decision latency (overhead)

5. **Ablations:**
   - T1a: age used only as a staleness gate (no variance inflation) — isolates the mapping from the gate
   - T1b: oracle (true state known) — upper bound

6. **Falsification rule:** If T1 does not achieve both (a) lower Brier score / better calibration than T0 and (b) equal-or-higher success rate at equal-or-lower deferral+fallback rate, the age-aware reliability hypothesis is falsified for this trace class.

7. **Reproducibility:** deterministic traces, fixed seeds, CSV/JSON output consistent with the existing experiment harness format.

**CPU/time:** modest — synthetic traces, in-memory, single JVM; no live multi-agent processes needed (environment already shown unable to sustain them).

---

## 6. Risks, unresolved assumptions, recommendation

### Risks

1. **Novelty not established.** Direction A overlaps with age-of-information and stale-telemetry scheduling literature (verified: NetKV, LEO meta-scheduler). A full-text review is required before any novelty language.
2. **Synthetic-trace validity.** The experiment uses simulated drift; real-node drift (thermal, battery, user interference) may behave differently. Results would not generalize without real telemetry.
3. **Misspecified age→variance mapping.** Without data to calibrate the process-noise term, inflation could be too aggressive (over-conservative) or too weak (no benefit).
4. **Selection bias in calibration.** Only selected nodes are observed; unselected candidates' counterfactual outcomes are unobserved (spec §13.4). The replay harness mitigates this offline but live calibration needs controlled exploration.
5. **Static threshold.** `θτ` is static config; an age-aware reliability may interact badly with a fixed threshold.

### Unresolved assumptions

- The Normal–Normal belief model is adequate for the chosen resources (spec §14.1 flags battery/latency as review targets).
- Per-resource independence (belief engine assumption) — cross-resource correlation not modelled.
- `DEFAULT_MAX_EVIDENCE_AGE_MILLIS=15_000` is an engineering approximation, not spec-derived.
- No cost model exists for deferral (relevant to Direction C).

### Recommendation

**Proceed with Candidate A (age-aware reliability under stale telemetry) as the leading research contribution**, contingent on:

1. Completing a targeted full-text literature review of age-of-information / stale-state scheduling to confirm the PCST-specific claim is not already published (do not claim novelty before this).
2. Running the small synthetic experiment above as a go/no-go gate.
3. If the experiment passes, scope the implementation to a single bounded change: age-dependent variance inflation in the predictive distribution used by `CapabilityEngine`/`ReliabilityEngine`, with unit tests and the calibration experiment. No scheduler-pipeline, schema, or contract change.

If the experiment fails or the literature review shows the idea is already published, fall back to Candidate B (missingness-aware reliability) only after a similar literature + experiment gate. Candidate C is deprioritized pending a cost model, which does not exist in the repository.

**No implementation is authorized by this memo.** The next step, if the owner chooses to proceed, is the literature review plus the synthetic experiment.
