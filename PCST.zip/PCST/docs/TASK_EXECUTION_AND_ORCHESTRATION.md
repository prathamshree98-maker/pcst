# Task Execution and Orchestration

Step 7 of PCST: connects the Master Scheduler and Node Agents so that a task can
be submitted, evaluated, scheduled, dispatched, executed, and reported back to
the Master. This document describes the execution architecture, message flow,
and APIs.

---

## 1. Execution Architecture and Message Flow

```
Client (REST)
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│                        PCST MASTER                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Task API     │  │ Execution    │  │ Scheduler (Step 6D)  │  │
│  │ (Controller) │──▶│ Coordinator  │──▶│ (PCSTScheduler)    │  │
│  └──────────────┘  └──────┬───────┘  └──────────┬───────────┘  │
│                           │                      │              │
│                    ┌──────▼───────┐              │              │
│                    │ TaskRegistry │◀─────────────┘              │
│                    └──────┬───────┘                             │
│                           │                                     │
│                    ┌──────▼───────┐                             │
│                    │ DispatchClient│                             │
│                    └──────┬───────┘                             │
└───────────────────────────┼─────────────────────────────────────┘
                            │ gRPC
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                      NODE AGENT                                  │
│  ┌────────────────┐  ┌──────────────┐  ┌────────────────────┐  │
│  │ gRPC Server    │  │ Workload     │  │ MasterGrpcClient   │  │
│  │ (TaskDispatch  │──▶│ Executor     │──▶│ (Lifecycle)      │  │
│  │  Service)      │  │ (NO_OP,      │  │                    │  │
│  └────────────────┘  │  COMPUTE,    │  └────────────────────┘  │
│                      │  SLEEP)      │                             │
│                      └──────────────┘                             │
└─────────────────────────────────────────────────────────────────┘
```

### Message Sequence

1. **Submit**: Client → `POST /api/v1/tasks` → Master validates, creates `TaskRecord` (ACCEPTED)
2. **Schedule**: Coordinator runs PCST scheduling pipeline (hard constraints → capability → reliability → policy)
3. **Dispatch**: If node selected, `DispatchTask` gRPC → Node Agent
4. **Acknowledge**: Agent → `ReportTaskLifecycle` (ACCEPTED) → Master
5. **Execute**: Agent runs workload on bounded thread pool
6. **Running**: Agent → `ReportTaskLifecycle` (RUNNING) → Master
6. **Complete**: Agent → `ReportTaskLifecycle` (SUCCEEDED/FAILED) with `TaskResult` → Master
7. **Query**: Client → `GET /api/v1/tasks/{taskId}` → Master returns full state + history

---

## 2. Supported Workload Types

| Type | Payload | Description |
|------|---------|-------------|
| `NO_OP` | ignored | Completes immediately with success; useful for testing scheduling |
| `COMPUTE` | integer (iterations) | Performs deterministic computation (sum 1..N); validates iterations ∈ [1, 10⁷] |
| `SLEEP` | integer (milliseconds) | Sleeps for specified duration; validates ms ∈ [1, 300000] |

All workloads execute on a bounded thread pool (4 workers, queue capacity 16). Duplicate
dispatch of the same `attemptId` is rejected to prevent double execution.

---

## 3. Task and Attempt Identity

| Field | Scope | Purpose |
|-------|-------|---------|
| `taskId` | client-provided | Stable logical task identity |
| `attemptId` | Master-generated (UUID) | Unique per execution attempt; enables retry with new attemptId |
| `nodeId` | from scheduling | Target execution node |
| `dispatchId` | not used | Dispatch is 1:1 with attempt |

**Deduplication**: The Node Agent tracks running attempts by `attemptId`. A repeated
dispatch with the same `attemptId` returns "attempt already executing" without
re-executing the workload.

**Retry**: Not automatic. A failed task can be resubmitted by the client with a new
`taskId` or the Master can create a new attempt (future enhancement).

---

## 4. State Transitions

```
ACCEPTED
    │
    ├── NO_FEASIBLE_NODE (no registered nodes)
    ├── UNRESOLVED_SCHEDULING (scheduling could not produce reliability)
    │
    ▼
DISPATCHING
    │
    ├── DISPATCH_ACCEPTED
    │     │
    │     ▼
    │     RUNNING
    │         │
    │         ├── SUCCEEDED
    │         ├── FAILED
    │         └── OUTCOME_UNKNOWN (agent unreachable after dispatch)
    │
    └── DISPATCH_REJECTED (agent rejected dispatch)
          │
          └── ACCEPTED (allow reschedule)
```

**Terminal states**: `NO_FEASIBLE_NODE`, `UNRESOLVED_SCHEDULING`, `DISPATCH_REJECTED`,
`SUCCEEDED`, `FAILED`, `OUTCOME_UNKNOWN`.

---

## 5. Dispatch and Acknowledgement Semantics

- **Dispatch**: Master sends `TaskDispatchRequest` (taskId, attemptId, workloadType,
  payload, deadline) via gRPC unary call.
- **Acknowledgement**: Agent validates request, returns `TaskDispatchResponse`
  (accepted/rejected) immediately.
- **Lifecycle updates**: Agent sends async `ReportTaskLifecycle` calls for ACCEPTED,
  RUNNING, SUCCEEDED/FAILED. Master applies updates atomically to `TaskRecord`.
- **Idempotency**: Lifecycle updates for unknown taskId/attemptId are ignored.
  Duplicate updates for same state are idempotent.

---

## 6. Timeout and Ambiguous-Outcome Behavior

- **Dispatch timeout**: Configurable (`pcst.execution.dispatch-timeout-ms`, default 30s).
  If no ACCEPTED/RUNNING lifecycle update received within timeout, Master marks
  task as `OUTCOME_UNKNOWN`.
- **Agent crash after dispatch**: Master cannot distinguish between "task never
  started" and "task completed but result lost". Outcome is `OUTCOME_UNKNOWN`.
- **No automatic retry**: Ambiguous outcomes require manual intervention or client
  resubmission.

---

## 7. Deduplication Guarantees and Limitations

| Scenario | Behavior |
|----------|----------|
| Duplicate dispatch (same attemptId) | Rejected by agent; no re-execution |
| Duplicate lifecycle update (same state) | Idempotent; ignored |
| Duplicate lifecycle update (different state) | Last write wins (last update applied) |
| Agent restarts mid-execution | In-flight attempt marked `OUTCOME_UNKNOWN` |
| Master restarts | All in-memory task state lost; tasks must be resubmitted |

**Not guaranteed**: Exactly-once execution across process crashes or network partitions.

---

## 8. Queue Limits and Execution Concurrency

- **Workers**: 4 (fixed)
- **Queue capacity**: 16 pending executions
- **Rejection**: When queue full, dispatch returns "execution queue full"
- **Isolation**: One task failure does not affect other tasks or agent stability

---

## 8. Result Size Limits

- **Request payload**: No explicit limit (bounded by gRPC max message size ~4MB)
- **Result output**: No explicit limit; large results should use external storage
- **Error messages**: Truncated to reasonable length in logs

---

## 9. API Endpoints

### Submit Task
```
POST /api/v1/tasks
Content-Type: application/json

{
  "taskId": "task-123",
  "taskClass": "NETWORK_BOUND",
  "workloadReference": "NO_OP",
  "inputCharacteristics": "optional input",
  "expectedDurationMillis": 60000,
  "resources": {
    "requiredMemoryBytes": 1073741824,
    "requiredStorageBytes": 10737418240,
    "acceleratorRequired": false,
    "requiredAcceleratorMemoryBytes": null,
    "requiredComputeUnits": null
  },
  "constraints": {
    "deadlineEpochMillis": 1700000000000,
    "expectedDurationMillis": 60000,
    "minimumBatteryPercent": 20.0,
    "maximumNetworkLatencyMillis": 100.0,
    "maximumPacketLossPercent": 1.0,
    "interruptionTolerance": "PREEMPTIBLE",
    "requiredExecutionProfile": "gpu-profile"
  }
}
```

Response: `202 Accepted` with task state.

### Get Task Status
```
GET /api/v1/tasks/{taskId}
```

Response: Full task state including scheduling decision, result, and history.

### List All Tasks
```
GET /api/v1/tasks
```

### Get Scheduling Decision
```
GET /api/v1/tasks/{taskId}/decision
```

Returns the `SchedulingDecision` with candidate trace.

---

## 10. Protobuf/gRPC Contract (Step 7 Additions)

```protobuf
service NodeService {
  // ... existing RPCs ...
  rpc DispatchTask (TaskDispatchRequest) returns (TaskDispatchResponse);
  rpc ReportTaskLifecycle (TaskLifecycleUpdate) returns (TaskLifecycleAck);
}

message TaskDispatchRequest {
  string task_id = 1;
  string attempt_id = 2;
  string workload_type = 3;
  string payload = 4;
  int64 dispatch_time = 5;
  int64 deadline_epoch_millis = 6;
}

message TaskDispatchResponse {
  bool accepted = 1;
  string message = 2;
  int64 server_time = 3;
}

message TaskLifecycleUpdate {
  string task_id = 1;
  string attempt_id = 2;
  string node_id = 3;
  TaskState state = 4;
  int64 timestamp = 5;
  string message = 6;
  TaskResult result = 7;
}

enum TaskState {
  TASK_STATE_UNSPECIFIED = 0;
  ACCEPTED = 1;
  RUNNING = 2;
  SUCCEEDED = 3;
  FAILED = 4;
  REJECTED = 5;
}

message TaskResult {
  bool success = 1;
  string output = 2;
  string error = 3;
  int64 duration_millis = 4;
}

message TaskLifecycleAck {
  bool accepted = 1;
  string message = 2;
  int64 server_time = 3;
}
```

---

## 11. How to Run End-to-End Local Test

1. Start Master:
   ```bash
   mvn -pl pcst-master spring-boot:run
   ```

2. Start Node Agent (in separate terminal):
   ```bash
   mvn -pl pcst-node-agent exec:java
   ```

3. Submit a task:
   ```bash
   curl -X POST http://localhost:8080/api/v1/tasks \
     -H "Content-Type: application/json" \
     -d '{"taskId":"test-1","taskClass":"NETWORK_BOUND","workloadReference":"NO_OP"}'
   ```

4. Poll for result:
   ```bash
   curl http://localhost:8080/api/v1/tasks/test-1
   ```

---

## 12. In-Memory State and Restart Limitations

- **TaskRegistry**: In-memory only; lost on Master restart
- **DigitalTwinManager**: In-memory only; nodes re-register on Master restart
- **WorkloadExecutor**: In-memory queue; in-flight work lost on agent restart
- **No persistence**: No database; all state rebuilt from node re-registration

---

## 13. Features Intentionally Deferred

- Automatic retry with new attemptId
- Exactly-once execution semantics
- Persistent task storage (database)
- Large result storage (object store integration)
- Dynamic task prioritization / preemption
- Multi-task scheduling (queueing, fairness)
- Task migration / dynamic rescheduling
- Authentication / authorization for task API
- Dashboard / UI for task monitoring