#!/usr/bin/env bash
# PCST Node Agent launcher (Linux / macOS)
# Configures the Master endpoint and enrollment credential via environment
# variables or a local config file (config/pcst-agent.properties). No secret
# is hard-coded here. See AGENT_CONFIGURATION.md for details.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JAR_DIR="$SCRIPT_DIR/pcst-node-agent/target"

if [[ ! -d "$JAR_DIR" ]]; then
    echo "ERROR: Build output directory not found: $JAR_DIR" >&2
    echo "Build the agent first:  mvn -pl pcst-node-agent package" >&2
    exit 1
fi

shopt -s nullglob
jars=("$JAR_DIR"/pcst-node-agent-*.jar)
shopt -u nullglob

if [[ ${#jars[@]} -eq 0 ]]; then
    echo "ERROR: PCST Node Agent runnable jar not found in $JAR_DIR" >&2
    echo "Build with:  mvn -pl pcst-node-agent package" >&2
    exit 1
fi
# Use the most recently built jar.
JAR="$(ls -t "${jars[@]}" | head -n 1)"

# Locate a Java runtime (Java 21 or later required).
if [[ -n "${JAVA_HOME:-}" ]]; then
    JAVA="$JAVA_HOME/bin/java"
else
    JAVA="java"
fi

if ! "$JAVA" -version >/dev/null 2>&1; then
    echo "ERROR: Java runtime not found. Install Java 21 or later and set JAVA_HOME." >&2
    exit 1
fi

echo "=========================================="
echo "PCST Node Agent launcher (Linux/macOS)"
echo "Using jar   : $JAR"
echo "Master host : ${PCST_MASTER_HOST:-}"
echo "Master port : ${PCST_MASTER_PORT:-}"
echo "Node id     : ${PCST_NODE_ID:-}"
echo "=========================================="
echo

# Pass any command-line arguments (e.g. --version) through to the agent.
exec "$JAVA" -jar "$JAR" "$@"
