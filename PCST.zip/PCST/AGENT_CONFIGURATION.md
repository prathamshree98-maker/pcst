# PCST Node Agent — configuration, build, and launch

## Java runtime requirements

- Java 21 or later (the project compiles with `source/target = 21`).
- A recent Maven 3.x is required to build (`mvn -v`).

No other runtime dependencies are needed: the agent is a self-contained,
executable (shaded) JAR that bundles gRPC, Logback, OSHI, and protobuf.

## Build

From the repository root:

    mvn -q -pl pcst-node-agent package

This produces the runnable artifact:

    pcst-node-agent/target/pcst-node-agent-1.0.0-SNAPSHOT.jar

The shaded JAR bundles all dependencies and carries `Main-Class` plus
`Implementation-Version` in its manifest.

## Configuration (no hard-coded secrets)

The Master endpoint and enrollment credential are resolved with this precedence
(lowest to highest):

1. built-in defaults
2. a local configuration file
3. environment variables
4. Java system properties (`-Dkey=value`)

Configuration file locations (first existing file wins):

- `PCST_AGENT_CONFIG` environment variable (absolute path to a `.properties` file)
- `config/pcst-agent.properties` in the current working directory
- `~/.pcst/agent.properties`

A template is provided at `config/pcst-agent.properties.example`. Copy it to
`config/pcst-agent.properties` (excluded from Git) and edit.

Relevant keys:

| Property | Environment variable | Default |
|---|---|---|
| pcst.master.host | PCST_MASTER_HOST | localhost |
| pcst.master.port | PCST_MASTER_PORT | 9090 |
| pcst.node.id | PCST_NODE_ID | local hostname |
| pcst.node.port | PCST_NODE_PORT | 9091 |
| pcst.agent.version | PCST_AGENT_VERSION | 1.0.0 |
| pcst.heartbeat.interval-ms | PCST_HEARTBEAT_INTERVAL_MS | 5000 |
| pcst.telemetry.interval-ms | PCST_TELEMETRY_INTERVAL_MS | 5000 |
| pcst.recovery.backoff-ms | PCST_RECOVERY_BACKOFF_MS | 2000 |
| pcst.node.token | PCST_NODE_TOKEN | (none) |

The `pcst.node.token` value is read from config/env but never logged. The
current Master accepts registration unconditionally, so credential validation
and device pairing are deferred to a future step.

## Launch

### Windows

    pcst-agent.bat

### Linux / macOS

    chmod +x pcst-agent.sh
    ./pcst-agent.sh

### Examples

Point the agent at a remote Master and identify the node:

    set PCST_MASTER_HOST=192.168.1.50
    set PCST_MASTER_PORT=9090
    set PCST_NODE_ID=friend-laptop-01
    pcst-agent.bat

    export PCST_MASTER_HOST=192.168.1.50
    export PCST_MASTER_PORT=9090
    export PCST_NODE_ID=friend-laptop-01
    ./pcst-agent.sh

Print the agent version:

    pcst-agent.bat --version
    ./pcst-agent.sh --version

## Logs

The agent logs startup configuration, Master connection attempts, registration
outcomes, heartbeats, telemetry deliveries, and task dispatches via SLF4J/
Logback. Successful connection is reported only after the Master accepts
registration (`Registration accepted by Master` → `PCST Node Agent ONLINE`).
Registration failures and connection losses are logged with backoff and retried
indefinitely in the background.

## Version

    pcst-agent.bat --version
    ./pcst-agent.sh --version

## Security notes (Deliverable A scope)

- No secret is hard-coded in code, launchers, or this document.
- The local configuration file is excluded from Git.
- gRPC currently uses plaintext (usePlaintext). Secure gRPC transport (TLS)
  and credential validation/pairing are deferred to a future step.
- Do not run arbitrary scripts or uploaded JARs; this agent only executes the
  built-in workload types (NO_OP, COMPUTE, SLEEP).

---
# PCST Master — JDBC Persistence (Neon PostgreSQL)

## Overview

The Master can persist task records to a Neon PostgreSQL database via Flyway-managed
schema and Spring Boot JDBC. Two `TaskRegistry` implementations exist:

- `InMemoryTaskRegistry` — concurrent map, state lost on restart (default)
- `JdbcTaskRegistry` — PostgreSQL-backed via `JdbcTaskRepository`, used when
  `pcst.persistence.jdbc.enabled=true` (annotated `@Primary`)

Only one implementation is active at a time. There is no silent fallback to
in-memory storage when JDBC is enabled but the database is unavailable —
startup fails closed.

## Enabling JDBC persistence

Set `pcst.persistence.jdbc.enabled=true` and supply a Neon connection string:

```bash
# Linux/macOS
export DATABASE_URL="postgresql://user:pass@host.neon.tech/neondb?channel_binding=require&sslmode=required"
export DATABASE_USERNAME=user   # optional when URL embeds credentials
export DATABASE_PASSWORD=pass   # optional when URL embeds credentials
mvn -pl pcst-master spring-boot:run -Dpcst.persistence.jdbc.enabled=true

# Windows PowerShell
$env:DATABASE_URL="postgresql://user:pass@host.neon.tech/neondb?channel_binding=require&sslmode=required"
mvn -pl pcst-master spring-boot:run -Dpcst.persistence.jdbc.enabled=true
```

The `DATABASE_URL` may be a Neon libpq URL (`postgresql://...`). At startup it is
normalized to a JDBC URL (`jdbc:postgresql://...`) and `channel_binding` is
translated to the pgjdbc-supported `channelBinding` property, preserving TLS and
channel-binding security. Credentials embedded in the URL userinfo are stripped
from the JDBC URL and supplied separately; they are never logged.

When `pcst.persistence.jdbc.enabled` is false or absent (default), no datasource
or Flyway initializer is activated, and the in-memory registry is used.

## Flyway migrations

Schema migration `V1__create_task_records.sql` lives at
`pcst-master/src/main/resources/db/migration/`. Flyway runs automatically on
startup when JDBC persistence is enabled. Migration history is tracked in
`flyway_schema_history`.

To apply migrations manually against a Neon development branch:

```bash
# Create a dev branch from production (one-time)
neon branches create --name pcst-dev --project-id <project-id> --parent production

# Get the connection string (do not print or log it)
neon connection-string pcst-dev --project-id <project-id> --ssl require > .env.local.dev

# Run the application with JDBC enabled against the dev branch
mvn -pl pcst-master spring-boot:run -Dpcst.persistence.jdbc.enabled=true
```

Never run migrations or write tests against the production branch.

## Environment variables

| Variable | Required when enabled | Description |
|---|---|---|
| `DATABASE_URL` | Yes | Neon connection string (libpq or JDBC format) |
| `DATABASE_USERNAME` | No | Overrides URL-embedded username |
| `DATABASE_PASSWORD` | No | Overrides URL-embedded password |
| `pcst.persistence.jdbc.enabled` | Yes | Set to `true` to enable JDBC persistence |

## Security

- Keep `.env.local.dev` and any file containing `DATABASE_URL` out of Git.
  Both are listed in `.gitignore`.
- Never print connection strings, passwords, or tokens to logs or test output.
- Confirm the target branch is a development branch (not production) before
  running migrations or write tests: `neon branches list --project-id <id>`

## Running tests

```bash
# Non-Docker unit and configuration tests (always safe to run)
mvn -pl pcst-master test -Dtest='!JdbcTaskRepositoryTest,!JdbcTaskRegistryTest'

# Testcontainers tests (require Docker; blocked without Docker daemon)
mvn -pl pcst-master test -Dtest=JdbcTaskRepositoryTest,JdbcTaskRegistryTest

# Neon read-only connectivity test (requires DATABASE_URL env var)
mvn -pl pcst-master test -Dtest=NeonReadOnlyConnectivityTest
```

## Returning to in-memory mode

Remove or unset `pcst.persistence.jdbc.enabled=true` (default is `false`).
The Master will restart with `InMemoryTaskRegistry`; state is lost on restart.

