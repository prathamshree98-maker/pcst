cd 'C:\Users\Pratham\Desktop\PCST'
$log = 'master.log'
$p = Start-Process -FilePath 'mvn.cmd' -ArgumentList 'spring-boot:run', '-pl', 'pcst-master', '-Dspring-boot.run.arguments=--grpc.server.port=9090' -WorkingDirectory 'C:\Users\Pratham\Desktop\PCST' -RedirectStandardOutput $log -RedirectStandardError $log -PassThru
Start-Sleep -Seconds 20
Write-Host "8080 status: " (Test-NetConnection -ComputerName localhost -Port 8080).TcpTestSucceeded
Write-Host "9090 status: " (Test-NetConnection -ComputerName localhost -Port 9090).TcpTestSucceeded
Write-Host "---Master log tail---"
Get-Content $log -Tail 15