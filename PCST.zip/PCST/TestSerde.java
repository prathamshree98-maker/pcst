import com.fasterxml.jackson.databind.ObjectMapper;
import com.omni.pcst.master.digitaltwin.TelemetryObservation;
public class TestSerde {
    public static void main(String[] args) throws Exception {
        TelemetryObservation o = new TelemetryObservation(100L, 10.0, 1024L, 512L, null, null, null, null, null, null, null, null, null, null, null, null);
        System.out.println(new ObjectMapper().writeValueAsString(o));
        System.out.println("SERIALIZED_OK");
    }
}
